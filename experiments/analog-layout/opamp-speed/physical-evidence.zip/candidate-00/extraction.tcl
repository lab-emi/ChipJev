tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load layout
select top cell
extract unique
extract do resistance
extresist threshold 0
extresist mindelay 0
extresist minresist 100
extract all
ext2spice lvs
ext2spice scale off
ext2spice cthresh 0
ext2spice extresist on
ext2spice -o pex.spice

} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
