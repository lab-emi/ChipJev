tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load ring_domain_p
box values 7117 6001 7117 6001
set p [dict merge $sky130::ruleset {plus_diff_type nsd plus_contact_type nsc sub_type nwell full_metal 1 viagb 100 viagt 100}]
sky130::guard_ring 71.17 60.01 $p
save ring_domain_p
} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
