tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load ring_domain_n
box values 2277 2666 2277 2666
set p [dict merge $sky130::ruleset {plus_diff_type psd plus_contact_type psc sub_type psub full_metal 1 viagb 100 viagt 100}]
sky130::guard_ring 22.77 26.66 $p
save ring_domain_n
} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
