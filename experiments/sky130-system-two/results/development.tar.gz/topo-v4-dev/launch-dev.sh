#!/usr/bin/env bash
cd /home/cgao/git/ChipJev-Dev
PYTHONPATH=src taskset -c 0-7 nohup .venv/bin/python scripts/topo-v4-run.py --dev > runs/topo-v4-dev/sky130-dev.log 2>&1 &
