#!/usr/bin/env bash
cd /home/cgao/git/ChipJev-Dev
eval "$(grep -E '^export OPENROUTER_API_KEY=' ~/.bashrc | tail -1)"
PYTHONPATH=src taskset -c 8-15 nohup .venv/bin/python scripts/topo-v4-run.py --dev --stage system2 > runs/topo-v4-dev/system2-dev.log 2>&1 &
