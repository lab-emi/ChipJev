from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with GBW Optimization')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['vbias']}V")
    # Input Signal (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias
    # Transistors (only widths are parameterized)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Vout', 'Vin', f"{params['c_comp']}pF")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range (1-500× L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range (1-500× L)
    # Bias voltage (0.8-1.2× original value, but not exceeding supply voltage)
    'vbias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V, range: 0.8-1.2× (Vdd=1.2V)
    # Compensation capacitor (0.5-5× original value)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True}  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,      # Original NMOS width (5μm)
    'w_M2': 10e-6,     # Original PMOS width (10μm)
    'vbias': 0.78,     # Original bias voltage (0.78V)
    'c_comp': 1.0,     # Original compensation capacitance (1pF)
}
