Here's the parameterized version of your single-stage GBW-optimized amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage GBW-Optimized Amplifier')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (voltage sources remain fixed at original values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltage (PMOS bias)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  
    
    # Main Amplifying Transistor (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed minimum length (45nm)
    
    # Active Load (PMOS) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed minimum length (45nm)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (widths)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width: 1-500× length
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width: 1-500× length
    
    # Bias voltage (conservative range around original value)
    'v_bias': {'min': 0.62, 'max': 0.94},  # Original 0.78V ±20% (but constrained to Vth)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,     # Original NMOS width (5um)
    'w_pmos': 10e-6,    # Original PMOS width (10um)
    'v_bias': 0.78,     # Original bias voltage (Vdd - |Vth| - 0.2V)
}

# Brief parameter descriptions:
# - w_nmos: Width of main amplifying NMOS transistor (affects transconductance & gain)
# - w_pmos: Width of active load PMOS transistor (affects load impedance & gain)
# - v_bias: Bias voltage for PMOS load (sets operating point, affects output swing)
```

Key features of this implementation:
1. Strictly follows all your requirements including:
   - Fixed supply voltage (1.2V) and input bias (0.42V)
   - Parameterized transistor widths with appropriate ranges (1-500×L)
   - Conservative bias voltage range (0.62-0.94V) that maintains proper operation
   - Preserved all original values in initial_params
   - Kept length fixed at 45nm as required
   - No load capacitors to parameterize (none present in original circuit)

2. The bias voltage range is carefully constrained:
   - Lower bound (0.62V) keeps PMOS in saturation (Vdd - Vbias > |Vth|)
   - Upper bound (0.94V) maintains sufficient overdrive (Vbias doesn't go too high)

3. All initial values are within their respective search ranges.

4. Width parameters use logarithmic scaling (log=True) as this is typically more appropriate for transistor sizing optimization.

This parameterized circuit is ready for optimization with tools like Optuna while maintaining all the original circuit's functionality and operating points.