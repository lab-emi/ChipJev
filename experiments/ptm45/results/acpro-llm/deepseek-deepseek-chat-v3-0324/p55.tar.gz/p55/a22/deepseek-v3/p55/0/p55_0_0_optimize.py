from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias (will be swept during analysis)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # Cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS current source bias
    # Input Transistor (M1)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=0.045e-6)  # Fixed 45nm channel length
    # Cascode Transistor (M2)
    circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1', 
                   model='nmos_model', 
                   w=params['w_M2'], 
                   l=0.045e-6)  # Fixed 45nm channel length
    # Current Source Load (M3)
    circuit.MOSFET('3', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M3'], 
                   l=0.045e-6)  # Fixed 45nm channel length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (kept within reasonable ranges around original values)
    'vbias1': {'min': 0.34, 'max': 0.50},  # Original 0.42V (0.8-1.2×, constrained by Vth)
    'vbias2': {'min': 0.62, 'max': 0.94},  # Original 0.78V (0.8-1.2×, must be <1.2V)
    # Transistor widths (1-500× length, 45nm-22.5µm range)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5µm
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5µm
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 10µm
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,     # Original Vbias1 value (0.42V)
    'vbias2': 0.78,     # Original Vbias2 value (0.78V)
    'w_M1': 5e-6,       # Original M1 width (5µm)
    'w_M2': 5e-6,       # Original M2 width (5µm)
    'w_M3': 10e-6,      # Original M3 width (10µm)
}
