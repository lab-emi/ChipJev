Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Max GBW')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies and Biasing (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET(
        '1',  # Name
        'Vout',  # Drain
        'Vin',  # Gate
        circuit.gnd,  # Source
        circuit.gnd,  # Bulk
        model='nmos_model',
        w=params['w_M1'],  # Parameterized width
        l=0.045e-6  # Fixed length for 45nm
    )
    
    # Active Load (PMOS Current Source)
    circuit.MOSFET(
        '2',  # Name
        'Vout',  # Drain
        'Vbias',  # Gate
        'Vdd',  # Source
        'Vdd',  # Bulk
        model='pmos_model',
        w=params['w_M2'],  # Parameterized width
        l=0.045e-6  # Fixed length for 45nm
    )
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range: 1-500×45nm
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range: 1-500×45nm
    
    # Bias voltage (constrained around original value, staying below Vdd=1.2V)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2×0.78V (original value), safely below Vdd
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original NMOS width
    'w_M2': 20e-6,    # Original PMOS width
    'vbias': 0.78,    # Original bias voltage
}
```

### Description of Parameters:

1. **Transistor Widths**:
   - `w_M1`: Width of the NMOS amplifying transistor (original: 10µm)
   - `w_M2`: Width of the PMOS active load (original: 20µm)
   - Both have ranges from 45nm (1×L) to 22.5µm (500×L) to maintain reasonable W/L ratios
   - Logarithmic sampling helps explore both small and large devices efficiently

2. **Bias Voltage**:
   - `vbias`: Gate bias voltage for PMOS current source (original: 0.78V)
   - Constrained to ±20% of original value (0.624V-0.936V) to maintain proper operation
   - Never exceeds Vdd (1.2V) even at the upper range limit

### Important Notes:
- All MOSFET lengths are fixed at 45nm as requested
- Power supply (Vdd=1.2V) and input bias (Vin=0.42V) remain fixed
- The bias voltage (Vbias) is parameterized but constrained to stay within ±20% of its original value while always remaining below Vdd
- All initial parameter values exactly match the original circuit specifications
- The parameter ranges are designed to maintain reasonable device operation while allowing optimization to find better performance points
- No load capacitors were present in the original circuit, so none were parameterized