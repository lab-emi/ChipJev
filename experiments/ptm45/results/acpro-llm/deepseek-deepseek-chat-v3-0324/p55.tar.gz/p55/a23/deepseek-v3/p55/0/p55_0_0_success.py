from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with Max GBW')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Biasing
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Bias Vin at Vth + 0.2V = 0.42V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)  # Bias Vbias at Vdd - |Vth| - 0.2V = 0.78V
# Main Amplifying Transistor (NMOS)
circuit.MOSFET(
    '1',  # Name
    'Vout',  # Drain (connected to output)
    'Vin',  # Gate (input node)
    circuit.gnd,  # Source (ground)
    circuit.gnd,  # Bulk (tied to source)
    model='nmos_model',
    w=10e-6,  # Width (maximize transconductance)
    l=0.045e-6  # Length (min for 45nm)
)
# Active Load (PMOS Current Source)
circuit.MOSFET(
    '2',  # Name
    'Vout',  # Drain (connected to output)
    'Vbias',  # Gate (biased for saturation)
    'Vdd',  # Source (Vdd)
    'Vdd',  # Bulk (tied to source)
    model='pmos_model',
    w=20e-6,  # Wider to reduce output resistance
    l=0.045e-6  # Length (min for 45nm)
)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
