from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with High GBW')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # NMOS bias: Vth + 200mV
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS bias: Vdd - |Vth| - 200mV
# Main Amplifier Stage --------------------------------------------------------
# Input NMOS transistor (M1)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS active load (M2)
circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# Miller Compensation Network ------------------------------------------------
# Creates proper series RC between Vout and Vin:
# Vout --Rc-- comp_node --Cc-- Vin
circuit.R('c', 'Vout', 'comp_node', 1@u_kΩ)  # Nulling resistor (1kΩ)
circuit.C('c', 'comp_node', 'Vin', 1@u_pF)  # Compensation capacitor (1pF)
# Analysis Part --------------------------------------------------------------
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
