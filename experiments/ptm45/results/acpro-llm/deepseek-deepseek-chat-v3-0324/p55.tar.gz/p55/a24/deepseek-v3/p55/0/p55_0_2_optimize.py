from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with High GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['vbias_p']@u_V)  # Parameterized PMOS bias
    # Main Amplifier Stage ----------------------------------------------------
    # Input NMOS transistor (M1)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1']@u_m,  # Parameterized width
                  l=0.045e-6@u_m)       # Fixed length (45nm)
    # PMOS active load (M2)
    circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                  model='pmos_model', 
                  w=params['w_m2']@u_m,  # Parameterized width
                  l=0.045e-6@u_m)       # Fixed length (45nm)
    # Miller Compensation Network ---------------------------------------------
    circuit.R('c', 'Vout', 'comp_node', params['r_comp']@u_kΩ)  # Parameterized nulling resistor
    circuit.C('c', 'comp_node', 'Vin', params['c_comp']@u_pF)   # Parameterized compensation cap
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× minimum length of 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (45nm-22.5um)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (45nm-22.5um)
    # Bias voltage (conservative range around original value)
    'vbias_p': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V (but <1.2V)
    # Passive components
    'r_comp': {'min': 0.5, 'max': 2.0},      # 0.5-2× original 1kΩ (500Ω-2kΩ)
    'c_comp': {'min': 0.5, 'max': 5.0},      # 0.5-5× original 1pF (0.5pF-5pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,       # Original NMOS width (5um)
    'w_m2': 10e-6,      # Original PMOS width (10um)
    'vbias_p': 0.78,    # Original PMOS bias voltage (0.78V)
    'r_comp': 1.0,      # Original compensation resistor (1kΩ)
    'c_comp': 1.0,      # Original compensation capacitor (1pF)
}
