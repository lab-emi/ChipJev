from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
    # Input and Bias Voltages (input fixed, others parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # M1 bias (fixed)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # NMOS cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # PMOS cascode bias
    # Transistors (widths parameterized, L fixed at 45nm)
    # M1: Input NMOS (common-source)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'],
                   l=0.045e-6)
    # M3: NMOS Cascode
    circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M3'],
                   l=0.045e-6)
    # M2: PMOS Active Load (cascode)
    circuit.MOSFET('2', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'],
                   l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M3
    # Bias voltages (in volts)
    'vbias1': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original (0.42V), below Vdd
    'vbias2': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), below Vdd
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 5e-6,
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
}
# Parameter descriptions (for reference)
parameter_descriptions = {
    'w_M1': 'Width of input NMOS transistor M1 (common-source stage)',
    'w_M2': 'Width of PMOS active load M2 (cascode)',
    'w_M3': 'Width of NMOS cascode transistor M3',
    'vbias1': 'Bias voltage for NMOS cascode stage (Vbias1)',
    'vbias2': 'Bias voltage for PMOS cascode stage (Vbias2)',
}
