Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with GBW Optimization')
    
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltage (0.8-1.2× original, but <=1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Main Amplifier Stage - NMOS
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Main Amplifier Stage - PMOS
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Parameterized compensation capacitor (0.5-5× original)
    circuit.C('1', 'Vout', 'Vin', params['c_comp']@u_pF)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5µm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS M1 width
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS M2 width
    
    # Bias voltage (0.8-1.2× original, but <=1.2V)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original 0.78V × [0.8,1.2]
    
    # Compensation capacitor (0.5-5× original 1pF)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,        # Original NMOS width
    'w_m2': 10e-6,       # Original PMOS width
    'v_bias': 0.78,      # Original bias voltage (Vdd - |Vth| - 0.2V)
    'c_comp': 1.0,       # Original compensation capacitance
}
```

### Parameter Descriptions:

1. **Transistor Widths**: 
   - `w_m1`: Width of NMOS transistor M1 (original: 5µm)
   - `w_m2`: Width of PMOS transistor M2 (original: 10µm)
   - Range: 45nm to 22.5µm (1-500× the 45nm length)

2. **Bias Voltage**:
   - `v_bias`: Gate bias voltage for PMOS M2 (original: 0.78V)
   - Range: 0.624V to 0.936V (0.8-1.2× original, respecting Vdd=1.2V constraint)
   - Conservative range maintains intended operating region (Vdd - |Vth| - 0.2V)

3. **Compensation Capacitor**:
   - `c_comp`: Miller compensation capacitor (original: 1pF)
   - Range: 0.5pF to 5pF (0.5-5× original for pole-splitting optimization)

### Key Features:
- Fixed parameters: Vdd (1.2V), Vin (0.42V), transistor lengths (45nm)
- All initial values match exactly the original circuit
- Parameter ranges respect all constraints:
  - Widths within 1-500× length
  - Bias voltage within 0.8-1.2× original but ≤1.2V
  - Compensation cap within 0.5-5× original
- Logarithmic scaling for transistor widths and capacitors (common in analog optimization)
- Linear scaling for bias voltage to maintain precise bias point control