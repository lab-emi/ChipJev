from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with GBW Optimization')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    # Parameterized bias voltage (0.8-1.2× original, but <=1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    # Main Amplifier Stage - NMOS
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Main Amplifier Stage - PMOS
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Parameterized compensation capacitor (0.5-5× original)
    circuit.C('1', 'Vout', 'Vin', params['c_comp']@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5µm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS M1 width
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS M2 width
    # Bias voltage (0.8-1.2× original, but <=1.2V)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original 0.78V × [0.8,1.2]
    # Compensation capacitor (0.5-5× original 1pF)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,        # Original NMOS width
    'w_m2': 10e-6,       # Original PMOS width
    'v_bias': 0.78,      # Original bias voltage (Vdd - |Vth| - 0.2V)
    'c_comp': 1.0,       # Original compensation capacitance
}
