from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Maximized GBW')
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized - 1.2V for 45nm technology)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Bias Voltage (fixed, not parameterized - sets DC operating point)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # PMOS Bias Voltage (parameterized within ±20% of original value)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    # NMOS Transistor (M1) - parameterized width, fixed length
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model',
                  w=params['w_M1'],
                  l=0.045e-6)  # Fixed at 45nm technology node
    # PMOS Transistor (M2, active load) - parameterized width, fixed length
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M2'],
                  l=0.045e-6)  # Fixed at 45nm technology node
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (width only, length fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm to 22.5µm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm to 22.5µm)
    # Bias voltage (constrained to keep PMOS in saturation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), but clamped to 1.2V max
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,        # Original NMOS width (10µm)
    'w_M2': 20e-6,        # Original PMOS width (20µm)
    'v_bias': 0.78,       # Original bias voltage (0.78V)
}
'''
Parameter Descriptions:
- w_M1: Width of NMOS transistor (M1) - affects transconductance and current
- w_M2: Width of PMOS transistor (M2, active load) - affects output impedance and gain
- v_bias: PMOS gate bias voltage - controls load current and output DC level
Constraints Explained:
- Transistor widths range from minimum (45nm) to 500× length (22.5µm)
- Bias voltage ranges ±20% from original but stays below supply (1.2V)
- Length fixed at 45nm for both transistors (process technology)
- Input voltages (Vin) remain fixed for proper biasing
- No load capacitors present in this circuit
'''
