from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Amplifier with Maximized GBW')
# --- Model Definitions (Added to Fix the Error) ---
# Define NMOS and PMOS models directly in the netlist (45nm technology parameters).
# These replace the placeholder 'from model import nmos_params, pmos_params'.
circuit.model('nmos_model', 'nmos', 
              kp=200e-6, vto=0.22, lambda=0.1, cgso=1e-12, cgdo=1e-12)  # Example 45nm NMOS
circuit.model('pmos_model', 'pmos', 
              kp=80e-6, vto=-0.22, lambda=0.1, cgso=1e-12, cgdo=1e-12)  # Example 45nm PMOS
# --- Power Supplies (Unchanged) ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # DC bias for NMOS (Vth + 0.2V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Bias for PMOS load (Vdd - |Vth| - 0.2V)
# --- Transistors (Corrected Bulk Connections) ---
# NMOS M1: Common-source stage
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS M2: Active load
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
# --- Analysis ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
