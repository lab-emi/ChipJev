Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.78V
M1 Vout Vin 0 0 nmos_model l=4.5e-08 w=1e-05
M2 Vout Vbias Vdd Vdd pmos_model l=4.5e-08 w=5e-06
.model nmos_model nmos (kp=0.0001 level=1 vto=0.22)
.model pmos_model pmos (kp=5e-05 level=1 vto=-0.22)

