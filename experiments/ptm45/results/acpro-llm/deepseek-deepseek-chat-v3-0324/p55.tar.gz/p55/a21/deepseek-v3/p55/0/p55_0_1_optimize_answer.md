Here's the parameterized version of your single-stage CS amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage CS Amplifier with Active Load')

    # Define MOSFET models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)         # Fixed Vdd = 1.2V
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)        # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)  # Parameterized bias voltage
    
    # Transistors (parameterized widths)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # NMOS, fixed length
    
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # PMOS, fixed length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keep L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS: 1-500×L (0.045-22.5μm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS: 1-500×L (0.045-22.5μm)
    
    # Bias voltage (conservative range around original value)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), max 1.2V-Vth
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original NMOS width
    'w_M2': 5e-6,     # Original PMOS width
    'vbias': 0.78,    # Original bias voltage (Vdd - |Vth| - 0.2V)
}

"""
Parameter descriptions:
- w_M1: NMOS transistor width (M1) - main amplifying device
- w_M2: PMOS transistor width (M2) - active load device
- vbias: PMOS gate bias voltage - sets operating point of active load

Design considerations:
- Width ranges allow 1-500× minimum length (conservative for 45nm)
- vbias range keeps PMOS in saturation (must be between Vdd-|Vth| and Vth)
- Original bias voltage (0.78V) is Vdd - |Vth| - 0.2V (overdrive of 0.2V)
- Range limited to ±20% around original bias to maintain intended operation
- All voltages constrained below 1.2V supply
"""
```

Key points about this implementation:

1. **Circuit Elements**:
   - Fixed the power supply (1.2V) and input voltage (0.42V)
   - Parameterized the bias voltage (Vbias), NMOS width (w_M1), and PMOS width (w_M2)
   - Kept all transistor lengths fixed at 45nm (0.045μm)

2. **Parameter Ranges**:
   - Transistor widths: 1-500× minimum length (45nm-22.5μm)
   - Bias voltage: ±20% of original value (0.624-0.936V), ensuring PMOS stays in saturation

3. **Design Constraints**:
   - All parameter ranges include the original values
   - Bias voltage range is conservative to maintain proper operation
   - No elements exceed the 1.2V supply limit
   - Kept the fixed import statement for MOSFET parameters

4. **Initial Parameters**:
   - Exactly match the original circuit values (10μm NMOS, 5μm PMOS, 0.78V bias)
   - All initial values are within their respective search ranges

The design maintains all your specified constraints while providing reasonable optimization ranges for the key circuit parameters.