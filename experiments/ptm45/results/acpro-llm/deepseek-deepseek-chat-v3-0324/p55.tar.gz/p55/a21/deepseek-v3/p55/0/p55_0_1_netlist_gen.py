from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Create the circuit
circuit = Circuit('Single-Stage CS Amplifier with Active Load')
# Define MOSFET models directly (since 'model' import is missing)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # NMOS: kp=100uA/V², Vth=0.22V
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # PMOS: kp=50uA/V², Vth=-0.22V
# Power Supplies (unchanged)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)         # Vdd = 1.2V
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)        # Biasing Vin = Vth + 0.2V = 0.42V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)    # Biasing Vbias = Vdd - |Vth| - 0.2V = 0.78V
# Transistors (corrected bulk connections and sizing)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # M1: NMOS
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)             # M2: PMOS
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
