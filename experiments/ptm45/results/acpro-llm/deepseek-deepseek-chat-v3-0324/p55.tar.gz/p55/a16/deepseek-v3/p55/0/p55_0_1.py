from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias for M1 (Vth + 0.2V = 0.42V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Bias for M2 (Vdd - |Vth| - 0.2V = 0.78V)
circuit.V('casn', 'Vcasn', circuit.gnd, 0.42@u_V)  # Bias for M3 (same as Vin)
circuit.V('casp', 'Vcasp', circuit.gnd, 0.78@u_V)  # Bias for M4 (same as Vbias)
# Main Amplifier Transistors
# M1: NMOS common-source
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M2: PMOS current source load
circuit.MOSFET('2', 'Drain2', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M3: NMOS cascode
circuit.MOSFET('3', 'Vout', 'Vcasn', 'Drain1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M4: PMOS cascode
circuit.MOSFET('4', 'Vout', 'Vcasp', 'Drain2', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Network - Corrected implementation:
# 1. First create an intermediate node for the RC series connection
circuit.X('comp_node', 'Drain1')  # This connects to M1's drain
# 2. Place the resistor between Vout and comp_node
circuit.R('comp', 'Vout', 'comp_node', 1@u_kΩ)  # Nulling resistor
# 3. Place the capacitor between comp_node and Drain1
circuit.C('comp', 'comp_node', 'Drain1', 1@u_pF)  # Compensation capacitor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
