from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input and Bias Voltages (input fixed, biases parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    circuit.V('casn', 'Vcasn', circuit.gnd, params['vcasn']@u_V)
    circuit.V('casp', 'Vcasp', circuit.gnd, params['vcasp']@u_V)
    # Main Amplifier Transistors (W parameterized, L fixed)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Vout', 'Vcasn', 'Drain1', circuit.gnd, 
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vcasp', 'Drain2', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Compensation Network (parameterized)
    circuit.R('comp_r', 'Vout', 'Drain1', f"{params['r_comp']}k")
    circuit.C('comp_c', 'Vout', 'Drain1', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1: Input transistor (NMOS)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2: PMOS current source
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3: NMOS cascode
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4: PMOS cascode
    # Bias voltages (0.8-1.2× original, but ≤1.2V)
    'vbias': {'min': 0.624, 'max': 0.936},   # Vbias: PMOS current source bias (original: 0.78V)
    'vcasn': {'min': 0.336, 'max': 0.504},   # Vcasn: NMOS cascode bias (original: 0.42V)
    'vcasp': {'min': 0.624, 'max': 0.936},   # Vcasp: PMOS cascode bias (original: 0.78V)
    # Compensation components
    'r_comp': {'min': 0.5, 'max': 2.0, 'log': True},  # Compensation resistor (original: 1kΩ)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # Compensation capacitor (original: 1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 10e-6,
    'w_m4': 10e-6,
    # Bias voltages
    'vbias': 0.78,
    'vcasn': 0.42,
    'vcasp': 0.78,
    # Compensation components
    'r_comp': 1.0,
    'c_comp': 1.0,
}
