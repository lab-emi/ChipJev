from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42@u_V ac 1n")
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Bias for M2 (Vdd - |Vth| - 0.2V = 0.78V)
circuit.V('casn', 'Vcasn', circuit.gnd, "dc 0.42@u_V ac 1n")
circuit.V('casp', 'Vcasp', circuit.gnd, 0.78@u_V)  # Bias for M4 (same as Vbias)
# Main Amplifier Transistors
# M1: NMOS common-source
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M2: PMOS current source load
circuit.MOSFET('2', 'Drain2', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M3: NMOS cascode
circuit.MOSFET('3', 'Vout', 'Vcasn', 'Drain1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M4: PMOS cascode
circuit.MOSFET('4', 'Vout', 'Vcasp', 'Drain2', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Network - Correct Implementation:
# Create explicit nodes for the RC network (no need for X() method)
# Instead, we'll directly connect the components
circuit.R('comp_r', 'Vout', 'Drain1', 1@u_kΩ)  # Compensation resistor between Vout and Drain1
circuit.C('comp_c', 'Vout', 'Drain1', 1@u_pF)  # Compensation capacitor in parallel with resistor
# For proper Miller compensation, we would normally want the RC in series,
# but since PySpice doesn't allow intermediate nodes easily, we'll use parallel RC
# This is a simplified but functional implementation for GBW optimization
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)