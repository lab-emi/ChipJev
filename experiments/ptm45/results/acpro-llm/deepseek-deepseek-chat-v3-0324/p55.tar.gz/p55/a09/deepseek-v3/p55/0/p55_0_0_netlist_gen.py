from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with Maximized GBW')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias voltage for M1 (Vth + 0.2V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Bias voltage for M2 (Vdd - |Vth| - 0.2V)
# Main Amplifier Stage: Common-Source with Active Load
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=20@u_um, l=0.045@u_um)
# Optional Compensation Capacitor (for stability)
circuit.C('1', 'Vout', 'Vbias', 1@u_pF)  # Compensation capacitor
circuit.R('1', 'Vout', 'Vbias', 1@u_kΩ)  # Optional resistor for stability
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
