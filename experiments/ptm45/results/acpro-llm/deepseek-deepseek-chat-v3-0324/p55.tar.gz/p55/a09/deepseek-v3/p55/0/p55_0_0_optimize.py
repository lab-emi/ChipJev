from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Maximized GBW')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (fixed)
    # Parameterized bias voltage (maintains Vdd - |Vth| - 0.2V relationship)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # Main Amplifier Stage (parameterized widths)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1']@u_um, 
                  l=0.045@u_um)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2']@u_um, 
                  l=0.045@u_um)
    # Compensation Network (parameterized)
    circuit.C('1', 'Vout', 'Vbias', params['c_comp']@u_pF)
    circuit.R('1', 'Vout', 'Vbias', params['r_comp']@u_kΩ)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (in um, L fixed at 45nm)
    # Range: 1-500× length (0.045um to 22.5um)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS width (affects gm and gain)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS width (active load)
    # Bias voltage (conservative range around original 0.78V to maintain operation)
    # Original was Vdd - |Vth| - 0.2V = 0.78V, range ±0.1V but never exceeding Vdd
    'vbias': {'min': 0.68, 'max': 0.88, 'log': False},  # PMOS gate bias
    # Compensation network components
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Miller compensation cap (0.5-5× original 1pF)
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},  # Compensation resistor (0.5-2× original 1kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10,     # Original NMOS width (10um)
    'w_M2': 20,     # Original PMOS width (20um)
    'vbias': 0.78,  # Original bias voltage (0.78V)
    'c_comp': 1,    # Original compensation cap (1pF)
    'r_comp': 1,    # Original compensation resistor (1kΩ)
}
