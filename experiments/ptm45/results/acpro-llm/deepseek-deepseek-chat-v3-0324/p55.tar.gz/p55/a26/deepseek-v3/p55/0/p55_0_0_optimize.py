from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Miller Compensation')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # 0.42V input bias
    # PMOS bias voltage (parameterized)
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['vbias_p'])
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'],
                  l=0.045e-6)  # Length fixed by 45nm process
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_pmos'],
                  l=0.045e-6)  # Length fixed by 45nm process
    # Miller Compensation Capacitor (parameterized)
    circuit.C('1', 'Vout', 'Vin', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    # Bias voltage
    'vbias_p': {'min': 0.7, 'max': 0.94},  # 0.8-1.2× original (0.78V), keeping <1.2V
    # Compensation capacitor
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # 0.5-5× original (1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 10e-6,     # Original NMOS width
    'w_pmos': 20e-6,     # Original PMOS width
    'vbias_p': 0.78,     # Original PMOS bias voltage (V)
    'c_comp': 1.0,       # Original compensation capacitance (pF)
}
