Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Maximized GBW')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)  # PMOS bias voltage
    
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, logarithmic scale)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 45nm to 22.5μm range
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 45nm to 22.5μm range
    
    # Bias voltage (conservative range around original value)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V, staying <1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 10e-6,    # Original NMOS width
    'w_pmos': 20e-6,    # Original PMOS width
    'vbias': 0.78,      # Original bias voltage
}
```

**Parameter Descriptions:**
1. `w_nmos`: Width of the NMOS amplifying transistor (1-500× length). Affects transconductance and current.
2. `w_pmos`: Width of the PMOS active load (1-500× length). Affects load impedance and gain.
3. `vbias`: Bias voltage for the PMOS load (0.8-1.2× original). Sets operating point.

**Key Features:**
- Fixed power supply (1.2V) and input bias (0.42V) as requested
- MOSFET lengths fixed at 45nm (technology constraint)
- Conservative voltage ranges ensure proper operation:
  - Bias voltage maintains enough headroom (0.624-0.936V is within safe range for Vdd=1.2V with Vth=0.22V)
- All initial values are within their search ranges
- Width ranges cover practical design space (1-500× length) with logarithmic scaling for better optimization
- No load capacitors to parameterize (none existed in original circuit)

The parameter ranges were chosen to:
1. Keep the circuit functional during optimization
2. Allow sufficient exploration of the design space
3. Respect physical constraints (e.g., staying below Vdd)
4. Maintain reasonable operating points (especially for bias voltages)

The initial parameters exactly match your original circuit values.