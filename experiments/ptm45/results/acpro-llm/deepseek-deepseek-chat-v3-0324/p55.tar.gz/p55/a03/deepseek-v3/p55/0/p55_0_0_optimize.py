from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Maximized GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)  # PMOS bias voltage
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, logarithmic scale)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 45nm to 22.5μm range
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 45nm to 22.5μm range
    # Bias voltage (conservative range around original value)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V, staying <1.2V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 10e-6,    # Original NMOS width
    'w_pmos': 20e-6,    # Original PMOS width
    'vbias': 0.78,      # Original bias voltage
}
