from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies for the power and input signal
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # 0.42V input bias voltage (= Vth + 0.2V = 0.22 + 0.2)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # 0.42V bias for NMOS cascode
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # 0.78V bias for PMOS active load (= Vdd - |Vth| - 0.2V)
# Input Stage (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Cascode Stage (NMOS)
circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (PMOS)
circuit.MOSFET('2', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Capacitor
circuit.C('c', 'Vout', circuit.gnd, 1e-12)  # 1pF compensation capacitor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
