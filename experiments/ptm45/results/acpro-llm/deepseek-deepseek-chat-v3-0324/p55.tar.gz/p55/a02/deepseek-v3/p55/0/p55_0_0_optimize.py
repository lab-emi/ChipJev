from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Telescopic Cascode Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply and input voltages (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias voltage (fixed)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # NMOS cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS active load bias
    # Input Stage (NMOS) - width parameterized, length fixed
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)
    # Cascode Stage (NMOS) - width parameterized, length fixed
    circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M3'], 
                  l=0.045e-6)
    # Active Load (PMOS) - width parameterized, length fixed
    circuit.MOSFET('2', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Vout', circuit.gnd, params['c_comp'])
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input NMOS: 1-500×L
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode NMOS: 1-500×L
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load: 1-500×L
    # Bias voltages (constrained to 0.8-1.2× original values, not exceeding 1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # NMOS cascode bias
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # PMOS load bias
    # Compensation capacitor (0.5-5× original value)
    'c_comp': {'min': 0.5e-12, 'max': 5e-12, 'log': True},
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Original input NMOS width
    'w_M3': 10e-6,   # Original cascode NMOS width
    'w_M2': 10e-6,   # Original PMOS load width
    # Bias voltages
    'vbias1': 0.42,  # Original NMOS cascode bias
    'vbias2': 0.78,  # Original PMOS load bias
    # Compensation capacitor
    'c_comp': 1e-12, # Original compensation cap value
}
# Parameter descriptions (for documentation)
"""
Parameter Descriptions:
- w_M1: Width of input NMOS transistor (M1)
- w_M3: Width of cascode NMOS transistor (M3)
- w_M2: Width of PMOS active load transistor (M2)
- vbias1: Bias voltage for NMOS cascode stage (~0.4V typical)
- vbias2: Bias voltage for PMOS active load (~0.8V typical)
- c_comp: Compensation capacitor for frequency stability (1pF original)
"""
