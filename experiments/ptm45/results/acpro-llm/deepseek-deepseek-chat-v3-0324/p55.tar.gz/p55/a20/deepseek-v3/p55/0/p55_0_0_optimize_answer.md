Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Max GBW')
    
    # Define MOSFET models (fixed parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input voltage sources (fixed values)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed bias voltage for input
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Parameterized bias voltage
    
    # Amplifier Stage: Common-Source with Active Load
    # NMOS transistor (input device)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # PMOS transistor (active load)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_pmos'],
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length [45nm], log scale)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (original: 5μm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (original: 10μm)
    
    # Bias voltage (conservative range around original)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), below Vdd
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,    # Original NMOS width (5μm)
    'w_pmos': 10e-6,   # Original PMOS width (10μm)
    'v_bias': 0.78,    # Original bias voltage (0.78V)
}

# Parameter descriptions (for reference)
parameter_descriptions = {
    'w_nmos': 'Width of NMOS input transistor (affects transconductance and gain)',
    'w_pmos': 'Width of PMOS active load transistor (affects output impedance and gain)',
    'v_bias': 'Bias voltage for PMOS active load (affects operating point and headroom)',
}
```

Key implementation details:
1. **Fixed Parameters**:
   - Power supply (Vdd = 1.2V) remains fixed as requested
   - Input voltage (Vin = 0.42V) remains fixed for DC analysis
   - MOSFET lengths fixed at 45nm (0.045μm) as per technology node

2. **Optimized Parameters**:
   - NMOS and PMOS widths with 1-500× L range (log scale for wide dynamic range)
   - Bias voltage (Vbias) constrained to 0.8-1.2× original (0.78V) but never exceeding Vdd
     - Note: Range keeps Vbias between 0.624V and 0.936V (safe margin from Vdd=1.2V considering PMOS Vth)

3. **Constraints**:
   - All initial values exactly match original circuit
   - All initial values are within their search ranges
   - Voltage ranges respect technology limits (≤1.2V)
   - W/L ratios kept reasonable (1-500×) for practical transistors
   - Conservative bias voltage range maintains intended operation region

The parameter ranges were chosen to:
- Allow sufficient exploration for optimization while keeping designs practical
- Maintain safe operating conditions (voltages, currents)
- Preserve the original circuit's operating principle
- Enable meaningful GBW optimization through transistor sizing