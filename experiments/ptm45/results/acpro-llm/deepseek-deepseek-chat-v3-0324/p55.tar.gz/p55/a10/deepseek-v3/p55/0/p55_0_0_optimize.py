from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with High GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Biasing (Vdd and input voltages fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias (Vth + 0.2V)
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # For M2 PMOS
    # Transistors (only widths parameterized, length fixed at 45nm)
    # M1 (NMOS): Input stage
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'], 
                   l=0.045e-6)
    # M2 (PMOS): Active load
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m2'], 
                   l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 NMOS width (45nm-22.5µm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 PMOS width (45nm-22.5µm)
    # Bias voltage (0.8-1.2× original value, constrained by Vdd and Vth)
    'vbias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original M1 NMOS width
    'w_m2': 10e-6,    # Original M2 PMOS width
    'vbias': 0.78,    # Original bias voltage
}
"""
Parameter Descriptions:
1. w_m1: Width of M1 NMOS input transistor (affects transconductance and gain)
2. w_m2: Width of M2 PMOS active load (affects output impedance and gain)
3. vbias: Bias voltage for M2 PMOS (determines operating point; constrained to maintain saturation)
Design Constraints Applied:
- All transistor lengths fixed at 45nm (technology minimum)
- Widths constrained to 1-500× length (45nm-22.5µm range)
- Bias voltage constrained to 0.8-1.2× original value (0.624-0.936V)
  (never exceeding Vdd=1.2V and maintaining Vbias > Vdd - |Vth| for saturation)
- Input voltages Vin fixed at original values since they will be swept
- Power supply voltage Vdd fixed at 1.2V (45nm technology typical value)
"""
