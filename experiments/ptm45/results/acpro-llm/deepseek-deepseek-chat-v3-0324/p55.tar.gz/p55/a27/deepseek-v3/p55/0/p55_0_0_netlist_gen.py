from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Telescopic Cascode Amplifier with Compensation')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
circuit.V('cas', 'Vcas', circuit.gnd, 0.42@u_V)  # Cascode bias (Vth + 0.2V)
# Transistors
# Input NMOS (M1)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Cascode NMOS (M3)
circuit.MOSFET('3', 'Vout', 'Vcas', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS Current Source Load (M2)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Capacitor (Cc)
circuit.C('c', 'Vout', 'Vcas', 1@u_pF)  # 1pF compensation capacitor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
