Here's the parameterized version of your single-stage amplifier circuit with GBW optimization:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with GBW Optimization')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply and Bias Voltages (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Input Stage (Common-Source NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'],
                  l=0.045e-6)  # Fixed length
    
    # Active Load (PMOS Current Source)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'],
                  l=0.045e-6)  # Fixed length
    
    # Compensation Network (parameterized)
    circuit.C('c', 'Vout', 'Vin', f"{params['c_comp']}p")  # Main compensation cap
    circuit.R('c', 'Vout', 'Vout_rc', f"{params['r_comp']}k")  # Nulling resistor
    circuit.C('c_extra', 'Vout_rc', 'Vin', 1e-12@u_F)  # Fixed parasitic cap
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (W in meters)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (0.045µm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (0.045µm)
    
    # Bias voltage (constrained to keep PMOS in saturation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), staying below Vdd
    
    # Compensation components
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # 0.5-5× original (1pF)
    'r_comp': {'min': 0.5, 'max': 2.0, 'log': True},  # 0.5-2× original (1kΩ)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 20e-6,   # Original NMOS width
    'w_pmos': 10e-6,   # Original PMOS width
    'v_bias': 0.78,    # Original bias voltage (Vdd - |Vth| - 0.2V)
    'c_comp': 1.0,     # Original compensation cap (pF)
    'r_comp': 1.0,     # Original nulling resistor (kΩ)
}
```

### Parameter Descriptions:
1. **w_nmos**: NMOS transistor width (1-500× length of 45nm). Affects transconductance and gain.
2. **w_pmos**: PMOS transistor width (1-500× length of 45nm). Affects load current and output impedance.
3. **v_bias**: PMOS gate bias voltage (0.624-0.936V). Sets operating point while ensuring PMOS stays in saturation.
4. **c_comp**: Miller compensation capacitor (0.5-5pF). Dominates frequency compensation and GBW.
5. **r_comp**: Nulling resistor (0.5-2kΩ). Helps optimize phase margin by shifting the zero.

### Key Design Constraints:
- All voltage parameters stay below the 1.2V supply limit
- Bias voltage range is carefully constrained to maintain PMOS in saturation (Vgs ≤ Vdd - |Vth|)
- Transistor widths maintain reasonable W/L ratios (1-500) for 45nm technology
- Compensation components have wider ranges as they are critical for stability optimization
- The small parasitic capacitor (1fF) is kept fixed as it's for simulation stability, not circuit behavior

The initial parameter values exactly match your original circuit implementation, ensuring the optimization starts from a known working point.