from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with GBW Optimization')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Bias Voltages (Vdd = 1.2V, Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
# Input Stage (Common-Source NMOS)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (PMOS Current Source)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Network (Cc and Rc)
circuit.C('c', 'Vout', 'Vin', 1@u_pF)  # Compensation capacitor
circuit.R('c', 'Vout', 'Vout_rc', 1@u_kΩ)  # Nulling resistor
circuit.C('c_extra', 'Vout_rc', 'Vin', 1e-12@u_F)  # Small parasitic cap for simulation stability
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
