from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Miller Compensation')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)  # Parameterized bias voltage
    # Transistors
    # M1: NMOS input transistor (width parameterized, length fixed at 45nm)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'],
                  l=0.045e-6)
    # M2: PMOS active load (width parameterized, length fixed at 45nm)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],
                  l=0.045e-6)
    # Miller Compensation Capacitor (parameterized)
    circuit.C('c', 'Vin', 'Vout', params['c_comp']@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (min 1×L, max 500×L, where L = 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range
    # Bias voltage (0.8-1.2× original, but constrained to maintain operation)
    # Original was 0.78V (Vdd - |Vth| - 0.2V). Constrained to 0.8-1.0V to stay in saturation
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8× to 1.2× of original 0.78V, but below Vdd
    # Miller compensation capacitor (0.5-5× original)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 10e-6,    # Original NMOS width (10um)
    'w_m2': 20e-6,    # Original PMOS width (20um)
    'vbias': 0.78,    # Original bias voltage (0.78V)
    'c_comp': 1,      # Original compensation cap (1pF)
}
