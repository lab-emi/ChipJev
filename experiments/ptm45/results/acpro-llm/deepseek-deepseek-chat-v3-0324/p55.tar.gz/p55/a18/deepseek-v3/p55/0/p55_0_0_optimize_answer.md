Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Max GBW')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias voltage (fixed)
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # PMOS bias voltage
    
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'],
                  l=0.045e-6)  # 45nm fixed
    
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'],
                  l=0.045e-6)  # 45nm fixed
    
    # Compensation Capacitor (parameterized)
    circuit.C('1', 'Vout', 'Vbias', f"{params['c_comp']}p")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for NMOS (original L=45nm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for PMOS (original L=45nm)
    
    # Bias voltage - kept within 0.8-1.2× original value (0.78V) but not exceeding Vdd=1.2V
    # Also considering Vth=0.22V to ensure proper operation
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8×0.78 to 1.2×0.78 (0.78±20%)
    
    # Compensation capacitor - 0.5-5× original value (1pF)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True}
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,      # Original NMOS width
    'w_pmos': 10e-6,     # Original PMOS width
    'v_bias': 0.78,      # Original bias voltage
    'c_comp': 1,         # Original compensation capacitance (pF)
}
```

### Parameter Descriptions:
1. **w_nmos**: Main amplifying NMOS transistor width (original: 5μm). Range allows 1-500× the fixed 45nm channel length.
2. **w_pmos**: Active load PMOS transistor width (original: 10μm). Range allows 1-500× the fixed 45nm channel length.
3. **v_bias**: PMOS gate bias voltage (original: 0.78V). Constrained to ±20% of original value while staying below Vdd (1.2V).
4. **c_comp**: Compensation capacitance (original: 1pF). Allowed to vary between 0.5-5× original value to stabilize the amplifier.

### Notes:
- All initial parameter values are within their defined search ranges
- Power supply (Vdd) and input voltage (Vin) remain fixed as requested
- Transistor lengths are fixed at 45nm (technology constraint)
- The bias voltage range is conservative (±20%) to maintain proper operating conditions
- Compensation capacitor range allows significant tuning (0.5-5pF) for stability optimization
- Both transistor widths can vary independently for optimal current matching