Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Max GBW')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies and Bias Voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    
    # Parameterized bias voltage (original value = 0.78V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Common-Source Amplifier (M1) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Active Load (M2) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (widths)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (original 5um)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (original 10um)
    
    # Bias voltage (conservative range around original value)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), capped at 1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,      # Original M1 width (5um)
    'w_m2': 10e-6,     # Original M2 width (10um)
    'v_bias': 0.78,    # Original bias voltage (0.78V)
}

"""
Parameter Descriptions:
1. w_m1: NMOS (M1) transistor width - affects transconductance and gain of input stage
2. w_m2: PMOS (M2) transistor width - affects current source strength and output impedance
3. v_bias: Bias voltage for PMOS current source - sets operating current and output DC level

Design Constraints:
- All transistor lengths fixed at 45nm (technology minimum)
- Widths constrained to maintain reasonable aspect ratios (1-500× length)
- Bias voltage constrained to stay within 20% of original value since it affects
  the operating point significantly (Vgs must remain above Vth but below supply)
- Supply voltage (1.2V) and input bias (0.42V) kept fixed as per requirements
"""
```

Key points about this implementation:
1. Strictly follows all your requirements including fixed names and structure
2. Preserves all original values exactly in `initial_params`
3. All initial values are within their respective search ranges
4. Voltage ranges are conservative (0.8-1.2× original) to maintain proper operation
5. Only parameterizes the elements you specified (widths and bias voltage)
6. Keeps lengths fixed at 45nm as required
7. Includes clear documentation of each parameter's role
8. Maintains all original imports exactly as specified

The parameter ranges were chosen to:
- Allow sufficient exploration for optimization while keeping devices in reasonable operating regions
- Maintain aspect ratios in practical ranges (1-500× length)
- Keep bias voltages within safe limits relative to the supply voltage
- Stay true to the original circuit's intended operation while allowing optimization