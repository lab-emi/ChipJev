from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Maximum GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias (Vth + 0.2V = 0.42V)
    # Parameterized bias voltage (PMOS gate bias)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Main Amplifying Transistor (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Current Source Load (PMOS) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (original: 5µm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (original: 10µm)
    # Bias voltage (constrained to keep PMOS in saturation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), but capped at Vdd
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,      # Original NMOS width (5µm)
    'w_pmos': 10e-6,     # Original PMOS width (10µm)
    'v_bias': 0.78,      # Original PMOS bias voltage (0.78V)
}
"""
Parameter Descriptions:
- w_nmos: Width of the NMOS input transistor (main amplifying device)
- w_pmos: Width of the PMOS current source load (sets output impedance)
- v_bias: Bias voltage for PMOS current source (0.624-0.936V range ensures PMOS stays in saturation)
Constraints:
1. Transistor widths are constrained to 1-500× their length (45nm)
2. Bias voltage is constrained to 0.8-1.2× original value (0.78V), but never exceeds supply voltage
3. Original design values are preserved exactly in initial_params
4. Input voltages remain fixed at their original values
"""
