from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input and Bias Voltages (fixed for input, parameterized for biases)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias fixed
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # NMOS cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # PMOS current source bias
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)  # PMOS cascode bias
    # Input Stage (M1: NMOS common-source)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1']@u_um, 
                  l=0.045@u_um)
    # Cascode Stage (M2: NMOS cascode)
    circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1', 
                  model='nmos_model', 
                  w=params['w_M2']@u_um, 
                  l=0.045@u_um)
    # Active Load (M3: PMOS current source)
    circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M3']@u_um, 
                  l=0.045@u_um)
    # Cascode Load (M4: PMOS cascode)
    circuit.MOSFET('4', 'Vout', 'Vbias3', 'Drain3', 'Drain3',
                  model='pmos_model', 
                  w=params['w_M4']@u_um, 
                  l=0.045@u_um)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length constraint means 0.045-22.5μm range)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},  # Input stage NMOS width (μm)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS cascode width (μm)
    'w_M3': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS current source width (μm)
    'w_M4': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS cascode width (μm)
    # Bias voltages (0.8-1.2× original but ≤1.2V, with Vth=0.22V consideration)
    'vbias1': {'min': 0.35, 'max': 0.53},  # NMOS cascode gate (original 0.44V)
    'vbias2': {'min': 0.62, 'max': 0.94},  # PMOS current source gate (original 0.78V)
    'vbias3': {'min': 0.62, 'max': 0.94},  # PMOS cascode gate (original 0.78V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5.0,     # Original width for M1
    'w_M2': 5.0,     # Original width for M2
    'w_M3': 10.0,    # Original width for M3
    'w_M4': 10.0,    # Original width for M4
    'vbias1': 0.44,  # Original bias for Vbias1
    'vbias2': 0.78,  # Original bias for Vbias2
    'vbias3': 0.78,  # Original bias for Vbias3
}
