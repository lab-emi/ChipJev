from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input and Bias Voltages (DC only)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.44@u_V)  # For M2 (NMOS cascode)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For M3 (PMOS current source)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # For M4 (PMOS cascode)
# Input Stage (M1: NMOS common-source)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
# Cascode Stage (M2: NMOS cascode)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1', model='nmos_model', w=5@u_um, l=0.045@u_um)
# Active Load (M3: PMOS current source)
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Cascode Load (M4: PMOS cascode)
circuit.MOSFET('4', 'Vout', 'Vbias3', 'Drain3', 'Drain3', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Output Node: Vout (drain of M2 and M4)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
