Here's the parameterized version of your single-stage amplifier circuit, following all your specified requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with High GBW')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltage (originally 0.78V)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}@u_V")
    
    # Common-Source Stage with Active Load
    # NMOS transistor (originally w=5e-6)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed length for 45nm technology
                  
    # PMOS transistor (originally w=10e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed length for 45nm technology
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (optimizing W while keeping L fixed at 45nm)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L range (45nm to 22.5µm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L range (45nm to 22.5µm)
    
    # Bias voltage (originally 0.78V, Vdd - |Vth| - 0.2V)
    # Keeping within 0.8-1.2× original value but never exceeding Vdd (1.2V)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8× to 1.2× original, below 1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,    # Original NMOS width (5µm)
    'w_pmos': 10e-6,   # Original PMOS width (10µm)
    'v_bias': 0.78,    # Original bias voltage (0.78V)
}

# Parameter descriptions:
# - w_nmos: Width of NMOS transistor in common-source configuration (affects gain and bandwidth)
# - w_pmos: Width of PMOS active load transistor (affects output impedance and gain)
# - v_bias: Bias voltage for PMOS gate (sets operating point, affects output swing and linearity)
```

Key features of this implementation:
1. Strictly follows your requirements including fixed Vdd (1.2V) and input voltage (0.42V)
2. Parameterizes all adjustable elements:
   - Transistor widths (W) with 1-500×L range (45nm to 22.5µm) while keeping L fixed at 45nm
   - Bias voltage with conservative 0.8-1.2× range around the original value (0.624V to 0.936V)
3. Preserves all original values in initial_params exactly as specified in your circuit
4. Maintains the exact function name `create_circuit` required by your optimization framework
5. Includes descriptive comments about each parameter's physical significance
6. Ensures all initial parameter values are within their respective search ranges
7. Uses proper logarithmic scaling for transistor width parameters which typically span several orders of magnitude

The circuit maintains its fundamental operation as a single-stage amplifier with active load while allowing optimization of the key parameters that affect gain, bandwidth, and power consumption.