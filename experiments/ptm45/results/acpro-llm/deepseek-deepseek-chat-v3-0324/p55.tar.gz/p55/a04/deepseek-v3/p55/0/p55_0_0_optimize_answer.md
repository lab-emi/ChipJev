Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with High GBW')

    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    
    # Parameterized bias voltage (0.8-1.2x original but ≤1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    
    # Transistors - Width parameterized, length fixed at 45nm
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)
    
    # Compensation Capacitor - parameterized (0.5-5x original)
    circuit.C('1', 'Vout', 'Vbias', f"{params['C1']}p")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping 45nm length fixed)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5um (5/0.045=111x)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10um (10/0.045=222x)
    
    # Bias voltage (0.8-1.2× original but ≤1.2V)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V, range: 0.78×[0.8,1.2]
    
    # Compensation capacitor (0.5-5× original)
    'C1': {'min': 0.5, 'max': 5.0, 'log': True},  # Original: 1pF
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,     # Original NMOS width
    'w_pmos': 10e-6,    # Original PMOS width
    'v_bias': 0.78,     # Original bias voltage
    'C1': 1.0,          # Original compensation capacitance
}
```

### Parameter Descriptions:
1. **Transistor Widths (w_nmos, w_pmos)**:
   - Controls gain, bandwidth, and power consumption
   - Search range: 45nm (min) to 22.5μm (500× length)
   - NMOS initial: 5μm (111× length), PMOS initial: 10μm (222× length)

2. **Bias Voltage (v_bias)**:
   - Sets operating point for PMOS current source
   - Original: 0.78V (Vdd - |Vth| - 0.2V)
   - Conservative range: 0.624V to 0.936V (0.8-1.2× original)
   - Ensures PMOS remains in saturation (Vgs ≥ Vth)

3. **Compensation Capacitor (C1)**:
   - Stabilizes the amplifier and affects GBW
   - Original: 1pF
   - Search range: 0.5pF to 5pF (0.5-5× original)

### Key Implementation Notes:
- Fixed values (Vdd, Vin) remain exactly as in original circuit
- Length parameters kept constant at 45nm (process-defined)
- Bias voltage range stays well below 1.2V supply (max 0.936V)
- All initial parameter values match original circuit exactly
- Width ranges allow exploration from minimum feature size up to reasonable maximum
- Logarithmic sampling suggested for semiconductor dimensions and capacitors
- C1 parameter range balances stability needs with bandwidth optimization