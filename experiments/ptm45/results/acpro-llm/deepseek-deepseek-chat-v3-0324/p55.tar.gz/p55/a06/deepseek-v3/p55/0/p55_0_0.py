from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier (Max GBW)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias (Vin = Vth + 0.2V for NMOS saturation)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # 0.22V + 0.2V
# PMOS Cascode Bias (Vdd - |Vth| - 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # 1.2V - 0.22V - 0.2V
# Main Amplifying Transistor (M1: NMOS)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
# Cascode Load (M2: PMOS)
circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Drain1', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Capacitor (C1: 1pF)
circuit.C('1', 'Drain1', 'Vout', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
