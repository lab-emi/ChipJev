from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Ensure 'model.py' exists with these params
# Step 1: Initialize the Circuit
circuit = Circuit('Telescopic Cascode Amplifier (Corrected)')
# Step 2: Define MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Step 3: Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Step 4: Input Bias (NMOS M1 in saturation)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.22V + 0.2V
# Step 5: PMOS Bias (Critical Fix: Ensure V_GS < Vth)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.1@u_V)  # Now V_GS = 0.1V - 0.3V = -0.2V < -0.22V
# Step 6: NMOS Transistor (M1)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# Step 7: PMOS Cascode Load (M2)
circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Drain1', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Step 8: Load Resistor (Stabilizes DC)
circuit.R('1', 'Vout', 'Vdd', 100@u_kΩ)
# Step 9: Compensation Capacitor (GBW Optimization)
circuit.C('1', 'Drain1', 'Vout', 1@u_pF)
# Step 10: Simulation (No changes needed here)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
