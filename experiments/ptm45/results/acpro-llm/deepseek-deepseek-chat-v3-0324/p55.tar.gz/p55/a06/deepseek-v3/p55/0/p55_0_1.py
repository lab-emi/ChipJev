from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
# PMOS Cascode Bias (Reduced to 0.1V for proper activation)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.1@u_V)  # Now V_GS = 0.1V - 0.3V = -0.2V < Vth (-0.22V)

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
