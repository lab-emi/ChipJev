Here's the parameterized version of your single-stage amplifier with high GBW, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with High GBW')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)  # Parameterized bias voltage
    
    # Common-Source Amplifier with Active Load
    # M1: NMOS (input stage)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'],  # Parameterized width
                   l=0.045e-6)  # Fixed length (45nm)
    
    # M2: PMOS (active load)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'],  # Parameterized width
                   l=0.045e-6)  # Fixed length (45nm)
    
    # Miller Compensation (parameterized)
    circuit.C('1', 'Vout', 'Vin', params['c_comp']@u_pF)  # Compensation capacitor
    circuit.R('1', 'Vout', 'Vin', params['r_comp']@u_kΩ)  # Nulling resistor
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping L=45nm fixed)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (1-500×45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (1-500×45nm)
    
    # Bias voltage (0.8-1.2× original, not exceeding 1.2V)
    'vbias': {'min': 0.624, 'max': 0.936},  # Original=0.78V (0.8×=0.624V, 1.2×=0.936V)
    
    # Compensation components
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Compensation cap (0.5-5× original 1pF)
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},  # Nulling resistor (0.5-2× original 1kΩ)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width (5µm)
    'w_M2': 10e-6,    # Original PMOS width (10µm)
    'vbias': 0.78,    # Original bias voltage (0.78V)
    'c_comp': 1,      # Original compensation cap (1pF)
    'r_comp': 1,      # Original nulling resistor (1kΩ)
}
```

### Parameter Descriptions:
1. **w_M1**: Width of NMOS input transistor (M1). Range allows from minimum feature size (45nm) to 500× length (22.5µm).
2. **w_M2**: Width of PMOS active load (M2). Same range as NMOS for balanced design.
3. **vbias**: Bias voltage for PMOS. Conservative range (0.624V-0.936V) maintains proper operation (Vdd-|Vth|±0.2V).
4. **c_comp**: Miller compensation capacitor. 0.5-5pF range allows for stability optimization.
5. **r_comp**: Nulling resistor. 0.5-2kΩ range helps optimize phase margin.

### Key Features:
- All original values are preserved in initial_params exactly as provided
- Voltage ranges are conservative to maintain proper operation (never exceeding 1.2V)
- Transistor widths can vary from minimum size up to 500× length (45nm to 22.5µm)
- Compensation components have wider ranges for stability optimization
- Fixed parameters (Vdd, Vin) are excluded from optimization as requested
- MOSFET lengths are fixed at 45nm as this affects matching more than behavior