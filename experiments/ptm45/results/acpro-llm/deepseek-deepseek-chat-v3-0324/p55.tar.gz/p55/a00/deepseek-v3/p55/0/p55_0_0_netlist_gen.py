from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with High GBW')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies for the power and input signal
# Assuming Vth = 0.22V (NMOS) and |Vth| = 0.22V (PMOS), Vdd = 1.2V
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V) # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V) # Input bias voltage (Vth + 0.2V = 0.22 + 0.2 = 0.42V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V) # Bias voltage for PMOS (Vdd - |Vth| - 0.2V = 1.2 - 0.22 - 0.2 = 0.78V)
# Common-Source Amplifier with Active Load
# M1: NMOS (input stage)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# M2: PMOS (active load)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Miller Compensation (C1 and R1)
circuit.C('1', 'Vout', 'Vin', 1@u_pF) # Compensation capacitor
circuit.R('1', 'Vout', 'Vin', 1@u_kΩ) # Nulling resistor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
