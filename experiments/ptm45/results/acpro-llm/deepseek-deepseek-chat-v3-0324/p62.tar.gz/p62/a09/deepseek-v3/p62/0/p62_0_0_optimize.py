from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    # Input Signals (DC bias for operating point analysis - fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Stage 1: Differential Pair with Active Load (transistor widths parameterized)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load (transistor widths parameterized)
    circuit.MOSFET('7', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Drain2', 'Vout', params['c_comp']@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) with 1-500× length range (45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror load
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS active load
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage NMOS
    # Bias voltages (0.8-1.2× original but ≤ 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (tail current)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (active load)
    # Compensation capacitor (0.5-5× original)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True}  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,  # M1 width
    'w_M2': 10e-6,  # M2 width
    'w_M3': 20e-6,  # M3 width
    'w_M4': 20e-6,  # M4 width
    'w_M5': 5e-6,   # M5 width
    'w_M6': 10e-6,  # M6 width
    'w_M7': 20e-6,  # M7 width
    # Bias voltages
    'vbias1': 0.42,  # Vbias1 for tail current
    'vbias2': 0.78,  # Vbias2 for active load
    # Compensation capacitor
    'c_comp': 1.0    # Compensation capacitance (pF)
}
