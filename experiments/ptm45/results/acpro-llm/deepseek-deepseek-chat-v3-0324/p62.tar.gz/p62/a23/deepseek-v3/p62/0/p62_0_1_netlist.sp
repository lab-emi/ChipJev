Vdd Vdd 0 1.2V
Vbias1 Vbias1 0 0.5V
Vbias2 Vbias2 0 0.7V
Vbias3 Vbias3 0 0.42V
Vbias4 Vbias4 0 0.42V
Vinp Vinp 0 0.6V
Vinn Vinn 0 0.6V
M1 D1 Vinp S1 0 nmos_model l=4.5e-08 w=1e-05
M2 D2 Vinn S1 0 nmos_model l=4.5e-08 w=1e-05
M3 D3 Vbias1 D1 0 nmos_model l=4.5e-08 w=1e-05
M4 D4 Vbias1 D2 0 nmos_model l=4.5e-08 w=1e-05
M5 D3 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M6 D4 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M8 S1 Vbias3 0 0 nmos_model l=4.5e-08 w=5e-06
M7 Vout D4 0 0 nmos_model l=4.5e-08 w=2e-05
M9 Vout Vbias4 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
Cc D4 Vout 1pF
Rc D4 Vout 1kOhm
.model nmos_model nmos (kp=0.0001 level=1 vto=0.22)
.model pmos_model pmos (kp=4e-05 level=1 vto=-0.22)

