from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Opamp (GBW/Power Optimized)')
# Define MOSFET models (since 'from model import...' fails)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Simplified NMOS model
circuit.model('pmos_model', 'pmos', level=1, kp=40e-6, vto=-0.22)  # Simplified PMOS model
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V assumed)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5@u_V)  # NMOS cascode bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7@u_V)  # PMOS mirror bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Tail current bias
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.42@u_V)  # M9 bias
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for DC
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Stage 1: Telescopic Cascode Differential Pair
# NMOS transistors (bulk connected to ground)
circuit.MOSFET('1', 'D1', 'Vinp', 'S1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'D2', 'Vinn', 'S1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'D3', 'Vbias1', 'D1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'D4', 'Vbias1', 'D2', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS transistors (bulk connected to Vdd)
circuit.MOSFET('5', 'D3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'D4', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current source
circuit.MOSFET('8', 'S1', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('7', 'Vout', 'D4', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vout', 'Vbias4', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'D4', 'Vout', 1@u_pF)  # Miller capacitor
circuit.R('c', 'D4', 'Vout', 1@u_kΩ)  # Compensation resistor
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
