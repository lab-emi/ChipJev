from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp (GBW/Power Optimized)')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply (1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Fixed input voltages (mid-rail for DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    circuit.V('bias4', 'Vbias4', circuit.gnd, params['vbias4']@u_V)
    # Stage 1: Telescopic Cascode Differential Pair
    # NMOS transistors (bulk connected to ground)
    circuit.MOSFET('1', 'D1', 'Vinp', 'S1', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'D2', 'Vinn', 'S1', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'D3', 'Vbias1', 'D1', circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'D4', 'Vbias1', 'D2', circuit.gnd, 
                   model='nmos_model', w=params['w_M4'], l=0.045e-6)
    # PMOS transistors (bulk connected to Vdd)
    circuit.MOSFET('5', 'D3', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'D4', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Tail current source
    circuit.MOSFET('8', 'S1', 'Vbias3', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M8'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier
    circuit.MOSFET('7', 'Vout', 'D4', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('9', 'Vout', 'Vbias4', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M9'], l=0.045e-6)
    # Compensation Network (parameterized)
    circuit.C('c', 'D4', 'Vout', params['c_comp']@u_pF)
    circuit.R('c', 'D4', 'Vout', params['r_comp']@u_kΩ)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to 0.8-1.2× original values, not exceeding 1.2V)
    'vbias1': {'min': 0.4, 'max': 0.6},    # Original: 0.5V (NMOS cascode bias)
    'vbias2': {'min': 0.56, 'max': 0.84},  # Original: 0.7V (PMOS mirror bias)
    'vbias3': {'min': 0.336, 'max': 0.504}, # Original: 0.42V (Tail current bias)
    'vbias4': {'min': 0.336, 'max': 0.504}, # Original: 0.42V (M9 bias)
    # NMOS transistor widths (1-500× length = 45nm-22.5µm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair M1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair M2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode M3
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode M4
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output stage M7
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current M8
    # PMOS transistor widths (1-500× length = 45nm-22.5µm)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Load M5
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Load M6
    'w_M9': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Load M9
    # Compensation network (0.5-5× original values)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},    # Original: 1pF
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},    # Original: 1kΩ
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.5,
    'vbias2': 0.7,
    'vbias3': 0.42,
    'vbias4': 0.42,
    # NMOS widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 10e-6,
    'w_M7': 20e-6,
    'w_M8': 5e-6,
    # PMOS widths
    'w_M5': 20e-6,
    'w_M6': 20e-6,
    'w_M9': 10e-6,
    # Compensation network
    'c_comp': 1,
    'r_comp': 1,
}
