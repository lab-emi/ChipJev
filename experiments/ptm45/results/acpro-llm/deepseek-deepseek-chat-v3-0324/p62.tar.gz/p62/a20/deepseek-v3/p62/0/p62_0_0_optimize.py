from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Fixed input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Fixed input
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    # Stage 1: Differential Pair with Current Mirror Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('8', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('3', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('9', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M9'], l=0.045e-6)
    # Miller Compensation (parameterized)
    circuit.C('c', 'Vout', 'Drain2', f"{params['cc']}p")
    circuit.R('c', 'Vout', 'NodeX', f"{params['rc']}k")
    circuit.C('x', 'NodeX', 'Drain2', f"{params['cx']}p")
    # Bias Circuitry
    circuit.MOSFET('4', 'Vbias1', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('10', 'Vbias1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M10'], l=0.045e-6)
    circuit.MOSFET('6', 'Vbias2', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('11', 'Vbias2', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M11'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500x length, 45nm process)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M9': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M10': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M11': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    # Bias voltages (0.8-1.2x original, not exceeding 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (Vth + 0.2V)
    'vbias2': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (Vth + 0.2V)
    # Compensation network (0.5-5x original)
    'cc': {'min': 0.5, 'max': 5.0, 'log': True},  # Original: 1pF
    'cx': {'min': 0.5, 'max': 5.0, 'log': True},  # Original: 1pF
    'rc': {'min': 0.5, 'max': 2.0, 'log': True},  # Original: 1kΩ
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6, 'w_M2': 10e-6, 'w_M3': 20e-6,
    'w_M4': 10e-6, 'w_M5': 10e-6, 'w_M6': 10e-6,
    'w_M7': 20e-6, 'w_M8': 20e-6, 'w_M9': 20e-6,
    'w_M10': 20e-6, 'w_M11': 20e-6,
    # Bias voltages
    'vbias1': 0.42, 'vbias2': 0.42,
    # Compensation network
    'cc': 1.0, 'cx': 1.0, 'rc': 1.0,
}
