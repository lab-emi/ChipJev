Here's the parameterized version of your three-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Opamp')
    
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2']@u_V)
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Stage 1: Differential Pair with Active Load (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source_pair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier (parameterized widths)
    circuit.MOSFET('6', 'Vout_intermediate', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m6'], l=0.045e-6)
    
    # Stage 3: Common-Source Buffer (parameterized widths)
    circuit.MOSFET('7', 'Vout', 'Vout_intermediate', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m7'], l=0.045e-6)
    
    # Compensation Network (parameterized)
    circuit.R('1', 'Vout_intermediate', 'Vout', f"{params['r_comp']}k")
    circuit.C('1', 'Vout_intermediate', 'Vout', f"{params['c_comp']}p")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original values but ≤1.2V)
    'v_bias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (tail current)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (M6 bias)
    
    # Differential pair and current mirror (W ranges)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    
    # Second stage (CS amplifier)
    'w_m6': {'min': 0.045e-6, 'max': 225e-6, 'log': True},  # Original: 30e-6 (wider range)
    
    # Output stage (buffer)
    'w_m7': {'min': 0.045e-6, 'max': 225e-6, 'log': True},  # Original: 40e-6 (wider range)
    
    # Compensation network
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},      # Original: 1kΩ
    'c_comp': {'min': 1.0, 'max': 10, 'log': True},     # Original: 2pF
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_bias1': 0.42,
    'v_bias2': 0.78,
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 5e-6,
    'w_m6': 30e-6,
    'w_m7': 40e-6,
    'r_comp': 1,
    'c_comp': 2,
}
```

### Parameter Descriptions:
1. **Voltage Parameters**:
   - `v_bias1`: Tail current source bias voltage (controls differential pair current)
   - `v_bias2`: Second stage bias voltage (controls output stage biasing)
   
2. **Transistor Width Parameters**:
   - `w_m1`, `w_m2`: Input pair transistor widths (affects gm and matching)
   - `w_m3`, `w_m4`: Active load PMOS widths (sets mirror ratio and load impedance)
   - `w_m5`: Tail current source width (sets bias current)
   - `w_m6`: Second stage PMOS width (sets gain and bandwidth)
   - `w_m7`: Output buffer width (affects drive capability)
   
3. **Compensation Network**:
   - `r_comp`: Miller compensation resistor (affects stability)
   - `c_comp`: Miller compensation capacitor (sets dominant pole)

The parameter ranges are set to:
- Keep all voltages below the 1.2V supply limit
- Allow transistor widths between 1-500× their minimum length (45nm)
- Provide conservative ranges around the original values for bias voltages (0.8-1.2×)
- Enable wide exploration of compensation network values (0.5-2× for resistor, 0.5-5× for capacitor)

All initial parameter values exactly match your original circuit specifications.