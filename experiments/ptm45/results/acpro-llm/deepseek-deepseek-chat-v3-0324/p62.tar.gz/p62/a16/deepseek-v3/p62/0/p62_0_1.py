from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Bias Voltages (Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5)  # Tail current bias (Vth + 0.28V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7)  # 2nd stage bias (Vdd - |Vth| - 0.3V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.5)  # Output stage bias (Vdd - |Vth| - 0.5V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinn', 'Source12', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'Source12', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source12', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Drain6', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain6', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=25e-6, l=0.045e-6)
# Stage 3: Output Stage with Proper Biasing
circuit.MOSFET('8', 'Vout', 'Drain6', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Miller Compensation
circuit.C('1', 'Drain6', 'Vout', 2@u_pF)
circuit.R('1', 'Drain6', 'Vout', 1.5@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
