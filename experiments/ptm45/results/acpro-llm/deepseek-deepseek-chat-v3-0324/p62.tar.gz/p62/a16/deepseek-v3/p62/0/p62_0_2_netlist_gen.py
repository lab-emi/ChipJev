from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Opamp with Proper Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (1.2V) and Reference Current
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
circuit.I('ref', 'Vdd', 'Vref', 100@u_nA)  # 100nA reference current
# Bias Generation Circuit (Self-biasing)
circuit.MOSFET('b1', 'Vbias1', 'Vbias1', 'Vref', circuit.gnd, model='nmos_model', w=2e-6, l=1e-6)
circuit.MOSFET('b2', 'Vbias2', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=4e-6, l=1e-6)
circuit.MOSFET('b3', 'Vbias3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=6e-6, l=1e-6)
# Input Stage: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Gain Stage: Common-Source Amplifier
circuit.MOSFET('6', 'Drain6', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain6', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=25e-6, l=0.045e-6)
# Output Stage with Active Load
circuit.MOSFET('8', 'Vout', 'Drain6', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain6', 'Vout', 2@u_pF)
circuit.R('r', 'Drain6', 'Vout', 1.5@u_kΩ)
# Input Bias and Startup Helpers
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.MOSFET('start', 'Vref', 'Vdd', circuit.gnd, circuit.gnd, model='nmos_model', w=1e-6, l=1e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
