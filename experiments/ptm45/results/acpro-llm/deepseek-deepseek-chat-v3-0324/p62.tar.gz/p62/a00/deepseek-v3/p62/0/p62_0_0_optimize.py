from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias_n', 'Vbias_n', circuit.gnd, f"{params['vbias_n']}V")  # NMOS bias
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, f"{params['vbias_p']}V")  # PMOS bias
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed mid-rail for DC bias
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed mid-rail for DC bias
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('9', 'Tail', 'Vbias_n', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M9'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Compensation
    circuit.MOSFET('3', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    # Compensation capacitor (parameterized)
    circuit.C('c', 'Drain2', 'Vout', f"{params['c_comp']}pF")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L
    'w_M9': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # 1-500× original L
    # Bias voltages (constrained to maintain operating regions)
    'vbias_n': {'min': 0.336, 'max': 0.504},  # Original 0.42V ±20% (Vth=0.22V + safety margin)
    'vbias_p': {'min': 0.624, 'max': 0.936},  # Original 0.78V ±20% (Vdd-Vth=0.98V - margin)
    # Compensation capacitor
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # 0.5-5× original 1pF value
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M5': 20e-6,
    'w_M6': 20e-6,
    'w_M8': 10e-6,
    'w_M9': 5e-6,
    # Bias voltages
    'vbias_n': 0.42,   # Original NMOS bias (Vth + 0.2V = 0.42V)
    'vbias_p': 0.78,   # Original PMOS bias (Vdd - Vth - 0.2V = 0.78V)
    # Compensation capacitor
    'c_comp': 1.0,     # Original 1pF value
}
