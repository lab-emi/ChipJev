from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For tail current source M5
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For current source M7
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for differential input
# First Stage: Differential Pair with Active Load
# Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (M5)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier with Current Source Load
# Amplifier (M6)
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
# Current Source Load (M7)
circuit.MOSFET('7', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Third Stage: Source Follower (M8)
circuit.MOSFET('8', 'Vdd', 'Vout', 'Vout', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Compensation Network (Miller Capacitor + Resistor)
circuit.C('1', 'Vout', 'Drain2', 1@u_pF)  # Miller capacitor
circuit.R('1', 'Vout', 'Drain2', 1@u_kΩ)  # Series resistor with C1
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
