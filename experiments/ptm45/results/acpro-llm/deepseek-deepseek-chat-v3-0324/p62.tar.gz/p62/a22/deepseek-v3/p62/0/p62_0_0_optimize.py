from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    # Parameterized bias voltages (constrained to safe ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # Tail current bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # Output stage bias
    # Input Signals (fixed DC operating points)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed mid-rail differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed mid-rail differential input
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Current Source Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to 0.8-1.2× original but ≤1.2V and above Vth)
    'vbias1': {'min': 0.34, 'max': 0.5},  # Original: 0.42V (0.42*0.8=0.336, 0.42*1.2=0.504)
    'vbias2': {'min': 0.34, 'max': 0.5},  # Original: 0.42V
    # Differential pair transistors (Stage 1)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6 (1-500×L)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    # Active load PMOS (Stage 1)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    # Tail current source (Stage 1)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    # Output stage transistors (Stage 2)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 30e-6
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 15e-6
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,
    'vbias2': 0.42,
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 5e-6,
    'w_m6': 30e-6,
    'w_m7': 15e-6,
}
# Physical meaning of parameters:
# - vbias1: Tail current source bias voltage (affects input stage current)
# - vbias2: Output stage current source bias voltage (affects output stage current)
# - w_m1/w_m2: Input pair transistor widths (affects gm, gain, noise)
# - w_m3/w_m4: Active load transistor widths (affects gain, swing)
# - w_m5: Tail current transistor width (sets input stage current)
# - w_m6: Output PMOS width (affects output drive capability)
# - w_m7: Output NMOS width (affects output drive capability)
