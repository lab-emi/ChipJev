from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Op-Amp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For M5 (tail current)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For M7/M8 (current mirror)
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for DC bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Vx', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vy', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vx', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vy', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Vz', 'Vy', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vz', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vy', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Stage 3: Output Buffer
circuit.MOSFET('9', 'Vout', 'Vz', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Vz', 'Vout', 1@u_pF)
circuit.R('z', 'Vz', 'Vout_comp', 2@u_kΩ)
circuit.C('cz', 'Vout_comp', 'Vout', 1@u_pF)  # Optional: Additional filtering
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
