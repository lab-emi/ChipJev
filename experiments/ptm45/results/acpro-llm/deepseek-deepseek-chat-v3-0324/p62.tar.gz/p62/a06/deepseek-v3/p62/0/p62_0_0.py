from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42) # NMOS bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78) # PMOS bias (Vdd - Vth - 0.2V)
# Input Sources
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Common-mode input voltage
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Common-mode input voltage
# Stage 1: Differential Input Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Current Source Load
circuit.MOSFET('3', 'Drain3', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('8', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Stage 3: Output Buffer (Common-Drain)
circuit.MOSFET('4', 'Vdd', 'Drain3', 'Vout', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain3', 'Drain1', 1@u_pF)
circuit.R('c', 'Drain3', 'Drain1', 1@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
