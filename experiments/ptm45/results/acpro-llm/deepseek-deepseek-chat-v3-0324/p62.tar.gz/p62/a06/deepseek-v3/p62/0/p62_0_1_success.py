from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Multi-Stage Opamp (Corrected)')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies (Vth = 0.22V, Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - Vth - 0.2V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.3@u_V)   # Additional NMOS bias
# Input Signals (Common-mode = 0.6V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
#-------------------------------------------
# Stage 1: Differential Pair with Active Load
#-------------------------------------------
# NMOS Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'TailNode', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'TailNode', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source
circuit.MOSFET('5', 'TailNode', 'Vbias1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS Active Load (Diode-connected)
circuit.MOSFET('6', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
#-------------------------------------------
# Stage 2: Common-Source Amplifier
#-------------------------------------------
circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('8', 'Drain3', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=30e-6, l=0.045e-6)
#-------------------------------------------
# Stage 3: PMOS Output Stage (Corrected)
#-------------------------------------------
circuit.MOSFET('9', 'Vout', 'Drain3', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('10', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd,
               model='nmos_model', w=15e-6, l=0.045e-6)
#-------------------------------------------
# Compensation Network
#-------------------------------------------
circuit.C('c', 'Drain3', 'Drain2', 1@u_pF)  # Miller capacitor
circuit.R('c', 'Drain3', 'Drain2', 1@u_kΩ)  # Nulling resistor
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
