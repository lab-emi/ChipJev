from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp (Parameterized)')
    # MOSFET Models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V supply
    # Parameterized Bias Voltages (maintaining conservative ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # NMOS bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # PMOS bias
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)  # Additional NMOS bias
    # Input Signals (fixed values)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed common-mode
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed common-mode
    #-------------------------------------------
    # Stage 1: Differential Pair with Active Load
    #-------------------------------------------
    # NMOS Differential Pair
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'TailNode', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'TailNode', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Tail Current Source
    circuit.MOSFET('5', 'TailNode', 'Vbias1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # PMOS Active Load
    circuit.MOSFET('6', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M7'], l=0.045e-6)
    #-------------------------------------------
    # Stage 2: Common-Source Amplifier
    #-------------------------------------------
    circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('8', 'Drain3', 'Vbias2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    #-------------------------------------------
    # Stage 3: PMOS Output Stage
    #-------------------------------------------
    circuit.MOSFET('9', 'Vout', 'Drain3', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M9'], l=0.045e-6)
    circuit.MOSFET('10', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M10'], l=0.045e-6)
    #-------------------------------------------
    # Compensation Network (parameterized)
    #-------------------------------------------
    circuit.C('c', 'Drain3', 'Drain2', params['c_comp']@u_pF)  # Miller capacitor
    circuit.R('c', 'Drain3', 'Drain2', params['r_comp']@u_kΩ)  # Nulling resistor
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (0.8-1.2× original, but must be ≤1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # NMOS bias (Vth + 0.2V)
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # PMOS bias (Vdd - Vth - 0.2V)
    'vbias3': {'min': 0.3*0.8, 'max': min(0.3*1.2, 1.2)},    # Additional NMOS bias
    # Transistor Widths (1-500× length = 0.045μm-22.5μm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS 1
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage NMOS
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage PMOS
    'w_M9': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output stage PMOS
    'w_M10': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True}, # Output stage NMOS
    # Compensation Network
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # Miller cap: 0.5-5× original (pF)
    'r_comp': {'min': 0.5, 'max': 2.0, 'log': True},  # Nulling resistor: 0.5-2× original (kΩ)
}
# Initial parameter values (EXACTLY the original circuit values)
initial_params = {
    # Bias Voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    'vbias3': 0.3,
    # Transistor Widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M5': 20e-6,
    'w_M6': 20e-6,
    'w_M7': 20e-6,
    'w_M3': 30e-6,
    'w_M8': 30e-6,
    'w_M9': 40e-6,
    'w_M10': 15e-6,
    # Compensation Network
    'c_comp': 1.0,
    'r_comp': 1.0,
}
