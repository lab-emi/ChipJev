from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias_n', 'Vbias_n', circuit.gnd, params['vbias_n'])
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['vbias_p'])
    # Differential Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-rail for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-rail for differential input
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias_n', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M7'], l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Vout', 'Drain2', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages
    'vbias_n': {'min': 0.34, 'max': 0.50},  # 0.8-1.2×0.42V, NMOS tail bias (Vth=0.22V)
    'vbias_p': {'min': 0.62, 'max': 0.94},  # 0.8-1.2×0.78V, PMOS load bias (Vdd-|Vth|-0.2V)
    # Differential pair transistors (M1, M2)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    # PMOS current mirror load (M3, M4)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    # NMOS tail current source (M5)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    # Second stage transistors (M6, M7)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (45nm)
    # Compensation capacitor
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # 0.5-5× original 1pF value
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias_n': 0.42,   # Original NMOS bias voltage
    'vbias_p': 0.78,   # Original PMOS bias voltage
    'w_M1': 5e-6,      # Original M1 width
    'w_M2': 5e-6,      # Original M2 width
    'w_M3': 10e-6,     # Original M3 width
    'w_M4': 10e-6,     # Original M4 width
    'w_M5': 10e-6,     # Original M5 width
    'w_M6': 10e-6,     # Original M6 width
    'w_M7': 20e-6,     # Original M7 width
    'c_comp': 1.0,     # Original compensation capacitance (1pF)
}
