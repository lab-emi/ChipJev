Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['Vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['Vbias2'])
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Drain6', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain6', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M7'], l=0.045e-6)
    
    # Compensation Network (parameterized)
    circuit.C('c', 'Drain2', 'Vout', f"{params['C_comp']}p")
    circuit.R('c', 'Drain2', 'Vout', f"{params['R_comp']}")
    
    # Output Stage: Source Follower (parameterized)
    circuit.MOSFET('8', 'Vout', 'Drain6', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to 0.8-1.2× original values, not exceeding 1.2V)
    'Vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # M5 gate bias (Vth + 0.2V)
    'Vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # M7 gate bias (Vdd - |Vth| - 0.2V)
    
    # Stage 1 transistor widths (1-500× length = 45nm-22.5μm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS (Vinp)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS (Vinn)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS active load
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS active load
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current source
    
    # Stage 2 transistor widths
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Common-source NMOS
    'w_M7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS active load
    
    # Output stage transistor width
    'w_M8': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Source follower
    
    # Compensation network
    'C_comp': {'min': 0.5, 'max': 5, 'log': True},  # 0.5-5× original 1pF
    'R_comp': {'min': 500, 'max': 2000, 'log': True},  # 0.5-2× original 1kΩ
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'Vbias1': 0.42,
    'Vbias2': 0.78,
    
    # Stage 1 transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 10e-6,
    
    # Stage 2 transistor widths
    'w_M6': 20e-6,
    'w_M7': 20e-6,
    
    # Output stage transistor width
    'w_M8': 30e-6,
    
    # Compensation network
    'C_comp': 1.0,  # 1pF
    'R_comp': 1000,  # 1kΩ
}
```

### Parameter Descriptions:

1. **Bias Voltages**:
   - `Vbias1`: Gate bias voltage for M5 (tail current source), originally set to Vth + 0.2V
   - `Vbias2`: Gate bias voltage for M7 (PMOS load in second stage), originally set to Vdd - |Vth| - 0.2V

2. **Transistor Widths**:
   - `w_M1`, `w_M2`: Input differential pair NMOS widths
   - `w_M3`, `w_M4`: PMOS active load for differential pair
   - `w_M5`: Tail current source NMOS width
   - `w_M6`: Common-source amplifier NMOS width
   - `w_M7`: PMOS active load for second stage
   - `w_M8`: Output source follower PMOS width

3. **Compensation Network**:
   - `C_comp`: Miller compensation capacitor (critical for stability)
   - `R_comp`: Compensation resistor (helps with pole-zero cancellation)

All transistor lengths are fixed at 45nm (0.045μm) as per the 45nm technology node. The width ranges are set to 1-500× the length (45nm-22.5μm) to ensure reasonable device operation. The compensation components have wider ranges as they are typically tuned for stability and bandwidth optimization. All initial values match exactly the original circuit specifications.