from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Fully-Corrected Multi-Stage Opamp')
# MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Bias Voltages (carefully calculated)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5)   # Tail current (0.5V > Vth)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.8)   # PMOS mirror (Vdd-0.4V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.4)   # Level shifter bias
# Input Signals
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-rail input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-rail input
# Stage 1: Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('9', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with Level Shifting
circuit.MOSFET('10', 'Drain10', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('5', 'Drain5', 'Drain2', 'Source5', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('11', 'Source5', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 3: Properly Biased Output Stage
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Drain10', 'Vdd', 'Vdd', model='pmos_model', w=50e-6, l=0.045e-6)
# Compensation
circuit.C('c', 'Drain5', 'Vout', 1@u_pF)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
