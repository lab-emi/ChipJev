from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for differential pair
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for differential pair
    # Bias Generation (parameterized)
    circuit.V('bias_gen', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2']@u_V)
    # Stage 1: Differential Pair with Current Mirror Load
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Miller Compensation Capacitor (parameterized)
    circuit.C('c', 'Vout', 'Drain2', params['c_comp']@u_pF)
    # Bias Generator (parameterized)
    circuit.MOSFET('8', 'Vbias1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (conservative ranges to maintain proper operation)
    'v_bias1': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (0.8-1.2x, clamped to 1.2V)
    'v_bias2': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (0.8-1.2x, clamped to 1.2V)
    # Differential pair transistors
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10um (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10um (1-500×L)
    # Current mirror load transistors
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20um (1-500×L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20um (1-500×L)
    # Tail current source
    'w_M5': {'min': 0.045e-6, 'max': 2.25e-6, 'log': True},  # Original: 5um (1-500×L)
    # Second stage transistors
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 30um (1-500×L)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 15um (1-500×L)
    # Bias generator transistor
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10um (1-500×L)
    # Compensation capacitor (0.5-5× original)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_bias1': 0.42,
    'v_bias2': 0.42,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 30e-6,
    'w_M7': 15e-6,
    'w_M8': 10e-6,
    'c_comp': 1.0,
}
