from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Opamp (Final Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42@u_V)  # M8 bias (Vth + 0.2V)
circuit.V('bias_pmos', 'Vbias_pmos', circuit.gnd, 0.78@u_V)  # M6 bias (Vdd - |Vth| - 0.2V)
circuit.V('bias_out', 'Vbias_out', circuit.gnd, 0.42@u_V)    # Additional bias for output stage
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for differential input
# First Stage: Differential Pair + Active Load
circuit.MOSFET('1', 'Vmid1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vmid2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vmid1', 'Vmid1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vmid2', 'Vmid1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('8', 'Tail', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage: Common-Source + Weaker Current Source Load to boost Vmid3
circuit.MOSFET('5', 'Vmid3', 'Vmid2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vmid3', 'Vbias_pmos', 'Vdd', 'Vdd', model='pmos_model', w=4e-6, l=0.045e-6)  # Reduced width
# Third Stage: Properly Biased Source Follower
circuit.MOSFET('7', 'Vdd', 'Vmid3', 'Vout', circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vout', 'Vbias_out', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # Output current source
# Compensation Network
circuit.C('c', 'Vmid2', 'Vmid3', 1@u_pF)  # Miller capacitor
circuit.R('c', 'Vmid2', 'Vmid3', 10@u_kΩ)  # Compensation resistor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
