from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Ensure 'model.py' exists
circuit = Circuit('Multi-Stage Opamp')
# Define MOSFET models explicitly
circuit.model('nmos_model', 'nmos', **nmos_params)  # Vth=0.22V
circuit.model('pmos_model', 'pmos', **pmos_params)  # |Vth|=0.22V
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Adjusted for proper operation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # M5: Vth + 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # M7: Vdd - |Vth| - 0.2V
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.7@u_V)   # Higher bias for M8 activation
# Input Signals (Set to mid-rail for symmetry)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  
# Stage 1: Differential Pair
circuit.MOSFET('1', 'Diff_out_p', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Diff_out_n', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Diff_out_p', 'Diff_out_n', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Diff_out_n', 'Diff_out_n', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('6', 'CS_out', 'Diff_out_p', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('7', 'CS_out', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Stage 3: Class-AB Output (Critical Fixes)
# Fix 1: Ensure V_GS > Vth for NMOS M8 by increasing gate voltage (CS_out)
circuit.MOSFET('8', 'Vdd', 'CS_out', 'Vout', circuit.gnd, model='nmos_model', w=100e-6, l=0.045e-6)
# Fix 2: Ensure V_SG > |Vth| for PMOS M9 by setting gate voltage < source
circuit.MOSFET('9', circuit.gnd, 'CS_out', 'Vout', 'Vdd', model='pmos_model', w=200e-6, l=0.045e-6)
# Compensation
circuit.C('c', 'CS_out', 'Diff_out_n', 1@u_pF)
circuit.R('c', 'CS_out', 'Diff_out_n', 1@u_kΩ)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
