from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Multi-Stage Opamp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V supply
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.22 + 0.2)  # M5 bias (0.42V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 1.2 - 0.22 - 0.2)  # M7 bias (0.78V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.6)  # Class-AB bias (mid-rail)
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-rail for symmetry
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-rail for symmetry
# Stage 1: Differential Pair
circuit.MOSFET('1', 'Diff_out_p', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Diff_out_n', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Diff_out_p', 'Diff_out_n', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Diff_out_n', 'Diff_out_n', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('6', 'CS_out', 'Diff_out_p', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('7', 'CS_out', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Stage 3: Class-AB Output
circuit.MOSFET('8', 'Vdd', 'CS_out', 'Vout', 'Vout', model='nmos_model', w=100e-6, l=0.045e-6)
circuit.MOSFET('9', circuit.gnd, 'CS_out', 'Vout', 'Vout', model='pmos_model', w=200e-6, l=0.045e-6)
# Compensation
circuit.C('c', 'CS_out', 'Diff_out_n', 1@u_pF)
circuit.R('c', 'CS_out', 'Diff_out_n', 1@u_kΩ)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
