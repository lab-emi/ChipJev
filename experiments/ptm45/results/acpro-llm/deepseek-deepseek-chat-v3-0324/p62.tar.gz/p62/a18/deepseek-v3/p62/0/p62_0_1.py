from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Three-Stage Op-Amp with Corrected Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS bias
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for DC
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for DC
# First Stage: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier
circuit.MOSFET('6', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
# Bias Network for Third Stage (Critical Fix)
circuit.MOSFET('10', 'BiasNode', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('11', 'BiasNode', 'BiasNode', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Third Stage: Properly Biased Output Stage
circuit.MOSFET('8', 'Vout', 'BiasNode', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # Increased width
circuit.MOSFET('9', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=60e-6, l=0.045e-6)  # Increased width
# Miller Compensation (Adjusted Values)
circuit.C('c', 'Drain3', 'Vout', 1@u_pF)  # Reduced for stability
circuit.R('c', 'Drain3', 'NodeRc', 1@u_kΩ)
circuit.C('L', 'Vout', circuit.gnd, 5@u_pF)  # Load capacitor
# Simulator Setup
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
