from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Stable Three-Stage Op-Amp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)  # Increased slightly for better biasing
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.75@u_V)  # Adjusted PMOS bias
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# First Stage: Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=7.5e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier
circuit.MOSFET('6', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Third Stage: Output Buffer with Proper Biasing
circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=80e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain3', 'Vout', 1.5@u_pF)
circuit.R('c', 'Drain3', 'NodeRc', 1.5@u_kΩ)
circuit.C('L', 'Vout', circuit.gnd, 5@u_pF)
# Additional Bias Current Path (Critical Fix)
circuit.MOSFET('10', 'BiasNode', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('11', 'BiasNode', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Simulator Setup
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
