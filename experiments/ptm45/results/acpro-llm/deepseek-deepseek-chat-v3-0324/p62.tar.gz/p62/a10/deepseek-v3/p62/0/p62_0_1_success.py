from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Multi-Stage Opamp (Corrected)')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
# Input and Bias Voltages (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for DC
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for DC
circuit.V('bias_nmos', 'Vbias_nmos', circuit.gnd, 0.42@u_V)  # NMOS bias (Vth + 0.2V)
circuit.V('bias_pmos', 'Vbias_pmos', circuit.gnd, 0.98@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source12', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source12', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source12', 'Vbias_nmos', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source with Active Load (M6-M7)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # PMOS driver
circuit.MOSFET('7', 'Vout', 'Vbias_nmos', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)  # NMOS load
# Compensation Network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)  # Miller capacitor
circuit.R('c', 'Drain2', 'Node1', 1@u_kΩ)  # Nulling resistor
circuit.C('c1', 'Node1', 'Vout', 1@u_pF)  # Optional: Splits Cc for stability
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
