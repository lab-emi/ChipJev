from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp (Parameterized)')
    # MOSFET Models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply fixed
    # Input and Bias Voltages (fixed for inputs, parameterized for biases)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply fixed
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply fixed
    circuit.V('bias_nmos', 'Vbias_nmos', circuit.gnd, params['vbias_nmos']@u_V)  # NMOS bias
    circuit.V('bias_pmos', 'Vbias_pmos', circuit.gnd, params['vbias_pmos']@u_V)  # PMOS bias
    # Stage 1: Differential Pair with Active Load (transistor widths parameterized)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source12', 'Vbias_nmos', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Stage 2: Common-Source (transistor widths parameterized)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias_nmos', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m7'], l=0.045e-6)
    # Compensation Network (parameterized)
    circuit.C('c', 'Drain2', 'Vout', f"{params['cc']}p")  # Miller capacitor
    circuit.R('c', 'Drain2', 'Node1', f"{params['rc']}k")  # Nulling resistor
    circuit.C('c1', 'Node1', 'Vout', 1@u_pF)  # Fixed as per requirements
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (conservative ranges around original values)
    'vbias_nmos': {'min': 0.38, 'max': 0.46},  # Original: 0.42V (slightly below Vdd/2)
    'vbias_pmos': {'min': 0.85, 'max': 1.15},  # Original: 0.98V (Vdd - |Vth| - 0.2V)
    # Transistor Widths (1-500× length = 45nm-22.5µm range, log scale)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width
    # Compensation Network (0.5-5× original values)
    'cc': {'min': 0.5, 'max': 5},  # Miller cap (original: 1pF)
    'rc': {'min': 0.5, 'max': 2},  # Nulling resistor (original: 1kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'vbias_nmos': 0.42,  # Original NMOS bias
    'vbias_pmos': 0.98,  # Original PMOS bias
    # Transistor Widths
    'w_m1': 10e-6,  # M1
    'w_m2': 10e-6,  # M2
    'w_m3': 20e-6,  # M3
    'w_m4': 20e-6,  # M4
    'w_m5': 5e-6,   # M5
    'w_m6': 40e-6,  # M6
    'w_m7': 20e-6,  # M7
    # Compensation Network
    'cc': 1.0,  # Cc
    'rc': 1.0,  # Rc
}
