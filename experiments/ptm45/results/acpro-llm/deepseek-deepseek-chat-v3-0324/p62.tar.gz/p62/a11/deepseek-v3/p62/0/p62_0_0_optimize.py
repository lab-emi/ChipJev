from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('biasn', 'Vbiasn', circuit.gnd, params['v_biasn'])
    circuit.V('biasp', 'Vbiasp', circuit.gnd, params['v_biasp'])
    # Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-rail for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-rail for differential input
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Tail', 'Vbiasn', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier
    circuit.MOSFET('6', 'Vout', 'Drain1', 'Source6', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Current Sources for Stage 2
    circuit.MOSFET('8', 'Source6', 'Vbiasp', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    circuit.MOSFET('9', 'Vout', 'Vbiasp', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M9'], l=0.045e-6)
    # Compensation Network (parameterized)
    circuit.C('c', 'Vout', 'Drain1', f"{params['c_miller']}p")
    circuit.R('c', 'Vout', 'NodeRc', f"{params['r_comp']}k")
    circuit.C('c2', 'NodeRc', 'Drain1', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to stay near original operating point)
    'v_biasn': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth + 0.2V ± 0.08V)
    'v_biasp': {'min': 0.70, 'max': 0.86},  # Original: 0.78V (Vdd-Vth-0.2V ± 0.08V)
    # Differential pair and active load transistors (Stage 1)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6, 1-500×L
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6, 1-500×L
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6, 1-500×L
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6, 1-500×L
    'w_M5': {'min': 0.045e-6, 'max': 2.25e-6, 'log': True},  # Original: 5e-6, 1-500×L
    # Common-source amplifier (Stage 2)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 40e-6, 1-500×L
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6, 1-500×L
    # Current sources (Stage 2)
    'w_M8': {'min': 0.045e-6, 'max': 5e-6, 'log': True},     # Original: 10e-6, 1-500×L
    'w_M9': {'min': 0.045e-6, 'max': 5e-6, 'log': True},     # Original: 10e-6, 1-500×L
    # Compensation network
    'c_miller': {'min': 0.5, 'max': 5, 'log': True},         # Original: 1pF, 0.5-5×
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},           # Original: 1kΩ, 0.5-2×
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},           # Original: 1pF, 0.5-5×
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_biasn': 0.42,
    'v_biasp': 0.78,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 40e-6,
    'w_M7': 20e-6,
    'w_M8': 10e-6,
    'w_M9': 10e-6,
    'c_miller': 1,
    'r_comp': 1,
    'c_comp': 1,
}
