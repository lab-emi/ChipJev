from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for DC operating point
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for DC operating point
    # Stage 1: Differential Pair
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 1: Active Load (PMOS Current Mirror)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier
    circuit.MOSFET('7', 'Vout', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M8'], l=0.045e-6)
    # Compensation (parameterized)
    circuit.C('c', 'Vout', 'Drain1', f"{params['Cc']}p")
    circuit.R('c', 'Vout', 'NodeRc', f"{params['Rc']}k")
    circuit.C('c2', 'NodeRc', 'Drain1', f"{params['Cc2']}p")  # Splitting Rc and Cc for numerical stability
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage NMOS
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage PMOS
    # Bias voltages (0.8-1.2× original but constrained by Vth=0.22V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original 0.42V (Vth + 0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (Vdd - |Vth| - 0.2V)
    # Compensation network
    'Cc': {'min': 0.5, 'max': 5.0, 'log': True},    # Main compensation cap (original 1pF)
    'Cc2': {'min': 0.5, 'max': 5.0, 'log': True},   # Split compensation cap (original 1pF)
    'Rc': {'min': 0.5, 'max': 2.0, 'log': True},    # Compensation resistor (original 1kΩ)
}
# Physical meaning of each parameter:
# w_M1, w_M2 - Input pair transistor widths (affects gm and matching)
# w_M3, w_M4 - Current mirror load widths (sets first stage gain)
# w_M5 - Tail current source width (sets bias current)
# w_M7 - Second stage NMOS width (main gain element)
# w_M8 - Second stage PMOS width (active load)
# vbias1 - Tail current source bias (sets operating current)
# vbias2 - Second stage PMOS bias (sets output operating point)
# Cc, Cc2 - Compensation capacitors (sets stability and bandwidth)
# Rc - Compensation resistor (helps with right-half-plane zero)
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (µm)
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M7': 20e-6,
    'w_M8': 10e-6,
    # Bias voltages (V)
    'vbias1': 0.42,
    'vbias2': 0.78,
    # Compensation network
    'Cc': 1.0,      # pF
    'Cc2': 1.0,     # pF
    'Rc': 1.0,      # kΩ
}
