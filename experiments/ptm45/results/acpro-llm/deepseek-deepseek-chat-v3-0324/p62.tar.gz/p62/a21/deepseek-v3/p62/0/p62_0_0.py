from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42) # Bias for M5 and M7
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78) # Bias for M8 (if used)
# Input Signals
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Common-mode input voltage (mid-supply)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Common-mode input voltage (mid-supply)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Vout', 'Drain2', 1@u_pF)
circuit.R('c', 'Vout', 'Node1', 1@u_kΩ)
circuit.C('c2', 'Node1', 'Drain2', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
