from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters (assumed to be predefined in model.py)
circuit = Circuit('Multi-Stage Opamp')
# --- Define MOSFET Models ---
# Explicitly define nmos and pmos models instead of just importing parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# --- Power Supply ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# --- Bias Voltages ---
# Fixed: Ensure proper biasing (Vth = 0.22V, so bias voltages are Vth + 0.2V for overdrive)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For NMOS current sources (M5, M7)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For PMOS (if used)
# --- Input Signals (DC bias for operating point analysis) ---
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply (1.2V/2)  
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for common-mode
# --- Stage 1: Differential Pair with Active Load ---
# NMOS differential pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS active load (M3, M4) - diode-connected M3
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail current source (M5)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# --- Stage 2: Common-Source Amplifier with Active Load ---
# PMOS amplifying transistor (M6)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# NMOS active load (M7)
circuit.MOSFET('7', 'Vout', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# --- Compensation Network (Miller Compensation) ---
circuit.C('c', 'Vout', 'Drain2', 1@u_pF)  # Compensation capacitor
circuit.R('z', 'Vout', 'Node1', 1@u_kΩ)   # Zero-resistor (optional for phase margin)
circuit.C('cz', 'Node1', 'Drain2', 0.1@u_pF)  # Optional for pole-zero cancellation
# --- Analysis ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
