from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # --- Power Supply (fixed) ---
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # --- Bias Voltages (parameterized) ---
    # Original values: 0.42V (Vbias1) and 0.78V (Vbias2)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    # --- Input Signals (fixed) ---
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # --- Stage 1: Differential Pair with Active Load ---
    # NMOS differential pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # PMOS active load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail current source (M5)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # --- Stage 2: Common-Source Amplifier with Active Load ---
    # PMOS amplifying transistor (M6)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # NMOS active load (M7)
    circuit.MOSFET('7', 'Vout', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # --- Compensation Network ---
    circuit.C('c', 'Vout', 'Drain2', params['c_comp']@u_pF)
    circuit.R('z', 'Vout', 'Node1', params['r_z']@u_kΩ)
    circuit.C('cz', 'Node1', 'Drain2', params['c_z']@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, logarithmic scale)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair transistor 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load transistor 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load transistor 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage PMOS
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage NMOS load
    # Bias voltages (0.8-1.2× original, max 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (NMOS bias)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (PMOS bias)
    # Compensation network components
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # Main compensation cap (original: 1pF)
    'r_z': {'min': 0.5, 'max': 2.0, 'log': True},     # Zero resistor (original: 1kΩ)
    'c_z': {'min': 0.05, 'max': 0.15, 'log': True},   # Zero cap (original: 0.1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,
    'w_M2': 5e-6,
    'w_M3': 10e-6,
    'w_M4': 10e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
    'w_M7': 10e-6,
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    # Compensation network
    'c_comp': 1.0,
    'r_z': 1.0,
    'c_z': 0.1,
}
