Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    
    # Differential Inputs (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for operating point
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for operating point
    
    # Stage 1: Differential Pair with Current Mirror Load (all widths parameterized)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('7', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width: 1-500× length
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width: 1-500× length
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width: 1-500× length
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width: 1-500× length
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width: 1-500× length
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width: 1-500× length
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width: 1-500× length
    
    # Bias voltage (original was 0.42V - Vth + 0.2V)
    'vbias': {'min': 0.35, 'max': 0.5},  # Conservative range around original bias
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original M1 width
    'w_M2': 10e-6,    # Original M2 width
    'w_M3': 20e-6,    # Original M3 width
    'w_M4': 20e-6,    # Original M4 width
    'w_M5': 5e-6,     # Original M5 width
    'w_M6': 10e-6,    # Original M6 width
    'w_M7': 20e-6,    # Original M7 width
    'vbias': 0.42,    # Original bias voltage (Vth + 0.2V)
}

# Parameter descriptions
param_descriptions = {
    'w_M1': 'Width of NMOS differential pair transistor M1',
    'w_M2': 'Width of NMOS differential pair transistor M2',
    'w_M3': 'Width of PMOS current mirror load transistor M3',
    'w_M4': 'Width of PMOS current mirror load transistor M4',
    'w_M5': 'Width of NMOS tail current transistor M5',
    'w_M6': 'Width of PMOS active load transistor M6 (stage 2)',
    'w_M7': 'Width of NMOS common-source transistor M7 (stage 2)',
    'vbias': 'Bias voltage for tail current and active load',
}
```

Key features of this implementation:

1. All transistor widths are parameterized with appropriate search ranges (1-500× length, keeping L fixed at 45nm)
2. Bias voltage is parameterized with a conservative range around the original value (0.35-0.5V)
3. Power supply (1.2V) and input voltages (0.6V) remain fixed as requested
4. All initial parameter values exactly match the original circuit values
5. The function is named `create_circuit` as required
6. Parameter ranges are defined with logarithmic scaling for transistor widths (common practice for device optimization)
7. The bias voltage range is constrained to stay within reasonable operating conditions (above threshold but below supply voltage)

Note that there were no resistors or capacitors in your original circuit that needed parameterization. If you have any load capacitors that you omitted from the example, they would remain fixed as per your requirements.