from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Opamp')
# Define MOSFET models (since 'from model import...' may not work)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Example NMOS params
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Example PMOS params
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # NMOS bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # PMOS bias (Vdd - |Vth| - 0.2V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-range DC input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-range DC input (for differential pair)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)  # Tail current
# Active Load (PMOS cross-coupled)
circuit.MOSFET('6', 'Drain1', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
circuit.MOSFET('3', 'Drain3', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('8', 'Drain3', 'Drain3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('9', 'Vout', 'Drain3', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Active load
# Output Stage (M4 for symmetry)
circuit.MOSFET('4', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
