Vdd Vdd 0 1.2
Vbias1 Vbias1 0 0.42
Vbias2 Vbias2 0 0.78
Vinp Vinp 0 0.6
Vinn Vinn 0 0.6
M1 Drain1 Vinp SourcePair 0 nmos_model l=4.5e-08 w=1e-05
M2 Drain2 Vinn SourcePair 0 nmos_model l=4.5e-08 w=1e-05
M5 SourcePair Vbias1 0 0 nmos_model l=4.5e-08 w=2e-05
M6 Drain1 Drain2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M7 Drain2 Drain1 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M3 Drain3 Drain1 0 0 nmos_model l=4.5e-08 w=2e-05
M8 Drain3 Drain3 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M9 Vout Drain3 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M4 Vout Drain2 0 0 nmos_model l=4.5e-08 w=2e-05
.model nmos_model nmos (kp=0.0001 level=1 vto=0.22)
.model pmos_model pmos (kp=5e-05 level=1 vto=-0.22)

