Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # NMOS bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS bias
    
    # Input Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed mid-range DC input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed mid-range DC input
    
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)  # Tail current
    
    # Active Load (PMOS cross-coupled)
    circuit.MOSFET('6', 'Drain1', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M7'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('3', 'Drain3', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('8', 'Drain3', 'Drain3', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)  # Diode-connected
    circuit.MOSFET('9', 'Vout', 'Drain3', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M9'], l=0.045e-6)  # Active load
    
    # Output Stage
    circuit.MOSFET('4', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M4'], l=0.045e-6)
    
    return circuit


# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2), 'log': False},  # NMOS bias voltage (V)
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2), 'log': False},  # PMOS bias voltage (V)
    
    # Differential pair transistors (W only, L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Input NMOS width (m)
    'w_M2': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Input NMOS width (m)
    'w_M5': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Tail current NMOS width (m)
    
    # Active load transistors (PMOS)
    'w_M6': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Cross-coupled PMOS width (m)
    'w_M7': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Cross-coupled PMOS width (m)
    
    # Second stage transistors
    'w_M3': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # CS stage NMOS width (m)
    'w_M8': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Diode-connected PMOS width (m)
    'w_M9': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Active load PMOS width (m)
    
    # Output stage transistor
    'w_M4': {'min': 0.045e-6, 'max': 500*0.045e-6, 'log': True},  # Output NMOS width (m)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.42,  # Original NMOS bias voltage
    'vbias2': 0.78,  # Original PMOS bias voltage
    
    # Transistor widths (all in meters)
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M5': 20e-6,
    'w_M6': 20e-6,
    'w_M7': 20e-6,
    'w_M3': 20e-6,
    'w_M8': 10e-6,
    'w_M9': 20e-6,
    'w_M4': 20e-6,
}
```

### Parameter Descriptions:
1. **Bias Voltages**:
   - `vbias1`: NMOS bias voltage (original 0.42V) - constrained to ±20% to stay near intended operating point
   - `vbias2`: PMOS bias voltage (original 0.78V) - constrained to ±20% and capped at 1.2V

2. **Transistor Widths** (all lengths fixed at 45nm):
   - `w_M1`, `w_M2`: Input differential pair NMOS widths (original 10μm)
   - `w_M5`: Tail current NMOS width (original 20μm)
   - `w_M6`, `w_M7`: Cross-coupled PMOS active load widths (original 20μm)
   - `w_M3`: Common-source stage NMOS width (original 20μm)
   - `w_M8`: Diode-connected PMOS width (original 10μm)
   - `w_M9`: Active load PMOS width (original 20μm)
   - `w_M4`: Output stage NMOS width (original 20μm)

All widths have a search range of 1-500× the length (45nm-22.5μm) with logarithmic scaling for better optimization of wide dynamic range.

The initial parameters exactly match the original circuit values, and all ranges are properly constrained to maintain reasonable circuit operation during optimization. The power supply and input voltages remain fixed as specified.