from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Opamp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42) # For NMOS current source (M5)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78) # For PMOS current source (M7)
# Input Signals (DC bias for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-supply for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-supply for differential input
# First Stage: Differential Pair with Active Load
# Differential Pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Current Mirror Load (PMOS)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage: Common-Source with Current Source Load
# Amplifier (NMOS)
circuit.MOSFET('6', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Current Source Load (PMOS)
circuit.MOSFET('7', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Third Stage: Common-Source with Resistor Load
# Amplifier (NMOS)
circuit.MOSFET('8', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Resistor Load
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
