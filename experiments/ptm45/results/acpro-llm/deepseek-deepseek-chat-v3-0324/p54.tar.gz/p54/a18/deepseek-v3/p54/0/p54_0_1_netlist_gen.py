from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters (assumed to be predefined elsewhere)
circuit = Circuit('Three-Stage Opamp')
# Define MOSFET models (FIX: Add model definitions)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Example NMOS params
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Example PMOS params
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
# Bias Voltages (FIX: Added units)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For NMOS M5 (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For PMOS M7 (Vdd - |Vth| - 0.2V)
# Input Signals (FIX: Added units and differential bias)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply DC bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply DC bias
# --- Stage 1: Differential Pair with Active Load ---
# NMOS Differential Pair (FIX: Bulk connected to ground)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS Current Mirror Load (FIX: Bulk connected to Vdd)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# NMOS Tail Current Source (FIX: Bulk connected to ground)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# --- Stage 2: Common-Source with Current Source Load ---
# NMOS Amplifier (FIX: Bulk connected to ground)
circuit.MOSFET('6', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS Current Source Load (FIX: Bulk connected to Vdd)
circuit.MOSFET('7', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# --- Stage 3: Common-Source with Resistor Load ---
# NMOS Amplifier (FIX: Bulk connected to ground)
circuit.MOSFET('8', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Resistor Load (FIX: Corrected unit syntax)
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
