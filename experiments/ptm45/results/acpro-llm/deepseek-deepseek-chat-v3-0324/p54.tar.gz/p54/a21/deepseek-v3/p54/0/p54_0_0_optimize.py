from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Differential input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Differential input (fixed)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']) # Bias for M5
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']) # Bias for M7
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']) # Bias for M8
    # First Stage: Differential Pair with Active Load
    # Differential Pair (NMOS)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Active Load (PMOS)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (NMOS)
    circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Second Stage: Common-Source Amplifier with Active Load
    # Amplifying Transistor (PMOS)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Current Source Load (NMOS)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Biasing for M7 (PMOS)
    circuit.MOSFET('8', 'Vbias2', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M8'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, where L=45nm)
    # Differential pair and current mirror transistors
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M8 width
    # Bias voltages (0.8-1.2× original value, but never exceeding 1.2V)
    # Original values calculated with Vth = 0.22V
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (Vth + 0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd-Vth-0.2V)
    'vbias3': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (Vth + 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values in meters)
    'w_M1': 10e-6,  # M1 original width
    'w_M2': 10e-6,  # M2 original width
    'w_M3': 20e-6,  # M3 original width
    'w_M4': 20e-6,  # M4 original width
    'w_M5': 10e-6,  # M5 original width
    'w_M6': 20e-6,  # M6 original width
    'w_M7': 10e-6,  # M7 original width
    'w_M8': 10e-6,  # M8 original width
    # Bias voltages
    'vbias1': 0.42,  # Original Vbias1 value
    'vbias2': 0.78,  # Original Vbias2 value
    'vbias3': 0.42,  # Original Vbias3 value
}
