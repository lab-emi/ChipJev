Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # Tail current bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # Second stage load bias
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed mid-supply for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed mid-supply for differential input
    
    # Stage 1: Differential Pair with Active Load (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load (parameterized widths)
    circuit.MOSFET('7', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m7'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (0.8-1.2× original but <=1.2V, conservative to maintain operation)
    'vbias1': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth+0.2V)
    'vbias2': {'min': 0.62, 'max': 0.94},  # Original: 0.78V (Vdd-|Vth|-0.2V)
    
    # Differential Pair (M1-M2) - keep symmetry by using same range
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
    
    # Current Mirror Load (M3-M4) - keep symmetry by using same range
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
    
    # Tail Current (M5)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
    
    # Second Stage (M6-M7)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'vbias1': 0.42,   # Original tail current bias
    'vbias2': 0.78,   # Original second stage load bias
    
    # Transistor widths (in meters)
    'w_m1': 5e-6,     # Differential pair NMOS
    'w_m2': 5e-6,     # Differential pair NMOS
    'w_m3': 10e-6,    # Current mirror PMOS
    'w_m4': 10e-6,    # Current mirror PMOS
    'w_m5': 10e-6,    # Tail current NMOS
    'w_m6': 20e-6,    # Active load PMOS
    'w_m7': 10e-6,    # Common-source NMOS
}
```

### Parameter Descriptions:
1. **Bias Voltages**:
   - `vbias1`: Tail current bias voltage (originally Vth + 0.2V = 0.42V)
   - `vbias2`: Second stage load bias voltage (originally Vdd - |Vth| - 0.2V = 0.78V)

2. **Transistor Widths**:
   - `w_m1`, `w_m2`: Input differential pair NMOS widths
   - `w_m3`, `w_m4`: Current mirror load PMOS widths (should maintain matching)
   - `w_m5`: Tail current source NMOS width (sets bias current)
   - `w_m6`: Second stage active load PMOS width
   - `w_m7`: Second stage driver NMOS width

### Key Features:
- All transistor lengths (`l`) are fixed at 45nm (0.045µm)
- Width ranges are set to 1-500× the channel length (45nm-22.5µm)
- Bias voltage ranges are conservative (±20% of original) while staying within 1.2V supply
- Logarithmic scaling enabled for transistor widths (common for device sizing optimization)
- Initial parameters exactly match your original circuit values
- Power supply and input voltages remain fixed as requested
- No load capacitors were included in your original circuit code