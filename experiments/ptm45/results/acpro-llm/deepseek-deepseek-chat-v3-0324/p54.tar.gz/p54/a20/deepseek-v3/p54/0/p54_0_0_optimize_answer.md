Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['v_bias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['v_bias2']}V")
    
    # Input Signals (DC operating point - fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Stage 1: Differential Pair with Active Load
    # Differential Pair (NMOS)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Tail Current Source (NMOS)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load (PMOS Current Mirror)
    circuit.MOSFET('6', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M7'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    # Common-Source Amplifier (NMOS)
    circuit.MOSFET('3', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    # Active Load (PMOS)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5μm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    
    # Bias voltages (0.8-1.2× original, but limited to 1.2V max)
    'v_bias1': {'min': 0.336, 'max': 0.504, 'log': False},  # Original: 0.42V
    'v_bias2': {'min': 0.624, 'max': 0.936, 'log': False},  # Original: 0.78V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 20e-6,
    'w_M7': 20e-6,
    'w_M8': 20e-6,
    
    # Bias voltages
    'v_bias1': 0.42,
    'v_bias2': 0.78,
}
```

### Explanation:

1. **Transistor Widths**:
   - All MOSFET widths are parameterized with ranges from 1× to 500× the length (45nm to 22.5μm)
   - The original values are maintained in initial_params
   - Length is fixed at 45nm (technology constraint)

2. **Bias Voltages**:
   - Vbias1 (tail current) range: 0.336V to 0.504V (0.8-1.2× original 0.42V)
   - Vbias2 (active load) range: 0.624V to 0.936V (0.8-1.2× original 0.78V)
   - Ranges are conservative to keep operation in saturation

3. **Fixed Parameters**:
   - Supply voltage (Vdd) fixed at 1.2V
   - Input voltages (Vinp, Vinn) fixed at 0.6V (mid-range)
   - MOSFET length fixed at 45nm
   - No capacitors were in the original netlist, so none are parameterized

4. **Constraints**:
   - All voltage parameters are ≤ 1.2V (supply voltage)
   - Bias voltages are constrained to sensible ranges considering Vth=0.22V
   - Widths maintain reasonable aspect ratios (1-500× length)

The function is named exactly as required (`create_circuit`) and maintains all original values in `initial_params`. The search ranges are designed to allow meaningful optimization while preventing unrealistic values that would break circuit operation.