from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Bias for M5 (tail current)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Bias for M8 (active load)
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # DC bias for Vinp
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # DC bias for Vinn
# Stage 1: Differential Pair with Active Load
# Differential Pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
circuit.MOSFET('6', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
# Common-Source Amplifier (NMOS)
circuit.MOSFET('3', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (PMOS)
circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
