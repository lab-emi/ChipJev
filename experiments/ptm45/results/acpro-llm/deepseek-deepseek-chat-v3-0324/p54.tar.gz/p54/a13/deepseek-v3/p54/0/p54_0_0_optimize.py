from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # NMOS tail current source
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS current source
    # Input Signals (fixed, DC operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for differential input
    # Stage 1: Differential Pair with Active Load
    # Differential Pair
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Current Mirror Load
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source
    circuit.MOSFET('9', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M9'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5µm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input pair M1 width
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input pair M2 width
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load M3 width
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load M4 width
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # CS stage M5 width
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load M6 width
    'w_M9': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current M9 width
    # Bias Voltages (0.8-1.2× original but never exceeding 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original 0.42V (Vth_n + 0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (Vdd - |Vth_p| - 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
    'w_M6': 10e-6,
    'w_M9': 5e-6,
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
}
