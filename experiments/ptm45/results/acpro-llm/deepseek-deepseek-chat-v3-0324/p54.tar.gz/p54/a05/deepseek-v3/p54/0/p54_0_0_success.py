from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42) # Bias for tail current source (Vth + 0.2V)
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-supply for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-supply for differential input
# Stage 1: Differential Pair with Active Load
# Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (M8)
circuit.MOSFET('8', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
# Amplifying Transistor (M5)
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (M7)
circuit.MOSFET('7', 'Vout', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
