Here's the parameterized implementation of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply (fixed)
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    
    # Input Signals (fixed DC operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-supply for differential input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-supply for differential input (fixed)
    
    # Stage 1: Differential Pair with Active Load
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'],
                  l=0.045e-6)  # Fixed length for 45nm technology
    
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model',
                  w=params['w_M2'],
                  l=0.045e-6)  # Fixed length
    
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M3'],
                  l=0.045e-6)
    
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M4'],
                  l=0.045e-6)
    
    # Tail Current Source (M8)
    circuit.MOSFET('8', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd,
                  model='nmos_model',
                  w=params['w_M8'],
                  l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    # Amplifying Transistor (M5)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model',
                  w=params['w_M5'],
                  l=0.045e-6)
    
    # Active Load (M7)
    circuit.MOSFET('7', 'Vout', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M7'],
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, length=45nm => min=45nm, max=22.5μm)
    # Differential pair transistors
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width
    
    # PMOS active load transistors
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width
    
    # Tail current source
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M8 width
    
    # Stage 2 transistors
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width
    
    # Bias voltage (conservative range around original value)
    'vbias': {'min': 0.34, 'max': 0.5},  # Original 0.42V, 0.8-1.2× range limited to 1.2V max
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,   # Original M1 width
    'w_M2': 10e-6,   # Original M2 width
    'w_M3': 20e-6,   # Original M3 width
    'w_M4': 20e-6,   # Original M4 width
    'w_M8': 5e-6,    # Original M8 width
    'w_M5': 20e-6,   # Original M5 width
    'w_M7': 20e-6,   # Original M7 width
    
    # Bias voltage
    'vbias': 0.42,   # Original Vbias value
}
```

### Physical Meaning of Each Parameter:
1. **Transistor Widths (w_M1-w_M8)**:
   - Controls current drive capability and transconductance of each transistor
   - M1/M2 form the input differential pair - their sizing affects input noise and offset
   - M3/M4 form the active load - affects gain of first stage
   - M8 sets the tail current - affects power consumption and slew rate
   - M5 is the second stage amplifier - affects gain-bandwidth product
   - M7 is the second stage active load - affects output swing and gain

2. **Bias Voltage (vbias)**:
   - Sets the current through the tail current source (M8)
   - Affects the overall bias current and power consumption
   - Must be above threshold voltage (Vth=0.22V) to keep M8 in saturation
   - Conservative range (0.34-0.5V) ensures safe operation with Vdd=1.2V

### Notes:
- All initial values are exactly preserved from the original circuit
- All parameter ranges are set according to the specified constraints
- Transistor lengths are fixed at 45nm (technology minimum)
- Width ranges are set to 1-500× the minimum length (45nm-22.5μm)
- Bias voltage range is conservative (0.8-1.2× original) but limited to safe operating values
- Input voltages remain fixed at mid-supply (0.6V)
- Power supply remains fixed at 1.2V
- No load capacitors were present in the original circuit, so none were parameterized