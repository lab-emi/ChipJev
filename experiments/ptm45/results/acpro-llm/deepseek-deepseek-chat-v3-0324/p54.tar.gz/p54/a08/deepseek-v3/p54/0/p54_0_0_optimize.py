from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']) # Bias for tail current source (M5)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']) # Bias for active load (M7)
    # Input Sources (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Input voltage Vinp (midpoint for DC analysis)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Input voltage Vinn (midpoint for DC analysis)
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain4', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain4', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m7'], l=0.045e-6)
    # Compensation Network (parameterized)
    circuit.C('c', 'Drain2', 'Vout', f"{params['c_comp']}p") # Compensation capacitor
    circuit.R('c', 'Drain2', 'Node1', f"{params['r_comp']}") # Nulling resistor
    circuit.C('c2', 'Node1', 'Vout', f"{1}e-12") # Additional capacitor (fixed)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (Vinp diff pair)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (Vinn diff pair)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (PMOS load)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (PMOS load)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (tail current)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (CS amplifier)
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (active load)
    # Bias voltages (0.8-1.2× original, capped at 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},   # Original 0.42V (tail current bias)
    'vbias2': {'min': 0.624, 'max': 0.936},   # Original 0.78V (active load bias)
    # Compensation network
    'c_comp': {'min': 0.5e-12, 'max': 5e-12, 'log': True},  # Compensation cap (original 1pF)
    'r_comp': {'min': 500, 'max': 2000},      # Nulling resistor (original 1kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 20e-6,
    'w_m6': 40e-6,
    'w_m7': 40e-6,
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    # Compensation network
    'c_comp': 1e-12,
    'r_comp': 1000,
}
# Parameter descriptions:
# w_m1-w_m7: Widths of transistors M1-M7 (all use fixed 45nm length)
# vbias1: Tail current source bias voltage (M5 gate voltage)
# vbias2: Active load bias voltage (M7 gate voltage)
# c_comp: Main compensation capacitor between Drain2 and Vout
# r_comp: Nulling resistor in compensation network
