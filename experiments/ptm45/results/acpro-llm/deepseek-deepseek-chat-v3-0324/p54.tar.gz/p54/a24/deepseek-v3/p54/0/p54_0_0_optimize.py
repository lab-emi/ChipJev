from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed voltages)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed DC bias for Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed DC bias for Vinn
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['v_bias1']}")  # Bias for M5
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['v_bias2']}")  # Bias for M8
    # Stage 1: Differential Pair with Current Mirror Load (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'Drain5', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'Drain5', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Drain5', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier (parameterized widths)
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (conservative ranges to maintain circuit operation)
    'v_bias1': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth + 0.2V)
    'v_bias2': {'min': 0.70, 'max': 0.90},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
    # Input pair and current mirror (M1-M4)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    # Current source M5
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    # Second stage transistors
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_bias1': 0.42,
    'v_bias2': 0.78,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 20e-6,
    'w_M8': 10e-6,
}
