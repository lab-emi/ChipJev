from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Fully-Corrected Two-Stage Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply input
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)  # NMOS bias (Vth + 0.23V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.75@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.55@u_V)  # Output stage bias
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source
circuit.MOSFET('8', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('5', 'Gm_node', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('6', 'Gm_node', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Output Stage - Class AB
circuit.MOSFET('7', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vout', 'Gm_node', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Level Shifter for Output Stage Bias
circuit.MOSFET('10', 'Vbias3', 'Gm_node', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('11', 'Vbias3', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
