from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    # Input Signals (fixed, mid-supply for DC bias)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Stage 1: Differential Pair with Active Load
    # Differential Pair (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    # Active Load (PMOS Current Mirror) (parameterized widths)
    circuit.MOSFET('5', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    # Tail Current Source (parameterized width)
    circuit.MOSFET('9', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m9'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    # Amplifying Transistor (parameterized width)
    circuit.MOSFET('3', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m3'], l=0.045e-6)
    # Active Load (parameterized width)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m8'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original but constrained below 1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Vbias1 (Vth + 0.2V)
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # Vbias2 (Vdd - |Vth| - 0.2V)
    # NMOS transistors (1-500× the minimum length of 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Differential pair NMOS 1
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Differential pair NMOS 2
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # CS Stage NMOS
    'w_m9': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Tail current NMOS
    # PMOS transistors (1-500× the minimum length of 45nm)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Current mirror PMOS 1
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Current mirror PMOS 2
    'w_m8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Active load PMOS
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Original bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    # Original transistor widths (W in meters)
    'w_m1': 10e-6,   # M1 width
    'w_m2': 10e-6,   # M2 width
    'w_m3': 20e-6,   # M3 width
    'w_m5': 20e-6,   # M5 width
    'w_m6': 20e-6,   # M6 width
    'w_m8': 40e-6,   # M8 width
    'w_m9': 5e-6,    # M9 width
}
