from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages (Adjusted for proper saturation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5)  # Increased to ensure NMOS M5 saturation (0.42V -> 0.5V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7)  # Decreased to ensure PMOS M7 saturation (0.78V -> 0.7V)
# Input Voltages (DC operating point at mid-rail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn
# Stage 1: Differential Pair with Active Load
# NMOS M1/M2: Ensure V_DS > V_GS - V_TH by setting V_Drain1/Drain2 ≈ 0.8V
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (Cross-coupled PMOS/NMOS for higher V_Drain)
circuit.MOSFET('3', 'Drain1', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)  # PMOS load for M1
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)  # PMOS load for M2
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # Tail current
# Stage 2: Common-Source Stage with PMOS Current Source Load
# PMOS M6: Ensure V_DS < V_GS - |V_TH| by sizing and biasing
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)  # Wider to lower Vout
circuit.MOSFET('7', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Current source load
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
