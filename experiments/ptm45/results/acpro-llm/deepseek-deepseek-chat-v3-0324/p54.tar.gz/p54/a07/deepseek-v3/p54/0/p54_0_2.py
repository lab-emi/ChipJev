from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp (Final Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages (Carefully adjusted)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5)  # For NMOS current source M5
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.65)  # For PMOS current source M7 (reduced from 0.7V)
# Input Voltages (DC operating point at mid-rail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn
# Stage 1: Differential Pair with Diode-Connected Loads
# Using NMOS diode-connected loads instead of PMOS for proper biasing
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Diode-connected NMOS loads
circuit.MOSFET('3', 'Drain1', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Tail current source
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Stage with Current Source Load
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # Widened to pull down Vout
circuit.MOSFET('7', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Current source load
# Small resistor to help set DC operating point
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
