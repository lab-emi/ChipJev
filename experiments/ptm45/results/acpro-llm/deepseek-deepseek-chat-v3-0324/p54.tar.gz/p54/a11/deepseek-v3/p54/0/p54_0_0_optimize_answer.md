Here's the parameterized conversion of your multi-stage opamp circuit:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Bias Voltages (parameterized with conservative ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original, constrained to <1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504, 'log': False},  # Original: 0.42V (±20%)
    'vbias2': {'min': 0.336, 'max': 0.504, 'log': False},  # Original: 0.42V (±20%)
    
    # Differential pair transistors (M1, M2)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    
    # PMOS load transistors (M3, M4)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    
    # Tail current source (M5)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    
    # Second stage transistors (M6, M7)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,
    'vbias2': 0.42,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 20e-6,
    'w_M7': 10e-6,
}
```

### Parameter Descriptions:
1. **Bias Voltages**:
   - `vbias1`: Tail current source bias voltage (original: 0.42V)
   - `vbias2`: Active load bias voltage (original: 0.42V)
   - These are constrained to ±20% of original values but kept <1.2V

2. **Transistor Widths**:
   - `w_M1`, `w_M2`: Input differential pair NMOS widths (original: 10μm)
   - `w_M3`, `w_M4`: PMOS active load widths (original: 20μm)
   - `w_M5`: Tail current source width (original: 5μm)
   - `w_M6`: PMOS second stage width (original: 20μm)
   - `w_M7`: NMOS second stage width (original: 10μm)
   - All widths range from 1-500× the gate length (45nm) to maintain reasonable current densities

### Key Features:
- All initial parameter values match exactly with the original circuit
- Voltage ranges are conservative (±20%) to maintain proper biasing
- Width ranges follow technology constraints (1-500× length)
- Fixed parameters (power supply, input voltages) are kept as in original
- All initial values are within their respective search ranges
- Logarithmic scaling enabled for transistor widths (common in analog optimization)