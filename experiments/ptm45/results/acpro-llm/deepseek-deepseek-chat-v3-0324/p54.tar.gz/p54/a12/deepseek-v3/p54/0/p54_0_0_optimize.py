from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Current Source Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W in meters, L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500× length)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500× length)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500× length)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500× length)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500× length)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (1-500× length)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (1-500× length)
    # Bias voltages (V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Vbias1 (0.8-1.2× original 0.42V)
    'vbias2': {'min': 0.336, 'max': 0.504},  # Vbias2 (0.8-1.2× original 0.42V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original M1 width
    'w_M2': 5e-6,    # Original M2 width
    'w_M3': 10e-6,   # Original M3 width
    'w_M4': 10e-6,   # Original M4 width
    'w_M5': 5e-6,    # Original M5 width
    'w_M6': 20e-6,   # Original M6 width
    'w_M7': 10e-6,   # Original M7 width
    'vbias1': 0.42,  # Original Vbias1 value
    'vbias2': 0.42,  # Original Vbias2 value
}
# Parameter descriptions
param_descriptions = {
    'w_M1': 'Width of input NMOS transistor M1 (differential pair left side)',
    'w_M2': 'Width of input NMOS transistor M2 (differential pair right side)',
    'w_M3': 'Width of PMOS load transistor M3 (active load left side)',
    'w_M4': 'Width of PMOS load transistor M4 (active load right side)',
    'w_M5': 'Width of NMOS tail current source M5',
    'w_M6': 'Width of PMOS load transistor M6 (second stage)',
    'w_M7': 'Width of NMOS driver transistor M7 (second stage)',
    'vbias1': 'Bias voltage for tail current source M5',
    'vbias2': 'Bias voltage for second stage current source M7'
}
