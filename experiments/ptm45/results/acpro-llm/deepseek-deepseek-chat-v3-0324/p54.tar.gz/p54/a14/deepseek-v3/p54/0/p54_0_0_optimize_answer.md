Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")
    
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)  # Diode-connected
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)  # Active load
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)  # Tail current
    
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)  # Active load
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (conservative ranges)
    'vbias1': {'min': 0.34, 'max': 0.50, 'log': False},  # Original: 0.42V
    'vbias2': {'min': 0.62, 'max': 0.94, 'log': False},  # Original: 0.78V
    
    # Differential pair transistors
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    
    # PMOS load transistors
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    
    # Tail current source
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    
    # Second stage transistors
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,
    'vbias2': 0.78,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 20e-6,
    'w_M8': 20e-6,
}
```

### Parameter Descriptions:
1. **Bias Voltages**:
   - `vbias1`: Controls tail current source bias (M5), affects differential pair biasing
   - `vbias2`: Controls PMOS active load bias (M8) in second stage

2. **Transistor Widths**:
   - `w_M1`, `w_M2`: Differential pair NMOS widths (affects gm, noise)
   - `w_M3`, `w_M4`: PMOS active load widths (affects first stage gain)
   - `w_M5`: Tail current source width (sets bias current)
   - `w_M6`: Second stage NMOS width (affects output drive)
   - `w_M8`: Second stage PMOS load width (affects output impedance)

### Key Features:
1. All original values are perfectly preserved in `initial_params`
2. Width ranges allow 1-500× the length (45nm) as requested
3. Bias voltage ranges are conservative (0.8-1.2× original values)
4. Supply voltage (1.2V) and input voltages (0.6V) remain fixed
5. All initial values fall within their specified ranges
6. Length parameters remain fixed at 45nm as per your requirements

The parameter ranges are set to ensure:
- Bias voltages stay within safe operating ranges (considering Vth = 0.22V)
- All parameter ranges include the original values
- Transistor widths can be optimized within practical limits for 45nm technology
- The circuit remains functional during optimization by not drifting too far from original operating points