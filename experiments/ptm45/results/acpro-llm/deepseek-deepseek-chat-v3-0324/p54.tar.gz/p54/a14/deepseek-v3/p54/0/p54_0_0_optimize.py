from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)  # Diode-connected
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)  # Active load
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)  # Tail current
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M8'], l=0.045e-6)  # Active load
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (conservative ranges)
    'vbias1': {'min': 0.34, 'max': 0.50, 'log': False},  # Original: 0.42V
    'vbias2': {'min': 0.62, 'max': 0.94, 'log': False},  # Original: 0.78V
    # Differential pair transistors
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    # PMOS load transistors
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    # Tail current source
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    # Second stage transistors
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,
    'vbias2': 0.78,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 20e-6,
    'w_M8': 20e-6,
}
