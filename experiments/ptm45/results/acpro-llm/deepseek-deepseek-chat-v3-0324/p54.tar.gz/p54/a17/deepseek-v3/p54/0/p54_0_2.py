from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Two-Stage Opamp with Class AB Output')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
circuit.V('ss', 'Vss', circuit.gnd, 0)
circuit.V('cm', 'Vcm', circuit.gnd, 0.6)  # Common mode voltage
# Input Signals - AC analysis setup
circuit.V('inp', 'Vinp', 'Vcm', 0.6 @u_V, dc_offset=0.6)
circuit.V('inn', 'Vinn', 'Vcm', 0.6 @u_V, dc_offset=0.6)
# Bias Generation
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # NMOS bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # PMOS bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.65)  # Class AB bias
# Input Stage - Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('9', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Second Stage
circuit.MOSFET('5', 'Vmid', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vmid', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Output Stage (Class AB)
circuit.MOSFET('7', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=100e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=100e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain2', 'Vmid', 2@u_pF)
circuit.R('c', 'Drain2', 'Vmid', 1@u_kΩ)
# Load
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
