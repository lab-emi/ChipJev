from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('ss', 'Vss', circuit.gnd, 0)    # Ground
# Input Signals (DC bias for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for differential pair
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for differential pair
# Bias Voltages (Assuming Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # Vth + 0.2V for M5
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # Vdd - Vth - 0.2V for M11
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42)  # Vth + 0.2V for M7
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('9', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('10', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('11', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Output Stage
circuit.MOSFET('4', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('12', 'Vout', 'Drain3', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)
circuit.R('c', 'Drain2', 'Node1', 1@u_kΩ)
circuit.C('c1', 'Node1', 'Vout', 1@u_pF)
# Load Resistor
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
