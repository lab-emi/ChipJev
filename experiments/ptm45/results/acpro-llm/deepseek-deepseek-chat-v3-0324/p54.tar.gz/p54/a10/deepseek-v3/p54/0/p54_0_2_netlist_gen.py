from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Fully-Corrected Three-Stage Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Generation Circuit
circuit.MOSFET('10', 'Vbiasn', 'Vbiasn', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('11', 'Vbiasn', 'Vdd', 'Vbiasp', 'Vbiasp', model='pmos_model', w=20e-6, l=0.045e-6)  # Current source
circuit.MOSFET('12', 'Vbiasp', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('13', 'Vbiasp', circuit.gnd, 'Vcas', 'Vcas', model='nmos_model', w=10e-6, l=0.045e-6)  # Current sink
# Differential Inputs (DC bias at midrail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # Mirror
circuit.MOSFET('5', 'SourcePair', 'Vbiasn', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with Active Load
circuit.MOSFET('6', 'Drain3', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Source Follower Output Stage
circuit.MOSFET('8', 'Vout', 'Drain3', 'Vsource', 'Vsource', model='nmos_model', w=80e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vsource', 'Vbiasn', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Compensation
circuit.C('c', 'Drain3', 'Drain2', 2@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
