from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Operational Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # For PMOS loads
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # For NMOS current sources
# Differential Inputs (DC bias at midrail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Mirror
circuit.MOSFET('5', 'SourcePair', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # Tail current
# Stage 2: Common-Source with Active Load
circuit.MOSFET('6', 'Drain3', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Active load
circuit.MOSFET('7', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # CS amplifier
# Compensation Capacitor
circuit.C('c', 'Drain3', 'Drain2', 1@u_pF)
# Stage 3: Common-Source with Resistor Load
circuit.MOSFET('8', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 2@u_kΩ)  # Reduced resistance
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p54/0/p54_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
