from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # Input Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # First Stage: Differential Pair with Current Mirror Load
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Second Stage: Common-Source with Current Source Load
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (V) - constrained to maintain proper operation
    'vbias': {'min': 0.34, 'max': 0.50},  # Original 0.42V ±20% (but never below Vth + 100mV)
    # Transistor widths (m)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500×L)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500×L)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500×L)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500×L)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500×L)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (1-500×L)
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (1-500×L)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias': 0.42,       # Original bias voltage
    # Original transistor widths
    'w_m1': 5e-6,       # M1 (input pair left side)
    'w_m2': 5e-6,       # M2 (input pair right side)
    'w_m3': 10e-6,      # M3 (PMOS current mirror left)
    'w_m4': 10e-6,      # M4 (PMOS current mirror right)
    'w_m5': 10e-6,      # M5 (NMOS tail current source)
    'w_m6': 20e-6,      # M6 (NMOS common-source stage)
    'w_m7': 20e-6,      # M7 (PMOS active load)
}
# Parameter descriptions:
# - vbias: Bias voltage for current sources (critical for correct biasing)
# - w_m1, w_m2: Input pair transistor widths (affects gm and matching)
# - w_m3, w_m4: Current mirror transistor widths (sets mirror ratio)
# - w_m5: Tail current source width (sets bias current)
# - w_m6, w_m7: Output stage transistor widths (affects gain and output swing)
