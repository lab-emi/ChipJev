from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['v_bias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['v_bias2']}V")
    # Input Signals (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for symmetry
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for symmetry
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('7', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m7'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original value, capped at 1.2V)
    'v_bias1': {'min': 0.336, 'max': 0.504, 'log': False},  # Original: 0.42V, range: 0.8-1.2×
    'v_bias2': {'min': 0.624, 'max': 0.936, 'log': False},  # Original: 0.78V, range: 0.8-1.2×
    # Differential pair transistors (1-500× length = 45nm-22.5μm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    # PMOS current mirror load (stage 1)
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 20μm
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 20μm
    # Tail current source
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 5μm
    # Stage 2 transistors
    'w_m6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10μm (PMOS active load)
    'w_m7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 20μm (NMOS driver)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'v_bias1': 0.42,
    'v_bias2': 0.78,
    # Transistor widths
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 5e-6,
    'w_m6': 10e-6,
    'w_m7': 20e-6,
}
