from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for operating point
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for operating point
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('9', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m9'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m8'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× of original values, constrained by 0<V<1.2V)
    'vbias1': {'min': 0.34, 'max': 0.5},   # Original: 0.42V (Vth + 0.2V)
    'vbias2': {'min': 0.62, 'max': 0.94},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
    # Stage 1 transistors (1-500× length)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 5um
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 5um
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10um
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10um
    'w_m9': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10um
    # Stage 2 transistors (1-500× length)
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 15um
    'w_m8': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 20um
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,
    'vbias2': 0.78,
    'w_m1': 5e-6,
    'w_m2': 5e-6,
    'w_m3': 10e-6,
    'w_m4': 10e-6,
    'w_m9': 10e-6,
    'w_m5': 15e-6,
    'w_m8': 20e-6,
}
# Parameter descriptions (for reference)
parameter_descriptions = {
    'vbias1': "NMOS current source bias voltage (Vth + overdrive)",
    'vbias2': "PMOS current source bias voltage (Vdd - |Vth| - overdrive)",
    'w_m1': "Width of NMOS differential pair transistor 1 (Vinp side)",
    'w_m2': "Width of NMOS differential pair transistor 2 (Vinn side)",
    'w_m3': "Width of PMOS active load transistor 1 (diode-connected)",
    'w_m4': "Width of PMOS active load transistor 2 (mirror)",
    'w_m9': "Width of NMOS tail current source",
    'w_m5': "Width of NMOS common-source amplifier",
    'w_m8': "Width of PMOS active load for common-source stage"
}
