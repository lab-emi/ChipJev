from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias voltage (fixed)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    # Stage 1: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Common-Source with Active Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length of 45nm, log scale recommended)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input NMOS
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # First-stage PMOS load
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Second-stage NMOS
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Second-stage PMOS load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output PMOS load
    # Bias voltages (0.8-1.2× original, clamped to <1.2V)
    # Conservative ranges to maintain operation in saturation
    'v_bias1': {'min': 0.624, 'max': 0.94},  # Original 0.78V (0.8-1.2×)
    'v_bias2': {'min': 0.56, 'max': 0.84},   # Original 0.7V (0.8-1.2×)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Original input NMOS width
    'w_M2': 10e-6,   # Original first-stage PMOS load width
    'w_M3': 10e-6,   # Original second-stage NMOS width
    'w_M4': 20e-6,   # Original second-stage PMOS load width
    'w_M5': 20e-6,   # Original output NMOS width
    'w_M6': 40e-6,   # Original output PMOS load width
    # Bias voltages
    'v_bias1': 0.78, # Original first bias voltage
    'v_bias2': 0.7,  # Original second bias voltage
}
# Parameter descriptions (for reference)
parameter_descriptions = {
    'w_M1': "Width of input NMOS transistor (M1)",
    'w_M2': "Width of first-stage PMOS load transistor (M2)",
    'w_M3': "Width of second-stage NMOS transistor (M3)",
    'w_M4': "Width of second-stage PMOS load transistor (M4)",
    'w_M5': "Width of output NMOS transistor (M5)",
    'w_M6': "Width of output PMOS load transistor (M6)",
    'v_bias1': "Bias voltage for first-stage current source (0.78V nominal)",
    'v_bias2': "Bias voltage for second-stage current source (0.7V nominal)",
}
