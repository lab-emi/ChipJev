I'll convert your three-stage high-gain amplifier circuit into a parameterized form according to your requirements. Here's the implementation:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage High-Gain Amplifier (Parameterized)')
    
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed Vdd = 1.2V
    
    # Bias Voltages (parameterized with conservative ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # PMOS M2 bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # PMOS M4 bias
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)  # NMOS M6 current sink
    
    # Input Voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input DC bias
    
    # Stage 1: Common-Source with PMOS Current Mirror Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Stage 2: Common-Source with NMOS Current Mirror Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Stage 3: Source Follower with Current Sink
    circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5µm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input NMOS
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # 2nd stage NMOS
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # 2nd stage PMOS
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output follower
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Current sink
    
    # Bias voltages (0.8-1.2× original values, not exceeding 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original 0.78V (PMOS M2)
    'vbias2': {'min': 0.336, 'max': 0.504},  # Original 0.42V (PMOS M4)
    'vbias3': {'min': 0.48, 'max': 0.72},    # Original 0.6V (NMOS M6)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # M1 original width
    'w_M2': 10e-6,    # M2 original width
    'w_M3': 10e-6,    # M3 original width
    'w_M4': 20e-6,    # M4 original width
    'w_M5': 20e-6,    # M5 original width
    'w_M6': 5e-6,     # M6 original width
    'vbias1': 0.78,   # Original Vbias1
    'vbias2': 0.42,   # Original Vbias2
    'vbias3': 0.6,    # Original Vbias3
}

# Parameter descriptions:
# Transistor widths (w_M1-w_M6):
#   - Affects transconductance, current, and gain of each stage
#   - Width range is 1-500× the 45nm channel length
#
# Bias voltages (vbias1-vbias3):
#   - Sets operating points for current mirrors and output stage
#   - Conservative ranges (0.8-1.2× original) to maintain circuit operation
#   - vbias3 (NMOS current sink bias) has slightly wider range for flexibility
```

Key features of this implementation:

1. **MOSFET Parameters**:
   - Only widths are parameterized (lengths fixed at 45nm)
   - Width ranges span 1-500× the channel length (45nm to 22.5µm)
   - Log-scale sampling for better optimization coverage

2. **Bias Voltages**:
   - Conservative ranges (0.8-1.2× original values)
   - Never exceed supply voltage (1.2V)
   - Maintain sufficient overdrive for all transistors (Vth = 0.22V)

3. **Fixed Values**:
   - Power supply (Vdd = 1.2V) fixed
   - Input bias voltage (0.42V) fixed for DC analysis
   - MOSFET models and lengths fixed by technology

4. **Initial Parameters**:
   - Exactly match your original circuit values
   - All values are within their respective search ranges

This implementation provides the optimization framework with all the necessary knobs to tune while maintaining safe operating conditions and preserving the original circuit topology.