from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier (Parameterized)')
    # MOSFET Models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    # Input Voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # Stage 1: CS with Current Source Load (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    # Stage 2: CS with Current Source Load (parameterized widths)
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Stage 3: Source Follower with NMOS Current Source (parameterized widths)
    circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (staying within 0.8-1.2× original values but ≤ 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (PMOS bias)
    'vbias3': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (NMOS current source)
    # NMOS transistor widths (1-500× length, 45nm = 0.045μm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5μm
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5μm
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20μm
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    # PMOS transistor widths (1-500× length)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10μm
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.78,   # Original value for PMOS current sources M2 and M4
    'vbias3': 0.42,   # Original value for NMOS current source M6
    # NMOS widths (original values in meters)
    'w_m1': 5e-6,     # M1 width
    'w_m3': 5e-6,     # M3 width
    'w_m5': 20e-6,    # M5 width
    'w_m6': 10e-6,    # M6 width
    # PMOS widths (original values in meters)
    'w_m2': 10e-6,    # M2 width
    'w_m4': 10e-6,    # M4 width
}
"""
Parameter Descriptions:
- vbias1: Bias voltage for PMOS current sources M2 and M4
- vbias3: Bias voltage for NMOS current source M6
- w_m1: Width of input NMOS transistor M1
- w_m2: Width of PMOS current source M2
- w_m3: Width of second stage NMOS transistor M3
- w_m4: Width of PMOS current source M4
- w_m5: Width of source follower NMOS transistor M5
- w_m6: Width of NMOS current source M6
Note: All transistor lengths are fixed at 45nm (0.045μm)
"""
