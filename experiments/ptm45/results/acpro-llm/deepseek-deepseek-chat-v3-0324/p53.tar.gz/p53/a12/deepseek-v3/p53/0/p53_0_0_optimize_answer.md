Here's the parameterized version of your three-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values - not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42) # Input bias voltage (fixed)
    
    # Bias voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3'])
    
    # First Stage: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m2'], l=0.045e-6)
    
    # Second Stage: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    
    # Third Stage: Common-Source with Active Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages
    'vbias1': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V (but <1.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Same constraints as vbias1
    'vbias3': {'min': 0.624, 'max': 0.936},  # Same constraints as vbias1
    
    # NMOS transistor widths (1st, 2nd, 3rd stages)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    
    # PMOS transistor widths (1st, 2nd, 3rd stages)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    'vbias3': 0.78,
    
    # Transistor widths
    'w_m1': 5e-6,    # Original M1 width
    'w_m2': 10e-6,   # Original M2 width
    'w_m3': 10e-6,   # Original M3 width
    'w_m4': 20e-6,   # Original M4 width
    'w_m5': 20e-6,   # Original M5 width
    'w_m6': 40e-6,   # Original M6 width
}
```

### Parameter Descriptions:

1. **Bias Voltages (vbias1, vbias2, vbias3)**:
   - Original: 0.78V (Vdd - |Vth| - 0.2V)
   - Range: 0.624-0.936V (0.8-1.2× original, kept below 1.2V)
   - Controls the operating point of each stage by setting the gate bias for PMOS loads

2. **NMOS Widths (w_m1, w_m3, w_m5)**:
   - Original: 5µm (1st stage), 10µm (2nd stage), 20µm (3rd stage)
   - Range: 45nm-22.5µm (1-500× the 45nm channel length)
   - Affects transconductance, gain, and bandwidth of each stage

3. **PMOS Widths (w_m2, w_m4, w_m6)**:
   - Original: 10µm (1st stage), 20µm (2nd stage), 40µm (3rd stage)
   - Range: 45nm-22.5µm (1-500× the 45nm channel length)
   - Sets the load characteristics and current mirror ratios

### Notes:
- All initial values are exactly preserved from your original circuit
- The voltage ranges are conservatively set to maintain proper operation (±20% from original)
- Channel lengths are fixed at 45nm (process-defined)
- Width ranges allow for significant optimization while staying within practical limits
- The logarithmic scale ('log': True) is used for transistor widths due to their wide dynamic range importance