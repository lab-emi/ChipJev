Here's the parameterized version of your multi-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input voltage sources (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2']@u_V)
    
    # Stage 1: Common-Source with Current Source Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)
    
    # Stage 2: Common-Source with Current Source Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M3'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M4'], 
                  l=0.045e-6)
    
    # Stage 3: Common-Source with Current Source Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M5'], 
                  l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M6'], 
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5µm range)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Stage 1 NMOS
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Stage 1 PMOS current source
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Stage 2 NMOS
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Stage 2 PMOS current source
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output stage NMOS
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output stage PMOS current source
    
    # Bias voltages (0.8-1.2× original but must be ≤1.2V and ≥Vth)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vgs must be > Vth)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vgs must be > Vth)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 10e-6,
    'w_M5': 20e-6,
    'w_M6': 20e-6,
    
    # Bias voltages
    'v_bias1': 0.78,
    'v_bias2': 0.78,
}
```

### Explanation:

1. **Function Structure**:
   - `create_circuit(params)` takes a dictionary of parameters and returns a configured circuit
   - All fixed values (supply voltage, input voltages) remain unchanged
   - All transistor widths and bias voltages are parameterized

2. **Parameter Ranges**:
   - **Transistor widths**: 1-500× the 45nm channel length (45nm to 22.5µm)
     - Using logarithmic scaling for better exploration of orders of magnitude
   - **Bias voltages**: Conservative 0.8-1.2× original values (0.624V-0.936V)
     - Lower bound ensures Vgs > Vth (0.22V) for proper operation
     - Upper bound keeps voltages safely below Vdd (1.2V)

3. **Initial Values**:
   - All original circuit values are preserved exactly in `initial_params`
   - All initial values fall within their respective search ranges

4. **Physical Meaning**:
   - `w_M1-w_M6`: Widths of each transistor (affects gain, bandwidth, power)
   - `v_bias1`: Bias voltage for first PMOS current source (sets operating point)
   - `v_bias2`: Bias voltage for second and third stage PMOS current sources

5. **Safety Considerations**:
   - All bias voltages are constrained to stay within valid operating ranges
   - Transistor sizes maintain reasonable aspect ratios (1-500× length)
   - Fixed supply and input voltages ensure consistent operating conditions