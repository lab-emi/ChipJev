from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42) # Input voltage (fixed)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    # Stage 1: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m2'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Stage 3: Common-Source with Active Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale appropriate for sizing)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M1 width (45nm-22.5μm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M2 width (45nm-22.5μm)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M3 width (45nm-22.5μm)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M4 width (45nm-22.5μm)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M5 width (45nm-22.5μm)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M6 width (45nm-22.5μm)
    # Bias voltages (conservative range around original values)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V (below 1.2V limit)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Same as v_bias1 range
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,    # Original M1 width
    'w_m2': 10e-6,   # Original M2 width
    'w_m3': 10e-6,   # Original M3 width
    'w_m4': 20e-6,   # Original M4 width
    'w_m5': 20e-6,   # Original M5 width
    'w_m6': 40e-6,   # Original M6 width
    # Bias voltages
    'v_bias1': 0.78, # Original Vbias1
    'v_bias2': 0.78, # Original Vbias2
}
