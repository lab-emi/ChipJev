Here's the parameterized conversion of your three-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')

    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply and Biasing (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # DC bias for input (fixed)
    
    # Bias voltages (parameterized with conservative ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3'])
    
    # Stage 1: Common-Source with PMOS Current Source Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    
    # Stage 2: Common-Source with PMOS Current Source Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m3'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m4'], 
                  l=0.045e-6)
    
    # Stage 3: Common-Source with PMOS Current Source Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'], 
                  l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m6'], 
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage parameters (0.8-1.2× original values, but never exceeding 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× 0.78V (Vdd - |Vth| - 0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  
    'vbias3': {'min': 0.624, 'max': 0.936},
    
    # Stage 1 transistor widths (1-500× length = 45nm-22.5µm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5µm
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10µm
    
    # Stage 2 transistor widths
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10µm
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10µm
    
    # Stage 3 (output stage) transistor widths
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20µm
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20µm
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    'vbias3': 0.78,
    
    # Stage 1 transistors
    'w_m1': 5e-6,
    'w_m2': 10e-6,
    
    # Stage 2 transistors
    'w_m3': 10e-6,
    'w_m4': 10e-6,
    
    # Stage 3 transistors
    'w_m5': 20e-6,
    'w_m6': 20e-6,
}
```

### Parameter Descriptions:
1. **Voltage Parameters:**
   - `vbias1`, `vbias2`, `vbias3`: Bias voltages for PMOS current sources (originally set to Vdd - |Vth| - 0.2V = 0.78V)
   - Range: 0.624V to 0.936V (0.8-1.2× original) to maintain proper biasing while allowing optimization

2. **Transistor Width Parameters:**
   - `w_m1`: Width of input NMOS (M1)
   - `w_m2`: Width of first stage PMOS load (M2)
   - `w_m3`: Width of second stage NMOS (M3)
   - `w_m4`: Width of second stage PMOS load (M4)
   - `w_m5`: Width of output stage NMOS (M5)
   - `w_m6`: Width of output stage PMOS load (M6)
   - All widths range from minimum (45nm = 1×L) to 22.5µm (500×L) with logarithmic scaling

### Important Notes:
1. All fixed values (Vdd, Vin) remain exactly as in the original circuit
2. All initial parameter values match the original circuit exactly
3. Transistor lengths are fixed at 45nm (0.045µm) as per the technology
4. Bias voltage ranges are conservatively set to avoid drifting too far from the intended operating point while still allowing optimization
5. All initial values are within their specified search ranges
6. The function name is exactly `create_circuit` as required