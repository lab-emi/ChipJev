Here's the parameterized version of your three-stage amplifier circuit following all the specified requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42) # Input bias voltage (fixed)
    
    # Bias voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['v_bias3'])
    
    # Stage 1: Common-Source with PMOS Current Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Stage 2: Common-Source with PMOS Current Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Stage 3: Common-Source with PMOS Current Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45e-9 to 22.5e-6)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS in stage 1
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS in stage 1
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS in stage 2
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS in stage 2
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS in stage 3
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS in stage 3
    
    # Bias voltages (0.8-1.2× original, but <= 1.2V)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2×)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    'v_bias3': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Original width for M1
    'w_M2': 10e-6,   # Original width for M2
    'w_M3': 5e-6,    # Original width for M3
    'w_M4': 10e-6,   # Original width for M4
    'w_M5': 5e-6,    # Original width for M5
    'w_M6': 10e-6,   # Original width for M6
    
    # Bias voltages
    'v_bias1': 0.78, # Original bias voltage for M2
    'v_bias2': 0.78, # Original bias voltage for M4
    'v_bias3': 0.78, # Original bias voltage for M6
}
```

**Parameter Descriptions:**
1. **w_M1-w_M6**: Widths of transistors M1-M6. The range allows exploration from minimum feature size (45nm) up to 500× the length (22.5μm), which gives sufficient flexibility for optimization while maintaining manufacturability.

2. **v_bias1-v_bias3**: Bias voltages for the PMOS current sources. The ranges are carefully constrained to:
   - Stay within 0.8-1.2× the original 0.78V value (0.624V-0.936V)
   - Never exceed the 1.2V supply voltage
   - Maintain sufficient overdrive voltage (VGS-Vth) to keep transistors in saturation
   - Remember that these PMOS devices have |Vth|≈0.22V, so VGS must be between -0.22V and -1.2V to stay in saturation (which corresponds to VSG between 0.22V and 1.2V)

**Implementation Notes:**
1. All transistor lengths are fixed at 45nm (0.045μm) as per the 45nm technology node.
2. The input voltage (Vin = 0.42V) and supply voltage (Vdd = 1.2V) remain fixed as requested.
3. All initial parameter values match exactly the original circuit values.
4. Voltage ranges are conservative to maintain proper biasing conditions while allowing optimization.
5. Width ranges follow the 1-500× length rule while being practical for implementation.