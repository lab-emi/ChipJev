from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42) # Input bias voltage (fixed)
    # Bias voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['v_bias3'])
    # Stage 1: Common-Source with PMOS Current Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with PMOS Current Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Common-Source with PMOS Current Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45e-9 to 22.5e-6)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS in stage 1
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS in stage 1
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS in stage 2
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS in stage 2
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS in stage 3
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS in stage 3
    # Bias voltages (0.8-1.2× original, but <= 1.2V)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2×)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    'v_bias3': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Original width for M1
    'w_M2': 10e-6,   # Original width for M2
    'w_M3': 5e-6,    # Original width for M3
    'w_M4': 10e-6,   # Original width for M4
    'w_M5': 5e-6,    # Original width for M5
    'w_M6': 10e-6,   # Original width for M6
    # Bias voltages
    'v_bias1': 0.78, # Original bias voltage for M2
    'v_bias2': 0.78, # Original bias voltage for M4
    'v_bias3': 0.78, # Original bias voltage for M6
}
