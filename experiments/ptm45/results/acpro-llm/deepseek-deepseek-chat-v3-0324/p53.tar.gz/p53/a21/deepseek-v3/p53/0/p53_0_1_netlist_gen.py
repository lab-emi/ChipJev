from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('High-Gain 3-Stage Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # M1 bias (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # M2 bias (Vdd - |Vth| - 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # M4 bias (same as M2)
# Stage 1: CS with Current Source Load
circuit.MOSFET('1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Node1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: CS with Current Source Load (modified sizing for proper biasing)
circuit.MOSFET('3', 'Node2', 'Node1', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)  # Increased width
circuit.MOSFET('4', 'Node2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Reduced width
# Stage 3: Source Follower with proper V_GS
circuit.MOSFET('5', 'Vdd', 'Node2', 'Vout', circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)  # Large width for proper biasing
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
