from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage High-Gain Amplifier')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and bias voltages (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    # Parameterized bias voltage
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    # Stage 1: Common-Source with PMOS current source
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m2'], l=0.045e-6)
    # Stage 2: Common-Source with PMOS current source
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Stage 3: Common-Source with resistor load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")  # Parameterized load
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5μm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 1 NMOS
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 1 PMOS
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 2 NMOS
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 2 PMOS
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 3 NMOS
    # Bias voltage (conservative range around original value)
    'v_bias1': {'min': 0.62, 'max': 0.94},  # Original: 0.78V (keep > Vth + 0.2V)
    # Load resistor (0.5-2× original value)
    'r_load': {'min': 5, 'max': 20, 'log': True},  # Original: 10kΩ
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 10e-6,    # Stage 1 NMOS width
    'w_m2': 20e-6,    # Stage 1 PMOS width
    'w_m3': 20e-6,    # Stage 2 NMOS width
    'w_m4': 40e-6,    # Stage 2 PMOS width
    'w_m5': 30e-6,    # Stage 3 NMOS width
    'v_bias1': 0.78,  # Bias voltage
    'r_load': 10,     # Load resistance (kΩ)
}
# Parameter descriptions (for reference)
"""
w_m1: Width of stage 1 NMOS (M1)
w_m2: Width of stage 1 PMOS current source (M2)
w_m3: Width of stage 2 NMOS (M3)
w_m4: Width of stage 2 PMOS current source (M4)
w_m5: Width of stage 3 NMOS (M5)
v_bias1: Bias voltage for PMOS current sources (0.62V-0.94V range ensures saturation)
r_load: Load resistor setting output DC level (5kΩ-20kΩ range)
"""
