from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies (Vdd = 1.2V, Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # M1 bias (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # M2 bias (Vdd - |Vth| - 0.2V)
# Stage 1: Common-Source with Current Source Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
# Stage 2: Common-Source with Resistive Load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.R('1', 'Drain2', 'Vdd', 20@u_kΩ)
# Stage 3: Source Follower (Output Buffer)
circuit.MOSFET('4', 'Vdd', 'Drain2', 'Vout', 'Vout', model='nmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
