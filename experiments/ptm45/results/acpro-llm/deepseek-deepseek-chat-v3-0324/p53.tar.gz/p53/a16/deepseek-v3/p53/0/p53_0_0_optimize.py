from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias (fixed)
    # Parameterized Bias Voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    # Stage 1: Common-Source with Current Source Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    # Stage 2: Common-Source with Current Source Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Stage 3: Common-Source with Current Source Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (µm)
    'w_m1': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS 1st stage input
    'w_m2': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS 1st stage load
    'w_m3': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS 2nd stage
    'w_m4': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS 2nd stage load
    'w_m5': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS output stage
    'w_m6': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS output stage load
    # Bias voltages (V)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V bias
    'v_bias2': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original 0.78V bias
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # Original M1 width
    'w_m2': 10e-6,   # Original M2 width
    'w_m3': 10e-6,   # Original M3 width
    'w_m4': 20e-6,   # Original M4 width
    'w_m5': 20e-6,   # Original M5 width
    'w_m6': 20e-6,   # Original M6 width
    'v_bias1': 0.78, # Original Vbias1 value
    'v_bias2': 0.78, # Original Vbias2 value
}
# Parameter descriptions:
# - w_m1 to w_m6: Widths of MOSFETs M1-M6 (µm)
# - v_bias1: Bias voltage for M2 and M4 (V)
# - v_bias2: Bias voltage for M6 (V)
