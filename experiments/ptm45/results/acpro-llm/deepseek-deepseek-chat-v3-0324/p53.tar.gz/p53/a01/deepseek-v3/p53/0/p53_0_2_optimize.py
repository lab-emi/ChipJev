from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('High-Gain Three-Stage Amplifier')
    # =============================================================================
    # Define MOSFET models 
    # =============================================================================
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # =============================================================================
    # Power Supplies (fixed values)
    # =============================================================================
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)          # Main supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)         # Input voltage (fixed)
    # =============================================================================
    # Parameterized bias voltages
    # =============================================================================
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}@u_V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}@u_V")
    # =============================================================================
    # First Stage: CS with PMOS current source load
    # =============================================================================
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=45e-9)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M2'], l=45e-9)
    # =============================================================================
    # Second Stage: CS with PMOS current source load
    # =============================================================================
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M3'], l=45e-9)
    circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=45e-9)
    # =============================================================================
    # Third Stage: CS with resistor load
    # =============================================================================
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M5'], l=45e-9)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}@u_kΩ")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # Input NMOS (original: 5um)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # PMOS current source (original: 10um)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # Gain NMOS (original: 10um)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # PMOS current source (original: 10um)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # Output driver (original: 20um)
    # Bias voltages (conservative ranges considering Vth=0.22V)
    'vbias1': {'min': 0.62, 'max': 0.94, 'log': False},    # PMOS bias (original: 0.78V)
    'vbias2': {'min': 0.34, 'max': 0.50, 'log': False},    # NMOS bias (original: 0.42V)
    # Load resistor (0.5-2× original value)
    'r_load': {'min': 5, 'max': 20, 'log': True},          # Original: 10kΩ
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Input NMOS
    'w_M2': 10e-6,   # PMOS current source (stage 1)
    'w_M3': 10e-6,   # Gain NMOS
    'w_M4': 10e-6,   # PMOS current source (stage 2)
    'w_M5': 20e-6,   # Output driver
    # Bias voltages
    'vbias1': 0.78,  # PMOS bias voltage
    'vbias2': 0.42,  # NMOS bias voltage
    # Load resistor
    'r_load': 10,    # Load resistor (kΩ)
}
