from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Keep this import as instructed
circuit = Circuit('High-Gain Three-Stage Amplifier')
# =============================================================================
# CRITICAL FIX 1: Define MOSFET models before using them
# =============================================================================
# Add these model definitions (using parameters from imported module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# =============================================================================
# Power Supplies (unchanged, correct)
# =============================================================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)
# =============================================================================
# First Stage: CS with PMOS load (correct topology)
# =============================================================================
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=45e-9)  # Fixed: l=45nm in meters
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',  # Bulk to Vdd for PMOS
              model='pmos_model', w=10e-6, l=45e-9)
# =============================================================================
# Second Stage: CS with NMOS load (corrected model name)
# =============================================================================
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
              model='nmos_model', w=10e-6, l=45e-9)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',  # NMOS with bulk to Vdd is correct here
              model='nmos_model', w=5e-6, l=45e-9)  # Acts as current source
# =============================================================================
# Third Stage: CS with resistor load (unchanged, correct)
# =============================================================================
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=45e-9)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# =============================================================================
# Analysis (keep this line exactly)
# =============================================================================
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
