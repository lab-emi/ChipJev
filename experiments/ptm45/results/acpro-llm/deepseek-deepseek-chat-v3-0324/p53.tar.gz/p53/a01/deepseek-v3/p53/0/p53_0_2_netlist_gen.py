from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('High-Gain Three-Stage Amplifier')
# =============================================================================
# Define MOSFET models 
# =============================================================================
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# =============================================================================
# Power Supplies (Vth = 0.22V assumed)
# =============================================================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)          # Main supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)         # Vth + 0.2V = 0.42V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)   # Vdd-Vth-0.2V = 0.78V (PMOS)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)   # Vth + 0.2V = 0.42V (NMOS)
# =============================================================================
# First Stage: CS with PMOS current source load
# =============================================================================
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
              model='nmos_model', w=5e-6, l=45e-9)    # Input NMOS
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=45e-9)   # PMOS current source
# =============================================================================
# Second Stage: CS with PMOS current source load (FIXED)
# =============================================================================
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
              model='nmos_model', w=10e-6, l=45e-9)   # Gain NMOS
circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', # Changed to PMOS!
              model='pmos_model', w=10e-6, l=45e-9)   # Uses same bias as M2
# =============================================================================
# Third Stage: CS with resistor load
# =============================================================================
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=45e-9)   # Output driver
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)                # Load resistor
# =============================================================================
# Analysis
# =============================================================================
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
