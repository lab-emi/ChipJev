from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('High-Gain Three-Stage Amplifier')
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias for M1
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # For PMOS load M2
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # For NMOS load M4
# First Stage: CS with PMOS load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Second Stage: CS with NMOS load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
               model='nmos_model', w=5e-6, l=0.045e-6)
# Third Stage: CS with resistor load
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
