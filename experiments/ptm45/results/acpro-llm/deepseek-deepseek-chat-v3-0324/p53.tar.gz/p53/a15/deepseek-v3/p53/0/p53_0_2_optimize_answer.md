Here's the parameterized version of your three-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    
    # MOS models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power supply and input voltages (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input DC operating point
    
    # Parameterized bias voltages (0.8-1.2× original, not exceeding 1.2V)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    
    # Stage 1: CS with Active Load
    circuit.M(1, 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', 
              l=45e-9, w=params['w_M1'])
    circuit.M(2, 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model',
              l=45e-9, w=params['w_M2'])
    
    # Stage 2: CS with Active Load 
    circuit.M(3, 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model',
              l=45e-9, w=params['w_M3'])
    circuit.M(4, 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model',
              l=45e-9, w=params['w_M4'])
    
    # Stage 3: CS with Resistor Load
    circuit.M(5, 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model',
              l=45e-9, w=params['w_M5'])
    circuit.R(1, 'Vout', 'Vdd', f"{params['r_load']}k")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm - 22.5µm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input NMOS
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Stage 2 NMOS
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Stage 2 PMOS load
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output NMOS
    
    # Bias voltages (0.8-1.2× original, max 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    
    # Load resistor (0.5-2× original)
    'r_load': {'min': 5, 'max': 20, 'log': True},  # Original: 10kΩ
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (µm)
    'w_M1': 5e-6,    # Original: 5µm
    'w_M2': 10e-6,   # Original: 10µm
    'w_M3': 10e-6,   # Original: 10µm
    'w_M4': 20e-6,   # Original: 20µm
    'w_M5': 20e-6,   # Original: 20µm
    
    # Bias voltages (V)
    'vbias1': 0.78,  # Original: 0.78V
    'vbias2': 0.78,  # Original: 0.78V
    
    # Load resistor (kΩ)
    'r_load': 10,    # Original: 10kΩ
}
```

### Parameter Descriptions:

1. **Transistor Widths (w_M1-w_M5)**:
   - Controls transconductance and current handling capability of each stage
   - w_M1: Input NMOS width - affects input transconductance and noise
   - w_M2: First stage PMOS load - affects gain and bandwidth
   - w_M3: Second stage NMOS - affects overall gain
   - w_M4: Second stage PMOS load - affects gain and power consumption
   - w_M5: Output NMOS - affects output impedance and drive capability

2. **Bias Voltages (vbias1, vbias2)**:
   - Sets operating points for active loads (PMOS transistors)
   - vbias1: First stage bias voltage (0.624V-0.936V range)
   - vbias2: Second stage bias voltage (0.624V-0.936V range)
   - Range ensures proper biasing (Vdd-Vth-0.2V ±20%)

3. **Load Resistor (r_load)**:
   - Output stage load resistor (5kΩ-20kΩ range)
   - Affects output voltage swing and power dissipation

### Notes:
- All initial parameter values are within their respective search ranges
- Voltage ranges are conservative (0.8-1.2× original) to maintain proper operation
- Transistor lengths are fixed at 45nm (minimum feature size for this technology)
- Input voltage (Vin) and power supply (Vdd) remain fixed as requested
- The parameter ranges follow your constraints for W/L ratios (1-500×) and voltage limits
- No capacitors were present in your original circuit, so none were parameterized