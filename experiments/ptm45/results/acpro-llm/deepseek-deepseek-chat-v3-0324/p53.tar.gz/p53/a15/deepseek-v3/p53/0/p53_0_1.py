from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Placeholder for user-defined MOSFET params
circuit = Circuit('Three-Stage Amplifier')
# --- Fix 1: Explicitly define MOSFET models ---
# Add .model statements for NMOS and PMOS using typical 45nm parameters
circuit.model('nmos_model', 'nmos', 
              level=54,  # BSIM4 model
              vto=0.22,  # Threshold voltage (V)
              kp=200e-6, # Transconductance parameter (A/V²)
              gamma=0.1, # Body effect parameter
              lambda=0.1 # Channel-length modulation
              )
circuit.model('pmos_model', 'pmos',
              level=54,
              vto=-0.22,
              kp=80e-6,
              gamma=0.1,
              lambda=0.1
              )
# --- Fix 2: Power Supplies ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V for saturation
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
# --- Stage 1: Common-Source with PMOS Load ---
# Transistor sizing: W/L = 5um/45nm for NMOS, 10um/45nm for PMOS
circuit.M(1, 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', 
          l=45e-9, w=5e-6)
circuit.M(2, 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', 
          l=45e-9, w=10e-6)
# --- Stage 2: Common-Source with PMOS Load ---
# Increased W for higher gain (10um/45nm NMOS, 20um/45nm PMOS)
circuit.M(3, 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', 
          l=45e-9, w=10e-6)
circuit.M(4, 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', 
          l=45e-9, w=20e-6)
# --- Stage 3: Common-Source with Resistor Load ---
circuit.M(5, 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
          l=45e-9, w=20e-6)
circuit.R(1, 'Vout', 'Vdd', 10@u_kΩ)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
