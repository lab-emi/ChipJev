Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias1 Vbias1 0 0.78V
Vbias2 Vbias2 0 0.78V
M1 Drain1 Vin 0 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain1 Vbias1 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M3 Drain2 Drain1 0 0 nmos_model l=4.5e-08 w=1e-05
M4 Drain2 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M5 Vout Drain2 0 0 nmos_model l=4.5e-08 w=2e-05
R1 Vout Vdd 10kOhm
.model nmos_model nmos (gamma=0.1 kp=0.0002 lambd=0.1 level=54 vto=0.22)
.model pmos_model pmos (gamma=0.1 kp=8e-05 lambd=0.1 level=54 vto=-0.22)

