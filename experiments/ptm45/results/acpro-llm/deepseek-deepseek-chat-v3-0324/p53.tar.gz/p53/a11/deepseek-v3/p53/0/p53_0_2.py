from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V for NMOS
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # For PMOS loads
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For output PMOS
# Stage 1: CS with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: CS with Current Source Load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=15e-6, l=0.045e-6)  # Wider for higher gain
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=15e-6, l=0.045e-6)  # Current source load
# Stage 3: Source Follower with Proper Biasing
circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)  # Upper resistor
circuit.R('2', 'Vout', circuit.gnd, 10@u_kΩ)  # Lower resistor (equal for Vout≈0.6V)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
