Here's the parameterized version of your three-stage high-gain amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage High-Gain Amplifier (Parameterized)')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies and Bias Voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed power supply (1.2V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltages (0.8-1.2× original, max 1.2V)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    
    # First Stage: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    
    # Second Stage: Common-Source with Resistor Load + Current Source
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.R('1', 'Drain2', 'Vdd', f"{params['r1']}k")  # Parameterized resistor
    circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    
    # Third Stage: Properly Biased Source Follower
    circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd,
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original, max 1.2V)
    'vbias1': {'min': 0.62, 'max': 0.94},  # Original 0.78V (PMOS current mirror)
    'vbias2': {'min': 0.42, 'max': 0.62},  # Original 0.52V (NMOS current sink)
    
    # Transistor widths (1-500× length, logarithmic scaling)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5μm
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 10μm
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 10μm
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 12μm
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 20μm
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5μm
    
    # Resistor (0.5-2× original value)
    'r1': {'min': 5, 'max': 20, 'log': True},  # Original 10kΩ
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.52,
    
    # Transistor widths
    'w_m1': 5e-6,
    'w_m2': 10e-6,
    'w_m3': 10e-6,
    'w_m4': 12e-6,
    'w_m5': 20e-6,
    'w_m6': 5e-6,
    
    # Resistor
    'r1': 10,
}
```

**Parameter Descriptions:**
1. **vbias1**: PMOS current mirror bias voltage (original 0.78V, range 0.62-0.94V)
2. **vbias2**: NMOS current sink bias voltage (original 0.52V, range 0.42-0.62V)
3. **w_m1**: Width of M1 (input NMOS, original 5μm, range 45nm-22.5μm)
4. **w_m2**: Width of M2 (PMOS active load, original 10μm, range 45nm-22.5μm)
5. **w_m3**: Width of M3 (2nd stage NMOS, original 10μm, range 45nm-22.5μm)
6. **w_m4**: Width of M4 (2nd stage PMOS, original 12μm, range 45nm-22.5μm)
7. **w_m5**: Width of M5 (output stage pull-up, original 20μm, range 45nm-22.5μm)
8. **w_m6**: Width of M6 (output stage current sink, original 5μm, range 45nm-22.5μm)
9. **r1**: Load resistor (original 10kΩ, range 5-20kΩ)

**Implementation Notes:**
- All MOSFET lengths are fixed at 45nm (technology constraint)
- Bias voltages are constrained to ±20% of original values but never exceed 1.2V
- Transistor widths can vary from minimum feature size (45nm) up to 500× length
- The load resistor has a reasonable variation range (0.5-2× original)
- All initial parameter values exactly match the original circuit
- The function is named `create_circuit` as required
- Power supply and input voltages remain fixed as specified