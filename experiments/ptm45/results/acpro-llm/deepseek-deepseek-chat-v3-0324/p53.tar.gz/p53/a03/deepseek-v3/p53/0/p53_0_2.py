from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('High-Gain 3-Stage Amplifier (Corrected)')
# =============================================
# 1. MOSFET MODEL DEFINITIONS
# =============================================
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22, lambda=0.05)
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22, lambda=0.05)
# =============================================
# 2. POWER SUPPLIES WITH PROPER BIASING
# =============================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.5@u_V)  # Increased from 0.42V for better bias
# Improved bias generation using current mirrors
circuit.MOSFET('bias_nmos', 'Vbias_n', 'Vbias_n', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.I('bias_current', 'Vdd', 'Vbias_n', 20@u_uA)  # Reference current
circuit.MOSFET('bias_pmos', 'Vbias1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.5@u_V)
# =============================================
# 3. MAIN AMPLIFIER STAGES WITH CORRECTED BIASING
# =============================================
# Stage 1: Common-Source with PMOS Current Source Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with PMOS Current Source Load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# =============================================
# 4. FIXED SOURCE FOLLOWER STAGE (M5)
# =============================================
# Add biasing for source follower
circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.I('source_bias', 'Vout', circuit.gnd, 50@u_uA)  # Active current source
# =============================================
# 5. LOAD AND STABILITY COMPONENTS
# =============================================
circuit.C('load_cap', 'Vout', circuit.gnd, 1@u_pF)  # Small stabilization capacitor
circuit.R('load_res', 'Vout', circuit.gnd, 10@u_kΩ)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
