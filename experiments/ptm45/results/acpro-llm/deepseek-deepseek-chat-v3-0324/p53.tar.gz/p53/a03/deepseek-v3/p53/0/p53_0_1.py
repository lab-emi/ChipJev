from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # This import must exist in your environment
circuit = Circuit('High-Gain 3-Stage Amplifier')
# =============================================
# CRITICAL FIX 1: Add MOSFET model definitions
# =============================================
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Basic NMOS parameters
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Basic PMOS parameters
# Note: In a real implementation, these would come from the imported parameters
# =============================================
# Power Supplies and Biasing
# =============================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias at Vth + 0.2V
# =============================================
# CRITICAL FIX 2: Ensure proper bias generation
# =============================================
# Using voltage dividers for more realistic bias generation
circuit.R('bias1_r1', 'Vdd', 'Vbias1', 100@u_kΩ)
circuit.R('bias1_r2', 'Vbias1', circuit.gnd, 100@u_kΩ)
circuit.R('bias2_r1', 'Vdd', 'Vbias2', 100@u_kΩ)
circuit.R('bias2_r2', 'Vbias2', circuit.gnd, 100@u_kΩ)
# =============================================
# Amplifier Stages
# =============================================
# Stage 1: Common-Source with PMOS Current Source Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with PMOS Current Source Load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Source Follower (Buffer)
circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# =============================================
# CRITICAL FIX 3: Add load for stability
# =============================================
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)  # Prevents floating output
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
