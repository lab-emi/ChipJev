Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Rbias1_r1 Vdd Vbias1 100kOhm
Rbias1_r2 Vbias1 0 100kOhm
Rbias2_r1 Vdd Vbias2 100kOhm
Rbias2_r2 Vbias2 0 100kOhm
M1 Drain1 Vin 0 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain1 Vbias1 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M3 Drain2 Drain1 0 0 nmos_model l=4.5e-08 w=1e-05
M4 Drain2 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M5 Vdd Drain2 Vout 0 nmos_model l=4.5e-08 w=2e-05
Rload Vout 0 10kOhm
.model nmos_model nmos (kp=0.0001 level=1 vto=0.22)
.model pmos_model pmos (kp=5e-05 level=1 vto=-0.22)

