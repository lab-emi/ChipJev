from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier (Parameterized)')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supplies and input voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['v_bias3'])
    # Stage 1: CS with Active Load - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: CS with Active Load - parameterized widths
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: CS with Active Load - parameterized widths
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2x original values, but max 1.2V)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - Vth - 0.2V)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    'v_bias3': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    # Transistor widths (1-500x L = 0.045um)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5um
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10um
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10um
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20um
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20um
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 30um
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'v_bias1': 0.78,
    'v_bias2': 0.78,
    'v_bias3': 0.78,
    # Transistor widths
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
    'w_M6': 30e-6,
}
