from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias voltage (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78)  # PMOS bias voltage (Vdd - |Vth| - 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # PMOS bias voltage (Vdd - |Vth| - 0.2V)
# First Stage: Common-Source with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Second Stage: Common-Source with Active Load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Third Stage: Common-Source with Active Load
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
