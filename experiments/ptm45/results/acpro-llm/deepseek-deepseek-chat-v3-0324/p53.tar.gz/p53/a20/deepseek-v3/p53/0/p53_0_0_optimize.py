from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (fixed inputs)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    # First Stage: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_nmos1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_pmos2'], l=0.045e-6)
    # Second Stage: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_nmos3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_pmos4'], l=0.045e-6)
    # Third Stage: Common-Source with Active Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_nmos5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_pmos6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length for 45nm process)
    # Widths are in meters (45nm = 45e-9m)
    'w_nmos1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 NMOS width (1-500×L)
    'w_pmos2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 PMOS width (1-500×L)
    'w_nmos3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 NMOS width (1-500×L)
    'w_pmos4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 PMOS width (1-500×L)
    'w_nmos5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 NMOS width (1-500×L)
    'w_pmos6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M6 PMOS width (1-500×L)
    # Bias voltages (constrained to reasonable ranges)
    'vbias1': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), max 1.2V
    'vbias2': {'min': 0.624, 'max': 0.936},  # Same as vbias1
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_nmos1': 5e-6,    # Original M1 width (5µm)
    'w_pmos2': 10e-6,   # Original M2 width (10µm)
    'w_nmos3': 10e-6,   # Original M3 width (10µm)
    'w_pmos4': 20e-6,   # Original M4 width (20µm)
    'w_nmos5': 20e-6,   # Original M5 width (20µm)
    'w_pmos6': 40e-6,   # Original M6 width (40µm)
    # Bias voltages
    'vbias1': 0.78,     # Original Vbias1 (Vdd - |Vth| - 0.2V)
    'vbias2': 0.78,     # Original Vbias2 (same as Vbias1)
}
