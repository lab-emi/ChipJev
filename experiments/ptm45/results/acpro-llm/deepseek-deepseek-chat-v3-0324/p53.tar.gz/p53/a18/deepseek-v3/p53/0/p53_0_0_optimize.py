from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed supply voltage
    # Input voltage (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed bias for NMOS
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2']@u_V)
    # Stage 1: Common-Source with Active Load (M1 and M2)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'],
                   l=0.045e-6)  # Fixed length for 45nm technology
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_m2'],
                   l=0.045e-6)
    # Stage 2: Common-Source with Active Load (M3 and M4)
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_m3'],
                   l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_m4'],
                   l=0.045e-6)
    # Stage 3: Common-Source with Active Load (M5 and M6)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_m5'],
                   l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_m6'],
                   l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W/L ratio optimization)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    # Bias voltages (conservative ranges to stay near intended operating point)
    'v_bias1': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), below 1.2V
    'v_bias2': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), below 1.2V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,    # Original NMOS width for M1
    'w_m2': 10e-6,   # Original PMOS width for M2
    'w_m3': 5e-6,    # Original NMOS width for M3
    'w_m4': 10e-6,   # Original PMOS width for M4
    'w_m5': 5e-6,    # Original NMOS width for M5
    'w_m6': 10e-6,   # Original PMOS width for M6
    # Bias voltages
    'v_bias1': 0.78, # Original bias voltage 1
    'v_bias2': 0.78, # Original bias voltage 2
}
