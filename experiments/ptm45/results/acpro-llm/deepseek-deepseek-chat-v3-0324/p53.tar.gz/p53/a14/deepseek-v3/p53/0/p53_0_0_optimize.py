from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    # Parameterized bias voltages (constrained to safe ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # First PMOS current source bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # Second PMOS current source bias
    # Stage 1: Common-Source with Active Load (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load (parameterized widths)
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Common-Source with Active Load (parameterized widths)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to 0.8-1.2× original but ≤1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # 0.8-1.2×0.78V (original=0.78V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # 0.8-1.2×0.78V (original=0.78V)
    # Stage 1 transistor widths (1-500× length, log scale)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original=5um
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original=10um
    # Stage 2 transistor widths (1-500× length, log scale)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original=10um
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original=20um
    # Stage 3 transistor widths (1-500× length, log scale)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original=20um
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original=30um
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    # Stage 1 transistors
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    # Stage 2 transistors
    'w_M3': 10e-6,
    'w_M4': 20e-6,
    # Stage 3 transistors
    'w_M5': 20e-6,
    'w_M6': 30e-6,
}
