Here's the parameterized version of your multi-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias
    
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # For M4
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # For M5 and M6
    
    # Stage 1: Common-Source with Active Load (M1 and M4)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed length
    circuit.MOSFET('4', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M4'], 
                  l=0.045e-6)  # Fixed length
    
    # Stage 2: Common-Source with Active Load (M2 and M5)
    circuit.MOSFET('2', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed length
    circuit.MOSFET('5', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M5'], 
                  l=0.045e-6)  # Fixed length
    
    # Stage 3: Common-Source with Active Load (M3 and M6)
    circuit.MOSFET('3', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M3'], 
                  l=0.045e-6)  # Fixed length
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M6'], 
                  l=0.045e-6)  # Fixed length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original value, never exceeding 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2× range)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2× range)
    
    # NMOS transistor widths (1-500× length)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    
    # PMOS transistor widths (1-500× length)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 30e-6
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.78,     # Original bias voltage for M4
    'vbias2': 0.78,     # Original bias voltage for M5 and M6
    'w_M1': 5e-6,       # Original width of M1
    'w_M2': 10e-6,      # Original width of M2
    'w_M3': 20e-6,      # Original width of M3
    'w_M4': 10e-6,      # Original width of M4
    'w_M5': 20e-6,      # Original width of M5
    'w_M6': 30e-6,      # Original width of M6
}

"""
Parameter Descriptions:
- vbias1: Bias voltage for M4 (PMOS current source load in 1st stage)
- vbias2: Bias voltage for M5 and M6 (PMOS current sources in 2nd and 3rd stages)
- w_M1: Width of M1 (NMOS input transistor in 1st stage)
- w_M2: Width of M2 (NMOS input transistor in 2nd stage)
- w_M3: Width of M3 (NMOS input transistor in 3rd stage)
- w_M4: Width of M4 (PMOS current source load in 1st stage)
- w_M5: Width of M5 (PMOS current source load in 2nd stage)
- w_M6: Width of M6 (PMOS current source load in 3rd stage)

Note: All transistor lengths are fixed at 45nm (0.045μm) for this 45nm technology.
"""
```

Key aspects of this implementation:
1. **Fixed Values**: Power supply voltage (1.2V) and input bias (0.42V) are kept fixed.
2. **Bias Voltages**: Made parameterizable with conservative ranges (0.8-1.2× original values, not exceeding 1.2V).
3. **MOSFET Parameters**: Only widths are parameterized (lengths fixed at 45nm), with ranges set to 1-500× the length.
4. **Initial Parameters**: Exactly match the original circuit values as required.
5. **Logarithmic Scaling**: Used for transistor widths to efficiently explore wide dynamic ranges.
6. **Physical Constraints**: All parameter ranges respect VDD (1.2V) and threshold voltage (0.22V) limits.

The implementation follows all your requirements and maintains compatibility with optimization frameworks while preserving the original circuit's functionality as a starting point.