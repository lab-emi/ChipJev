from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias (Vth + 200mV)
    # Parameterized bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    # Single Stage: Common-Source with Active Load
    # NMOS transistor (input device)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model',
                  w=params['w_nmos'],
                  l=0.045e-6)  # Fixed 45nm length
    # PMOS transistor (active load)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_pmos'],
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L=45nm fixed)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (original: 5µm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L (original: 10µm)
    # Bias voltage (conservative range around original value)
    'vbias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V) but clamped to ~(Vdd - Vth ± 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,     # Original NMOS width
    'w_pmos': 10e-6,    # Original PMOS width
    'vbias': 0.78,      # Original bias voltage (Vdd - |Vth| - 0.2V)
}
# Brief parameter descriptions:
# - w_nmos: Width of NMOS input transistor (affects transconductance and gain)
# - w_pmos: Width of PMOS active load (affects output impedance and gain)
# - vbias: PMOS gate bias voltage (sets operating point and output swing range)
