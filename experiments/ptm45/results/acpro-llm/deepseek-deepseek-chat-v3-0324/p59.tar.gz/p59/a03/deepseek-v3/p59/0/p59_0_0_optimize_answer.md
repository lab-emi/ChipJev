Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    
    # Parameterized bias voltage (Vbias)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}V")

    # Common-Source Stage with Current-Source Load
    # NMOS (M1) - parameterized width (length fixed at 45nm)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)
    
    # PMOS Current-Source Load (M2) - parameterized width (length fixed at 45nm)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)

    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS: 1-500× length (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS: 1-500× length (45nm)
    
    # Bias voltage (constrained to maintain proper operation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V) but max 1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original NMOS width
    'w_M2': 10e-6,   # Original PMOS width
    'v_bias': 0.78,  # Original bias voltage (Vdd - |Vth| - 0.2V)
}
```

### Parameter Descriptions:

1. **Transistor Widths**:
   - `w_M1`: Width of NMOS transistor M1 (common-source amplifier)
     - Range: 45nm (minimum feature size) to 22.5µm (500× length)
     - Original value: 5µm
   - `w_M2`: Width of PMOS transistor M2 (current-source load)
     - Range: Same as NMOS for consistency
     - Original value: 10µm

2. **Bias Voltage**:
   - `v_bias`: Gate voltage for PMOS current source (M2)
     - Range: ±20% of original value (0.624V-0.936V)
     - Constrained to keep PMOS in saturation
     - Original value: 0.78V (Vdd - |Vth| - 0.2V)

### Important Notes:
- The transistor lengths are fixed at 45nm (typical for this technology node)
- The input voltage (Vin) remains fixed at 0.42V (Vth + 0.2V) to keep M1 in saturation
- The bias voltage range is carefully constrained to maintain proper operation:
  - Minimum 0.624V ensures Vgs for M2 doesn't drop too low
  - Maximum 0.936V prevents gate voltage from getting too close to Vdd
- All initial parameter values are within their defined search ranges
- The power supply voltage (Vdd) remains fixed at 1.2V