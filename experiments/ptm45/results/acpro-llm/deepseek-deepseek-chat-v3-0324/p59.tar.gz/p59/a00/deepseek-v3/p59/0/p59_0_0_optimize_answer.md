Here's the parameterized conversion of your telescopic cascode amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Telescopic Cascode Amplifier')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Fixed power supply and input voltage
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltages (constrained to 0.8-1.2× original values, ≤1.2V)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # Cascode NMOS bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # Active load PMOS bias
    
    # Input Stage (M1) with parameterized width
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=0.045e-6)  # Fixed length 45nm
    
    # Cascode Stage (M3) with parameterized width
    circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M3'], 
                   l=0.045e-6)  # Fixed length 45nm
    
    # Active Load (M2) with parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'], 
                   l=0.045e-6)  # Fixed length 45nm
    
    # Fixed compensation capacitor (original value)
    circuit.C('1', 'Vout', 'Drain1', 1@u_pF)  # Fixed 1pF compensation capacitor
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5μm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input NMOS width
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load width
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode NMOS width
    
    # Bias voltages (0.8-1.2× original values, never exceeding 1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Cascode NMOS bias
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # Active load PMOS bias
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original M1 width
    'w_M2': 10e-6,    # Original M2 width
    'w_M3': 5e-6,     # Original M3 width
    'vbias1': 0.42,   # Original Vbias1 value
    'vbias2': 0.78,   # Original Vbias2 value
}

"""
Parameter Descriptions:
- w_M1: Input NMOS transistor width (affects transconductance and gain)
- w_M2: PMOS active load width (affects output impedance and gain)
- w_M3: Cascode NMOS transistor width (affects output impedance and gain)
- vbias1: Cascode NMOS bias voltage (sets cascode operating point)
- vbias2: PMOS active load bias voltage (sets load transistor operating point)

Note: All transistor lengths are fixed at 45nm (technology minimum).
Compensation capacitor is fixed at original 1pF value.
Power supply (1.2V) and input bias (0.42V) remain fixed.
"""
```

Key considerations:
1. **Fixed Values**: Power supply (1.2V), input bias (0.42V), and compensation capacitor (1pF) remain fixed as requested
2. **Width Parameters**: All transistor widths are parameterized with a range of 1-500× the 45nm length (45nm-22.5μm)
3. **Bias Voltages**: Constrained to ±20% of original values but never exceeding 1.2V supply
4. **Initial Values**: All initial_params exactly match your original circuit values
5. **Load Capacitors**: As per your request, no load capacitors were present in the original circuit, so none were parameterized

The circuit maintains the original telescopic cascode architecture while allowing optimization of critical parameters that affect gain, bandwidth, and power consumption.