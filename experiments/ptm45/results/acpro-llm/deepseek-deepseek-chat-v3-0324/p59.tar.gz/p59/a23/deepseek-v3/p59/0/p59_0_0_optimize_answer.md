Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)  # Parameterized bias voltage
    
    # Single Stage: Common-Source with Active Load
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=45e-9)  # Fixed 45nm length
    
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'], 
                   l=45e-9)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS width range (1-500×45nm)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS width range (1-500×45nm)
    
    # Bias voltage (conservative range around original value, constrained by Vth)
    'v_bias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), but clamped to stay above Vth and below Vdd
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width (5μm)
    'w_M2': 10e-6,    # Original PMOS width (10μm)
    'v_bias': 0.78,   # Original bias voltage (0.78V)
}
```

### Parameter Descriptions:

1. **w_M1**: NMOS transistor width (M1)
   - Search range: 45nm to 22.5μm (1-500× the 45nm length)
   - Physical meaning: Controls the driving strength and transconductance of the input transistor
   - Original value: 5μm (5000nm)

2. **w_M2**: PMOS transistor width (M2)
   - Search range: 45nm to 22.5μm (1-500× the 45nm length)
   - Physical meaning: Sets the load characteristics and gain of the amplifier
   - Original value: 10μm (10000nm)

3. **v_bias**: PMOS gate bias voltage
   - Search range: 0.62V to 0.94V (0.8-1.2× original 0.78V)
   - Physical meaning: Sets the operating point for the PMOS active load
   - Constrained to stay above threshold (~0.22V) and below Vdd (1.2V)
   - Original value: 0.78V (Vdd - |Vth| - 0.2V)

### Important Notes:

- All transistor lengths are fixed at 45nm (technology constraint)
- Power supply (Vdd = 1.2V) and input bias (Vin = 0.42V) are fixed
- The bias voltage range is carefully constrained:
  - Minimum (0.62V) maintains ~0.2V overdrive (0.8× original)
  - Maximum (0.94V) prevents PMOS from turning off (1.2× original but <1.2V)
- All initial values match exactly the original circuit specifications
- Width ranges allow 1-500× scaling of device sizes while maintaining practical dimensions