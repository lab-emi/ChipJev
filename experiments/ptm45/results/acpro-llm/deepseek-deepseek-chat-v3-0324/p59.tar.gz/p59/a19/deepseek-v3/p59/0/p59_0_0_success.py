from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
# Bias Voltages for Cascode and Active Load
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Vth + 0.2V for NMOS cascode
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V for PMOS load
# Input Stage
# M1: NMOS (Input Transistor)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# M3: NMOS (Cascode Transistor)
circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', 'Drain1', model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (M2: PMOS)
circuit.MOSFET('2', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Vout', 'Drain1', 1@u_pF)  # Compensation capacitor
circuit.R('c', 'Drain1', 'Node_c', 1@u_kΩ)  # Nulling resistor
circuit.C('x', 'Node_c', circuit.gnd, 1@u_pF)  # Dummy capacitor for simulation stability
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
