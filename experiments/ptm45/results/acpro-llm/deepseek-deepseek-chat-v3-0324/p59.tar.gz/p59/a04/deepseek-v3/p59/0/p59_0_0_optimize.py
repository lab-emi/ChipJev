from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply and input voltages (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    # Parameterized bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # Transistors with parameterized widths (length fixed at 45nm)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'], 
                   l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, with length fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width: 1-500×45nm
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width: 1-500×45nm
    # Bias voltage (0.8-1.2× original value, constrained by Vdd and Vth)
    'vbias': {'min': 0.624, 'max': 0.936},  # Original=0.78V, range=0.8× to 1.2× (never exceeds 1.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width
    'w_M2': 10e-6,    # Original PMOS width
    'vbias': 0.78,    # Original bias voltage
}
"""
Parameter Descriptions:
- w_M1: Width of NMOS transistor (M1). Affects transconductance and current.
- w_M2: Width of PMOS transistor (M2). Affects load characteristics and current.
- vbias: PMOS gate bias voltage. Critical for setting proper operating point.
         Range limited to 0.8-1.2× original value (0.78V) to maintain proper biasing
         while staying within 1.2V supply and accounting for Vth (0.22V).
"""
