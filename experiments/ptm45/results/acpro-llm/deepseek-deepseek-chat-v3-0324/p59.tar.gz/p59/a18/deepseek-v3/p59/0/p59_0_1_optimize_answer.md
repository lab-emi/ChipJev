Here's the parameterized version of your single-stage amplifier with active load, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # Define MOSFET models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # --- Power Supplies (fixed values) ---
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed supply voltage
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V) # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Parameterized PMOS bias
    
    # --- Transistors ---
    # M1: NMOS input transistor (common-source)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', l=0.045@u_um, w=params['w_M1'])
    
    # M2: PMOS active load (current source)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model', l=0.045@u_um, w=params['w_M2'])
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - kept within 1-500× the 45nm channel length
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},   # NMOS width (µm)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},   # PMOS width (µm)
    
    # Bias voltage - kept within 0.8-1.2× original value but constrained by Vdd and Vth
    'v_bias': {'min': 0.62, 'max': 0.94},  # Original was 0.78V (0.8× to 1.2× range)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5.0,       # Original NMOS width (µm)
    'w_M2': 10.0,      # Original PMOS width (µm)
    'v_bias': 0.78,    # Original PMOS bias voltage (V)
}

"""
Parameter Descriptions:
1. w_M1: Width of NMOS input transistor (M1). Affects transconductance and current.
   Range: 0.045-22.5µm (1-500× the 45nm length)
   
2. w_M2: Width of PMOS active load (M2). Affects output impedance and current sourcing.
   Range: 0.045-22.5µm (1-500× the 45nm length)
   
3. v_bias: PMOS gate bias voltage. Critical for setting operating point.
   Range: 0.62-0.94V (±20% around original 0.78V, constrained by Vdd-Vth)
   
Note:
- All transistor lengths fixed at 45nm (technology minimum)
- Supply voltage (Vdd) and input voltage (Vin) remain fixed
- No load capacitors were present in original circuit
- Voltage ranges carefully constrained to maintain proper operation:
  * v_bias must keep PMOS in saturation (Vgs < Vth for PMOS)
  * Input voltage (0.42V) keeps NMOS in saturation (Vgs > Vth)
"""
```

Key points implemented:
1. Preserved all original values exactly in `initial_params`
2. Kept Vdd (1.2V) and Vin (0.42V) fixed as requested
3. Parameterized transistor widths and PMOS bias voltage
4. Set conservative ranges for all parameters:
   - Widths: 1-500× the 45nm length (0.045-22.5µm)
   - PMOS bias: ±20% around original 0.78V (0.62-0.94V), staying well within 1.2V supply limit
5. Maintained fixed transistor lengths (45nm)
6. Included model imports exactly as specified
7. Added parameter descriptions in the docstring
8. The function is named `create_circuit` as required

The ranges ensure:
- All initial values are within the search ranges
- Circuit stays in intended operating regions (saturation for both transistors)
- No parameters exceed safe limits (especially voltage staying ≤1.2V)
- Width ranges allow sufficient exploration while being practical for 45nm technology