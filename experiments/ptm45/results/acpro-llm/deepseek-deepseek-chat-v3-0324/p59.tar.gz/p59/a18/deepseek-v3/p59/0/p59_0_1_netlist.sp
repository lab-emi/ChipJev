Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.78V
M1 Vout Vin 0 0 nmos_model l=0.045um w=5um
M2 Vout Vbias Vdd Vdd pmos_model l=0.045um w=10um
.model nmos_model nmos (Gamma=0.3 KP=0.0002 Lambda=0.1 Phi=0.6 Vto=0.22)
.model pmos_model pmos (Gamma=0.3 KP=0.0001 Lambda=0.1 Phi=0.6 Vto=-0.22)

