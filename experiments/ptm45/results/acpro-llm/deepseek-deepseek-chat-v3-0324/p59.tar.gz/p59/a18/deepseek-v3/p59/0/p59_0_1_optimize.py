from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define MOSFET models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # --- Power Supplies (fixed values) ---
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed supply voltage
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V) # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Parameterized PMOS bias
    # --- Transistors ---
    # M1: NMOS input transistor (common-source)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', l=0.045@u_um, w=params['w_M1'])
    # M2: PMOS active load (current source)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model', l=0.045@u_um, w=params['w_M2'])
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - kept within 1-500× the 45nm channel length
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},   # NMOS width (µm)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},   # PMOS width (µm)
    # Bias voltage - kept within 0.8-1.2× original value but constrained by Vdd and Vth
    'v_bias': {'min': 0.62, 'max': 0.94},  # Original was 0.78V (0.8× to 1.2× range)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5.0,       # Original NMOS width (µm)
    'w_M2': 10.0,      # Original PMOS width (µm)
    'v_bias': 0.78,    # Original PMOS bias voltage (V)
}
"""
Parameter Descriptions:
1. w_M1: Width of NMOS input transistor (M1). Affects transconductance and current.
   Range: 0.045-22.5µm (1-500× the 45nm length)
2. w_M2: Width of PMOS active load (M2). Affects output impedance and current sourcing.
   Range: 0.045-22.5µm (1-500× the 45nm length)
3. v_bias: PMOS gate bias voltage. Critical for setting operating point.
   Range: 0.62-0.94V (±20% around original 0.78V, constrained by Vdd-Vth)
Note:
- All transistor lengths fixed at 45nm (technology minimum)
- Supply voltage (Vdd) and input voltage (Vin) remain fixed
- No load capacitors were present in original circuit
- Voltage ranges carefully constrained to maintain proper operation:
  * v_bias must keep PMOS in saturation (Vgs < Vth for PMOS)
  * Input voltage (0.42V) keeps NMOS in saturation (Vgs > Vth)
"""
