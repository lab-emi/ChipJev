from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters (assumed to exist)
circuit = Circuit('Single-Stage Amplifier with Active Load')
# --- Critical Fix: Define MOSFET Models ---
# Explicitly declare models instead of relying on external imports (avoid "model not found" error)
# These parameters are typical for 45nm technology: Vth=0.22V, KP=200uA/V², etc.
circuit.model('nmos_model', 'nmos', 
              Vto=0.22, KP=200e-6, Lambda=0.1, Gamma=0.3, Phi=0.6)  # NMOS BSIM4-like parameters
circuit.model('pmos_model', 'pmos', 
              Vto=-0.22, KP=100e-6, Lambda=0.1, Gamma=0.3, Phi=0.6)  # PMOS BSIM4-like parameters
# --- Power Supplies ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # NMOS bias: Vth + 0.2V = 0.42V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # PMOS bias: Vdd - |Vth| - 0.2V = 0.78V
# --- Transistors ---
# M1: NMOS input transistor (common-source)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', l=0.045@u_um, w=5@u_um)  # Fixed model name
# M2: PMOS active load (current source)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', l=0.045@u_um, w=10@u_um)  # Fixed model name
# --- Analysis ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
