from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier (GBW/Power Optimized)')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (Vdd = 1.2V) - fixed
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
    # Input and Bias Voltages
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input voltage
    # Parameterized bias voltage (constrained range to maintain proper operation)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Transistors with parameterized widths
    # M1: NMOS input transistor
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'], 
                   l=0.045e-6)  # Fixed 45nm length
    # M2: PMOS active load
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m2'], 
                   l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length constraint)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (45nm to 22.5um)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (45nm to 22.5um)
    # Bias voltage (constrained to maintain proper operating region)
    'v_bias': {'min': 0.62, 'max': 0.94},  # 0.78V original ±20% keeping Vgs in moderate inversion
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,      # Original NMOS width (5um)
    'w_m2': 10e-6,     # Original PMOS width (10um)
    'v_bias': 0.78,    # Original bias voltage (0.78V)
}
"""
Parameter Descriptions:
- w_m1: Width of NMOS input transistor (M1)
- w_m2: Width of PMOS active load transistor (M2)
- v_bias: Bias voltage for PMOS transistor gate (Vbias)
Design Constraints:
- Transistor widths maintain 1-500× length ratio (45nm process)
- Bias voltage range keeps PMOS in saturation (Vdd - |Vth| - 0.2V ±20%)
- All voltages stay within 1.2V supply limit
- Original values preserved in initial_params for optimization seeding
"""
