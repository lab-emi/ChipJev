from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Folded Cascode Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Vdd = 1.2V
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vin = Vth + 0.2V = 0.42V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vbias1 = Vdd - |Vth| - 0.2V
# Bias Current Source (50 µA)
circuit.I('bias', 'Vdd', 'Vbias2', 50@u_uA)  # Critical fix: Provides current path
# Input Stage (M1)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
# Current Source Load (M2) - Wider for current matching
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
# Cascode Transistor (M3)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
# Diode-Connected PMOS (M4) - Sized for 50 µA
circuit.MOSFET('4', 'Vbias2', 'Vbias2', 'Vdd', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
