from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Folded Cascode Amplifier (Final Corrected)')
    # Define MOSFET models (fixed by technology)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth_n + 0.2V (fixed for input DC sweep)
    # Parameterized bias voltages (scaled from original values)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    # Parameterized bias current (50 µA original value)
    circuit.I('bias', 'Vbias2', circuit.gnd, params['i_bias']@u_uA)
    # Transistors with parameterized widths (length fixed at 45nm)
    # Input Stage (M1) - NMOS
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    # Current Source Load (M2) - PMOS
    circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    # Cascode Transistor (M3) - NMOS
    circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd,
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    # Diode-Connected PMOS (M4)
    circuit.MOSFET('4', 'Vbias2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length of 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 (NMOS input)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 (PMOS load)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 (NMOS cascode)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 (PMOS diode-connected)
    # Bias voltages (0.8-1.2× original, never exceeding 1.2V)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth_p| - 0.2V)
    # Bias current (0.5-2× original)
    'i_bias': {'min': 25, 'max': 100},  # Original: 50µA
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # M1 original width
    'w_m2': 20e-6,   # M2 original width
    'w_m3': 5e-6,    # M3 original width
    'w_m4': 40e-6,   # M4 original width
    'v_bias1': 0.78, # Original bias voltage
    'i_bias': 50,    # Original bias current (µA)
}
# Parameter descriptions for reference:
"""
w_m1: Width of input NMOS transistor (M1) [5µm original]
w_m2: Width of PMOS current source load (M2) [20µm original]
w_m3: Width of NMOS cascode transistor (M3) [5µm original]
w_m4: Width of diode-connected PMOS (M4) [40µm original]
v_bias1: Bias voltage for PMOS current source [0.78V original]
i_bias: Bias current setting [50µA original]
"""
