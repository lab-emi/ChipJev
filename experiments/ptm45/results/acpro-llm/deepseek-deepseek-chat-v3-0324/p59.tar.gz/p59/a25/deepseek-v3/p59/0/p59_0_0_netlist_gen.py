from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Folded Cascode Amplifier (GBW/Power Optimized)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias (Vin = Vth + 0.2V = 0.42V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
# Bias Voltage for PMOS Load (Vbias1 = Vdd - |Vth| - 0.2V = 0.78V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)
# Input Transistor (M1)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Current Source Load (M2)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Cascode Transistor (M3)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Diode-Connected PMOS for Vbias2 (M4)
circuit.MOSFET('4', 'Vbias2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
