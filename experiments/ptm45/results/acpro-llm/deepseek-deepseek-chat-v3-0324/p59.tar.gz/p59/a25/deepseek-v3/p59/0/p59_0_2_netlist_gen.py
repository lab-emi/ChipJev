from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Folded Cascode Amplifier (Final Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth_n + 0.2V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth_p| - 0.2V
# Corrected Bias Current Source (50 μA from Vbias2 to ground)
circuit.I('bias', 'Vbias2', circuit.gnd, 50@u_uA)
# Input Stage (M1) - NMOS
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
# Current Source Load (M2) - PMOS
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# Cascode Transistor (M3) - NMOS
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
# Diode-Connected PMOS (M4) - Corrected sizing
circuit.MOSFET('4', 'Vbias2', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=40e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
