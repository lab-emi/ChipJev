Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Fixed power supply (1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Fixed input signals and bias (will be swept during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias Vin at Vth + 0.2V (fixed)
    
    # Parameterized bias voltage (original: 0.78V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Input Stage: Common-Source with M1 (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=0.045e-6)  # Fixed length for 45nm technology
    
    # Active Load: Current Mirror (M2 and M3, PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'], 
                   l=0.045e-6)  # Diode-connected M2
    
    circuit.MOSFET('3', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M3'], 
                   l=0.045e-6)  # M3 mirrors M2 current
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L for M1 (NMOS)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L for M2 (PMOS)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L for M3 (PMOS)
    
    # Bias voltage (constrained to keep PMOS in saturation)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), keeping below Vdd - |Vth|
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original width for M1 (NMOS)
    'w_M2': 10e-6,   # Original width for M2 (PMOS)
    'w_M3': 10e-6,   # Original width for M3 (PMOS)
    'vbias': 0.78,   # Original bias voltage (V)
}
```

### Parameter Descriptions:

1. **Transistor Widths**:
   - `w_M1`: Width of NMOS input transistor (M1). Original: 5µm, range: 45nm (1×L) to 22.5µm (500×L)
   - `w_M2`: Width of diode-connected PMOS load (M2). Original: 10µm, range: 45nm to 22.5µm
   - `w_M3`: Width of PMOS mirror transistor (M3). Original: 10µm, range: 45nm to 22.5µm

2. **Bias Voltage**:
   - `vbias`: Gate bias voltage for PMOS current mirror. Original: 0.78V, range: 0.624V to 0.936V (0.8-1.2× original)
     - This range ensures Vbias stays below Vdd - |Vth| (1.2V - 0.22V = 0.98V)
     - The minimum 0.624V ensures enough overdrive voltage for the input NMOS (Vgs - Vth)

### Notes:
- All transistor lengths are fixed at 45nm (technology constraint)
- The power supply (1.2V) and input bias (0.42V) remain fixed as requested
- The bias voltage range is conservatively set to maintain circuit operation while allowing optimization
- Width ranges allow scaling from minimum size (1×L) up to 500×L, which is practical for analog design
- All initial parameter values are exactly the original values from your circuit
- No load capacitors were in the original circuit, so none were added