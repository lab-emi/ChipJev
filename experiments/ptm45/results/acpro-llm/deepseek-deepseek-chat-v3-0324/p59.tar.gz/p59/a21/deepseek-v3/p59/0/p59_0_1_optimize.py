from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define MOSFET Models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input and Bias Voltages (input fixed, biases parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # M1 bias (Vth + 0.2V)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    # Transistors (W parameterized, L fixed at 45nm)
    # M1: Input NMOS
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M1']@u_um, l=0.045@u_um)
    # M2: NMOS Cascode
    circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1',
                  model='nmos_model', w=params['w_M2']@u_um, l=0.045@u_um)
    # M3: PMOS Cascode
    circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain3', 'Drain3',
                  model='pmos_model', w=params['w_M3']@u_um, l=0.045@u_um)
    # M4: PMOS Current Source
    circuit.MOSFET('4', 'Drain3', 'Vbias3', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4']@u_um, l=0.045@u_um)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 0.045-22.5μm)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},  # Input NMOS width (μm)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS Cascode width (μm)
    'w_M3': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS Cascode width (μm)
    'w_M4': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS Current Source width (μm)
    # Bias voltages (0.8-1.2× original values, clamped to 1.2V max)
    'vbias1': {'min': 0.336, 'max': 0.504},  # M2 bias (0.42V original)
    'vbias2': {'min': 0.624, 'max': 0.936},  # M3 bias (0.78V original)
    'vbias3': {'min': 0.624, 'max': 0.936},  # M4 bias (0.78V original)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5.0,    # Original M1 width (μm)
    'w_M2': 5.0,    # Original M2 width (μm)
    'w_M3': 10.0,   # Original M3 width (μm)
    'w_M4': 10.0,   # Original M4 width (μm)
    # Bias voltages
    'vbias1': 0.42,  # Original M2 bias voltage (V)
    'vbias2': 0.78,  # Original M3 bias voltage (V)
    'vbias3': 0.78,  # Original M4 bias voltage (V)
}
