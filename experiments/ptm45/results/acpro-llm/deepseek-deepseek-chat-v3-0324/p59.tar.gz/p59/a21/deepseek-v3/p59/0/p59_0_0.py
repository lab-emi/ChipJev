from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS cascode bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # PMOS current source bias
# Transistors (45nm technology, L=0.045µm)
# NMOS M1 (input)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# NMOS M2 (cascode)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1', 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# PMOS M3 (cascode)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain3', 'Drain3', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# PMOS M4 (current source)
circuit.MOSFET('4', 'Drain3', 'Vbias3', 'Vdd', 'Vdd', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
