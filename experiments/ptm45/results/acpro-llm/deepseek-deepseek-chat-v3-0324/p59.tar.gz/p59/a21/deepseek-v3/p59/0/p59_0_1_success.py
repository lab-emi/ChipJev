from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Assumes model.py provides these parameters
circuit = Circuit('Telescopic Cascode Amplifier')
# Define MOSFET Models Explicitly (Critical Fix)
circuit.model('nmos_model', 'nmos', **nmos_params)  # Uses imported nmos_params
circuit.model('pmos_model', 'pmos', **pmos_params)  # Uses imported pmos_params
# Power Supply (Unchanged)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (Unchanged but marked explicitly)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # M1 bias (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # M2 bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # M3 bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # M4 bias
# Transistors (Fixed bulk connections and units)
# M1: Input NMOS (bulk to ground)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# M2: NMOS Cascode (bulk to source, not ground!)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1',  # Bulk tied to source
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# M3: PMOS Cascode (bulk to source, not Vdd!)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain3', 'Drain3',  # Bulk tied to source
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# M4: PMOS Current Source (bulk to Vdd)
circuit.MOSFET('4', 'Drain3', 'Vbias3', 'Vdd', 'Vdd',  # Bulk tied to Vdd
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
