from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define MOSFET models (fixed parameters from module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    # Bias Voltages (parameterized)
    circuit.V('bias_n', 'Vbias_n', circuit.gnd, params['v_bias_n']@u_V)  # NMOS cascode bias
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['v_bias_p']@u_V)  # PMOS active load bias
    # Transistors (widths parameterized, length fixed at 45nm)
    # M1: Input NMOS
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=0.045e-6)
    # M3: NMOS Cascode
    circuit.MOSFET('3', 'Vout', 'Vbias_n', 'Drain1', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M3'], 
                   l=0.045e-6)
    # M2: PMOS Active Load
    circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M2'], 
                   l=0.045e-6)
    # Optional compensation capacitor (commented out in original)
    # if params.get('c_comp', 0) > 0:  # Only add if value > 0
    #     circuit.C('1', 'Vout', 'Vbias_n', params['c_comp']@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input NMOS
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode NMOS
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Load PMOS
    # Bias voltages (0.8-1.2× original but ≤1.2V)
    'v_bias_n': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # NMOS cascode gate
    'v_bias_p': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # PMOS gate
    # Optional compensation capacitor (0-5pF if enabled)
    # 'c_comp': {'min': 0, 'max': 5},  # Uncomment if enabling compensation
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,     # Original M1 width
    'w_M3': 5e-6,     # Original M3 width
    'w_M2': 10e-6,    # Original M2 width
    # Bias voltages
    'v_bias_n': 0.42, # Original NMOS cascode bias (Vth + 0.2V)
    'v_bias_p': 0.78, # Original PMOS load bias
    # Optional compensation cap
    # 'c_comp': 1,     # Uncomment if enabling compensation
}
