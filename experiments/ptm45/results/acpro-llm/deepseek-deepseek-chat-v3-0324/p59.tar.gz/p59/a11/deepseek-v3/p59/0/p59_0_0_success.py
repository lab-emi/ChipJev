from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V = 0.42V)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # NMOS cascode bias
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS active load bias
# Transistors
# M1: Input NMOS (Vin -> M1 gate)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# M3: NMOS Cascode (M1 drain -> M3 source, Vbias_n -> M3 gate)
circuit.MOSFET('3', 'Vout', 'Vbias_n', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# M2: PMOS Active Load (Vdd -> M2 source, Vbias_p -> M2 gate, Vout -> M2 drain)
circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Optional: Frequency Compensation Capacitor (uncomment if needed)
# circuit.C('1', 'Vout', 'Vbias_n', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
