Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.78V
M1 Vout Vin 0 0 nmos_model l=4.5e-08 w=1e-05
M2 Vout Vbias Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M3 Vbias Vbias Vdd Vdd pmos_model l=4.5e-08 w=2e-05
.model nmos_model nmos (CGDO=1e-12 CGSO=1e-12 KP=0.0001 LAMBDA=0.1 LEVEL=1 VTO=0.22)
.model pmos_model pmos (CGDO=1e-12 CGSO=1e-12 KP=5e-05 LAMBDA=0.1 LEVEL=1 VTO=-0.22)

