from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with Current Mirror Load')
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # 0.42V input bias (Vth + 0.2V)
# Common-Source Stage (M1)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Current Mirror Load (M2, M3)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vbias', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Bias Voltage for Current Mirror (Vbias)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)  # Vdd - |Vth| - 0.2V = 1.2 - 0.22 - 0.2 = 0.78V
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
