from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters (note: this line is retained but overridden below)
circuit = Circuit('Single-Stage Amplifier with Current Mirror Load')
# --- Define MOSFET Models (CRITICAL FIX) ---
# Override the imported models with explicit .model statements
circuit.model('nmos_model', 'nmos', 
              LEVEL=1, 
              VTO=0.22,    # Threshold voltage (Vth)
              KP=100e-6,   # Transconductance parameter
              LAMBDA=0.1,  # Channel-length modulation
              CGSO=1e-12,  # Gate-source overlap capacitance
              CGDO=1e-12)  # Gate-drain overlap capacitance
circuit.model('pmos_model', 'pmos', 
              LEVEL=1, 
              VTO=-0.22,   # Threshold voltage (|Vth|)
              KP=50e-6,    # Lower KP for PMOS (typical for 45nm)
              LAMBDA=0.1,
              CGSO=1e-12,
              CGDO=1e-12)
# --- Power Supplies ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)   # 1.2V supply
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42@u_V ac 1n")
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V = 0.78V
# --- Common-Source Stage (M1) ---
# M1: NMOS, gate=Vin, source=gnd, drain=Vout, bulk=gnd
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', 
               w=10e-6, l=0.045e-6)
# --- Current Mirror Load (M2, M3) ---
# M2: PMOS, gate=Vbias, source=Vdd, drain=Vout, bulk=Vdd
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', 
               w=20e-6, l=0.045e-6)
# M3: Diode-connected PMOS, gate=Vbias, source=Vdd, drain=Vbias, bulk=Vdd
circuit.MOSFET('3', 'Vbias', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', 
               w=20e-6, l=0.045e-6)
# --- Analysis ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)