from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Current Mirror Load')
    # --- MOSFET Models ---
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # --- Power Supplies (fixed voltages) ---
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)          # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)         # Fixed input bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)  # Parameterized bias
    # --- Common-Source Stage (M1) ---
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)  # Fixed length for 45nm
    # --- Current Mirror Load (M2, M3) ---
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2M3'],
                   l=0.045e-6)  # Fixed length
    circuit.MOSFET('3', 'Vbias', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2M3'],  # M3 matches M2 width
                   l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (min 1um, max 500× length (22.5um) for 45nm)
    'w_M1': {'min': 1e-6, 'max': 22.5e-6, 'log': True},      # NMOS width
    'w_M2M3': {'min': 1e-6, 'max': 22.5e-6, 'log': True},    # PMOS width (mirror pair)
    # Bias voltage (original 0.78V, range centered around Vdd-Vth-0.2V)
    'v_bias': {'min': 0.62, 'max': 0.94, 'log': False}  # 0.8-1.2× original, max < Vdd
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,      # Original M1 width
    'w_M2M3': 20e-6,    # Original M2/M3 width
    'v_bias': 0.78,     # Original bias voltage
}
"""
Parameter Descriptions:
- w_M1: Width of input NMOS transistor (M1). Affects gain and bandwidth.
- w_M2M3: Width of PMOS current mirror transistors (M2, M3). Affects output impedance and current.
- v_bias: Bias voltage for PMOS current mirror. Must keep PMOS in saturation while allowing sufficient Vds for M1.
Constraints:
- All widths maintain 1-500× length ratio (45nm → 0.045um length → 0.045-22.5um width)
- Bias voltage range (0.62-0.94V) ensures:
  - Minimum: 0.8× original (0.62V) keeps Vgs > |Vth| for PMOS (0.22V)
  - Maximum: 1.2× original (0.94V) but < Vdd (1.2V)
"""
