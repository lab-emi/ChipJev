from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# === Key Fixes ===
# 1. Added explicit SPICE model definitions (PySpice cannot use Python variables directly).
# 2. Simplified bulk connections (NMOS bulk to ground, PMOS bulk to Vdd).
# 3. Adjusted bias voltages for proper saturation.
circuit = Circuit('Telescopic Cascode Amplifier (Fixed)')
# === Power Supply ===
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
# === Input Bias ===
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42@u_V ac 1n")
# === Bias Voltages ===
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V = 0.78V (PMOS M2)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.5@u_V)   # Adjusted for cascode (M3)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.5@u_V)   # Adjusted for cascode (M4)
# === MOSFET Models (Critical Fix) ===
# PySpice requires explicit .model definitions (cannot use 'nmos_model'/'pmos_model' directly).
circuit.model('nmos', 'nmos', level=1, kp=100e-6, vto=0.22)  # Simplified NMOS model
circuit.model('pmos', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Simplified PMOS model
# === Transistors ===
# M1: Input NMOS (W=10um, L=45nm)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos', w=10@u_um, l=0.045@u_um)
# M2: PMOS Current Source Load (W=20um, L=45nm)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos', w=20@u_um, l=0.045@u_um)
# M3: NMOS Cascode (W=5um, L=45nm)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, model='nmos', w=5@u_um, l=0.045@u_um)
# M4: PMOS Cascode (W=10um, L=45nm)
circuit.MOSFET('4', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
# === Analysis ===
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)