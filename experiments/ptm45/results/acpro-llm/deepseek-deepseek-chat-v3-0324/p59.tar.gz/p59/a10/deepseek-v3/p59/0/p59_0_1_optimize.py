from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier (Parameterized)')
    # === Power Supply (Fixed) ===
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply (fixed)
    # === Input Bias (Fixed) ===
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V (fixed)
    # === Bias Voltages (Parameterized) ===
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    # === MOSFET Models (Fixed) ===
    circuit.model('nmos', 'nmos', **nmos_params)
    circuit.model('pmos', 'pmos', **pmos_params)
    # === Transistors (Widths Parameterized) ===
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos', w=params['w_M1']@u_um, l=0.045@u_um)
    circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos', w=params['w_M2']@u_um, l=0.045@u_um)
    circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, 
                   model='nmos', w=params['w_M3']@u_um, l=0.045@u_um)
    circuit.MOSFET('4', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                   model='pmos', w=params['w_M4']@u_um, l=0.045@u_um)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length constraint, 0.045-22.5μm range)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},  # Input NMOS (M1)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS current source (M2)
    'w_M3': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS cascode (M3)
    'w_M4': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS cascode (M4)
    # Bias voltages (0.8-1.2× original values, not exceeding 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
    'vbias2': {'min': 0.4,   'max': 0.6},    # Original: 0.5V (NMOS cascode)
    'vbias3': {'min': 0.4,   'max': 0.6},    # Original: 0.5V (PMOS cascode)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values in um)
    'w_M1': 10.0,  # Input NMOS
    'w_M2': 20.0,  # PMOS current source
    'w_M3': 5.0,   # NMOS cascode
    'w_M4': 10.0,  # PMOS cascode
    # Bias voltages (original values in V)
    'vbias1': 0.78,  # Vdd - |Vth| - 0.2V
    'vbias2': 0.5,   # NMOS cascode bias
    'vbias3': 0.5,   # PMOS cascode bias
}
# Parameter descriptions
parameter_descriptions = {
    'w_M1': "Input NMOS transistor (M1) width (μm)",
    'w_M2': "PMOS current source load (M2) width (μm)",
    'w_M3': "NMOS cascode transistor (M3) width (μm)",
    'w_M4': "PMOS cascode transistor (M4) width (μm)",
    'vbias1': "PMOS current source bias voltage (V)",
    'vbias2': "NMOS cascode bias voltage (V)",
    'vbias3': "PMOS cascode bias voltage (V)",
}
