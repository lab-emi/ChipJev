Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias1 Vbias1 0 0.78V
Vbias2 Vbias2 0 0.5V
Vbias3 Vbias3 0 0.5V
M1 Drain1 Vin 0 0 nmos l=0.045um w=10um
M2 Vout Vbias1 Vdd Vdd pmos l=0.045um w=20um
M3 Vout Vbias2 Drain1 0 nmos l=0.045um w=5um
M4 Vout Vbias3 Vdd Vdd pmos l=0.045um w=10um
.model nmos nmos (kp=0.0001 level=1 vto=0.22)
.model pmos pmos (kp=5e-05 level=1 vto=-0.22)

