from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier (Max GBW/Power)')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
# Input Bias (DC operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias at Vth + 0.2V
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # For M2 (PMOS current source)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # For M3 (NMOS cascode)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # For M4 (PMOS cascode)
# Transistors
# M1: Input NMOS (W=10um, L=45nm)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)
# M2: PMOS Current Source Load (W=20um, L=45nm)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=20@u_um, l=0.045@u_um)
# M3: NMOS Cascode (W=5um, L=45nm)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
# M4: PMOS Cascode (W=10um, L=45nm)
circuit.MOSFET('4', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
