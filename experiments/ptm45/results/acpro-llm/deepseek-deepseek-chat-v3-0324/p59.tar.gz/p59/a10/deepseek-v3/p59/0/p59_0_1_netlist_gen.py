from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# === Key Fixes ===
# 1. Added explicit SPICE model definitions (PySpice cannot use Python variables directly).
# 2. Simplified bulk connections (NMOS bulk to ground, PMOS bulk to Vdd).
# 3. Adjusted bias voltages for proper saturation.
circuit = Circuit('Telescopic Cascode Amplifier (Fixed)')
# === Power Supply ===
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
# === Input Bias ===
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.42V (NMOS input bias)
# === Bias Voltages ===
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V = 0.78V (PMOS M2)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.5@u_V)   # Adjusted for cascode (M3)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.5@u_V)   # Adjusted for cascode (M4)
# === MOSFET Models (Critical Fix) ===
# PySpice requires explicit .model definitions (cannot use 'nmos_model'/'pmos_model' directly).
circuit.model('nmos', 'nmos', level=1, kp=100e-6, vto=0.22)  # Simplified NMOS model
circuit.model('pmos', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Simplified PMOS model
# === Transistors ===
# M1: Input NMOS (W=10um, L=45nm)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos', w=10@u_um, l=0.045@u_um)
# M2: PMOS Current Source Load (W=20um, L=45nm)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos', w=20@u_um, l=0.045@u_um)
# M3: NMOS Cascode (W=5um, L=45nm)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, model='nmos', w=5@u_um, l=0.045@u_um)
# M4: PMOS Cascode (W=10um, L=45nm)
circuit.MOSFET('4', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
# === Analysis ===
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
