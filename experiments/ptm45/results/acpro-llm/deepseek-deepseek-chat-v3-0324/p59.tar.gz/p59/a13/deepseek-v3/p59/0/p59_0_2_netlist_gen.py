from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Regulated Cascode Amplifier (Max GBW/Power)')
# ================================================
# CRITICAL FIX: Replace 'lambda' parameter name which conflicts with Python keyword
# Using 'lambd' instead (note the missing 'a') for channel length modulation
# ================================================
circuit.model(
    'nmos_model', 'nmos',
    level=54,
    vto=0.22,
    kp=200e-6,
    gamma=0.3,
    lambd=0.1  # Changed from 'lambda' to 'lambd'
)
circuit.model(
    'pmos_model', 'pmos',
    level=54,
    vto=-0.22,
    kp=80e-6,
    gamma=0.25,
    lambd=0.1  # Changed from 'lambda' to 'lambd'
)
# ================================================
# Power Supplies (unchanged)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)
# Transistor Definitions (unchanged)
circuit.MOSFET(
    '1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
    model='nmos_model',
    w=5@u_um, l=0.045@u_um
)
circuit.MOSFET(
    '2', 'Vout', 'Vbias', 'Drain1', 'Drain1',
    model='nmos_model',
    w=5@u_um, l=0.045@u_um
)
circuit.MOSFET(
    '3', 'Vreg', 'Drain1', circuit.gnd, circuit.gnd,
    model='nmos_model',
    w=2.5@u_um, l=0.045@u_um
)
circuit.MOSFET(
    '4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
    model='pmos_model',
    w=10@u_um, l=0.045@u_um
)
# Feedback Resistor (unchanged)
circuit.R('1', 'Vreg', 'Vbias', 1@u_kΩ)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
