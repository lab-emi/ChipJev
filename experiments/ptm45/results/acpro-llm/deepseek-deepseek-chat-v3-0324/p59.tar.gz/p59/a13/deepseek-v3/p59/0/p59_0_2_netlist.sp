Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.42V
Vbias_p Vbias_p 0 0.78V
M1 Drain1 Vin 0 0 nmos_model l=0.045um w=5um
M2 Vout Vbias Drain1 Drain1 nmos_model l=0.045um w=5um
M3 Vreg Drain1 0 0 nmos_model l=0.045um w=2.5um
M4 Vout Vbias_p Vdd Vdd pmos_model l=0.045um w=10um
R1 Vreg Vbias 1kOhm
.model nmos_model nmos (gamma=0.3 kp=0.0002 lambd=0.1 level=54 vto=0.22)
.model pmos_model pmos (gamma=0.25 kp=8e-05 lambd=0.1 level=54 vto=-0.22)

