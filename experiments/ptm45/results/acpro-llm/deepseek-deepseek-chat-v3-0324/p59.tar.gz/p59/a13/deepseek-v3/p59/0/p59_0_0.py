from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Regulated Cascode Amplifier (Max GBW/Power)')
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V = 0.42V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Cascode bias (same as input)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS load bias (Vdd - |Vth| - 0.2V = 0.78V)
# Transistors
# M1: Input NMOS (Common-Source)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# M2: Cascode NMOS
circuit.MOSFET('2', 'Vout', 'Vbias', 'Drain1', 'Drain1', model='nmos_model', w=5e-6, l=0.045e-6)
# M3: Regulator NMOS
circuit.MOSFET('3', 'Vreg', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=2.5e-6, l=0.045e-6)
# M4: PMOS Load
circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Feedback Resistor for Regulation
circuit.R('1', 'Vreg', 'Vbias', 1@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
