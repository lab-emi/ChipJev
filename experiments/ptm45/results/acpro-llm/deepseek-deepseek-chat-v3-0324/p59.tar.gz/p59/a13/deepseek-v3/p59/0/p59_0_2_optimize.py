from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Regulated Cascode Amplifier (Max GBW/Power)')
    # ================================================
    # MOSFET Models (using imported params)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # ================================================
    # Fixed Power Supplies
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed supply voltage
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input voltage
    # Parameterized Bias Voltages
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}")  # Parameterized
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, f"{params['v_bias_p']}")  # Parameterized
    # ================================================
    # Transistors - Width parameterized, Length fixed at 45nm
    circuit.MOSFET(
        '1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
        model='nmos_model',
        w=f"{params['w_M1']}u", l=0.045@u_um  # Width parameterized
    )
    circuit.MOSFET(
        '2', 'Vout', 'Vbias', 'Drain1', 'Drain1',
        model='nmos_model',
        w=f"{params['w_M2']}u", l=0.045@u_um  # Width parameterized
    )
    circuit.MOSFET(
        '3', 'Vreg', 'Drain1', circuit.gnd, circuit.gnd,
        model='nmos_model',
        w=f"{params['w_M3']}u", l=0.045@u_um  # Width parameterized
    )
    circuit.MOSFET(
        '4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
        model='pmos_model',
        w=f"{params['w_M4']}u", l=0.045@u_um  # Width parameterized
    )
    # ================================================
    # Feedback Resistor - parameterized
    circuit.R('1', 'Vreg', 'Vbias', f"{params['r_fb']}k")  # Parameterized
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (um) - range 1-500× length (45nm = 0.045um)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},  # Original: 5um
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},  # Original: 5um
    'w_M3': {'min': 0.0225, 'max': 11.25, 'log': True},  # Original: 2.5um
    'w_M4': {'min': 0.045, 'max': 22.5, 'log': True},  # Original: 10um
    # Bias Voltages (V) - 0.8-1.2× original, not exceeding 1.2V
    # Original values: Vbias=0.42V, Vbias_p=0.78V
    'v_bias': {'min': 0.336, 'max': 0.504},  # (0.42×0.8 to 0.42×1.2)
    'v_bias_p': {'min': 0.624, 'max': 0.936},  # (0.78×0.8 to 0.78×1.2)
    # Feedback Resistor (kΩ) - 0.5-2× original value (1kΩ)
    'r_fb': {'min': 0.5, 'max': 2, 'log': True},
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (um)
    'w_M1': 5.0,
    'w_M2': 5.0,
    'w_M3': 2.5,
    'w_M4': 10.0,
    # Bias Voltages (V)
    'v_bias': 0.42,
    'v_bias_p': 0.78,
    # Feedback Resistor (kΩ)
    'r_fb': 1.0,
}
# Parameter descriptions:
"""
w_M1: Width of input NMOS transistor (M1, original=5um)
w_M2: Width of cascode NMOS transistor (M2, original=5um)
w_M3: Width of regular NMOS transistor (M3, original=2.5um)
w_M4: Width of PMOS load transistor (M4, original=10um)
v_bias: Cascode bias voltage (original=0.42V)
v_bias_p: PMOS bias voltage (original=0.78V)
r_fb: Feedback resistance (original=1kΩ)
"""
