from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Regulated Cascode Amplifier (Max GBW/Power)')
# ================================================
# CRITICAL FIX: Add explicit SPICE model definitions
# ================================================
# 45nm BSIM4 models (simplified for PySpice compatibility)
circuit.model(
    'nmos_model', 'nmos',
    level=54,  # BSIM4
    vto=0.22,  # Threshold voltage
    kp=200e-6, # Transconductance parameter
    gamma=0.3, # Body effect parameter
    lambda=0.1 # Channel length modulation
)
circuit.model(
    'pmos_model', 'pmos',
    level=54,
    vto=-0.22,
    kp=80e-6,
    gamma=0.25,
    lambda=0.1
)
# ================================================
# Power Supplies (unchanged)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)
# ================================================
# TRANSISTOR CONNECTIONS VERIFIED:
# 1. Fixed bulk connections (NMOS to ground, PMOS to Vdd)
# 2. Corrected width/length units (now explicit in micrometers)
# ================================================
# M1: Input NMOS (W=5um, L=45nm)
circuit.MOSFET(
    '1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
    model='nmos_model',
    w=5@u_um, l=0.045@u_um
)
# M2: Cascode NMOS
circuit.MOSFET(
    '2', 'Vout', 'Vbias', 'Drain1', 'Drain1',  # Bulk tied to source (Drain1)
    model='nmos_model',
    w=5@u_um, l=0.045@u_um
)
# M3: Regulator NMOS (smaller width for lower power)
circuit.MOSFET(
    '3', 'Vreg', 'Drain1', circuit.gnd, circuit.gnd,
    model='nmos_model',
    w=2.5@u_um, l=0.045@u_um
)
# M4: PMOS Load (wider for current matching)
circuit.MOSFET(
    '4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',  # Bulk tied to Vdd
    model='pmos_model',
    w=10@u_um, l=0.045@u_um
)
# Feedback Resistor (value adjusted for stability)
circuit.R('1', 'Vreg', 'Vbias', 1@u_kΩ)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
