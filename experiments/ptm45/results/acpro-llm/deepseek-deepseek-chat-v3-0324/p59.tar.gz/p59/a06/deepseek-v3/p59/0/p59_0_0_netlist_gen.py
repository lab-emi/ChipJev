from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies (Vdd = 1.2V, Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias for M1 (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.64@u_V)  # Bias for M3 (Vth + 0.2V + Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Bias for M2 (Vdd - |Vth| - 0.2V)
# Input Stage (M1: NMOS, W/L = 5um/45nm)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Cascode Stage (M3: NMOS, W/L = 5um/45nm)
circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (M2: PMOS, W/L = 10um/45nm)
circuit.MOSFET('2', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
