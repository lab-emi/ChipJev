from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # This import is kept as per requirements
circuit = Circuit('Telescopic Cascode Amplifier')
# Fix 1: Explicitly define MOSFET models in the netlist (required by SPICE)
# Using BSIM4 models (typical for 45nm) with placeholder parameters
circuit.model('nmos_model', 'nmos', 
              level=54,  # BSIM4
              vto=0.22,  # Threshold voltage
              kp=100e-6, # Transconductance parameter
              lambda=0.1 # Channel-length modulation
              )
circuit.model('pmos_model', 'pmos', 
              level=54,
              vto=-0.22,  # Negative for PMOS
              kp=50e-6,
              lambda=0.1
              )
# Power Supplies (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Fix 2: Adjusted bias voltages to ensure saturation (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode: Vth + 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS current source: Vdd - |Vth| - 0.2V
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.6@u_V)   # PMOS cascode: Mid-rail bias
# Fix 3: Input DC bias (ensure M1 is in saturation)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
# Transistors (45nm)
# NMOS: M1 (input), M2 (cascode)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1', 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# PMOS: M3 (current source), M4 (cascode)
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Vout', 'Vbias4', 'Drain3', 'Drain3', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
