from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Use provided model parameters
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply (1.2V for 45nm technology)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Parameterized bias voltages (constrained near original values)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # NMOS cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # PMOS current source bias
    circuit.V('bias4', 'Vbias4', circuit.gnd, params['vbias4']@u_V)  # PMOS cascode bias
    # Fixed input bias voltage (Vth + 0.2V to keep M1 in saturation)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # NMOS transistors (fixed L=45nm, parameterized W)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045@u_um)
    circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1',
                  model='nmos_model', w=params['w_M2'], l=0.045@u_um)
    # PMOS transistors (fixed L=45nm, parameterized W)
    circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M3'], l=0.045@u_um)
    circuit.MOSFET('4', 'Vout', 'Vbias4', 'Drain3', 'Drain3',
                  model='pmos_model', w=params['w_M4'], l=0.045@u_um)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 0.045-22.5μm)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},  # Input NMOS width (μm)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},  # NMOS cascode width (μm)
    'w_M3': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS current source width (μm)
    'w_M4': {'min': 0.045, 'max': 22.5, 'log': True},  # PMOS cascode width (μm)
    # Bias voltages (0.8-1.2× original but ≤1.2V, considering Vth=0.22V)
    'vbias1': {'min': 0.34, 'max': 0.50, 'log': False},  # Original 0.42V (NMOS cascode)
    'vbias2': {'min': 0.62, 'max': 0.94, 'log': False},  # Original 0.78V (PMOS current source)
    'vbias4': {'min': 0.48, 'max': 0.72, 'log': False},  # Original 0.6V (PMOS cascode)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original 5μm for NMOS, 10μm for PMOS)
    'w_M1': 5.0,
    'w_M2': 5.0,
    'w_M3': 10.0,
    'w_M4': 10.0,
    # Bias voltages (original values)
    'vbias1': 0.42,  # Vth + 0.2V for NMOS cascode
    'vbias2': 0.78,  # Vdd - |Vth| - 0.2V for PMOS current source
    'vbias4': 0.6,   # Mid-rail for PMOS cascode
}
# Physical meaning of parameters:
# w_M1: Input transistor width - affects gm and gain
# w_M2: NMOS cascode width - affects output impedance
# w_M3: PMOS current source width - affects bias current
# w_M4: PMOS cascode width - affects output impedance
# vbias1: NMOS cascode gate voltage - ensures saturation
# vbias2: PMOS current source gate voltage - sets current
# vbias4: PMOS cascode gate voltage - ensures saturation
