from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Power Supplies and Biasing (Vdd = 1.2V, Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS current source bias (Vdd - |Vth| - 0.2V)
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.6@u_V)   # PMOS cascode bias (Vdd/2)
# Input Signal (DC bias only, no AC)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
# Transistors (45nm technology)
# NMOS: M1 (input), M2 (cascode)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Vout', 'Vbias1', 'Drain1', 'Drain1', model='nmos_model', w=5@u_um, l=0.045@u_um)
# PMOS: M3 (current source), M4 (cascode)
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Vout', 'Vbias4', 'Drain3', 'Drain3', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
