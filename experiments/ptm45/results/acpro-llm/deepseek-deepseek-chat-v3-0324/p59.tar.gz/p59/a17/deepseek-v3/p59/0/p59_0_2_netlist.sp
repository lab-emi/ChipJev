Vdd Vdd 0 1.2V
Vbias1 Vbias1 0 0.42V
Vbias2 Vbias2 0 0.78V
Vbias4 Vbias4 0 0.6V
Vin Vin 0 0.42V
M1 Drain1 Vin 0 0 nmos_model l=0.045um w=5um
M2 Vout Vbias1 Drain1 Drain1 nmos_model l=0.045um w=5um
M3 Drain3 Vbias2 Vdd Vdd pmos_model l=0.045um w=10um
M4 Vout Vbias4 Drain3 Drain3 pmos_model l=0.045um w=10um
.model nmos_model nmos (kp=0.0001 lambd=0.1 level=54 vto=0.22)
.model pmos_model pmos (kp=5e-05 lambd=0.1 level=54 vto=-0.22)

