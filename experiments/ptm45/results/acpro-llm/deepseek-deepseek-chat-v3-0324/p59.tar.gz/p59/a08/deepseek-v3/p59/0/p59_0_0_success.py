from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Signal and Biasing Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vbias1 for M1 (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.52@u_V)  # Vbias2 for M2 (Vth + 0.3V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # Vbias3 for M3 (Vdd - |Vth| - 0.2V)
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.68@u_V)  # Vbias4 for M4 (Vdd - |Vth| - 0.3V)
# Input Stage (M1: Common-Source NMOS)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# NMOS Cascode (M2)
circuit.MOSFET('2', 'Vout', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS Current Source Load (M3)
circuit.MOSFET('3', 'Drain3', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# PMOS Cascode (M4)
circuit.MOSFET('4', 'Vout', 'Vbias4', 'Drain3', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
