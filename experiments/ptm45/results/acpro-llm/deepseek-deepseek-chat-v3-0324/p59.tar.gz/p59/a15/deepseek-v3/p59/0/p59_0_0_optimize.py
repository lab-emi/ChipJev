from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Parameterized bias voltage
    # Transistors - only width is parameterized (length fixed at 45nm)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width: 1-500×L (45nm to 22.5μm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width: 1-500×L (45nm to 22.5μm)
    # Bias voltage (conservative range around original value, staying within Vth constraints)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), not exceeding Vdd-Vth
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # Original NMOS width (5μm)
    'w_m2': 10e-6,   # Original PMOS width (10μm)
    'v_bias': 0.78,  # Original bias voltage (0.78V)
}
# Parameter descriptions for reference:
# - w_m1: NMOS transistor width (affects gain and bandwidth)
# - w_m2: PMOS transistor width (active load, affects output impedance)
# - v_bias: PMOS gate bias voltage (sets operating point)
