from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier (Parameterized)')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Biasing (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.4@u_V)  # Fixed input bias (M1)
    # Parameterized bias voltages
    circuit.V('cas', 'Vcas', circuit.gnd, params['v_cas']@u_V)  # M3 cascode bias
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)  # M2 PMOS bias
    # Transistors (all with parameterized widths)
    # M1: Common-source NMOS (input stage)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    # M3: Cascode NMOS (common-gate)
    circuit.MOSFET('3', 'Vout', 'Vcas', 'Drain1', circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    # M2: PMOS current source load
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length constraint)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× 45nm (input NMOS)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× 45nm (cascode NMOS)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× 45nm (PMOS load)
    # Bias voltages (constrained to 0.8-1.2× original, ≤1.2V)
    'v_cas': {'min': 0.56, 'max': 0.84},  # Original 0.7V ±20% (must keep M3 in saturation)
    'v_bias': {'min': 0.4, 'max': 0.6},   # Original 0.5V ±20% (must keep PMOS in saturation)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,     # Original M1 width
    'w_M3': 10e-6,     # Original M3 width
    'w_M2': 20e-6,     # Original M2 PMOS width
    'v_cas': 0.7,      # Original cascode bias voltage (V)
    'v_bias': 0.5,     # Original PMOS bias voltage (V)
}
"""
Parameter Descriptions:
- w_M1: Width of input NMOS transistor (M1) - affects transconductance and current
- w_M3: Width of cascode NMOS transistor (M3) - affects output impedance and gain
- w_M2: Width of PMOS load transistor (M2) - affects bias current and gain
- v_cas: Cascode bias voltage - determines cascode transistor operating point
- v_bias: PMOS bias voltage - sets the current through the output branch
Constraints maintained:
1. All widths are constrained to 1-500× the 45nm length (0.045µm)
2. Bias voltages constrained to ±20% of original values while ensuring:
   - v_cas maintains M3 in saturation (Vcas > Vth + Vdsat)
   - v_bias keeps PMOS in saturation (Vbias < Vdd - |Vth|)
3. No voltage exceeds the 1.2V supply limit
4. Input voltages (Vin) remain fixed for DC analysis
"""
