from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias
    # Parameterized Bias Voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    # Common-Source Stage with Active Load
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed 45nm length
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths - range 1-500× length (45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (5µm original)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (10µm original)
    # Bias voltage - constrained to maintain proper operation
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), staying within Vdd
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width (5µm)
    'w_M2': 10e-6,    # Original PMOS width (10µm)
    'vbias': 0.78,    # Original bias voltage (Vdd - |Vth| - 0.2V)
}
"""
Parameter Descriptions:
1. w_M1: Width of NMOS transistor M1. Impacts transconductance and current capability.
         Original: 5µm, Range: 45nm (1×L) to 22.5µm (500×L)
2. w_M2: Width of PMOS transistor M2. Impacts load impedance and current mirror matching.
         Original: 10µm, Range: 45nm (1×L) to 22.5µm (500×L)
3. vbias: Bias voltage for PMOS load. Must maintain saturation (Vdd - |Vth| - overdrive).
          Original: 0.78V, Range: 0.624V to 0.936V (0.8-1.2× original)
          Constrained to never exceed Vdd (1.2V) and keep sufficient overdrive.
"""
