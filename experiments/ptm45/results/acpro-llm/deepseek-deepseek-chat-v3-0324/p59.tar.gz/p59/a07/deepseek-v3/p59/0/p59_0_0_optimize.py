from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models (fixed parameters from external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supplies and input voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias
    # Parameterized components
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # PMOS bias voltage
    # Main Amplifier Stage - parameterized transistor widths (length fixed at 45nm)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'], 
                   l=0.045e-6)  # NMOS transistor
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m2'], 
                   l=0.045e-6)  # PMOS active load
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping L fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (5µm original)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (10µm original)
    # Bias voltage (0.8-1.2× original value, but must stay above Vdd - |Vth|)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original NMOS width (5µm)
    'w_m2': 10e-6,    # Original PMOS width (10µm)
    'v_bias': 0.78,   # Original bias voltage (0.78V)
}
# Parameter descriptions for documentation:
"""
Parameter Descriptions:
- w_m1: Width of NMOS input transistor (M1) - affects transconductance and gain
- w_m2: Width of PMOS active load (M2) - affects output impedance and gain
- v_bias: Bias voltage for PMOS active load - sets operating point and affects output swing
Design Constraints:
- All transistor widths constrained to 1-500× the minimum length (45nm)
- Bias voltage constrained to remain in saturation region (0.624V to 0.936V)
- Input voltages fixed to maintain known operating conditions
"""
