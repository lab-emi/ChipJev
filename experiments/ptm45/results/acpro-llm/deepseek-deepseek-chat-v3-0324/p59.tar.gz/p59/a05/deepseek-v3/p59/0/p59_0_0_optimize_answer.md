Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42) # Input bias (fixed)
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    
    # Transistors (only widths parameterized, lengths fixed)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range: 1-500×45nm
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range: 1-500×45nm
    
    # Bias voltage (constrained to maintain proper operation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), but capped at Vdd
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # Original NMOS width
    'w_m2': 10e-6,   # Original PMOS width
    'v_bias': 0.78,  # Original bias voltage
}
```

### Parameter Descriptions:

1. **Transistor Widths**:
   - `w_m1`: Width of NMOS transistor M1 (original: 5µm)
   - `w_m2`: Width of PMOS transistor M2 (original: 10µm)
   - Range: 45nm (minimum feature size) to 22.5µm (500× length)
   - Log-scale recommended for optimal exploration

2. **Bias Voltage**:
   - `v_bias`: Gate bias voltage for PMOS active load (original: 0.78V)
   - Range: 0.624V to 0.936V (0.8-1.2× original)
   - Constrained to stay within reasonable operating range (Vdd - |Vth| - margin)
   - Never exceeds Vdd (1.2V)

### Key Implementation Notes:

1. The input voltage (Vin) and supply voltage (Vdd) remain fixed as requested
2. Transistor lengths are fixed at 45nm (technology minimum)
3. Bias voltage range is carefully constrained to:
   - Minimum: 0.8× original (0.624V) - ensures sufficient overdrive
   - Maximum: 1.2× original (0.936V) - keeps PMOS in saturation
   - Never exceeds Vdd (1.2V)
4. Width ranges allow exploration from minimum feature size up to 500× length
5. Initial parameters exactly match original circuit values
6. No load capacitors were present in original circuit, so none were parameterized

This implementation maintains all the original circuit functionality while allowing automated optimization of the key parameters that affect performance. The ranges are carefully chosen to maintain reasonable operating conditions while allowing sufficient exploration space for optimization.