from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42) # Input bias (fixed)
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Transistors (only widths parameterized, lengths fixed)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range: 1-500×45nm
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range: 1-500×45nm
    # Bias voltage (constrained to maintain proper operation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), but capped at Vdd
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # Original NMOS width
    'w_m2': 10e-6,   # Original PMOS width
    'v_bias': 0.78,  # Original bias voltage
}
