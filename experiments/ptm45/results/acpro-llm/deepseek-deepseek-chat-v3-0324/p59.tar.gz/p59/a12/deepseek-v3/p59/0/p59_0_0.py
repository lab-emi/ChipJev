from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier (Folded Cascode)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.6@u_V)  # Cascode bias (mid-supply)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # Tail current bias (Vth + 0.2V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)          # Input bias (Vth + 0.2V)
# Transistors
# Input Stage: M1 (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Cascode Load: M2 (PMOS)
circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Drain1', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source: M3 (NMOS)
circuit.MOSFET('3', 'Source1', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
