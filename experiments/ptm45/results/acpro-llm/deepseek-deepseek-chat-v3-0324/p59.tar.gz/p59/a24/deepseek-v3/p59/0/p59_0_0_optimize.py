from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier (GBW/Power Optimized)')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Input Voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Bias for M1 (Vth + 0.2V)
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    # Transistors
    # M1: NMOS input transistor (width parameterized, length fixed)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)
    # M2: PMOS active load (width parameterized, length fixed)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (W ranges 1-500× L, log scale recommended)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5µm (111× L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10µm (222× L)
    # Bias voltage (constrained to keep transistors in saturation)
    'vbias': {'min': 0.72, 'max': 0.9},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width
    'w_M2': 10e-6,    # Original PMOS width
    'vbias': 0.78,    # Original bias voltage
}
