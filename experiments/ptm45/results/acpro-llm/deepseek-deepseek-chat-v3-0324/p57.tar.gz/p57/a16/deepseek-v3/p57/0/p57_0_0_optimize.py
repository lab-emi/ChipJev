from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    # Parameterized bias voltages (constrained to safe ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3'])
    # First Stage: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Second Stage: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Third Stage: Common-Source with Active Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5μm), log scale for wide range
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS first stage
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS first stage
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS second stage
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS second stage
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS third stage
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS third stage
    # Bias voltages (0.8-1.2× original values, constrained below Vdd=1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V, range: 0.624-0.936V
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V, range: 0.624-0.936V
    'vbias3': {'min': 0.624, 'max': 0.936},  # Original: 0.78V, range: 0.624-0.936V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Original NMOS first stage
    'w_M2': 10e-6,   # Original PMOS first stage
    'w_M3': 10e-6,   # Original NMOS second stage
    'w_M4': 20e-6,   # Original PMOS second stage
    'w_M5': 20e-6,   # Original NMOS third stage
    'w_M6': 40e-6,   # Original PMOS third stage
    # Bias voltages
    'vbias1': 0.78,  # Original bias voltage 1
    'vbias2': 0.78,  # Original bias voltage 2
    'vbias3': 0.78,  # Original bias voltage 3
}
# Parameter descriptions
param_descriptions = {
    'w_M1': 'Width of NMOS transistor in first stage (affects gain and bandwidth)',
    'w_M2': 'Width of PMOS transistor in first stage (affects gain and current mirror matching)',
    'w_M3': 'Width of NMOS transistor in second stage (affects gain and slew rate)',
    'w_M4': 'Width of PMOS transistor in second stage (affects gain and current mirror matching)',
    'w_M5': 'Width of NMOS transistor in third stage (affects output drive capability)',
    'w_M6': 'Width of PMOS transistor in third stage (affects output drive capability)',
    'vbias1': 'Bias voltage for first PMOS current mirror (affects operating point)',
    'vbias2': 'Bias voltage for second PMOS current mirror (affects operating point)',
    'vbias3': 'Bias voltage for third PMOS current mirror (affects operating point)',
}
