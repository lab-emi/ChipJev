Here's the parameterized version of your three-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with High GBW')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    
    # First Stage: Common-Source with PMOS Current-Source Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    
    # Second Stage: Common-Source with NMOS Current-Source Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m3'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m4'], 
                  l=0.045e-6)
    
    # Third Stage: Common-Source with Resistor Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'], 
                  l=0.045e-6)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - ranging from 1-500× the length (45nm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (original 5µm)
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (original 10µm)
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (original 10µm)
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (original 10µm)
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (original 20µm)
    
    # Bias voltages (0.8-1.2× original, not exceeding 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original 0.78V (Vth + 0.56V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (Vth + 0.56V)
    
    # Load resistor (0.5-2× original value)
    'r_load': {'min': 5, 'max': 20, 'log': True},  # Original 10kΩ
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,
    'w_m2': 10e-6,
    'w_m3': 10e-6,
    'w_m4': 10e-6,
    'w_m5': 20e-6,
    
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    
    # Load resistor
    'r_load': 10,
}
```

**Parameter Descriptions:**
1. **Transistor Widths (w_m1-w_m5):** Controls current drive capability and transconductance of each transistor stage, affecting gain, bandwidth, and power consumption.
2. **Bias Voltages (vbias1, vbias2):** Sets the operating points for the current sources, affecting the bias current and output swing of each stage.
3. **Load Resistor (r_load):** Determines the output impedance and voltage gain of the final stage.

**Key Features:**
- All original values are preserved exactly in `initial_params`
- Transistor widths can vary between 1-500× the minimum length (45nm)
- Bias voltages can vary ±20% around their original values but stay within safe operating range (0.8-1.2× original)
- Load resistor can vary between 5kΩ and 20kΩ (0.5-2× original 10kΩ)
- All voltage parameters are constrained to never exceed the 1.2V supply
- Input voltages remain fixed as required
- MOSFET lengths are fixed at 45nm as specified

The parameter ranges are chosen to maintain reasonable operating conditions while allowing sufficient exploration for optimization. The logarithmic scaling for transistor widths and resistors helps explore orders of magnitude efficiently.