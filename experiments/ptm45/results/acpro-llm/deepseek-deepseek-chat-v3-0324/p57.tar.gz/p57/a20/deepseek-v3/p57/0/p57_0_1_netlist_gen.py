from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Three-Stage Amplifier with High GBW (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V = 0.42V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Bias for M2 (PMOS)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Bias for M4 (PMOS)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # Bias for M3B (PMOS)
# First Stage: Common-Source with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Second Stage: Common-Source with Active Load (to increase Vout1)
circuit.MOSFET('3', 'Vout1', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)  # Larger W for higher gain
circuit.MOSFET('3B', 'Vout1', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # Active load replaces R1
# Third Stage: Source Follower (Corrected Biasing)
circuit.MOSFET('4', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)  # Current source
circuit.MOSFET('5', 'Vdd', 'Vout1', 'Vout', 'Vout', model='nmos_model', w=20e-6, l=0.045e-6)  # Larger W to ensure V_GS > V_TH
circuit.R('2', 'Vout', circuit.gnd, 5@u_kΩ)  # Biasing resistor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
