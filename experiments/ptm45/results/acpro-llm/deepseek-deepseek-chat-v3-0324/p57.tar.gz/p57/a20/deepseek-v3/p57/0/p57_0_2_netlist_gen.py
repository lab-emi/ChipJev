from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
# MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)
# First Stage: Common-Source with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Second Stage: Common-Source with Active Load
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Level Shifting Stage
circuit.MOSFET('5', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.R('1', 'Drain3', 'Vdd', 5@u_kΩ)
# Output Stage: Properly Biased Source Follower
circuit.MOSFET('6', 'Vdd', 'Drain3', 'Vout', 'Vout',
               model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias3', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
