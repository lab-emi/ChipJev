from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with GBW Optimization')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (fixed supplies and inputs)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['vbias_p']@u_V)  # PMOS bias voltage
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2)
    # Stage 1: Common-Source with PMOS Active Load
    circuit.MOSFET('1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Node1', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.C('c1', 'Node1', 'Vout', params['c1']@u_pF)  # Miller compensation capacitor
    # Stage 2: Common-Source with PMOS Active Load
    circuit.MOSFET('3', 'Node2', 'Node1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Node2', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.C('c2', 'Node2', 'Vout', params['c2']@u_pF)  # Miller compensation capacitor
    # Stage 3: Common-Source with PMOS Active Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Node2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5µm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS input stage width
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load width (Stage 1)
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS gain stage width
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load width (Stage 2)
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS output stage width
    'w_m6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS output stage width
    # Bias voltage (Vth = 0.22V, keeping within reasonable headroom)
    'vbias_p': {'min': 0.62, 'max': 0.94},  # Original: 0.78V (0.8-1.2× with 1.2V ceiling)
    # Compensation capacitors (0.5-5× original value)
    'c1': {'min': 0.5, 'max': 5, 'log': True},  # Stage 1 compensation cap (original: 1pF)
    'c2': {'min': 0.5, 'max': 5, 'log': True},  # Stage 2 compensation cap (original: 1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,    # Original M1 width (5µm)
    'w_m2': 10e-6,   # Original M2 width (10µm)
    'w_m3': 10e-6,   # Original M3 width (10µm)
    'w_m4': 20e-6,   # Original M4 width (20µm)
    'w_m5': 20e-6,   # Original M5 width (20µm)
    'w_m6': 40e-6,   # Original M6 width (40µm)
    # Bias voltage
    'vbias_p': 0.78,  # Original PMOS bias voltage (0.78V)
    # Compensation capacitors
    'c1': 1.0,       # Original C1 value (1pF)
    'c2': 1.0,       # Original C2 value (1pF)
}
# Physical meaning of each parameter:
# - w_m1-m6: Widths of MOSFETs (affects transconductance and current)
# - vbias_p: PMOS bias voltage (sets operating point for active loads)
# - c1, c2: Miller compensation capacitors (affects frequency response and stability)
