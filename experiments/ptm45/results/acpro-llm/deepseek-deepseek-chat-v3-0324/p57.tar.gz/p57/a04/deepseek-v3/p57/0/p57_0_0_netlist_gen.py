from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with GBW Optimization')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS bias voltage (Vdd - Vth - 0.2)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2)
# Stage 1: Common-Source with PMOS Active Load
circuit.MOSFET('1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Node1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.C('c1', 'Node1', 'Vout', 1@u_pF)  # Miller compensation capacitor
# Stage 2: Common-Source with PMOS Active Load
circuit.MOSFET('3', 'Node2', 'Node1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Node2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.C('c2', 'Node2', 'Vout', 1@u_pF)  # Miller compensation capacitor
# Stage 3: Common-Source with PMOS Active Load (Output Stage)
circuit.MOSFET('5', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
