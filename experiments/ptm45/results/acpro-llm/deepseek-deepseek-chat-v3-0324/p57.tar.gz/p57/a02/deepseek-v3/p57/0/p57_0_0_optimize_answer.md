Here's your parameterized circuit implementation following all the specified requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.6) # Input voltage (fixed)
    
    # Parameterized Bias Voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']) # Tail current bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']) # PMOS bias
    
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', 'Source1', 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6) # Length fixed at 45nm
    circuit.MOSFET('3', 'Drain2', 'Vcm', 'Source1', 'Source1', 
                  model='nmos_model', 
                  w=params['w_m3'], 
                  l=0.045e-6)
    circuit.MOSFET('7', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m7'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m4'], 
                  l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'], 
                  l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m6'], 
                  l=0.045e-6)
    
    # Miller Compensation (fixed capacitor value - not parameterized)
    circuit.C('1', 'Drain2', 'Vout', 1@u_pF)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (constrained to be within 0.8-1.2× original but never > 1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2), 'log': False},  # Tail current bias
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2), 'log': False},  # PMOS bias
    
    # NMOS Transistor Widths (range 1-500× length = 45nm-22.5µm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input pair transistor 1
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input pair transistor 2
    'w_m7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current source
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # CS stage NMOS
    
    # PMOS Transistor Widths (range 1-500× length = 45nm-22.5µm)
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Current mirror load 1
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Current mirror load 2
    'w_m6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # CS stage active load
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    
    # NMOS Widths
    'w_m1': 10e-6,
    'w_m3': 10e-6,
    'w_m7': 20e-6,
    'w_m5': 20e-6,
    
    # PMOS Widths
    'w_m2': 20e-6,
    'w_m4': 20e-6,
    'w_m6': 20e-6,
}
```

### Parameter Descriptions:
1. **Bias Voltages**:
   - `vbias1`: Controls the tail current in the differential pair (original: 0.42V)
   - `vbias2`: Sets the operating point for the PMOS active load (original: 0.78V)

2. **NMOS Widths**:
   - `w_m1`, `w_m3`: Input pair transistor widths (affects gm, noise, matching)
   - `w_m7`: Tail current source width (sets bias current)
   - `w_m5`: Common-source stage driver width (affects gain-bandwidth)

3. **PMOS Widths**:
   - `w_m2`, `w_m4`: Current mirror load widths (affects gain and matching)
   - `w_m6`: Active load for common-source stage (affects output impedance)

Key Features:
- Maintains all original values in `initial_params` exactly as specified
- All voltage sources are properly constrained (0.8-1.2× original, ≤1.2V)
- Transistor widths can vary from 45nm (1×L) to 22.5µm (500×L)
- Fixed capacitors are not parameterized as requested
- Input voltages (Vin, Vcm) remain fixed for DC analysis
- Power supply (Vdd) remains fixed at 1.2V