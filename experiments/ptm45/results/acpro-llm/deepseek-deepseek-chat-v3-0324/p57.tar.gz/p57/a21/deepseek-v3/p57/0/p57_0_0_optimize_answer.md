Here's the parameterized version of your three-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier')
    
    # Define the MOSFET models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Fixed power supplies and input voltages (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias voltage (fixed)
    
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    
    # First Stage: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    
    # Second Stage: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    
    # Third Stage: Common-Source with Resistor Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")
    
    # Miller Compensation Capacitor (parameterized)
    circuit.C('c', 'Drain1', 'Vout', f"{params['c_comp']}p")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - keep L=45nm fixed
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500×L)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500×L)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500×L)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500×L)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500×L)
    
    # Bias voltages (constrained to 0.8-1.2× original, ≤1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original 0.78V (0.8-1.2× range)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (0.8-1.2× range)
    
    # Passive components
    'r_load': {'min': 5, 'max': 20, 'log': True},  # Load resistor: 0.5-2× original (10kΩ)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Compensation cap: 0.5-5× original (1pF)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,
    'w_m2': 10e-6,
    'w_m3': 10e-6,
    'w_m4': 20e-6,
    'w_m5': 20e-6,
    
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    
    # Passive components
    'r_load': 10,     # Original 10kΩ
    'c_comp': 1,      # Original 1pF
}
```

### Parameter Descriptions:
1. **Transistor Widths (w_m1 to w_m5):** Channel widths for each MOSFET in the circuit. Range is set to 1-500× the minimum length (45nm) to ensure proper device operation.
2. **Bias Voltages (vbias1, vbias2):** Gate bias voltages for the PMOS active loads. Ranges are constrained to ±20% of original values (0.78V) to maintain proper biasing while allowing optimization.
3. **Load Resistor (r_load):** Output stage load resistor (originally 10kΩ), allowed to vary between 5-20kΩ (0.5-2× original).
4. **Compensation Capacitor (c_comp):** Miller compensation capacitor (originally 1pF), allowed to vary between 0.5-5pF.

Key features:
- All initial values exactly match your original circuit
- All parameter ranges are properly constrained as per your requirements
- Voltage ranges are conservative to maintain proper biasing
- Transistor widths have logarithmic ranges for optimal search
- Fixed parameters (Vdd, Vin) remain unchanged
- Unit conversions are handled properly for Spice compatibility