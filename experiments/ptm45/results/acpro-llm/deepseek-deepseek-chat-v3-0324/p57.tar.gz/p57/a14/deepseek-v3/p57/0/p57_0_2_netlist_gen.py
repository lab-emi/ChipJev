from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage Amplifier (High GBW)')
# =============================================
# MOSFET MODEL DEFINITIONS (FIXED SYNTAX)
# =============================================
# Define NMOS and PMOS models (45nm technology)
# NOTE: Removed 'lambda' parameter since it's a Python keyword
# Added typical 45nm parameters (VTO, KP, etc.)
circuit.model('nmos_model', 'nmos', 
    VTO=0.22, KP=100e-6, CGSO=1e-12, CGDO=1e-12)  # Basic 45nm NMOS
circuit.model('pmos_model', 'pmos', 
    VTO=-0.22, KP=50e-6, CGSO=1e-12, CGDO=1e-12)  # Basic 45nm PMOS
# =============================================
# POWER SUPPLY AND BIAS VOLTAGES
# =============================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Vth + 0.2V for M5 (SF)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # DC bias for operating point
# =============================================
# STAGE 1: COMMON-SOURCE WITH ACTIVE LOAD
# =============================================
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
              model='pmos_model', w=10e-6, l=0.045e-6)
# =============================================
# STAGE 2: COMMON-SOURCE WITH ACTIVE LOAD
# =============================================
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
# =============================================
# STAGE 3: SOURCE FOLLOWER (OUTPUT BUFFER)
# =============================================
# Key fix: Bulk must be grounded for NMOS (source ≠ bulk here)
circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd, 
              model='nmos_model', w=20e-6, l=0.045e-6)
# =============================================
# COMPENSATION CAPACITOR (POLE SPLITTING)
# =============================================
circuit.C('c', 'Drain1', 'Drain2', 1@u_pF)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
