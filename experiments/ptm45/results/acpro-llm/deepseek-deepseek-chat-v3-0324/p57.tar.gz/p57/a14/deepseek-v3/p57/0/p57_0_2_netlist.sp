Vdd Vdd 0 1.2V
Vbias1 Vbias1 0 0.78V
Vbias2 Vbias2 0 0.78V
Vbias3 Vbias3 0 0.42V
Vin Vin 0 0.42V
M1 Drain1 Vin 0 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain1 Vbias1 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M3 Drain2 Drain1 0 0 nmos_model l=4.5e-08 w=1e-05
M4 Drain2 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M5 Vdd Drain2 Vout 0 nmos_model l=4.5e-08 w=2e-05
Cc Drain1 Drain2 1pF
.model nmos_model nmos (CGDO=1e-12 CGSO=1e-12 KP=0.0001 VTO=0.22)
.model pmos_model pmos (CGDO=1e-12 CGSO=1e-12 KP=5e-05 VTO=-0.22)

