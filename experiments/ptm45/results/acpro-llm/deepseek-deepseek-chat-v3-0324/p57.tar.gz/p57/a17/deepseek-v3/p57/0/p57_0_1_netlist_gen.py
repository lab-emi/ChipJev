from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V) # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V) # Bias for PMOS current sources
circuit.V('tail', 'Vtail', circuit.gnd, 0.5@u_V) # Increased tail bias to ensure Vgs > Vth
circuit.V('in', 'Vin', circuit.gnd, 0.5@u_V) # Input bias set to match tail bias
# First Stage: Differential Pair with Active Load
# M1: Input transistor with Vin = 0.5V (Vgs = 0.5V - Vs)
circuit.MOSFET('1', 'Drain1', 'Vin', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M2: Grounded gate transistor now properly biased through higher tail current
circuit.MOSFET('2', 'Drain2', 'Vbias2', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.5@u_V) # Added bias for M2 gate
# Active load PMOS transistors
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current source with increased bias
circuit.MOSFET('5', 'SourcePair', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier
circuit.MOSFET('6', 'Drain5', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain5', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Third Stage: Source Follower
circuit.MOSFET('8', 'Vdd', 'Drain5', 'Vout', circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.R('1', 'Vout', circuit.gnd, 1@u_kΩ)
# Miller Compensation
circuit.C('c', 'Drain1', 'Drain5', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
