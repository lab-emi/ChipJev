from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V) # 1.2V power supply
circuit.V('bias_pmos', 'Vbias_pmos', circuit.gnd, 0.7@u_V) # Bias for PMOS current sources
circuit.V('tail', 'Vtail', circuit.gnd, 0.5@u_V) # Tail current bias
circuit.V('in', 'Vin', circuit.gnd, 0.5@u_V) # Input bias (DC operating point)
# First Stage: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.V('cm', 'Vcm', circuit.gnd, 0.5@u_V) # Common-mode voltage for M2
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier with proper biasing
circuit.MOSFET('6', 'Drain5', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain5', 'Vbias_pmos', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
# Third Stage: Properly biased Source Follower
circuit.MOSFET('8', 'Vdd', 'Drain5', 'Vout', circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
# Increased resistor to set proper output DC level
circuit.R('1', 'Vout', circuit.gnd, 10@u_kΩ) 
# Miller Compensation
circuit.C('c', 'Drain1', 'Drain5', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
