from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with GBW Maximization')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # PMOS bias voltage (parameterized)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS bias voltage (parameterized)
    # Stage 1: Common-Source with Current Source Load (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w1'], 
                  l=0.045e-6)  # Fixed length for 45nm technology
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w2'], 
                  l=0.045e-6)
    # Stage 2: Common-Source with Current Source Load (M3, M4)
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w3'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w4'], 
                  l=0.045e-6)
    # Stage 3: Common-Source with Current Source Load (M5, M6)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w5'], 
                  l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w6'], 
                  l=0.045e-6)
    # Compensation Capacitor (Cc) - parameterized
    circuit.C('c', 'Drain2', 'Vout', f"{params['cc']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original but max 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original 0.78V (PMOS bias)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (PMOS bias)
    # NMOS transistor widths (1-500× length = 45nm to 22.5μm)
    'w1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5μm
    'w3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5μm
    'w5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 5μm
    # PMOS transistor widths (1-500× length = 45nm to 22.5μm)
    'w2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 10μm
    'w4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 10μm
    'w6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original 10μm
    # Compensation capacitor (0.5-5× original)
    'cc': {'min': 0.5, 'max': 5, 'log': True},  # Original 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.78,       # Original Vbias1 value (V)
    'vbias2': 0.78,       # Original Vbias2 value (V)
    'w1': 5e-6,           # Original M1 width (m)
    'w2': 10e-6,          # Original M2 width (m)
    'w3': 5e-6,           # Original M3 width (m)
    'w4': 10e-6,          # Original M4 width (m)
    'w5': 5e-6,           # Original M5 width (m)
    'w6': 10e-6,          # Original M6 width (m)
    'cc': 1.0,            # Original compensation capacitance (pF)
}
