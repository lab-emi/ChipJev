from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Signal (DC bias only)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Mid-rail bias
# Corrected Biasing Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # PMOS: Vdd - |Vth| - 0.2
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # NMOS: Vth + 0.2
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.3@u_V)   # PMOS cascode: Lower than Drain1 (~0.5V)
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.42@u_V)  # NMOS current source
circuit.V('bias5', 'Vbias5', circuit.gnd, 0.78@u_V)  # PMOS current source
circuit.V('bias6', 'Vbias6', circuit.gnd, 0.42@u_V)  # NMOS current source
# Stage 1: Folded-Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Stage1_Out', 'Vbias2', 'Drain1', 'Drain1', model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Stage1_Out', 'Vbias3', 'Drain1', 'Drain1', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('8', 'Stage1_Out', 'Vbias4', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Stage2_Out', 'Stage1_Out', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('9', 'Stage2_Out', 'Vbias5', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Source Follower (Corrected)
circuit.MOSFET('6', 'Vdd', 'Stage2_Out', 'Vout', 'Vout', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias6', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Stage1_Out', 'Stage2_Out', 1@u_pF)
circuit.R('1', 'Stage1_Out', 'Stage2_Out', 1@u_kΩ)  # Zero cancellation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
