from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input DC bias (fixed)
    # Bias voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    # Stage 1: Common-Source with Current Source Load
    circuit.MOSFET('1', 'V1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'V1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with Current Source Load
    circuit.MOSFET('3', 'V2', 'V1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'V2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Common-Drain (Source Follower)
    circuit.MOSFET('5', 'Vdd', 'V2', 'Vout', 'Vout', 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Load resistor (parameterized)
    circuit.R('1', 'Vout', circuit.gnd, f"{params['r_load']}k")
    # Compensation Network (parameterized)
    circuit.C('c', 'Vcomp', 'V1', f"{params['c_comp']}p")
    circuit.R('c', 'V2', 'Vcomp', f"{params['r_comp']}k")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width: 1-500× L (45nm)
    'w_M2': {'min': 0.09e-6, 'max': 45e-6, 'log': True},     # M2 width: 1-500× L (45nm)
    'w_M3': {'min': 0.09e-6, 'max': 45e-6, 'log': True},     # M3 width: 1-500× L (45nm)
    'w_M4': {'min': 0.18e-6, 'max': 90e-6, 'log': True},     # M4 width: 1-500× L (45nm)
    'w_M5': {'min': 0.18e-6, 'max': 90e-6, 'log': True},     # M5 width: 1-500× L (45nm)
    # Bias voltages (constrained to stay near original operating points)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original 0.78V (0.8-1.2× range)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (0.8-1.2× range)
    # Passive components
    'r_load': {'min': 0.5, 'max': 2, 'log': True},     # Load resistor: 0.5-2× original (1kΩ)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},     # Miller cap: 0.5-5× original (1pF)
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},     # Nulling resistor: 0.5-2× original (1kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    # Passive components
    'r_load': 1.0,       # Original: 1 kΩ
    'c_comp': 1.0,       # Original: 1 pF
    'r_comp': 1.0,       # Original: 1 kΩ
}
