from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input DC bias (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78)  # Bias for PMOS current sources (Vdd - |Vth| - 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # Identical to Vbias1 for simplicity
# Stage 1: Common-Source with Current Source Load
circuit.MOSFET('1', 'V1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'V1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with Current Source Load
circuit.MOSFET('3', 'V2', 'V1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'V2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Common-Drain (Source Follower)
circuit.MOSFET('5', 'Vdd', 'V2', 'Vout', 'Vout', model='nmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', circuit.gnd, 1@u_kΩ)  # Load resistor
# Compensation Network
circuit.C('c', 'V2', 'V1', 1@u_pF)  # Miller capacitor
circuit.R('c', 'V2', 'Vcomp', 1@u_kΩ)  # Nulling resistor
circuit.C('c_extra', 'Vcomp', 'V1', 1@u_fF)  # Small parasitic cap (optional)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
