from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('ss', 'Vss', circuit.gnd, 0)    # Ground
circuit.V('bias', 'Vbias', circuit.gnd, 0.5)  # Tail current bias (adjusted for V_GS > V_TH)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.5)  # M2 gate bias (ensure V_GS > V_TH)
# First Stage: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vx', 'Vbias2', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias', 'Vss', 'Vss', model='nmos_model', w=20e-6, l=0.045e-6)  # Tail current
# Active Load (PMOS current mirror)
circuit.MOSFET('4', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vx', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier
circuit.MOSFET('3', 'Vy', 'Vx', 'Vss', 'Vss', model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vy', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)  # Current source load
# Third Stage: Source Follower (Output Buffer)
circuit.MOSFET('8', 'Vout', 'Vy', 'Vss', 'Vss', model='nmos_model', w=40e-6, l=0.045e-6)
# Miller Compensation Capacitor
circuit.C('c', 'Vx', 'Vy', 1@u_pF)  # Compensation capacitor
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
