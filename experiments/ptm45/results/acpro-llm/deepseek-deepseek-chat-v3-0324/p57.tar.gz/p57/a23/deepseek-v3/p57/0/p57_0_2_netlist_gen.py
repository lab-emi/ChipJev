from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Adjusted for proper saturation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5@u_V)  # Tail current bias (M3)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7@u_V)  # PMOS load bias (M4a, M4b, M6)
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)        # Common-mode input
# Input Signal (DC bias at mid-supply)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)        # Input signal (to M1)
# First Stage: Differential Pair with PMOS Loads
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # Tail current
# PMOS Loads for the First Stage (M4a, M4b)
circuit.MOSFET('4a', 'Drain1', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4b', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Second Stage: Common-Source with Miller Compensation
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # PMOS Load
circuit.C('c', 'Drain5', 'Drain2', 1@u_pF)  # Miller cap
# Third Stage: Source Follower (M7: Increased Width for Proper Biasing)
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
# Run Simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
