Here's the parameterized version of your high-GBW three-stage amplifier circuit according to your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('High-GBW Three-Stage Amplifier (Parameterized)')
    
    # MOSFET Models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 200mV)
    
    # Parameterized Bias Voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['v_bias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['v_bias2']}V")
    
    # Stage 1: CS with Active Load (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Stage 2: CS with Active Load (parameterized widths)
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Stage 3: Source Follower (parameterized widths and resistors)
    circuit.R('1', 'Drain2', 'Gate5', f"{params['r1']}k")
    circuit.MOSFET('5', 'Vdd', 'Gate5', 'Vout', circuit.gnd,
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.R('2', 'Vout', circuit.gnd, f"{params['r2']}k")
    
    # Compensation (parameterized capacitors)
    circuit.C('c1', 'Drain1', 'Vout', f"{params['c1']}p")
    circuit.C('c2', 'Drain2', 'Vout', f"{params['c2']}p")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (0.8-1.2× original but never exceeding Vdd, conservative for proper operation)
    'v_bias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth| - 200mV)
    'v_bias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V
    
    # Transistor widths (1-500× length of 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5µm
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10µm
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10µm
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20µm 
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 50µm
    
    # Resistors (0.5-2× original values)
    'r1': {'min': 0.5, 'max': 2, 'log': True},  # Original: 1kΩ
    'r2': {'min': 2.5, 'max': 10, 'log': True},  # Original: 5kΩ
    
    # Compensation capacitors (0.5-5× original values)
    'c1': {'min': 0.5, 'max': 5, 'log': True},  # Original: 1pF
    'c2': {'min': 0.25, 'max': 2.5, 'log': True},  # Original: 0.5pF
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'v_bias1': 0.78,
    'v_bias2': 0.78,
    
    # Transistor widths
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 20e-6,
    'w_M5': 50e-6,
    
    # Resistors
    'r1': 1,
    'r2': 5,
    
    # Capacitors
    'c1': 1,
    'c2': 0.5,
}
```

### Parameter Descriptions:

1. **Bias Voltages**:
   - `v_bias1`, `v_bias2`: Gate bias voltages for PMOS loads (critical for proper biasing)
   - Range is 0.8-1.2× original values (0.78V), but capped below Vdd (1.2V)

2. **Transistor Widths**:
   - `w_M1`-`w_M5`: Widths of all transistors (M1-M5)
   - Range spans 1-500× the minimum length (45nm), logarithmic scaling

3. **Resistors**:
   - `r1`: Feedback resistor in output stage (original: 1kΩ)
   - `r2`: Output load resistor (original: 5kΩ)
   - Range is 0.5-2× original values

4. **Compensation Capacitors**:
   - `c1`: Primary compensation cap (original: 1pF)
   - `c2`: Secondary compensation cap (original: 0.5pF)
   - Range is 0.5-5× original values to enable stability optimization

All initial values exactly match your original circuit, and all ranges are carefully constrained to maintain circuit functionality while allowing meaningful optimization. The ranges respect:
- Transistor width constraints (1-500× length)
- Voltage source limits (≤1.2V)
- Conservative bias point variations (±20%)
- Component value practical ranges (0.5-2× or 0.5-5× original)

The circuit keeps fixed:
- Supply voltage (1.2V)
- Input bias voltage (0.42V)
- All transistor lengths (45nm)
- MOSFET model parameters (imported from external module)