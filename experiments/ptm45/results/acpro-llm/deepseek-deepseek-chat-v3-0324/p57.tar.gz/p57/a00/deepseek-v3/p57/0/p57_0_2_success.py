from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('High-GBW Three-Stage Amplifier (Final Corrected)')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 200mV
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 200mV
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
# Stage 1: CS with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: CS with Active Load 
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Properly Biased Source Follower
circuit.R('1', 'Drain2', 'Gate5', 1@u_kΩ)  # Reduced from 10kΩ
circuit.MOSFET('5', 'Vdd', 'Gate5', 'Vout', circuit.gnd,
              model='nmos_model', w=50e-6, l=0.045e-6)  # Increased width
circuit.R('2', 'Vout', circuit.gnd, 5@u_kΩ)  # Reduced from 50kΩ
# Compensation
circuit.C('c1', 'Drain1', 'Vout', 1@u_pF)
circuit.C('c2', 'Drain2', 'Vout', 0.5@u_pF)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
