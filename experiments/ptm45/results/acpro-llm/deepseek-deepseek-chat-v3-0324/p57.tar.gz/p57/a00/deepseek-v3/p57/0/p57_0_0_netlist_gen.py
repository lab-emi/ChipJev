from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-GBW Three-Stage Amplifier')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Biasing
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # DC bias for input (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Bias for M2 (PMOS)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Bias for M4 (PMOS)
# Stage 1: Common-Source with Active Load (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with Active Load (M3, M4)
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Source Follower (M5)
circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Compensation Capacitors
circuit.C('c1', 'Drain1', 'Vout', 1@u_pF)  # Dominant pole compensation
circuit.C('c2', 'Drain2', 'Vout', 0.5@u_pF)  # Nested Miller compensation
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
