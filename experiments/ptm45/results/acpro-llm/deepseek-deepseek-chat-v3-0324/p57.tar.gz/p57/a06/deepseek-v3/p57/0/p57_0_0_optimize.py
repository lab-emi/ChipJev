from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with High GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # Parameterized
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # Parameterized
    # Stage 1: Common-Source with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Common-Source with Resistor Load (Output Buffer)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")  # Parameterized
    # Compensation Capacitor
    circuit.C('c', 'Drain1', 'Vout', f"{params['c_comp']}p")  # Parameterized
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    # Bias voltages (V in volts)
    'vbias1': {'min': 0.624, 'max': 0.936, 'log': False},  # 0.8-1.2× original (0.78V)
    'vbias2': {'min': 0.624, 'max': 0.936, 'log': False},  # 0.8-1.2× original (0.78V)
    # Passive components
    'r_load': {'min': 5, 'max': 20, 'log': True},      # Load resistor: 0.5-2× original (kΩ)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},     # Compensation cap: 0.5-5× original (pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,      # Original M1 width
    'w_M2': 10e-6,     # Original M2 width
    'w_M3': 10e-6,     # Original M3 width
    'w_M4': 20e-6,     # Original M4 width
    'w_M5': 20e-6,     # Original M5 width
    # Bias voltages
    'vbias1': 0.78,    # Original Vbias1 voltage
    'vbias2': 0.78,    # Original Vbias2 voltage
    # Passive components
    'r_load': 10,      # Original load resistance (kΩ)
    'c_comp': 1,       # Original compensation capacitance (pF)
}
