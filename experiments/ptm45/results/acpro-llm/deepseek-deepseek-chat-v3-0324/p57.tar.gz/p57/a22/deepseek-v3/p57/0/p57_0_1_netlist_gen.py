from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Corrected Multi-Stage Amplifier')
# MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V supply
circuit.V('in', 'Vin', circuit.gnd, 0.5)  # Increased input bias for better operation
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.7)  # NMOS cascode bias (Vth + 2*Vov + margin)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.65)  # PMOS current source bias (adjusted)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.45)  # PMOS cascode bias (lowered)
# Stage 1: Properly biased cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)  # M1 (wider for more current)
circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)  # M3 cascode
# Current sources with proper biasing
circuit.MOSFET('2', 'Source2', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)  # M2 (wider)
circuit.MOSFET('4', 'Drain3', 'Vbias3', 'Source2', 'Vdd',
               model='pmos_model', w=15e-6, l=0.045e-6)  # M4 cascode load
# Stage 2: Properly biased output stage
circuit.MOSFET('5', 'Vout', 'Drain3', circuit.gnd, circuit.gnd,
               model='nmos_model', w=15e-6, l=0.045e-6)  # M5 (wider)
circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=30e-6, l=0.045e-6)  # M6 (much wider for current matching)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
