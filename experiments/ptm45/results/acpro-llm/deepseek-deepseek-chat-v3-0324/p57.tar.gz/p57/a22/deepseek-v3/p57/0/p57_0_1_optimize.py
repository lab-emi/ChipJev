from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Corrected Multi-Stage Amplifier')
    # MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.5)  # Fixed input bias
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # NMOS cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS current source bias
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3'])  # PMOS cascode bias
    # Stage 1: Properly biased cascode
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)  # M1
    circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)  # M3 cascode
    # Current sources with proper biasing
    circuit.MOSFET('2', 'Source2', 'Vbias2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=0.045e-6)  # M2
    circuit.MOSFET('4', 'Drain3', 'Vbias3', 'Source2', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)  # M4 cascode load
    # Stage 2: Properly biased output stage
    circuit.MOSFET('5', 'Vout', 'Drain3', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)  # M5
    circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)  # M6
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5µm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input NMOS
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current source
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS cascode
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS cascode load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output PMOS
    # Bias voltages (constrained to 80-120% of original values, but ≤ 1.2V)
    'vbias1': {'min': 0.7*0.8, 'max': min(0.7*1.2, 1.2)},    # NMOS cascode bias
    'vbias2': {'min': 0.65*0.8, 'max': min(0.65*1.2, 1.2)},  # PMOS current source bias
    'vbias3': {'min': 0.45*0.8, 'max': min(0.45*1.2, 1.2)},  # PMOS cascode bias
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_M1': 10e-6,    # M1 (Input NMOS)
    'w_M2': 20e-6,    # M2 (PMOS current source)
    'w_M3': 10e-6,    # M3 (NMOS cascode)
    'w_M4': 15e-6,    # M4 (PMOS cascode load)
    'w_M5': 15e-6,    # M5 (Output NMOS)
    'w_M6': 30e-6,    # M6 (Output PMOS)
    # Bias voltages (original values)
    'vbias1': 0.7,    # NMOS cascode bias
    'vbias2': 0.65,   # PMOS current source bias
    'vbias3': 0.45,   # PMOS cascode bias
}
