from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with GBW Optimization')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply and Bias Voltages (fixed inputs, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed bias for M1
    # Parameterized bias voltage for PMOS loads
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    # Stage 1: Common-Source with PMOS Active Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with PMOS Active Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Common-Source with PMOS Active Load (Output Stage)
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Miller Compensation (parameterized)
    circuit.C('c', 'Drain2', 'Vout', f"{params['c_comp']}p")
    circuit.R('c', 'Drain2', 'Vout', f"{params['r_comp']}k")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (constrained to stay near original value)
    'vbias1': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original value (0.78V), but <1.2V
    # Stage 1 transistor widths (constrained to 1-500× length = 45nm-22.5μm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    # Stage 2 transistor widths
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    # Stage 3 transistor widths
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},
    # Compensation components
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # 0.5-5× original 1pF
    'r_comp': {'min': 0.5, 'max': 2, 'log': True},  # 0.5-2× original 1kΩ
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.78,
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    'w_M3': 5e-6,
    'w_M4': 10e-6,
    'w_M5': 5e-6,
    'w_M6': 10e-6,
    'c_comp': 1,
    'r_comp': 1,
}
