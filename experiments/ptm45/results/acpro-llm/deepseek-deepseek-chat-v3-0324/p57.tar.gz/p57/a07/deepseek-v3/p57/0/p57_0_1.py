from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
  # model.py (example contents)
  nmos_params = {'VTO': 0.22, 'KP': 120e-6, 'LAMBDA': 0.1}
  pmos_params = {'VTO': -0.22, 'KP': 40e-6, 'LAMBDA': 0.1}

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
