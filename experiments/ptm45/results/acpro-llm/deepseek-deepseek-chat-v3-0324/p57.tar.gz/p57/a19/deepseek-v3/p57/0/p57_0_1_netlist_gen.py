from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define NMOS and PMOS models (Level 1 SPICE)
circuit.model('nmos_model', 'nmos', 
              VTO=0.22, KP=100e-6, LAMBDA=0.1, GAMMA=0.5, PHI=0.6)  # 45nm NMOS
circuit.model('pmos_model', 'pmos', 
              VTO=-0.22, KP=50e-6, LAMBDA=0.1, GAMMA=0.5, PHI=0.6)  # 45nm PMOS
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Input DC bias
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Common-mode voltage
# Tail Current Source (I1 = 100uA)
circuit.I('1', 'Vdd', 'Tail', 100@u_uA)
# Stage 1: Differential Pair with Current Mirror Load
# NMOS transistors (M1, M2) - bulk tied to source
circuit.MOSFET('1', 'Drain1', 'Vin', 'Tail', 'Tail', model='nmos_model', 
               w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Tail', 'Tail', model='nmos_model', 
               w=10@u_um, l=0.045@u_um)
# PMOS current mirror (M3, M4) - bulk tied to Vdd
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=0.045@u_um)
# Stage 2: Common-Source Amplifier
# M5 (NMOS) - bulk tied to ground
circuit.MOSFET('5', 'Node2', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=20@u_um, l=0.045@u_um)
# M6 (PMOS current source) - bulk tied to Vdd
circuit.MOSFET('6', 'Node2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', 
               w=10@u_um, l=0.045@u_um)
# Stage 3: Output Stage (NMOS)
# M7 (NMOS) - bulk tied to ground
circuit.MOSFET('7', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=30@u_um, l=0.045@u_um)
# Compensation Network
circuit.C('c', 'Node2', 'Vout', 1@u_pF)  # Miller capacitor
circuit.R('z', 'Node2', 'Vout', 1@u_kOhm)  # Nulling resistor (simplified)
# Bias Voltage for M6 (0.78V = Vdd - |Vth| - 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
# Load Resistor (optional)
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
# Simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
