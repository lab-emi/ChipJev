from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models (Level 1 SPICE)
circuit.model('nmos_model', 'nmos', VTO=0.22, KP=100e-6, LAMBDA=0.05)  # 45nm NMOS
circuit.model('pmos_model', 'pmos', VTO=-0.22, KP=50e-6, LAMBDA=0.05)  # 45nm PMOS
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (Key Fix: Adjusted bias points)
circuit.V('in', 'Vin', circuit.gnd, 0.7@u_V)  # Increased to ensure V_GS > V_TH
circuit.V('cm', 'Vcm', circuit.gnd, 0.7@u_V)  # Matches Vin for symmetry
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.4@u_V)  # Tail current bias (~VTH + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.8@u_V)  # PMOS current source bias (Vdd - |VTH| - 0.2V)
# Stage 1: Differential Pair with Proper Biasing
# Current Mirror Load Fix: M3 diode-connected, M4 mirror
circuit.MOSFET('1', 'Drain1', 'Vin', 'Tail', circuit.gnd, model='nmos_model', 
               w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Tail', circuit.gnd, model='nmos_model', 
               w=10@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=0.045@u_um)
# Tail current source (NMOS)
circuit.MOSFET('0', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=5@u_um, l=0.045@u_um)
# Stage 2: Common-Source with Proper V_DS
circuit.MOSFET('5', 'Node2', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=20@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Node2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', 
               w=15@u_um, l=0.045@u_um)
# Stage 3: Output Stage
circuit.MOSFET('7', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=30@u_um, l=0.045@u_um)
# Compensation Network
circuit.C('c', 'Node2', 'Vout', 1@u_pF)
circuit.R('z', 'Node2', 'Vout', 1@u_kOhm)
# Load Resistor
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
