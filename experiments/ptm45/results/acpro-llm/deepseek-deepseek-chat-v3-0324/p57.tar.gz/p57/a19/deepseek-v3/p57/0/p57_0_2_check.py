from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models (Level 1 SPICE)
circuit.model('nmos_model', 'nmos', VTO=0.22, KP=100e-6, LAMBDA=0.05)  # 45nm NMOS
circuit.model('pmos_model', 'pmos', VTO=-0.22, KP=50e-6, LAMBDA=0.05)  # 45nm PMOS
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (Key Fix: Adjusted bias points)
circuit.V('in', 'Vin', circuit.gnd, "dc 0.7@u_V ac 1n")
circuit.V('cm', 'Vcm', circuit.gnd, "dc 0.7@u_V ac 1n")
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.4@u_V)  # Tail current bias (~VTH + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.8@u_V)  # PMOS current source bias (Vdd - |VTH| - 0.2V)
# Stage 1: Differential Pair with Proper Biasing
# Current Mirror Load Fix: M3 diode-connected, M4 mirror
circuit.MOSFET('1', 'Drain1', 'Vin', 'Tail', circuit.gnd, model='nmos_model', 
               w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Tail', circuit.gnd, model='nmos_model', 
               w=10@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=0.045@u_um)
# Tail current source (NMOS)
circuit.MOSFET('0', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=5@u_um, l=0.045@u_um)
# Stage 2: Common-Source with Proper V_DS
circuit.MOSFET('5', 'Node2', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=20@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Node2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', 
               w=15@u_um, l=0.045@u_um)
# Stage 3: Output Stage
circuit.MOSFET('7', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=30@u_um, l=0.045@u_um)
# Compensation Network
circuit.C('c', 'Node2', 'Vout', 1@u_pF)
circuit.R('z', 'Node2', 'Vout', 1@u_kOhm)
# Load Resistor
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)