from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (assuming common-mode voltage = 0.6V)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Input signal (DC bias)
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Common-mode voltage for differential pair
# Current Source for Differential Pair (I1 = 100uA)
circuit.I('1', 'Vdd', 'Tail', 100@u_uA)
# Stage 1: Differential Pair with Current Mirror Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'Tail', 'Tail', model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Tail', 'Tail', model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20@u_um, l=0.045@u_um)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('5', 'Node2', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Node2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Stage 3: Output Stage (Common-Source)
circuit.MOSFET('7', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', w=30@u_um, l=0.045@u_um)
# Compensation Network (Miller Capacitor + Nulling Resistor)
circuit.C('c', 'Node2', 'Vout', 1@u_pF)  # Miller capacitor
circuit.R('z', 'Node2', 'NodeZ', 1@u_kOhm)  # Nulling resistor
circuit.C('cz', 'NodeZ', 'Vout', 0.1@u_pF)  # Additional capacitor (optional)
# Bias Voltage for M6 (Vbias2 = Vdd - |Vth| - 0.2V = 1.2 - 0.22 - 0.2 = 0.78V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
# Load Resistor (optional, if needed)
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
# Simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
