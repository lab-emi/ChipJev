Vdd Vdd 0 1.2V
Vin Vin 0 0.6V
Vcm Vcm 0 0.6V
I1 Vdd Tail 100uA
M1 Drain1 Vin Tail Tail nmos_model l=0.045um w=10um
M2 Drain2 Vcm Tail Tail nmos_model l=0.045um w=10um
M3 Drain1 Drain1 Vdd Vdd pmos_model l=0.045um w=20um
M4 Drain2 Drain1 Vdd Vdd pmos_model l=0.045um w=20um
M5 Node2 Drain2 0 0 nmos_model l=0.045um w=20um
M6 Node2 Vbias2 Vdd Vdd pmos_model l=0.045um w=10um
M7 Vout Node2 0 0 nmos_model l=0.045um w=30um
Cc Node2 Vout 1pF
Rz Node2 Vout 1kOhm
Vbias2 Vbias2 0 0.78V
R1 Vout Vdd 10kOhm
.model nmos_model nmos (GAMMA=0.5 KP=0.0001 LAMBDA=0.1 PHI=0.6 VTO=0.22)
.model pmos_model pmos (GAMMA=0.5 KP=5e-05 LAMBDA=0.1 PHI=0.6 VTO=-0.22)

