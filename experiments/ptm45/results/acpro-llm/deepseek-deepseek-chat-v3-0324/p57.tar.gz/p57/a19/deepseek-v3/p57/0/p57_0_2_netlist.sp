Vdd Vdd 0 1.2V
Vin Vin 0 0.7V
Vcm Vcm 0 0.7V
Vbias1 Vbias1 0 0.4V
Vbias2 Vbias2 0 0.8V
M1 Drain1 Vin Tail 0 nmos_model l=0.045um w=10um
M2 Drain2 Vcm Tail 0 nmos_model l=0.045um w=10um
M3 Drain1 Drain1 Vdd Vdd pmos_model l=0.045um w=20um
M4 Drain2 Drain1 Vdd Vdd pmos_model l=0.045um w=20um
M0 Tail Vbias1 0 0 nmos_model l=0.045um w=5um
M5 Node2 Drain2 0 0 nmos_model l=0.045um w=20um
M6 Node2 Vbias2 Vdd Vdd pmos_model l=0.045um w=15um
M7 Vout Node2 0 0 nmos_model l=0.045um w=30um
Cc Node2 Vout 1pF
Rz Node2 Vout 1kOhm
R1 Vout Vdd 10kOhm
.model nmos_model nmos (KP=0.0001 LAMBDA=0.05 VTO=0.22)
.model pmos_model pmos (KP=5e-05 LAMBDA=0.05 VTO=-0.22)

