from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Corrected Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (now properly calculated)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)  # Slightly increased for better biasing
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.75@u_V)  # Slightly decreased for better PMOS biasing
circuit.V('cm', 'Vcm', circuit.gnd, 0.65@u_V)  # Adjusted common-mode voltage
# Input Signal (DC bias at common-mode with small AC perturbation)
circuit.V('in', 'Vin', 'Vcm', 0)
# Start-up Circuit (ensures proper biasing)
circuit.MOSFET('start', 'Vbias1', 'Vdd', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=2e-6, l=0.5e-6)
# Stage 1: Differential Pair with Current Mirror Load (now properly sized)
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, 
              model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Source1', circuit.gnd, 
              model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain2', 'Vdd', 'Vdd', 
              model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain2', 'Vdd', 'Vdd', 
              model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('9', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd,
              model='nmos_model', w=8e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with adjusted sizing
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=35e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Output Stage with proper biasing
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd,
              model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=30e-6, l=0.045e-6)
# Feedback and Compensation Network
circuit.R('f', 'Vout', 'Drain2', 100@u_kΩ)  # DC feedback for stabilization
circuit.C('c', 'Vout', 'Drain2', 500@u_fF)  # Compensation capacitor
# Additional small resistor for compensation zero control
circuit.R('z', 'Drain5', 'Vout', 2@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
