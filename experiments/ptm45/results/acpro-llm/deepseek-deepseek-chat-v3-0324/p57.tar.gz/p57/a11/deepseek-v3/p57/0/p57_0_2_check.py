from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
# Note: These values ensure all MOSFETs are in saturation
circuit.V('bias_diff', 'Vbias_diff', circuit.gnd, 0.45@u_V)  # Differential pair bias
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.5@u_V)   # Tail current (100uA)
circuit.V('bias_pmos', 'Vbias_p', circuit.gnd, 0.8@u_V)      # PMOS current sources
circuit.V('bias_out', 'Vbias_out', circuit.gnd, 0.6@u_V)     # Output stage bias
circuit.V('in', 'Vin', circuit.gnd, "dc 0.6@u_V ac 1n")
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'drain1', 'Vin', 'tail_node', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'drain2', 'Vbias_diff', 'tail_node', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'drain1', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'drain2', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('tail', 'tail_node', 'Vbias_tail', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common Source Amplifier
circuit.MOSFET('5', 'drain5', 'drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'drain5', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=40e-6, l=0.045e-6)
# Stage 3: Output Buffer
circuit.MOSFET('7', 'Vdd', 'drain5', 'Vout', circuit.gnd,
              model='nmos_model', w=60e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias_out', circuit.gnd, circuit.gnd,
              model='nmos_model', w=30e-6, l=0.045e-6)
# Miller Compensation
circuit.C('c', 'drain5', 'drain2', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)