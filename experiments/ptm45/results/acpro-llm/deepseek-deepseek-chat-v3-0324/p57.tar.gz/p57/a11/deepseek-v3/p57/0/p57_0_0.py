from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (assuming Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For NMOS (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For PMOS (Vdd - |Vth| - 0.2V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # For tail current source
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (mid-rail for single-ended)
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source
circuit.MOSFET('tail', 'Source1', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Current Source Load
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 3: Source Follower (Output Buffer)
circuit.MOSFET('7', 'Vdd', 'Drain5', 'Vout', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Output Bias Current Source
circuit.MOSFET('8', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Miller Compensation Capacitor
circuit.C('c', 'Drain5', 'Drain2', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
