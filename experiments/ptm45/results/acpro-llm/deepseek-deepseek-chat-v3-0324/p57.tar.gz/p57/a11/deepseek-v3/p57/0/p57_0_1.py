from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V assumed)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # NMOS bias (Vth + 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.5@u_V)  # Tail current bias
circuit.V('bias_out', 'Vbias_out', circuit.gnd, 0.5@u_V)  # Output stage bias
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Input mid-rail for single-ended
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Stage 1: Differential Pair with Active Load
# Differential pair
circuit.MOSFET('1', 'drain1', 'Vin', 'tail_node', circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'drain2', 'Vbias_n', 'tail_node', circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
# Current mirror load
circuit.MOSFET('3', 'drain1', 'drain1', 'Vdd', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'drain2', 'drain1', 'Vdd', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current source (100uA)
circuit.MOSFET('tail', 'tail_node', 'Vbias_tail', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common Source with Current Source Load
circuit.MOSFET('5', 'drain5', 'drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# Current source load (200uA)
circuit.MOSFET('6', 'drain5', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=40e-6, l=0.045e-6)
# Stage 3: Source Follower with Current Sink
circuit.MOSFET('7', 'Vdd', 'drain5', 'Vout', circuit.gnd,
              model='nmos_model', w=40e-6, l=0.045e-6)
# Output current sink (100uA)
circuit.MOSFET('8', 'Vout', 'Vbias_out', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# Miller Compensation
circuit.C('c', 'drain5', 'drain2', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
