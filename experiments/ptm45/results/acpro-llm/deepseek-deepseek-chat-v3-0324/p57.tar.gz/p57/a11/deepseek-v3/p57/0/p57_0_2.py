from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
# Note: These values ensure all MOSFETs are in saturation
circuit.V('bias_diff', 'Vbias_diff', circuit.gnd, 0.45@u_V)  # Differential pair bias
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.5@u_V)   # Tail current (100uA)
circuit.V('bias_pmos', 'Vbias_p', circuit.gnd, 0.8@u_V)      # PMOS current sources
circuit.V('bias_out', 'Vbias_out', circuit.gnd, 0.6@u_V)     # Output stage bias
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)                 # Input bias
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'drain1', 'Vin', 'tail_node', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'drain2', 'Vbias_diff', 'tail_node', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'drain1', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'drain2', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('tail', 'tail_node', 'Vbias_tail', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common Source Amplifier
circuit.MOSFET('5', 'drain5', 'drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'drain5', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=40e-6, l=0.045e-6)
# Stage 3: Output Buffer
circuit.MOSFET('7', 'Vdd', 'drain5', 'Vout', circuit.gnd,
              model='nmos_model', w=60e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias_out', circuit.gnd, circuit.gnd,
              model='nmos_model', w=30e-6, l=0.045e-6)
# Miller Compensation
circuit.C('c', 'drain5', 'drain2', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
