from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier with High GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (Vth = 0.22V and Vdd = 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage (Vth + 0.2V)
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    # First Stage: Telescopic Cascode Amplifier
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', 'Drain1', 
                  model='nmos_model', 
                  w=params['w_m3'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    # Second Stage: Common-Source Amplifier with Current Source Load
    circuit.MOSFET('5', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m4'], 
                  l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Drain3', 'Vout', params['c_comp']@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - range 1-500×L (45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M1 width (original: 5μm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M2 width (original: 10μm) 
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M3 width (original: 5μm)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M4 width (original: 10μm)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # M5 width (original: 10μm)
    # Bias voltages (constrained around original values, never exceeding Vdd=1.2V)
    'vbias1': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth + 0.2V)
    'vbias2': {'min': 0.62, 'max': 0.94},  # Original: 0.78V (Vdd - Vth - 0.2V)
    # Compensation capacitor (0.5-5× original value)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True}  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,
    'w_m2': 10e-6,
    'w_m3': 5e-6,
    'w_m4': 10e-6,
    'w_m5': 10e-6,
    # Bias voltages
    'vbias1': 0.42,  # Vth + 0.2V
    'vbias2': 0.78,  # Vdd - Vth - 0.2V
    # Compensation capacitor
    'c_comp': 1.0  # 1pF
}
# Brief description of parameters:
# - w_m*: Transistor widths (affects gm, ro, and current)
# - vbias1: First stage cascode bias voltage (sets operating point)
# - vbias2: Current source bias voltage (sets load current)
# - c_comp: Miller compensation capacitor (critical for stability)
