from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('High_FoM_3Stage_Amplifier')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    # Input Signal (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # Stage 1: Telescopic Cascode
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w1'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain2', 'Vbias1', 'Drain1', circuit.gnd,
                  model='nmos_model', w=params['w3'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w2'], l=0.045e-6)
    # Stage 2: Common-Source
    circuit.MOSFET('4', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w4'], l=0.045e-6)
    circuit.MOSFET('5', 'Drain3', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w5'], l=0.045e-6)
    # Stage 3: Class-AB Output Stage
    circuit.MOSFET('6', 'Vout', 'Drain3', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Drain3', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w7'], l=0.045e-6)
    # Compensation Network
    circuit.C('c', 'Drain2', 'Vout', f"{params['cc']}p")
    circuit.R('c', 'Drain2', 'NodeX', f"{params['rc']}k")
    circuit.C('c2', 'NodeX', 'Vout', "0.1p")  # Fixed as requested
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length for 45nm)
    'w1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS
    'w2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode PMOS
    'w3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode NMOS
    'w4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 2nd stage NMOS
    'w5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 2nd stage PMOS
    'w6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output NMOS
    'w7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output PMOS
    # Bias voltages (0.8-1.2× original, not exceeding 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (Vth+0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd-Vth-0.2V)
    'vbias3': {'min': 0.48, 'max': 0.72},    # Original: 0.6V (mid-rail)
    # Compensation network
    'cc': {'min': 0.5, 'max': 5, 'log': True},  # Main compensation cap (original 1pF)
    'rc': {'min': 0.5, 'max': 2, 'log': True},  # Compensation resistor (original 1kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w1': 10e-6,
    'w2': 20e-6,
    'w3': 10e-6,
    'w4': 20e-6,
    'w5': 40e-6,
    'w6': 100e-6,
    'w7': 200e-6,
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    'vbias3': 0.6,
    # Compensation network
    'cc': 1.0,  # 1pF
    'rc': 1.0,  # 1kΩ
}
