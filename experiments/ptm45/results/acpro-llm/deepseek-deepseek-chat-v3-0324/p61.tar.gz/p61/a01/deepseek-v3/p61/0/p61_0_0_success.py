from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High_FoM_3Stage_Amplifier')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (assuming Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Vdd - Vth - 0.2V
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.6@u_V)   # Mid-rail for class-AB
# Input Signal (DC operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Set at Vbias1 for operation
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain2', 'Vbias1', 'Drain1', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('4', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Drain3', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=40e-6, l=0.045e-6)
# Stage 3: Class-AB Output Stage
circuit.MOSFET('6', 'Vout', 'Drain3', circuit.gnd, circuit.gnd,
              model='nmos_model', w=100e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Drain3', 'Vdd', 'Vdd',
              model='pmos_model', w=200e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)
circuit.R('c', 'Drain2', 'NodeX', 1@u_kΩ)
circuit.C('c2', 'NodeX', 'Vout', 0.1@u_pF)  # Split cap for better zero placement
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
