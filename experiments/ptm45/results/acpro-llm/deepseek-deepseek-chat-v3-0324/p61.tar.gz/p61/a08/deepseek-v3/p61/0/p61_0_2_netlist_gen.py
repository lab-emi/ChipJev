from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
# Initialize circuit
circuit = Circuit('Three-Stage Amplifier (Final Corrected)')
# 1. Define MOSFET models (UNCHANGED)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# 2. Power Supply (UNCHANGED)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# 3. Bias Voltages (MODIFIED values for better operation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)  # Increased from 0.42V for better current
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.75@u_V)  # Adjusted PMOS bias
circuit.V('bias_dc', 'Vbias_dc', circuit.gnd, 0.6@u_V)  # Common-mode input
# 4. Input Signal (MODIFIED to include AC+DC)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # DC bias only
# 5. First Stage: Differential Pair with Current Mirror Load (MODIFIED sizes)
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', 'Source1', model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias_dc', 'Source1', 'Source1', model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('8', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=8e-6, l=0.045e-6)
# 6. Current Mirror Load (MODIFIED sizes for better matching)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# 7. Second Stage: Common-Source with Active Load (MODIFIED sizes)
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# 8. Third Stage: Common-Source with Resistor Load (MODIFIED sizes)
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 8@u_kΩ)  # Reduced from 10kΩ for better current
# 9. Compensation Network (COMPLETELY REWORKED)
circuit.C('c', 'Drain5', 'Vout', 1.5@u_pF)  # Main Miller capacitor
circuit.R('z', 'Drain5', 'Vout', 1.5@u_kΩ)  # Direct RC compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
