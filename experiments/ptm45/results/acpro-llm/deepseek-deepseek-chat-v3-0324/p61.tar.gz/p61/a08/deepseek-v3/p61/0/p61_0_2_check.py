from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
# Initialize circuit
circuit = Circuit('Three-Stage Amplifier (Final Corrected)')
# 1. Define MOSFET models (UNCHANGED)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# 2. Power Supply (UNCHANGED)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# 3. Bias Voltages (MODIFIED values for better operation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)  # Increased from 0.42V for better current
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.75@u_V)  # Adjusted PMOS bias
circuit.V('bias_dc', 'Vbias_dc', circuit.gnd, 0.6@u_V)  # Common-mode input
# 4. Input Signal (MODIFIED to include AC+DC)
circuit.V('in', 'Vin', circuit.gnd, "dc 0.6@u_V ac 1n")
# 5. First Stage: Differential Pair with Current Mirror Load (MODIFIED sizes)
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', 'Source1', model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias_dc', 'Source1', 'Source1', model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('8', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=8e-6, l=0.045e-6)
# 6. Current Mirror Load (MODIFIED sizes for better matching)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# 7. Second Stage: Common-Source with Active Load (MODIFIED sizes)
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# 8. Third Stage: Common-Source with Resistor Load (MODIFIED sizes)
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 8@u_kΩ)  # Reduced from 10kΩ for better current
# 9. Compensation Network (COMPLETELY REWORKED)
circuit.C('c', 'Drain5', 'Vout', 1.5@u_pF)  # Main Miller capacitor
circuit.R('z', 'Drain5', 'Vout', 1.5@u_kΩ)  # Direct RC compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)