from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
circuit.V('bias_dc', 'Vbias_dc', circuit.gnd, 0.6@u_V)  # Common-mode input
# Input Signal (DC bias only, no AC)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Matches common-mode
# First Stage: Differential Pair with Current Mirror Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', 'Source1', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias_dc', 'Source1', 'Source1', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('8', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Current Mirror Load (PMOS)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Second Stage: Common-Source with Diode-Connected Load
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Third Stage: Common-Source with Resistor Load
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Compensation Network
circuit.C('c', 'Drain5', 'Vout', 1@u_pF)
circuit.R('z', 'Drain5', 'Node_z', 1@u_kΩ)  # Rz in series with Cc
circuit.C('cz', 'Node_z', 'Vout', 1@u_pF)  # Practical implementation of Rz+Cc
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
