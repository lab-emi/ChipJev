from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier with High GBW/Power')
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized with conservative ranges)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # M7 bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # M2/M4 bias
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)  # M6 bias
    circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Common-mode voltage (fixed)
    # Input Signal (DC operating point only, fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)
    # Stage 1: Differential Pair with Active Load
    # Differential Pair (M1, M3)
    circuit.MOSFET('1', 'Node1', 'Vin', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('3', 'Node2', 'Vcm', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    # Active Load (M2, M4)
    circuit.MOSFET('2', 'Node1', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('4', 'Node2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (M7)
    circuit.MOSFET('7', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('5', 'Vout', 'Node2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (m)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (m)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (m)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (m)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (m)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (m)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (m)
    # Bias voltages (0.8-1.2× original, but below 1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # M7 bias (V)
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # M2/M4 bias (V)
    'vbias3': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # M6 bias (V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_M1': 5e-6,    'w_M3': 5e-6,    # Differential pair
    'w_M2': 10e-6,   'w_M4': 10e-6,   # Active load
    'w_M5': 10e-6,                    # CS stage NMOS
    'w_M6': 10e-6,                    # CS stage PMOS
    'w_M7': 10e-6,                    # Tail current
    # Bias voltages (original values)
    'vbias1': 0.42,  # M7 bias
    'vbias2': 0.78,  # M2/M4 bias
    'vbias3': 0.78,  # M6 bias
}
# Brief parameter descriptions:
# - w_M1-w_M7: Widths of corresponding MOSFETs (1-500× length, 45nm process)
# - vbias1: Tail current source bias voltage (0.8-1.2× original, Vgs ≈ Vth + 0.2V)
# - vbias2: Active load PMOS bias voltage (0.8-1.2× original, Vgs ≈ Vdd - Vth - 0.2V)
# - vbias3: Second stage PMOS bias voltage (0.8-1.2× original, same as vbias2)
