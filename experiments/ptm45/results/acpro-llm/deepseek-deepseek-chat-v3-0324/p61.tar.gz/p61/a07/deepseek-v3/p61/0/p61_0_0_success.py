from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier with High GBW/Power')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (assuming Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # M7 bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # M2/M4 bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # M6 bias
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)        # Common-mode voltage
# Input Signal (DC operating point only)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
# Differential Pair (M1, M3)
circuit.MOSFET('1', 'Node1', 'Vin', 'Tail', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Node2', 'Vcm', 'Tail', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (M2, M4)
circuit.MOSFET('2', 'Node1', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Node2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (M7)
circuit.MOSFET('7', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
circuit.MOSFET('5', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
