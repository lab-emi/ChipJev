from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier (GBW/Power Optimized)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Corrected Bias Voltages (Vth = 0.22V assumed)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.84@u_V)  # NMOS cascode: V_S(M3) + Vth + 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS cascode: Vdd - |Vth| - 0.2V
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # PMOS current source: Vdd - |Vth| - 0.2V
# Input Signal (DC bias at Vth + 0.2V = 0.42V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
# Stage 1: Telescopic Cascode (Fixed)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=45e-9)  # M1: Input NMOS (V_S = 0V)
circuit.MOSFET('3', 'Stage1Out', 'Vbias1', 'Drain1', 'Drain1', 
               model='nmos_model', w=5e-6, l=45e-9)  # M3: Cascode NMOS (V_S = Drain1 ~ 0.42V)
circuit.MOSFET('2', 'Stage1Out', 'Vbias2', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=45e-9)  # M2: PMOS load
circuit.MOSFET('4', 'Drain1', 'Vbias3', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=45e-9)  # M4: Current source
# Stage 2: Common-Source
circuit.MOSFET('5', 'Stage2Out', 'Stage1Out', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=20e-6, l=45e-9)  # M5: Gain NMOS
circuit.MOSFET('6', 'Stage2Out', 'Vbias3', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=45e-9)  # M6: Current load
# Stage 3: Common-Drain Buffer
circuit.MOSFET('7', 'Vdd', 'Stage2Out', 'Vout', 'Vout', 
               model='nmos_model', w=50e-6, l=45e-9)  # M7: Output buffer
circuit.R('load', 'Vout', circuit.gnd, 1@u_kΩ)  # Load resistor
# Compensation Network
circuit.C('miller', 'Stage2Out', 'Stage1Out', 5@u_pF)  # Miller capacitor
circuit.R('null', 'Stage2Out', 'CompNode', 1@u_kΩ)  # Nulling resistor
circuit.C('comp', 'CompNode', 'Stage1Out', 5@u_pF)  # Additional compensation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
