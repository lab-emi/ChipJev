from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Three-Stage Amplifier (GBW/Power Optimized)')
# Define MOSFET models from imported parameters
circuit.model('nmos_model', 'nmos', **nmos_params)  # Add NMOS model
circuit.model('pmos_model', 'pmos', **pmos_params)  # Add PMOS model
# Power Supply (1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode: Vth + 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS cascode: Vdd - |Vth| - 0.2V
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # PMOS current source
# Input Signal (DC bias at Vth + 0.2V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=45e-9)  # Input NMOS
circuit.MOSFET('3', 'Stage1Out', 'Vbias1', 'Drain1', 'Drain1', 
               model='nmos_model', w=5e-6, l=45e-9)  # Cascode NMOS
circuit.MOSFET('2', 'Stage1Out', 'Vbias2', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=45e-9)  # PMOS load
circuit.MOSFET('4', 'Drain1', 'Vbias3', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=45e-9)  # Current source
# Stage 2: Common-Source
circuit.MOSFET('5', 'Stage2Out', 'Stage1Out', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=20e-6, l=45e-9)  # Gain NMOS
circuit.MOSFET('6', 'Stage2Out', 'Vbias3', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=45e-9)  # Current load
# Stage 3: Common-Drain Buffer
circuit.MOSFET('7', 'Vdd', 'Stage2Out', 'Vout', 'Vout', 
               model='nmos_model', w=50e-6, l=45e-9)  # Output buffer
circuit.R('load', 'Vout', circuit.gnd, 1@u_kΩ)  # Load resistor
# Compensation Network (Miller + Nulling Resistor)
circuit.C('miller', 'Stage2Out', 'Stage1Out', 5@u_pF)  # Miller cap
circuit.R('null', 'Stage2Out', 'CompNode', 1@u_kΩ)  # Nulling resistor
circuit.C('comp', 'CompNode', 'Stage1Out', 5@u_pF)  # Additional compensation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
