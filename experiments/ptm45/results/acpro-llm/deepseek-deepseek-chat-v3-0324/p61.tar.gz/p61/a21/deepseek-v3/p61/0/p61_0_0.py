from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier for Max GBW/Power')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltages (assuming Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42) # NMOS cascode bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78) # PMOS cascode bias (Vdd - |Vth| - 0.2V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78) # PMOS current source bias
# Input Signal
circuit.V('in', 'Vin', circuit.gnd, 0.42) # DC operating point at Vth + 0.2V
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Stage1Out', 'Vbias1', 'Drain1', 'Drain1', model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Stage1Out', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain1', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Stage2Out', 'Stage1Out', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Stage2Out', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Common-Drain Buffer
circuit.MOSFET('7', 'Vdd', 'Stage2Out', 'Vout', 'Vout', model='nmos_model', w=50e-6, l=0.045e-6)
circuit.R('2', 'Vout', circuit.gnd, 1@u_kΩ) # Load resistor
# Compensation Network
circuit.C('1', 'Stage2Out', 'Stage1Out', 5@u_pF) # Miller capacitor
circuit.R('1', 'Stage2Out', 'CompNode', 1@u_kΩ) # Nulling resistor
circuit.C('2', 'CompNode', 'Stage1Out', 5@u_pF) # Additional compensation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
