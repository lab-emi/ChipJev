from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Typical input bias
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
circuit.R('1', 'Vbias3', 'Vdd', 100@u_kΩ)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain3', 'Vbias2', 'Drain2', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Drain5', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Drain5', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Stage 3: Source Follower
circuit.MOSFET('7', 'Vdd', 'Drain5', 'Vout', 'Vdd', model='pmos_model', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('8', 'Vout', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
