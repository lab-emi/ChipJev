from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier')
# 1. FIRST CRITICAL FIX: Add proper SPICE model definitions
# Define NMOS model (using parameters from imported nmos_params)
circuit.model('nmos', 'nmos', level=1, kp=120e-6, vto=0.22, gamma=0.3, lambda=0.05)
# Define PMOS model (using parameters from imported pmos_params)
circuit.model('pmos', 'pmos', level=1, kp=40e-6, vto=-0.22, gamma=0.3, lambda=0.05)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias - changed from fixed voltage to use a DC source for flexibility
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Typical input bias (Vth + 200mV)
# 2. IMPROVEMENT: Better bias network implementation
# Bias Voltages - added series resistors to prevent floating nodes
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)
circuit.R('bias1r', 'Vbias1', circuit.gnd, 1@u_kΩ)  # Small resistor to ground
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
circuit.R('bias2r', 'Vbias2', circuit.gnd, 1@u_kΩ)  
circuit.R('bias3r', 'Vbias3', 'Vdd', 100@u_kΩ)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)
circuit.R('bias3gnd', 'Vbias3', circuit.gnd, 1@u_MΩ)  # Large resistor to prevent floating
# 3. FIX: Corrected MOSFET model names to match the defined models
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd, model='nmos', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain3', 'Vbias2', 'Drain2', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vbias3', 'Vdd', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Drain5', 'Drain3', circuit.gnd, circuit.gnd, model='nmos', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Drain5', 'Vbias3', 'Vdd', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
# 4. FIX: Corrected bulk connections for PMOS in Stage 3
# Stage 3: Source Follower
circuit.MOSFET('7', 'Vdd', 'Drain5', 'Vout', 'Vdd', model='pmos', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('8', 'Vout', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos', w=10@u_um, l=0.045@u_um)
# 5. IMPROVEMENT: Added load capacitance for stability
circuit.C('load', 'Vout', circuit.gnd, 100@u_fF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
