from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier')
# 1. FIXED MODEL DEFINITION: Replace 'lambda' with 'lambd' (SPICE uses 'lambda' but we must avoid Python keyword)
circuit.model('nmos', 'nmos', 
              level=1, 
              kp=120e-6,    # Transconductance parameter
              vto=0.22,     # Threshold voltage
              gamma=0.3,    # Body effect parameter
              lambd=0.05)   # Channel-length modulation (changed from 'lambda')
circuit.model('pmos', 'pmos', 
              level=1, 
              kp=40e-6, 
              vto=-0.22, 
              gamma=0.3, 
              lambd=0.05)   # Same fix for PMOS
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias - DC source for input signal
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 200mV for proper biasing
# 2. IMPROVED BIAS NETWORK: Added proper resistive loading for each bias node
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)
circuit.R('bias1r', 'Vbias1', circuit.gnd, 1@u_kΩ)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
circuit.R('bias2r', 'Vbias2', circuit.gnd, 1@u_kΩ)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)
circuit.R('bias3r', 'Vbias3', 'Vdd', 100@u_kΩ)
circuit.R('bias3gnd', 'Vbias3', circuit.gnd, 1@u_MΩ)  # Prevents floating node
# 3. STAGE 1: Telescopic Cascode - Fixed all model references
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd, model='nmos', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain3', 'Vbias2', 'Drain2', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vbias3', 'Vdd', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
# 4. STAGE 2: Common-Source - Fixed bulk connections
circuit.MOSFET('5', 'Drain5', 'Drain3', circuit.gnd, circuit.gnd, model='nmos', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Drain5', 'Vbias3', 'Vdd', 'Vdd', model='pmos', w=10@u_um, l=0.045@u_um)
# 5. STAGE 3: Source Follower - Added explicit bulk connections
circuit.MOSFET('7', 'Vdd', 'Drain5', 'Vout', 'Vdd', model='pmos', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('8', 'Vout', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos', w=10@u_um, l=0.045@u_um)
# 6. STABILITY IMPROVEMENTS: Added realistic load components
circuit.C('load', 'Vout', circuit.gnd, 100@u_fF)  # Typical load capacitance
circuit.R('load', 'Vout', circuit.gnd, 1@u_MΩ)    # High-impedance load
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
