from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Cascode Compensation')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias for M1 (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Bias for M2 (Vdd - |Vth| - 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Bias for M4 (same as M2)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Bias for M3 (Vth + 0.2V)
# Stage 1: Common-Source with Current Source Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Cascode Stage
circuit.MOSFET('3', 'Drain2', 'Vbias3', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 3: Output Stage
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)
circuit.R('c', 'Drain2', 'Vout_comp', 10@u_kΩ)
circuit.C('c_extra', 'Vout_comp', 'Vout', 1@u_fF)  # Small parasitic cap
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
