from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (1.2V, fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Fixed input voltages (will be swept during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.5@u_V)  # Fixed input bias
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    # Stage 1: CS with PMOS current source load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m2'], l=0.045e-6)
    # Stage 2: Cascode stage
    circuit.MOSFET('3', 'Drain2', 'Vbias3', 'Drain1', circuit.gnd,
                  model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Stage 3: Output stage
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Parameterized load resistor
    circuit.R('load', 'Vout', 'Vdd', f"{params['r_load']}@u_kΩ")
    # Parameterized compensation network
    circuit.C('c', 'Drain2', 'Vout', f"{params['c_comp']}@u_pF")
    circuit.R('c', 'Drain2', 'Vout', f"{params['r_comp']}@u_kΩ")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L=45nm fixed)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1: 1-500×L (original 5u)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2: 1-500×L (original 10u)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3: 1-500×L (original 5u)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4: 1-500×L (original 10u)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5: 1-500×L (original 5u)
    # Bias voltages (constrained to 0.8-1.2× original but ≤ 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2×)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2×)
    'vbias3': {'min': 0.52, 'max': 0.78},    # Original: 0.65V (0.8-1.2×)
    # Passive components
    'r_load': {'min': 5, 'max': 20, 'log': True},      # Original: 10kΩ (0.5-2×)
    'r_comp': {'min': 5, 'max': 20, 'log': True},      # Original: 10kΩ (0.5-2×)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},     # Original: 1pF (0.5-5×)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 5e-6,
    'w_m2': 10e-6,
    'w_m3': 5e-6,
    'w_m4': 10e-6,
    'w_m5': 5e-6,
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.78,
    'vbias3': 0.65,
    # Passive components
    'r_load': 10,
    'r_comp': 10,
    'c_comp': 1,
}
