from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Adjusted Bias Voltages:
# Stage 1: Set Vin to get Drain1 ~0.4V (Vgs_m1 = 0.5V > Vth)
circuit.V('in', 'Vin', circuit.gnd, 0.5@u_V)  # Increased from 0.42V to 0.5V
# Current source biases (PMOS)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Same as Vbias1
# Critical Fix: Increased cascode bias to ensure Vgs_m3 > Vth
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.65@u_V)  # Increased from 0.42V to 0.65V
# Stage 1: CS with PMOS current source load
# M1: W/L=5u/45n, biased to give Drain1 ~0.4V
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
# M2: W/L=10u/45n current source
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Cascode stage
# M3: Now properly biased with Vgs = 0.65V - 0.4V = 0.25V > Vth
circuit.MOSFET('3', 'Drain2', 'Vbias3', 'Drain1', circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
# M4: Current source
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 3: Output stage
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.R('load', 'Vout', 'Vdd', 10@u_kΩ)
# Compensation network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)
circuit.R('c', 'Drain2', 'Vout', 10@u_kΩ)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
