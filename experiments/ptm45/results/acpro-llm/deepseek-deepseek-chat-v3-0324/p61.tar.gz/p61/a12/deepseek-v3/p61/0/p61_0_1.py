from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Cascode Compensation')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (all referenced to ground)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 200mV = 0.22V + 0.2V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 200mV = 1.2 - 0.22 - 0.2
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Same as Vbias1 for symmetry
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Vth + 200mV for cascode
# Stage 1: CS with PMOS current source load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Cascode stage
circuit.MOSFET('3', 'Drain2', 'Vbias3', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 3: Output stage with explicit load
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.R('load', 'Vout', 'Vdd', 10@u_kΩ)  # Added explicit load resistor
# Compensation network (Cc + Rc between stage2 output and final output)
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)  # Changed from u_fF to u_pF
circuit.R('c', 'Drain2', 'Vout', 10@u_kΩ)  # Direct connection (no Vout_comp node)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
