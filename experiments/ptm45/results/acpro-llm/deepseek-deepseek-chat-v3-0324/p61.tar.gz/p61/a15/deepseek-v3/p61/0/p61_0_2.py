from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (carefully adjusted)
circuit.V('in', 'Vin', circuit.gnd, 0.45@u_V)  # Slightly above Vth
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.72@u_V)  # Adjusted for proper current mirror operation
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.65@u_V)  # Ensures M3 in saturation
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.45@u_V)  # Proper PMOS cascode bias (Vdd - |Vth| - 0.15V)
# Stage 1: Enhanced Telescopic Cascode
# Main input pair
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
# NMOS cascode
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
# PMOS current source
circuit.MOSFET('2', 'Drain3', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# PMOS cascode - critical fix
circuit.MOSFET('4', 'Drain4', 'Vbias3', 'Drain3', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Drain5', 'Drain4', circuit.gnd, circuit.gnd, model='nmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=50e-6, l=0.045e-6)
# Stage 3: Output Stage
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=50e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain4', 'Vout', 1.5@u_pF)
circuit.R('c', 'Drain4', 'NodeC', 8@u_kΩ)
circuit.C('cz', 'NodeC', 'Vout', 0.3@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
