from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier (Corrected Cascode Biasing)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Corrected)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # PMOS current sources
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.6@u_V)   # NMOS cascode (increased to 0.6V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.5@u_V)   # PMOS cascode
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)        # Input bias
# Current Sources (Properly Biased)
circuit.MOSFET('I1', 'Tail', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('I2', 'Node1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('I3', 'Node2', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Stage 1: Folded-Cascode with Corrected Biasing
circuit.MOSFET('1', 'Drain1', 'Vin', 'Tail', 'Tail', model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# Cascode transistors with proper V_GS
circuit.MOSFET('3', 'Node1', 'Vbias2', 'Drain1', 'Drain1', model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('4', 'Node1', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Node2', 'Node1', circuit.gnd, circuit.gnd, model='nmos_model', w=25e-6, l=0.045e-6)
# Stage 3: Source Follower
circuit.MOSFET('6', 'Vout', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=100e-6, l=0.045e-6)
# Compensation Capacitor
circuit.C('c', 'Node2', 'Node1', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
