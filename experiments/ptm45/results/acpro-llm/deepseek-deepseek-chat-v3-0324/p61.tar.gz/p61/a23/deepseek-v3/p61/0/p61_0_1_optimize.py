from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier')
    # Define MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    # Input Voltage (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed bias for M1
    # Parameterized Bias Voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # Bias for M2/M5
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # Bias for M4
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)  # Bias for M7
    # Stage 1: Common-Source with Active Load (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045@u_um)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M2'], l=0.045@u_um)
    # Stage 2: Cascode Stage (M3, M4, M5)
    circuit.MOSFET('3', 'Drain3', 'Drain1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045@u_um)
    circuit.MOSFET('4', 'Drain4', 'Vbias2', 'Drain3', circuit.gnd, 
                   model='nmos_model', w=params['w_M4'], l=0.045@u_um)
    circuit.MOSFET('5', 'Drain4', 'Vbias1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M5'], l=0.045@u_um)
    # Stage 3: Output Stage with Active Load (M6, M7)
    circuit.MOSFET('6', 'Vout', 'Drain4', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M6'], l=0.045@u_um)
    circuit.MOSFET('7', 'Vout', 'Vbias3', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M7'], l=0.045@u_um)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (0.8-1.2× original value, constrained to ≤1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},   # Original: 0.78V (for M2/M5)
    'vbias2': {'min': 0.496, 'max': 0.744},   # Original: 0.62V (for M4)
    'vbias3': {'min': 0.624, 'max': 0.936},   # Original: 0.78V (for M7)
    # Transistor widths (1-500× length = 0.045μm-22.5μm)
    'w_M1': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 5μm (M1)
    'w_M2': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 10μm (M2)
    'w_M3': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 10μm (M3)
    'w_M4': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 10μm (M4)
    'w_M5': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 20μm (M5)
    'w_M6': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 15μm (M6)
    'w_M7': {'min': 0.045, 'max': 22.5, 'log': True},   # Original: 15μm (M7)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'vbias1': 0.78,
    'vbias2': 0.62,
    'vbias3': 0.78,
    # Transistor Widths
    'w_M1': 5,
    'w_M2': 10,
    'w_M3': 10,
    'w_M4': 10,
    'w_M5': 20,
    'w_M6': 15,
    'w_M7': 15,
}
# Parameter descriptions (for reference)
"""
Parameter Descriptions:
- vbias1: Bias voltage for PMOS loads M2 and M5 (originally set to Vdd - |Vth| - 0.2V)
- vbias2: Bias voltage for NMOS M4 in cascode stage (originally set to Vth + 0.4V)
- vbias3: Bias voltage for PMOS load M7 in output stage
- w_M1: Width of NMOS input transistor M1
- w_M2: Width of PMOS load transistor M2
- w_M3: Width of NMOS cascode transistor M3
- w_M4: Width of NMOS cascode transistor M4
- w_M5: Width of PMOS load transistor M5
- w_M6: Width of NMOS output transistor M6
- w_M7: Width of PMOS load transistor M7
"""
