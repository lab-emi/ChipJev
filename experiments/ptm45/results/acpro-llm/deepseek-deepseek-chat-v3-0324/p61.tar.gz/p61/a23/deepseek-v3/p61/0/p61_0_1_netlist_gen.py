from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias for M1 (Vth + 0.2V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Bias for M2/M5 (Vdd - |Vth| - 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.62@u_V)  # Bias for M4 (Vth + 0.4V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # New bias for M7 (PMOS load)
# Stage 1: Common-Source with Active Load (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Stage 2: Cascode Stage (M3, M4, M5)
circuit.MOSFET('3', 'Drain3', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain4', 'Vbias2', 'Drain3', circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('5', 'Drain4', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=20@u_um, l=0.045@u_um)
# Stage 3: Output Stage with Active Load (M6, M7)
circuit.MOSFET('6', 'Vout', 'Drain4', circuit.gnd, circuit.gnd, model='nmos_model', w=15@u_um, l=0.045@u_um)
circuit.MOSFET('7', 'Vout', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=15@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
