from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.52@u_V)  # Optimized for tail current
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.8@u_V)   # Improved current source bias
circuit.V('in', 'Vin', circuit.gnd, 0.65@u_V)       # Mid-supply with margin
circuit.V('cm', 'Vin_cm', circuit.gnd, 0.65@u_V)    # Common-mode voltage
# Stage 1: Differential Pair with Current Mirror Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vin_cm', 'Source1', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('7', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2.5e-6, l=0.045e-6)  # Tail current
# Current Mirror Load
circuit.MOSFET('4a', 'Drain1', 'Drain2', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4b', 'Drain2', 'Drain2', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source with Current Source Load
circuit.MOSFET('3', 'Drain3', 'Drain1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=30e-6, l=0.045e-6)  # Increased width
circuit.MOSFET('6', 'Drain3', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=5e-6, l=0.045e-6)   # Reduced width
# Stage 3: Common-Source with Resistor Load
circuit.MOSFET('5', 'Vout', 'Drain3', circuit.gnd, circuit.gnd,
               model='nmos_model', w=40e-6, l=0.045e-6)  # Increased drive
circuit.R('1', 'Vout', 'Vdd', 2@u_kΩ)                   # Reduced resistance
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
