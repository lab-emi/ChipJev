from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Optimized Multi-Stage Amplifier')
# --------------------------
# 1. 45nm MOSFET Models (with realistic parameters)
# --------------------------
circuit.model('nmos_model', 'nmos', 
             VTO=0.22, KP=150e-6, GAMMA=0.3, 
             PHI=0.6, LAMBDA=0.05, TOX=1.2e-9)
circuit.model('pmos_model', 'pmos', 
             VTO=-0.22, KP=50e-6, GAMMA=0.3,
             PHI=0.6, LAMBDA=0.05, TOX=1.2e-9)
# --------------------------
# 2. Power Supplies & Biasing
# --------------------------
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Main supply
circuit.V('in', 'Vin', circuit.gnd, 0.55@u_V)  # Increased input bias
# Stable bias network for PMOS current sources
circuit.R('bias1', 'Vdd', 'Vbias_p', 80@u_kΩ)
circuit.R('bias2', 'Vbias_p', circuit.gnd, 120@u_kΩ)  # Sets Vbias_p ≈ 0.72V
# --------------------------
# 3. Stage 1: CS with Active Load
# --------------------------
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
              model='nmos_model', w=8e-6, l=0.045e-6)  # Increased width
circuit.MOSFET('2', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=15e-6, l=0.045e-6)
# --------------------------
# 4. Stage 2: CS with Active Load
# --------------------------
circuit.MOSFET('3', 'Vout_int', 'Drain1', circuit.gnd, circuit.gnd,
              model='nmos_model', w=12e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout_int', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=15e-6, l=0.045e-6)  # PMOS load
# --------------------------
# 5. Stage 3: Source Follower (Corrected)
# --------------------------
# Current source for SF (properly biased)
circuit.MOSFET('5', 'Vout', 'Vbias_n', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# SF transistor (ensured VGS > VTH)
circuit.MOSFET('6', 'Vout', 'Vout_int', circuit.gnd, circuit.gnd,
              model='nmos_model', w=25e-6, l=0.045e-6)  # Large W for low Ron
# Bias for NMOS SF (sets Vout ≈ Vout_int - VTH)
circuit.R('bias3', 'Vdd', 'Vbias_n', 100@u_kΩ)
circuit.R('bias4', 'Vbias_n', circuit.gnd, 150@u_kΩ)  # Vbias_n ≈ 0.51V
# --------------------------
# 6. Stabilization Capacitor
# --------------------------
circuit.C('1', 'Drain1', circuit.gnd, 100@u_fF)  # Compensation cap
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
