from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Amplifier (Corrected)')
# --------------------------
# 1. MODEL DEFINITIONS (CRITICAL FIX)
# --------------------------
# 45nm MOSFET models (typical parameters)
circuit.model('nmos_model', 'nmos', 
              VTO=0.22, KP=150e-6, GAMMA=0.3, PHI=0.6, LAMBDA=0.05)
circuit.model('pmos_model', 'pmos', 
              VTO=-0.22, KP=50e-6, GAMMA=0.3, PHI=0.6, LAMBDA=0.05)
# --------------------------
# 2. POWER SUPPLY & BIASING
# --------------------------
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
# Stable bias generation (voltage divider)
circuit.R('bias1', 'Vdd', 'Vbias', 100@u_kΩ)
circuit.R('bias2', 'Vbias', circuit.gnd, 100@u_kΩ)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
# --------------------------
# 3. STAGE 1: CS with Active Load
# --------------------------
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
# --------------------------
# 4. STAGE 2: CS with Resistor Load
# --------------------------
circuit.MOSFET('3', 'Vout_int', 'Drain1', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.R('1', 'Vout_int', 'Vdd', 10@u_kΩ)
# --------------------------
# 5. STAGE 3: Source Follower
# --------------------------
circuit.MOSFET('4', 'Vbias_sf', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)  # Current source
circuit.MOSFET('5', 'Vdd', 'Vout_int', 'Vout', 'Vout', 
               model='nmos_model', w=20e-6, l=0.045e-6)  # SF transistor
# --------------------------
# 6. DC ANALYSIS
# --------------------------
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
