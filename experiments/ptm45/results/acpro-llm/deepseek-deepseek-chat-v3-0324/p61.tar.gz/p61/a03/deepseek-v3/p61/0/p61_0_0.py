from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier with High GBW/Power')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input Bias (DC operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.42V
# Stage 1: Common-Source with Active Load (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with Resistor Load (M3, R1)
circuit.MOSFET('3', 'Vout_int', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.R('1', 'Vout_int', 'Vdd', 10@u_kΩ)
# Stage 3: Source Follower (M5, M4)
circuit.MOSFET('4', 'Vbias', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # Diode-connected PMOS
circuit.MOSFET('5', 'Vdd', 'Vout_int', 'Vout', 'Vout', model='nmos_model', w=20e-6, l=0.045e-6)  # Source Follower
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
