Vdd Vdd 0 1.2V
Rbias1 Vdd Vbias 100kOhm
Rbias2 Vbias 0 100kOhm
Vin Vin 0 0.42V
M1 Drain1 Vin 0 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain1 Vbias Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M3 Vout_int Drain1 0 0 nmos_model l=4.5e-08 w=1e-05
R1 Vout_int Vdd 10kOhm
M4 Vbias_sf Vbias Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M5 Vdd Vout_int Vout Vout nmos_model l=4.5e-08 w=2e-05
.model nmos_model nmos (GAMMA=0.3 KP=0.00015 LAMBDA=0.05 PHI=0.6 VTO=0.22)
.model pmos_model pmos (GAMMA=0.3 KP=5e-05 LAMBDA=0.05 PHI=0.6 VTO=-0.22)

