from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
# Input (single-ended for simplicity, with DC bias at 0.6V)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
# Tail Current
circuit.MOSFET('tail', 'tail_node', 'Vbias1', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
# Differential Pair
circuit.MOSFET('1', 'drain1', 'Vin', 'tail_node', 'tail_node',
              model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'drain2', 'Vcm', 'tail_node', 'tail_node',
              model='nmos_model', w=20e-6, l=0.045e-6)
# Common-mode voltage (0.6V)
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)
# Active Load (PMOS current mirror)
circuit.MOSFET('3', 'drain1', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'drain2', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('5', 'drain3', 'drain2', 'Vdd', 'Vdd',
              model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('6', 'drain3', 'Vbias2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Output Buffer
circuit.MOSFET('7', 'Vout', 'drain3', 'Vdd', 'Vdd',
              model='pmos_model', w=80e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'drain3', 'Vout', 2@u_pF)
circuit.R('c', 'drain3', 'comp_node', 2@u_kΩ)
circuit.C('c2', 'comp_node', 'Vout', 2@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
