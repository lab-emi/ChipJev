from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier (Parameterized)')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply and input voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Fixed input bias
    circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Fixed common-mode voltage
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")
    circuit.V('bias3', 'Vbias3', circuit.gnd, f"{params['vbias3']}V")
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('tail', 'tail_node', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_tail'], l=0.045e-6)
    # Differential Pair
    circuit.MOSFET('1', 'drain1', 'Vin', 'tail_node', 'tail_node',
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'drain2', 'Vcm', 'tail_node', 'tail_node',
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Active Load (PMOS current mirror)
    circuit.MOSFET('3', 'drain1', 'drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'drain2', 'drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier
    circuit.MOSFET('5', 'drain3', 'drain2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'drain3', 'Vbias3', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    # Stage 3: Output Buffer
    circuit.MOSFET('7', 'Vout', 'drain3', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M8'], l=0.045e-6)
    # Fixed compensation network (as per requirement to keep load caps fixed)
    circuit.C('c', 'drain3', 'Vout', 1@u_pF)
    circuit.R('c', 'drain3', 'comp_node', 1@u_kΩ)
    circuit.C('c2', 'comp_node', 'Vout', 1@u_pF)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W in meters, L fixed at 45nm)
    'w_tail': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M1':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M2':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M3':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M4':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M5':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M6':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M7':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M8':    {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    # Bias voltages (constrained around original values, never exceeding 1.2V)
    'vbias1': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth + 0.2V)
    'vbias2': {'min': 0.24, 'max': 0.36},  # Original: 0.30V (for PMOS activation)
    'vbias3': {'min': 0.72, 'max': 1.08},  # Original: 0.90V (output stage bias)
    # Compensation network (kept fixed as per requirements)
    # Note: If you want these parameterized later, add ranges like:
    # 'r_comp': {'min': 0.5, 'max': 2},      # Original: 1kΩ
    # 'c_comp1': {'min': 0.5, 'max': 5},     # Original: 1pF
    # 'c_comp2': {'min': 0.5, 'max': 5},     # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (W in meters)
    'w_tail': 10e-6,
    'w_M1':   20e-6,
    'w_M2':   20e-6,
    'w_M3':   10e-6,
    'w_M4':   10e-6,
    'w_M5':   40e-6,
    'w_M6':   20e-6,
    'w_M7':   80e-6,
    'w_M8':   40e-6,
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.30,
    'vbias3': 0.90,
    # Compensation network (if parameterized)
    # 'r_comp': 1,
    # 'c_comp1': 1,
    # 'c_comp2': 1,
}
