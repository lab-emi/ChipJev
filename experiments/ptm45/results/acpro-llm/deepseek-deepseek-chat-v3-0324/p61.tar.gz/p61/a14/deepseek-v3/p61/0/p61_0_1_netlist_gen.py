from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V as per specification)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
# For NMOS: Vgs > Vth (0.22V + overdrive)
# For PMOS: |Vgs| > |Vth|
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.44@u_V)  # Vth + 0.22V overdrive
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.44@u_V)  # Same for source follower
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Common-mode midpoint (Vdd/2)
circuit.V('in', 'Vin', 'Vcm', 0)  # Input signal referenced to Vcm
# First Stage - Differential Pair with Active Load
# Differential pair NMOS (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vin', 'SourcePair', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'SourcePair', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
# Active load PMOS (M3, M4) - current mirror
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
# Tail current source (M6)
circuit.MOSFET('6', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.18@u_um)
# Second Stage - Common Source with Miller Compensation
# Main amplifier transistor (M5)
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20@u_um, l=0.045@u_um)
# Miller compensation network (Rm and Cm)
# FIX: Changed u_fF to u_pF and added intermediate node
circuit.R('m', 'Drain2', 'NodeRm', 2@u_kΩ)
circuit.C('m', 'NodeRm', 'Drain5', 0.5@u_pF)  # 500fF = 0.5pF
# Third Stage - Source Follower
# Output transistor (M7)
circuit.MOSFET('7', 'Vout', 'Drain5', 'Source7', circuit.gnd, model='nmos_model', w=30@u_um, l=0.045@u_um)
# Current source for source follower (M8)
circuit.MOSFET('8', 'Source7', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
# Load resistor for simulation (not part of actual design)
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
