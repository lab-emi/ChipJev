from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Miller Compensation')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.44@u_V)  # Vth + 0.22V for proper overdrive
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.44@u_V)  # For source follower bias
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Common-mode voltage
circuit.V('in', 'Vin', 'Vcm', 0)  # AC input will be added later
# First Stage - Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vin', 'SourcePair', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'SourcePair', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.18@u_um)
# Second Stage - Common Source with Miller Compensation
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20@u_um, l=0.045@u_um)
circuit.C('m', 'Drain2', 'Drain5', 500@u_fF)
circuit.R('m', 'Drain2', 'NodeRm', 2@u_kΩ)
# Third Stage - Source Follower
circuit.MOSFET('7', 'Vout', 'Drain5', 'Source7', circuit.gnd, model='nmos_model', w=30@u_um, l=0.045@u_um)
circuit.MOSFET('8', 'Source7', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
# Load (for simulation purposes)
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
