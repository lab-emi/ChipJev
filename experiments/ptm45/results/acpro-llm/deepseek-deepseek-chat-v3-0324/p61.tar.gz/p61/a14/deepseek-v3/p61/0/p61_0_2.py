from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Improved Bias Voltages (Vth = 0.22V)
# 1. Increased tail current bias for proper first stage output swing
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5@u_V)  # Was 0.44V
# 2. New bias for second stage current source
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.7@u_V)  
# 3. Source follower bias now higher to ensure VGS > Vth
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.8@u_V)  # Was 0.44V
# Common-mode input voltage at optimal point
circuit.V('cm', 'Vcm', circuit.gnd, 0.65@u_V)  # Was 0.6V
circuit.V('in', 'Vin', 'Vcm', 0)  # Input signal referenced to Vcm
# First Stage - Differential Pair with Active Load (unchanged)
circuit.MOSFET('1', 'Drain1', 'Vin', 'SourcePair', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'SourcePair', circuit.gnd, model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5@u_um, l=0.18@u_um)
# Second Stage - Common Source with Active Load
# Changed to use PMOS current source instead of resistor
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('9', 'Drain5', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=15@u_um, l=0.045@u_um)  # New PMOS load
# Miller compensation network
circuit.R('m', 'Drain2', 'NodeRm', 2@u_kΩ)
circuit.C('m', 'NodeRm', 'Drain5', 0.5@u_pF)
# Third Stage - Source Follower with modified biasing
circuit.MOSFET('7', 'Vout', 'Drain5', 'Source7', circuit.gnd, model='nmos_model', w=30@u_um, l=0.045@u_um)
# Current source for source follower with higher bias
circuit.MOSFET('8', 'Source7', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=10@u_um, l=0.045@u_um)  # Increased width
# Load resistor for simulation
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
