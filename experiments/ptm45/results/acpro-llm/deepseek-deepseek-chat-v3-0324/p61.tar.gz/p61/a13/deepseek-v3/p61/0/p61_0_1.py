from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Amplifier with High GBW/Power')
# =============================================
# CRITICAL FIX: ADD MOSFET MODEL DEFINITIONS
# =============================================
# Define NMOS and PMOS models (45nm technology parameters)
circuit.model('nmos_model', 'nmos', 
              kp=200e-6, vto=0.22, lambda=0.1, gamma=0.3)
circuit.model('pmos_model', 'pmos', 
              kp=80e-6, vto=-0.22, lambda=0.1, gamma=0.3)
# =============================================
# Power Supply and Bias Voltages
# =============================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth_n + 0.2V overdrive
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth_p| - 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.64@u_V)  # Proper cascode bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.5@u_V)   # Intermediate bias
# =============================================
# Stage 1: Folded-Cascode (Fixed bulk connections)
# =============================================
circuit.MOSFET('1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Node1', 'Vbias1', 'Vdd', 'Vdd', 
              model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Node2', 'Vbias2', 'Node1', 'Node1',  # Fixed bulk connection
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Node2', 'Vbias3', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# =============================================
# Stage 2: Common-Source
# =============================================
circuit.MOSFET('5', 'Node3', 'Node2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20e-6, l=0.045e-6)
# =============================================
# Stage 3: Output Stage (Fixed resistor value)
# =============================================
circuit.MOSFET('6', 'Node4', 'Vbias3', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Node3', circuit.gnd, circuit.gnd,
              model='nmos_model', w=30e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 5@u_kΩ)
# =============================================
# Compensation Network (Fixed connection)
# =============================================
# Create an explicit node for compensation network
circuit.R('c', 'Node2', 'Node2_comp', 1@u_kΩ)
circuit.C('c', 'Node2_comp', 'Vout', 1@u_pF)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
