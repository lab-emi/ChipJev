from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage GBW-Optimized Amplifier')
# =============================================================================
# CRITICAL FIX: Proper MOSFET model definitions (using lamda instead of lambda)
# =============================================================================
circuit.model('nmos_model', 'nmos', 
              kp=200e-6, vto=0.22, lamda=0.1, gamma=0.3)  # Changed lambda->lamda
circuit.model('pmos_model', 'pmos', 
              kp=80e-6, vto=-0.22, lamda=0.1, gamma=0.3)  # Changed lambda->lamda
# =============================================================================
# Power Supplies and Biasing (Enhanced biasing network)
# =============================================================================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input bias: Vth + 0.2V overdrive (for 45nm)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  
# Improved bias voltages with proper scaling:
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.9@u_V)  # For PMOS current source
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.6@u_V)  # For NMOS cascode
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.3@u_V)  # For output stage
# =============================================================================
# Stage 1: Folded Cascode (Optimized for high gain)
# =============================================================================
# Input pair (NMOS)
circuit.MOSFET('1', 'Node1', 'Vin', circuit.gnd, circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)  # Increased width for gm
# PMOS current source load
circuit.MOSFET('2', 'Node1', 'Vbias1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)  # Wide for low ro
# NMOS cascode
circuit.MOSFET('3', 'Node2', 'Vbias2', 'Node1', 'Node1',  # Proper bulk conn
              model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS cascode current source
circuit.MOSFET('4', 'Node2', 'Vbias1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# =============================================================================
# Stage 2: Common Source (Gain stage)
# =============================================================================
circuit.MOSFET('5', 'Node3', 'Node2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=30e-6, l=0.045e-6)  # Large for high gain
# =============================================================================
# Stage 3: Output Stage (Class-AB for driving capability)
# =============================================================================
# PMOS current bias
circuit.MOSFET('6', 'Node4', 'Vbias3', 'Vdd', 'Vdd',
              model='pmos_model', w=15e-6, l=0.045e-6)
# NMOS output driver
circuit.MOSFET('7', 'Vout', 'Node3', circuit.gnd, circuit.gnd,
              model='nmos_model', w=50e-6, l=0.045e-6)  # Very wide for low Ron
# Load resistor (reduced from 5k to 2k for better drive)
circuit.R('1', 'Vout', 'Vdd', 2@u_kΩ)
# =============================================================================
# Compensation Network (Enhanced stability)
# =============================================================================
circuit.R('comp', 'Node2', 'Node2_comp', 2@u_kΩ)  # Increased for better phase margin
circuit.C('comp', 'Node2_comp', 'Vout', 2@u_pF)  # Doubled compensation cap
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
