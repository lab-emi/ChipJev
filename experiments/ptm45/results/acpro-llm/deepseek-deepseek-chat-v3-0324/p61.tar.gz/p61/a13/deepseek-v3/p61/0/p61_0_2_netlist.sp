Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias1 Vbias1 0 0.9V
Vbias2 Vbias2 0 0.6V
Vbias3 Vbias3 0 0.3V
M1 Node1 Vin 0 0 nmos_model l=4.5e-08 w=1e-05
M2 Node1 Vbias1 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M3 Node2 Vbias2 Node1 Node1 nmos_model l=4.5e-08 w=1e-05
M4 Node2 Vbias1 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M5 Node3 Node2 0 0 nmos_model l=4.5e-08 w=3e-05
M6 Node4 Vbias3 Vdd Vdd pmos_model l=4.5e-08 w=1.5e-05
M7 Vout Node3 0 0 nmos_model l=4.5e-08 w=5e-05
R1 Vout Vdd 2kOhm
Rcomp Node2 Node2_comp 2kOhm
Ccomp Node2_comp Vout 2pF
.model nmos_model nmos (gamma=0.3 kp=0.0002 lamda=0.1 vto=0.22)
.model pmos_model pmos (gamma=0.3 kp=8e-05 lamda=0.1 vto=-0.22)

