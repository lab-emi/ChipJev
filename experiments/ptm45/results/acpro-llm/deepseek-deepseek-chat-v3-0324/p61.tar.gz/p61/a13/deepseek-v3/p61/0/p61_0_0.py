from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier with High GBW/Power')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias (Vth + 0.2V overdrive)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth_n + 0.2 = 0.22 + 0.2
# Bias Voltages (calculated for proper operation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # Vdd - |Vth_p| - 0.2 = 1.2 - 0.22 - 0.2
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.64@u_V)  # Vth_n + Vov + Vov = 0.22 + 0.2 + 0.2
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.5@u_V)   # Intermediate bias
# First Stage: Folded-Cascode
circuit.MOSFET('1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Node1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Node2', 'Vbias2', 'Node1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Node2', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Second Stage: Common-Source
circuit.MOSFET('5', 'Node3', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Third Stage: Output with resistor load
circuit.MOSFET('6', 'Node4', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # Bias current
circuit.MOSFET('7', 'Vout', 'Node3', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 5@u_kΩ)
# Compensation Network
circuit.C('c', 'Node2', 'Vout', 1@u_pF)
circuit.R('c', 'Node2', 'Node2_comp', 1@u_kΩ)  # Connect Cc between Node2_comp and Vout
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
