from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Amplifier (GBW/Power Optimized)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias (DC operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # For M3 and M6
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.52@u_V)  # For M2
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # For M4
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # M1
circuit.MOSFET('2', 'Drain2', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # M2 (cascode)
circuit.MOSFET('3', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # M3 (cascode load)
circuit.MOSFET('4', 'Drain2', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # M4 (current source)
# Stage 2: Common-Source with Active Load
circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # M5
circuit.MOSFET('6', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # M6 (active load)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
