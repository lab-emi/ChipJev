from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Amplifier (GBW/Power Optimized)')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Bias (fixed, DC operating point)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['v_bias3']@u_V)
    # Stage 1: Telescopic Cascode with parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', 
                   w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', 
                   w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', 
                   w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', 
                   w=params['w_M4'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load
    circuit.MOSFET('5', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
                   w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', 
                   w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input transistor - affects gm
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode transistor - affects output impedance
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS cascode load - affects gain
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Current source - sets bias current
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Second stage driver - affects GBW
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load - affects gain
    # Bias voltages (0.8-1.2× original, not exceeding 1.2V)
    'v_bias1': {'min': 0.624, 'max': min(0.936, 1.2), 'log': False},  # Original: 0.78V
    'v_bias2': {'min': 0.416, 'max': min(0.624, 1.2), 'log': False},  # Original: 0.52V
    'v_bias3': {'min': 0.624, 'max': min(0.936, 1.2), 'log': False},  # Original: 0.78V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_M1': 5e-6,     # M1 width (5um)
    'w_M2': 5e-6,     # M2 width (5um)
    'w_M3': 10e-6,    # M3 width (10um)
    'w_M4': 10e-6,    # M4 width (10um)
    'w_M5': 10e-6,    # M5 width (10um)
    'w_M6': 10e-6,    # M6 width (10um)
    # Bias voltages (original values)
    'v_bias1': 0.78,  # Vbias1 (0.78V)
    'v_bias2': 0.52,  # Vbias2 (0.52V)
    'v_bias3': 0.78,  # Vbias3 (0.78V)
}
