from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Define the circuit
circuit = Circuit('Multi-Stage GBW/Power-Optimized Amplifier')
# --- Define MOSFET Models (45nm technology) ---
# NMOS model (Vth = 0.22V, KP ~120uA/V², lambda ~0.1/V)
circuit.model(
    'nmos_model', 'nmos',
    VTO=0.22,      # Threshold voltage
    KP=120e-6,     # Transconductance parameter
    LAMBDA=0.1,    # Channel-length modulation
    GAMMA=0.45,    # Body effect parameter
    PHI=0.9,       # Surface potential
    TOX=1.2e-9,    # Oxide thickness (1.2nm)
)
# PMOS model (Vth = -0.22V, KP ~40uA/V², lambda ~0.1/V)
circuit.model(
    'pmos_model', 'pmos',
    VTO=-0.22,     # Threshold voltage
    KP=40e-6,      # Transconductance parameter
    LAMBDA=0.1,    # Channel-length modulation
    GAMMA=0.45,    # Body effect parameter
    PHI=0.9,       # Surface potential
    TOX=1.2e-9,    # Oxide thickness (1.2nm)
)
# --- Power Supply (1.2V) ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# --- Input Bias (Vth + 0.2V = 0.42V) ---
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
# --- Bias Voltages ---
# Vbias1 (NMOS cascode): 0.42V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)
# Vbias2 (PMOS load): Vdd - |Vth| - 0.2V = 0.78V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)
# Vbias3 (NMOS current source): 0.42V
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)
# --- Stage 1: Telescopic Cascode (High Gain) ---
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('9', 'Drain1', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# --- Stage 2: Common-Source (Moderate Gain) ---
circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('8', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# --- Stage 3: Source Follower (Buffer) ---
circuit.MOSFET('4', 'Vdd', 'Drain3', 'Vout', 'Vout', model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# --- Simulate ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
