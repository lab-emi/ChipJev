Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias1 Vbias1 0 0.42V
Vbias2 Vbias2 0 0.78V
Vbias3 Vbias3 0 0.42V
M1 Drain1 Vin 0 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain2 Vbias1 Drain1 0 nmos_model l=4.5e-08 w=5e-06
M7 Drain2 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M9 Drain1 Vbias3 0 0 nmos_model l=4.5e-08 w=5e-06
M3 Drain3 Drain2 0 0 nmos_model l=4.5e-08 w=1e-05
M8 Drain3 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M4 Vdd Drain3 Vout Vout nmos_model l=4.5e-08 w=2e-05
M5 Vout Vbias3 0 0 nmos_model l=4.5e-08 w=1e-05
.model nmos_model nmos (GAMMA=0.45 KP=0.00012 LAMBDA=0.1 PHI=0.9 TOX=1.2e-09 VTO=0.22)
.model pmos_model pmos (GAMMA=0.45 KP=4e-05 LAMBDA=0.1 PHI=0.9 TOX=1.2e-09 VTO=-0.22)

