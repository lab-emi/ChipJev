from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Multi-Stage GBW/Power-Optimized Amplifier')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias (DC operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Mid-rail bias
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS loads
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # NMOS current sources
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('9', 'Drain1', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('8', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 3: Source Follower
circuit.MOSFET('4', 'Vdd', 'Drain3', 'Vout', 'Vout', model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Vout', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Bias Resistor (optional, for stability)
circuit.R('1', 'Vbias1', 'Vdd', 10@u_kΩ)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
