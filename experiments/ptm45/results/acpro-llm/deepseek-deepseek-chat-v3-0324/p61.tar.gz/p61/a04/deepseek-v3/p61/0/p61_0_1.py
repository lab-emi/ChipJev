from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
nmos_params = { 'VTO': 0.22, 'KP': 120e-6, ... }
pmos_params = { 'VTO': -0.22, 'KP': 40e-6, ... }

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
