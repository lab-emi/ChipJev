Vdd Vdd 0 1.2V
Vbias1 Vbias1 0 0.6V
Vbias2 Vbias2 0 0.7V
Vin Vin 0 0.65V
M1 Drain1 Vin Source1 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain2 Vcm Source1 0 nmos_model l=4.5e-08 w=5e-06
M3 Drain1 Drain1 0 0 nmos_model l=4.5e-08 w=5e-06
M4 Drain2 Drain1 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M5 Source1 Vbias1 0 0 nmos_model l=4.5e-08 w=2e-06
M6 Vout_int Drain2 Vdd Vdd pmos_model l=4.5e-08 w=1.5e-05
M7 Vout_int Vbias2 0 0 nmos_model l=4.5e-08 w=7e-06
M8 Vdd Vout_int Vout Vdd pmos_model l=4.5e-08 w=3e-05
Vcm Vcm 0 0.65V
Cc Drain2 Vout_int 0.3pF
.model nmos_model nmos (KP=0.0002 LAMBDA=0.1 LEVEL=1 VTO=0.22)
.model pmos_model pmos (KP=0.0001 LAMBDA=0.1 LEVEL=1 VTO=-0.22)

