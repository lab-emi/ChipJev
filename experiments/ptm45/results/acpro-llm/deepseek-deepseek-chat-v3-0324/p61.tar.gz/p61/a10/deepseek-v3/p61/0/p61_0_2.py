from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with High FoM')
# 1. FIXED MODEL DEFINITION SYNTAX - Using PySpice's proper parameter names
# BSIM4 model parameters for 45nm technology
circuit.model('nmos_model', 'nmos', 
              VTO=0.22,   # Threshold voltage
              KP=200e-6,  # Transconductance parameter
              LAMBDA=0.1, # Channel length modulation
              LEVEL=1     # MOSFET model level
             )
circuit.model('pmos_model', 'pmos',
              VTO=-0.22,
              KP=100e-6,
              LAMBDA=0.1,
              LEVEL=1
             )
# 2. POWER SUPPLY DEFINITION
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# 3. BIAS VOLTAGES - Using proper DC operating points
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.6@u_V)  # Adjusted for better operation
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7@u_V)  # Adjusted for better current source operation
# 4. INPUT CONFIGURATION - Single-ended with mid-rail bias
circuit.V('in', 'Vin', circuit.gnd, 0.65@u_V)  # Slightly above mid-rail for NMOS pair
# FIRST STAGE: Differential pair with current mirror load
# 5. PROPER DIFFERENTIAL PAIR CONNECTIONS
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# 6. DIODE-CONNECTED LOAD - Proper implementation
circuit.MOSFET('3', 'Drain1', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# 7. CURRENT MIRROR LOAD
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# 8. TAIL CURRENT SOURCE
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# SECOND STAGE: Common-source with active load
# 9. PROPER GAIN STAGE CONNECTIONS
circuit.MOSFET('6', 'Vout_int', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout_int', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=7e-6, l=0.045e-6)
# THIRD STAGE: Source follower (output buffer)
# 10. OUTPUT BUFFER WITH PROPER DRIVING CAPABILITY
circuit.MOSFET('8', 'Vdd', 'Vout_int', 'Vout', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# COMMON-MODE VOLTAGE - Critical for differential operation
# 11. PROPER COMMON-MODE REFERENCE
circuit.V('cm', 'Vcm', circuit.gnd, 0.65@u_V)  # Matches input bias
# MILLER COMPENSATION - Stability improvement
# 12. REALISTIC COMPENSATION CAPACITOR VALUE
circuit.C('c', 'Drain2', 'Vout_int', 0.3@u_pF)  # Optimized for 45nm
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
