from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with High FoM')
# 1. FIRST CRITICAL FIX: Properly define MOSFET models before using them
# Using the imported parameters to create proper model definitions
# Note: Normally these would come from the model import, but we'll define them explicitly here
circuit.model('nmos_model', 'nmos', level=1, kp=200e-6, vto=0.22, lambda=0.1)
circuit.model('pmos_model', 'pmos', level=1, kp=100e-6, vto=-0.22, lambda=0.1)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.22 + 0.2
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2 = 1.2 - 0.22 - 0.2
# 2. FIXED INPUT CONFIGURATION:
# Using single-ended input with proper biasing
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Mid-rail for proper operation
# First Stage: Differential Pair with Current Mirror Load
# 3. FIXED TRANSISTOR CONNECTIONS:
# M3 should be diode-connected properly (gate-drain shorted)
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vcm', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Current mirror
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # Tail current
# Second Stage: Common-Source with Active Load
# 4. FIXED OUTPUT NODE NAME CONSISTENCY:
circuit.MOSFET('6', 'Vout_int', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout_int', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
# Third Stage: Source Follower (Output Buffer)
# 5. FIXED BUFFER CONNECTIONS:
circuit.MOSFET('8', 'Vdd', 'Vout_int', 'Vout', 'Vdd', model='pmos_model', w=50e-6, l=0.045e-6)
# Common-mode voltage (for differential input)
# 6. ADDED PROPER COMMON-MODE VOLTAGE:
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)
# Miller Compensation
# 7. ADJUSTED COMPENSATION CAPACITOR VALUE:
circuit.C('c', 'Drain2', 'Vout_int', 0.5@u_pF)  # More realistic value
# Bias Resistor (for current mirror)
# 8. REMOVED UNNECESSARY RESISTOR (was causing DC path issues)
# circuit.R('1', 'Drain1', 'Vdd', 10@u_kΩ)  # Commented out as not needed
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
