from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V assumed)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS current source bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.68@u_V)  # PMOS cascode load bias
# Input Signal (DC operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain4', 'Vbias3', 'Drain3', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source (Modified sizing)
circuit.MOSFET('5', 'Drain5', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
# Stage 3: Source Follower with pull-down
circuit.MOSFET('7', 'Vdd', 'Drain5', 'Vout', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
circuit.R('1', 'Vout', circuit.gnd, 10@u_kΩ)  # Ensures Vout < V(Drain5) - Vth
# Compensation Capacitor
circuit.C('c', 'Drain5', 'Drain3', 1@u_pF)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
