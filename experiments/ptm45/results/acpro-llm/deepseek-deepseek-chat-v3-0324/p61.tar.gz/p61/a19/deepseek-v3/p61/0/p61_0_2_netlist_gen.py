from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)   # M1 bias (Vth + 0.23V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.85@u_V)   # M3 cascode bias (0.45V + 0.4V margin)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)   # M6 tail current (Vth + 0.2V)
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.35@u_V)   # M7 PMOS load (Vdd - Vth - 0.65V)
# Input Signal (DC bias)
circuit.V('in', 'Vin', circuit.gnd, 0.45@u_V)
# First Stage (Input CS + Active Load)
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Source1', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage (Cascode) - Now properly biased
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Third Stage (Output with PMOS load)
circuit.MOSFET('5', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias4', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
# Compensation Capacitor
circuit.C('c', 'Drain1', 'Vout', 1@u_pF)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
