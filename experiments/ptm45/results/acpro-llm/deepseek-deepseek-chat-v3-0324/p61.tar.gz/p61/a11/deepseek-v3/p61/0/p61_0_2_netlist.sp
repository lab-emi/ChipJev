Vdd Vdd 0 1.2V
Vbias1 Vbias1 0 0.78V
Vbias2 Vbias2 0 0.42V
Vbias3 Vbias3 0 0.68V
Rbias Vbias1 Vdd 10kOhm
Vin Vin 0 0.42V
M1 Drain1 Vin 0 0 nmos_model l=0.045um w=5um
M3 Drain3 Vbias2 Drain1 Drain1 nmos_model l=0.045um w=5um
M2 Drain3 Vbias1 Vdd Vdd pmos_model l=0.045um w=10um
M5 Drain5 Drain3 0 0 nmos_model l=0.045um w=10um
M4 Drain5 Vbias1 Vdd Vdd pmos_model l=0.045um w=20um
M7 Vdd Drain5 Vout Vout nmos_model l=0.045um w=50um
M6 Vout Vbias3 Vdd Vdd pmos_model l=0.045um w=20um
.model nmos_model nmos (gamma=0.25 kp=0.00018 lambd=0.05 level=54 tox=1.2e-09 vto=0.22)
.model pmos_model pmos (gamma=0.3 kp=6e-05 lambd=0.07 level=54 tox=1.2e-09 vto=-0.22)

