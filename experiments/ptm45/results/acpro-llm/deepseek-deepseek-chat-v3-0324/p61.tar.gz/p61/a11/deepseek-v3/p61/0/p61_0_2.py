from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage GBW/Power Optimized Amplifier')
# MODIFICATION 1: Replace 'lambda' with 'lambd' to avoid Python keyword conflict
# Using BSIM4 models which are standard for 45nm technology
circuit.model('nmos_model', 'nmos', 
              level=54,        # BSIM4
              vto=0.22,       # Threshold voltage
              kp=180e-6,      # Transconductance parameter
              gamma=0.25,     # Body effect parameter
              lambd=0.05,     # Channel length modulation (renamed from lambda)
              tox=1.2e-9)     # Oxide thickness
circuit.model('pmos_model', 'pmos',
              level=54,
              vto=-0.22,
              kp=60e-6,
              gamma=0.3,
              lambd=0.07,     # Channel length modulation (renamed from lambda)
              tox=1.2e-9)
# Power Supply (unchanged)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (unchanged)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.68@u_V)
circuit.R('bias', 'Vbias1', 'Vdd', 10@u_kΩ)
# Input Signal (unchanged)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
# MODIFICATION 2: Added bulk connections to prevent floating nodes
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Drain1', 'Drain1',  # Bulk connected to source
               model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain3', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# Stage 2: Common Source
circuit.MOSFET('5', 'Drain5', 'Drain3', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain5', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# Stage 3: Source Follower
circuit.MOSFET('7', 'Vdd', 'Drain5', 'Vout', 'Vout',
               model='nmos_model', w=50@u_um, l=0.045@u_um)
circuit.MOSFET('6', 'Vout', 'Vbias3', 'Vdd', 'Vdd',
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
