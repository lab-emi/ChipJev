from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier (Parameterized)')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")  # PMOS bias (Stage 1)
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")  # PMOS bias (Stage 2)
    # Input voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
    # Stage 1: Common-Source with Current Source Load
    circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    # Stage 2: Common-Source with Current Source Load
    circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Stage 3: Source Follower with Load Resistor
    circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd,
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.R('1', 'Vout', circuit.gnd, f"{params['r_load']}k")  # Load resistor
    # Compensation Capacitor
    circuit.C('c', 'Drain1', 'Drain2', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5μm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 1 NMOS width
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 1 PMOS width
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 2 NMOS width
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Stage 2 PMOS width
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Source follower NMOS width
    # Bias voltages (0.8-1.2× original, not exceeding 1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936},  # Stage 1 PMOS bias (original 0.78V)
    'vbias2': {'min': 0.56, 'max': 0.84},    # Stage 2 PMOS bias (original 0.7V)
    # Passive components
    'r_load': {'min': 5, 'max': 20, 'log': True},  # Load resistor (0.5-2× original 10kΩ)
    'c_comp': {'min': 1, 'max': 10, 'log': True},  # Compensation cap (0.5-5× original 2pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,
    'w_M2': 10e-6,
    'w_M3': 15e-6,
    'w_M4': 15e-6,
    'w_M5': 20e-6,
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.7,
    # Passive components
    'r_load': 10,
    'c_comp': 2,
}
