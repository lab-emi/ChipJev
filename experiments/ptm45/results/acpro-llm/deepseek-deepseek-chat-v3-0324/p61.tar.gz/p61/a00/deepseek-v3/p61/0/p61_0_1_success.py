from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (adjusted Vbias2 to 0.7V for proper Drain2 voltage)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # PMOS bias (Stage 1)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7@u_V)   # PMOS bias (Stage 2 - lowered)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)        # Input bias (Vth + 0.2V)
# Stage 1: Common-Source with Current Source Load
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain1', 'Vbias1', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source with Current Source Load (adjusted sizing)
circuit.MOSFET('3', 'Drain2', 'Drain1', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=15e-6, l=0.045e-6)  # Wider for higher gain
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
               model='pmos_model', w=15e-6, l=0.045e-6)  # Narrower to reduce current
# Stage 3: Source Follower with Load Resistor (ensures V_GS > Vth)
circuit.MOSFET('5', 'Vdd', 'Drain2', 'Vout', circuit.gnd, 
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', circuit.gnd, 10@u_kΩ)  # Establishes DC operating point
# Compensation Capacitor
circuit.C('c', 'Drain1', 'Drain2', 2@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
