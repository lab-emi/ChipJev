Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.42V
M1 Drain1 Vin Source1 0 nmos_model l=45nm w=5um
M2 Drain2 0 Source1 0 nmos_model l=45nm w=5um
M3 Drain1 Drain1 Vdd Vdd pmos_model l=45nm w=10um
M4 Drain2 Drain1 Vdd Vdd pmos_model l=45nm w=10um
M6 Source1 Vbias 0 0 nmos_model l=45nm w=10um
M5 Drain5 Drain2 0 0 nmos_model l=45nm w=15um
M9 Drain5 Vbias_CS Vdd Vdd pmos_model l=45nm w=20um
Vbias_cs Vbias_CS 0 0.8V
M7 Vout Drain5 0 0 nmos_model l=45nm w=30um
Cc Drain5 Drain2 1pF
.model nmos_model nmos (GAMMA=0.3 KP=0.0002 LAMBDA=0.1 PHI=0.9 TOX=1.1e-08 VTO=0.22)
.model pmos_model pmos (GAMMA=0.3 KP=0.0001 LAMBDA=0.2 PHI=0.9 TOX=1.1e-08 VTO=-0.22)

