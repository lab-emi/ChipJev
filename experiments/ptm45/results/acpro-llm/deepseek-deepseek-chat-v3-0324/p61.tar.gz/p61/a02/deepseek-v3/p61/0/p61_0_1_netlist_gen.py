from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage Amplifier')
# Define MOSFET models (45nm typical parameters)
circuit.model('nmos_model', 'nmos', 
              VTO=0.22, KP=200e-6, GAMMA=0.3, 
              PHI=0.9, LAMBDA=0.1, TOX=1.1e-8)
circuit.model('pmos_model', 'pmos', 
              VTO=-0.22, KP=100e-6, GAMMA=0.3,
              PHI=0.9, LAMBDA=0.2, TOX=1.1e-8)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias (Vth + 200mV overdrive)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # NMOS: 0.22V + 0.2V
# Bias for Tail Current (Vth + 200mV)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
# Stage 1: Differential Pair with Active Load
# NMOS differential pair
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', 
               w=5@u_um, l=45@u_nm)
circuit.MOSFET('2', 'Drain2', circuit.gnd, 'Source1', circuit.gnd, model='nmos_model', 
               w=5@u_um, l=45@u_nm)
# PMOS active load (current mirror)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=10@u_um, l=45@u_nm)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
               w=10@u_um, l=45@u_nm)
# Tail Current Source
circuit.MOSFET('6', 'Source1', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=10@u_um, l=45@u_nm)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=15@u_um, l=45@u_nm)  # Wider for higher gain
circuit.MOSFET('9', 'Drain5', 'Vbias_CS', 'Vdd', 'Vdd', model='pmos_model', 
               w=20@u_um, l=45@u_nm)  # Current source load
# Bias for CS stage current source
circuit.V('bias_cs', 'Vbias_CS', circuit.gnd, 0.8@u_V)  # Vdd - |Vth| - 200mV
# Stage 3: Output Buffer
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', 
               w=30@u_um, l=45@u_nm)  # Large for drive capability
# Miller Compensation (Cc between stage2 output and stage1 output)
circuit.C('c', 'Drain5', 'Drain2', 1@u_pF)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
