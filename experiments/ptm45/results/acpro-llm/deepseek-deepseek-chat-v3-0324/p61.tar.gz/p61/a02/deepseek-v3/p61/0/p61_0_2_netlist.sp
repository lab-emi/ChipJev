Vdd Vdd 0 1.2V
R1 Vdd Vmid 100kOhm
R2 Vmid 0 100kOhm
Vin Vin Vmid 0V
Vbias Vbias 0 0.52V
M1 Drain1 Vin Source1 0 nmos_model l=45nm w=5um
M2 Drain2 Vmid Source1 0 nmos_model l=45nm w=5um
M3 Drain1 Drain1 Vdd Vdd pmos_model l=45nm w=10um
M4 Drain2 Drain1 Vdd Vdd pmos_model l=45nm w=10um
M6 Source1 Vbias 0 0 nmos_model l=45nm w=15um
M5 Drain5 Drain2 0 0 nmos_model l=45nm w=15um
Vbias_cs Vbias_CS 0 0.7V
M9 Drain5 Vbias_CS Vdd Vdd pmos_model l=45nm w=20um
M7 Vout Drain5 0 0 nmos_model l=45nm w=30um
Rload Vout Vdd 10kOhm
Cc Drain5 Drain2 2pF
.model nmos_model nmos (GAMMA=0.3 KP=0.0002 LAMBDA=0.1 PHI=0.9 TOX=1.1e-08 VTO=0.22)
.model pmos_model pmos (GAMMA=0.3 KP=0.0001 LAMBDA=0.2 PHI=0.9 TOX=1.1e-08 VTO=-0.22)

