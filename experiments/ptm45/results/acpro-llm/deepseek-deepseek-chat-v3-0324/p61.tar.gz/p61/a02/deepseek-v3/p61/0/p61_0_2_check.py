from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Three-Stage Amplifier (Corrected)')
# Define MOSFET models (45nm typical parameters)
circuit.model('nmos_model', 'nmos', 
              VTO=0.22, KP=200e-6, GAMMA=0.3,
              PHI=0.9, LAMBDA=0.1, TOX=1.1e-8)
circuit.model('pmos_model', 'pmos',
              VTO=-0.22, KP=100e-6, GAMMA=0.3,
              PHI=0.9, LAMBDA=0.2, TOX=1.1e-8)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Bias Network (resistive divider for proper DC biasing)
circuit.R('1', 'Vdd', 'Vmid', 100@u_kΩ)
circuit.R('2', 'Vmid', circuit.gnd, 100@u_kΩ)
circuit.V('in', 'Vin', 'Vmid', "dc 0@u_V ac 1n")
# Bias for Tail Current (Vth + 300mV overdrive)
circuit.V('bias', 'Vbias', circuit.gnd, 0.52@u_V)  # 0.22V + 0.3V
# Stage 1: Differential Pair with Active Load
# NMOS differential pair
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd,
              model='nmos_model', w=5@u_um, l=45@u_nm)
circuit.MOSFET('2', 'Drain2', 'Vmid', 'Source1', circuit.gnd,
              model='nmos_model', w=5@u_um, l=45@u_nm)
# PMOS active load (current mirror)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=10@u_um, l=45@u_nm)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=10@u_um, l=45@u_nm)
# Tail Current Source (wider for better matching)
circuit.MOSFET('6', 'Source1', 'Vbias', circuit.gnd, circuit.gnd,
              model='nmos_model', w=15@u_um, l=45@u_nm)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd,
              model='nmos_model', w=15@u_um, l=45@u_nm)
# Current source load with proper biasing
circuit.V('bias_cs', 'Vbias_CS', circuit.gnd, 0.7@u_V)  # Vdd - |Vth| - 0.3V
circuit.MOSFET('9', 'Drain5', 'Vbias_CS', 'Vdd', 'Vdd',
              model='pmos_model', w=20@u_um, l=45@u_nm)
# Stage 3: Output Buffer with load resistor
circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd,
              model='nmos_model', w=30@u_um, l=45@u_nm)
circuit.R('load', 'Vout', 'Vdd', 10@u_kΩ)  # Establish DC operating point
# Miller Compensation
circuit.C('c', 'Drain5', 'Drain2', 2@u_pF)  # Increased for better stability
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)