Here's the parameterized version of your three-stage amplifier circuit according to your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with High FoM')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input and Bias Voltages (all DC)
    circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Input at mid-rail (fixed)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # Vth + 0.2V for NMOS cascode
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # Vdd - |Vth| - 0.2V for PMOS
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)  # Vth + 0.2V for NMOS current source
    
    # Stage 1: Telescopic Cascode
    circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Drain1', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('4', 'Source1', 'Vbias3', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Stage 2: Common-Source
    circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain3', 'Vbias3', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M7'], l=0.045e-6)
    
    # Stage 3: Output Stage
    circuit.MOSFET('6', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M8'], l=0.045e-6)
    
    # Compensation Network
    circuit.C('c', 'Drain3', 'Drain2', params['c_comp']@u_pF)  # Miller capacitor
    circuit.R('c', 'Drain3', 'NodeX', params['r_comp']@u_kΩ)   # Resistor for zero cancellation
    circuit.C('c2', 'NodeX', 'Drain2', params['c_comp2']@u_pF)  # Second part of split compensation
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500×L where L=45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair transistor
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS cascode
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Second stage NMOS
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS current source
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output stage NMOS
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Second stage PMOS
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output stage PMOS
    
    # Bias voltages (0.8-1.2× original but ≤1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504, 'log': False},  # Original 0.42V (Vth+0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936, 'log': False},  # Original 0.78V (Vdd-|Vth|-0.2V)
    'vbias3': {'min': 0.336, 'max': 0.504, 'log': False},  # Original 0.42V (Vth+0.2V)
    
    # Compensation network components
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},   # Miller cap (original 1pF)
    'r_comp': {'min': 0.5, 'max': 2.0, 'log': True},   # Zero cancellation resistor (original 1kΩ)
    'c_comp2': {'min': 0.5, 'max': 5.0, 'log': True},  # Split compensation cap (original 1pF)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (um)
    'w_M1': 5e-6,
    'w_M2': 5e-6,
    'w_M3': 10e-6,
    'w_M4': 2.5e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
    'w_M7': 20e-6,
    'w_M8': 10e-6,
    
    # Bias voltages (V)
    'vbias1': 0.42,
    'vbias2': 0.78,
    'vbias3': 0.42,
    
    # Compensation network
    'c_comp': 1.0,     # pF
    'r_comp': 1.0,     # kΩ
    'c_comp2': 1.0,    # pF
}
```

### Parameter Descriptions:

1. **Transistor Widths (w_Mx)**:
   - These control the current drive capability and transconductance of each transistor in the amplifier stages
   - The range (45nm to 22.5μm) ensures devices stay in practical W/L ratios (1-500×)
   - Logarithmic scale helps explore large dynamic range efficiently

2. **Bias Voltages (vbiasx)**:
   - Critical for proper biasing of the cascode and current source transistors
   - Conservative ranges (±20% from original) maintain intended operating regions
   - vbias1 and vbias3 relate to NMOS thresholds (Vth + 0.2V)
   - vbias2 relates to PMOS thresholds (Vdd - |Vth| - 0.2V)

3. **Compensation Network**:
   - c_comp: Miller capacitor for dominant pole compensation (affects bandwidth)
   - r_comp: Resistor for zero cancellation (affects phase margin)
   - c_comp2: Second capacitor for split compensation (improves stability)

The parameter ranges ensure:
- All voltages stay ≤1.2V supply
- Transistors remain in practical W/L ratios
- Bias points stay close to intended operating regions
- Compensation components can vary sufficiently to explore stability/performance tradeoffs

All initial parameter values are within their respective search ranges and match exactly the original circuit values.