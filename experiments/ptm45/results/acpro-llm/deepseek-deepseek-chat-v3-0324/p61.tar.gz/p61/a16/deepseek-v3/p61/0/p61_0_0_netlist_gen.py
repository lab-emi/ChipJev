from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with High FoM')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input and Bias Voltages (all DC)
circuit.V('in', 'Vin', circuit.gnd, 0.6@u_V)  # Input at mid-rail
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Vth + 0.2V for NMOS cascode
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V for PMOS
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Vth + 0.2V for NMOS current source
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('5', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Source1', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=2.5e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('3', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain3', 'Vbias3', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Output Stage
circuit.MOSFET('6', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain3', 'Drain2', 1@u_pF)  # Miller capacitor
circuit.R('c', 'Drain3', 'NodeX', 1@u_kΩ)   # Resistor for zero cancellation
circuit.C('c2', 'NodeX', 'Drain2', 1@u_pF)  # Second part of split compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
