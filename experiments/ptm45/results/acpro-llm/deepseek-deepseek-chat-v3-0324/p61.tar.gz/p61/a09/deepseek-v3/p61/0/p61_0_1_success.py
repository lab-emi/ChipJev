from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Signal (DC operating point only)
circuit.V('in', 'Vin', circuit.gnd, 0.45@u_V)  # Set slightly above Vth for proper operation
# Bias Voltages (carefully tuned for saturation)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # PMOS current sources
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.45@u_V)  # NMOS input pair
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.65@u_V)  # NMOS cascode
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.55@u_V)  # PMOS cascode
circuit.V('bias5', 'Vbias5', circuit.gnd, 0.42@u_V)  # Tail current source
# Current Sources for proper biasing
circuit.MOSFET('tail', 'Source1', 'Vbias5', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 1: Properly Biased Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', 'Source1', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Stage1_Out', 'Vbias3', 'Drain1', 'Drain1', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Stage1_Out', 'Vbias4', 'Drain2', 'Drain2', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source with Proper VDS
circuit.MOSFET('5', 'Stage2_Out', 'Stage1_Out', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Stage2_Out', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Stage 3: Source Follower with Proper Biasing
circuit.MOSFET('7', 'Vdd', 'Stage2_Out', 'Vout', 'Vout', model='nmos_model', w=100e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias5', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
