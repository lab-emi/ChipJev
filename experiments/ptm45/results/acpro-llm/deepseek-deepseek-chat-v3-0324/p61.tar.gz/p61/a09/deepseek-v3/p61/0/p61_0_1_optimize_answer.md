Here's the parameterized version of your three-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Three-Stage Amplifier with Proper Biasing')
    
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Signal (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.45@u_V)
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3']@u_V)
    circuit.V('bias4', 'Vbias4', circuit.gnd, params['vbias4']@u_V)
    circuit.V('bias5', 'Vbias5', circuit.gnd, params['vbias5']@u_V)
    
    # Current Sources (parameterized W, fixed L)
    circuit.MOSFET('tail', 'Source1', 'Vbias5', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_tail'], l=0.045e-6)
    
    # Stage 1: Telescopic Cascode (parameterized W, fixed L)
    circuit.MOSFET('1', 'Drain1', 'Vin', 'Source1', 'Source1', 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('3', 'Stage1_Out', 'Vbias3', 'Drain1', 'Drain1', 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('4', 'Stage1_Out', 'Vbias4', 'Drain2', 'Drain2', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Stage 2: Common-Source (parameterized W, fixed L)
    circuit.MOSFET('5', 'Stage2_Out', 'Stage1_Out', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Stage2_Out', 'Vbias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    
    # Stage 3: Source Follower (parameterized W, fixed L)
    circuit.MOSFET('7', 'Vdd', 'Stage2_Out', 'Vout', 'Vout', 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias5', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M8'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original values, constrained by Vdd=1.2V)
    'vbias1': {'min': 0.624, 'max': 0.936, 'log': False},  # Original: 0.78V (PMOS current sources)
    'vbias2': {'min': 0.36, 'max': 0.54, 'log': False},    # Original: 0.45V (NMOS input pair)
    'vbias3': {'min': 0.52, 'max': 0.78, 'log': False},    # Original: 0.65V (NMOS cascode)
    'vbias4': {'min': 0.44, 'max': 0.66, 'log': False},    # Original: 0.55V (PMOS cascode)
    'vbias5': {'min': 0.336, 'max': 0.504, 'log': False},  # Original: 0.42V (Tail current source)
    
    # Transistor widths (1-500× length, where L=45nm)
    'w_tail': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 10e-6
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 10e-6
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 20e-6
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 20e-6
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 20e-6
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 40e-6
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 100e-6
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},    # Original: 40e-6
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.78,
    'vbias2': 0.45,
    'vbias3': 0.65,
    'vbias4': 0.55,
    'vbias5': 0.42,
    
    # Transistor widths
    'w_tail': 5e-6,
    'w_M1': 10e-6,
    'w_M3': 10e-6,
    'w_M2': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
    'w_M6': 40e-6,
    'w_M7': 100e-6,
    'w_M8': 40e-6,
}

# Parameter descriptions (for documentation)
param_descriptions = {
    'vbias1': "Bias voltage for PMOS current sources (Stage 1 load)",
    'vbias2': "Bias voltage for NMOS input differential pair",
    'vbias3': "Bias voltage for NMOS cascode devices",
    'vbias4': "Bias voltage for PMOS cascode devices",
    'vbias5': "Bias voltage for tail current source",
    'w_tail': "Width of tail current source transistor",
    'w_M1': "Width of input NMOS transistor",
    'w_M3': "Width of NMOS cascode transistor (Stage 1)",
    'w_M2': "Width of PMOS current source (Stage 1 load)",
    'w_M4': "Width of PMOS cascode transistor (Stage 1)",
    'w_M5': "Width of NMOS transistor (Stage 2 common-source)",
    'w_M6': "Width of PMOS current source (Stage 2 load)",
    'w_M7': "Width of NMOS source follower (Stage 3)",
    'w_M8': "Width of NMOS current source (Stage 3 load)",
}
```

Key aspects of this parameterization:

1. **Voltage Sources**: All bias voltages are parameterized with conservative ranges (0.8-1.2× original values) to maintain proper operating points while allowing optimization.

2. **Transistor Sizing**: Only widths are parameterized (with lengths fixed at 45nm). The width ranges allow 1-500× the minimum length (0.045µm to 22.5µm).

3. **Initial Values**: The `initial_params` dictionary contains exactly the original values from your circuit.

4. **Physical Constraints**: All bias voltages are constrained to stay below the 1.2V supply voltage, and transistor sizes maintain reasonable aspect ratios.

5. **Structure**: The circuit topology remains unchanged - only numerical values are parameterized.

The parameter descriptions provide documentation about the role of each parameter in the circuit, which can be helpful for optimization analysis.