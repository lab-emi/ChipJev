from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Amplifier GBW/Power Optimized')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Signal (DC operating point only)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Set at Vth + 0.2V for operating point
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78@u_V)  # For PMOS current sources
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # For NMOS cascode
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.78@u_V)  # For PMOS cascode
circuit.V('bias4', 'Vbias4', circuit.gnd, 0.42@u_V)  # For output current sink
# Stage 1: Telescopic Cascode
circuit.MOSFET('1', 'Drain1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain3', 'Vbias2', 'Drain1', 'Drain1', model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Stage1_Out', 'Vbias3', 'Drain2', 'Drain2', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source
circuit.MOSFET('5', 'Stage2_Out', 'Stage1_Out', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('6', 'Stage2_Out', 'Vbias1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Source Follower
circuit.MOSFET('7', 'Vdd', 'Stage2_Out', 'Vout', 'Vout', model='nmos_model', w=50e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias4', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
