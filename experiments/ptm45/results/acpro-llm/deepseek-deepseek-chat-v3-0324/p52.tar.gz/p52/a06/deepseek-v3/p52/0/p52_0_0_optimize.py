from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (45nm technology)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed input voltage (mid-supply)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed input voltage (mid-supply)
    # Bias voltage (parameterized, original value was Vth + 0.2V = 0.42V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Differential Pair Transistors
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
                  model='nmos_model',
                  w=params['w_M1'],
                  l=0.045e-6)  # Fixed 45nm length
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model',
                  w=params['w_M2'],
                  l=0.045e-6)  # Fixed 45nm length
    # Active Load (Current Mirror)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M3'],
                  l=0.045e-6)  # Fixed 45nm length
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M4'],
                  l=0.045e-6)  # Fixed 45nm length
    # Tail Current Source
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd,
                  model='nmos_model',
                  w=params['w_M5'],
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W ranges from 1-500×L, where L=45nm → ~45nm to 22.5μm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Differential pair transistor 1
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Differential pair transistor 2
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 1
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 2
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current source
    # Bias voltage (constrained near original value of Vth+0.2V=0.42V)
    'v_bias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original, but constrained to safe range
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,   # Original width for M1
    'w_M2': 10e-6,   # Original width for M2
    'w_M3': 20e-6,   # Original width for M3
    'w_M4': 20e-6,   # Original width for M4
    'w_M5': 10e-6,   # Original width for M5
    'v_bias': 0.42,  # Original bias voltage (Vth + 0.2V)
}
# Parameter descriptions for reference:
"""
Parameter Descriptions:
- w_M1, w_M2: Widths of differential pair NMOS transistors (M1, M2)
              Affect gain, noise, and matching
- w_M3, w_M4: Widths of PMOS current mirror load transistors (M3, M4)
              Affect output impedance and mirror accuracy
- w_M5: Width of tail current source NMOS (M5)
        Determines bias current and common-mode rejection
- v_bias: Voltage for tail current source gate
           Controls bias current while staying in saturation
"""
