from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Opamp')
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Tail current bias (Vth + 0.2V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # DC bias for Vinp
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # DC bias for Vinn
# Define MOSFET models (simplified 45nm parameters)
circuit.model('nmos', 'nmos', level=1, kp=100e-6, vto=0.22, lambda=0.1)
circuit.model('pmos', 'pmos', level=1, kp=40e-6, vto=-0.22, lambda=0.1)
# Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)
# Active Load (M3, M4 - PMOS Current Mirror)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', model='pmos', w=20e-6, l=0.045e-6)
# Tail Current Source (M5)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
