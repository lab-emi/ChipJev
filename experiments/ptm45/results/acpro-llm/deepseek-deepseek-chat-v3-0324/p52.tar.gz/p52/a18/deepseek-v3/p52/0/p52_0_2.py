from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
   circuit.lib('45nm_bulk.pm', 'tt')  # 'tt' = typical corner
   circuit.model('nmos', 'nmos')
   circuit.model('pmos', 'pmos')

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
