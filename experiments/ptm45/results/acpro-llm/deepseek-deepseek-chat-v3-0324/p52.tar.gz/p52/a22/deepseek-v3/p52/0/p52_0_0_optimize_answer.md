Here's the parameterized version of your single-stage differential opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Opamp')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Voltages (fixed for DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for symmetric operation
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for symmetric operation
    
    # Parameterized Bias Voltage (Vth + 0.2V = 0.42V original)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Differential Pair (M1, M2) and Tail Current Source (M5)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourceCommon', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    circuit.MOSFET('2', 'Vout', 'Vinp', 'SourceCommon', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    circuit.MOSFET('5', 'SourceCommon', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m3'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m4'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5µm range)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (differential pair)
    'w_m5': {'min': 90e-9, 'max': 22.5e-6, 'log': True},  # M5 width (tail current, original was 20µm)
    'w_m3': {'min': 90e-9, 'max': 22.5e-6, 'log': True},  # M3 width (active load PMOS)
    'w_m4': {'min': 90e-9, 'max': 22.5e-6, 'log': True},  # M4 width (active load PMOS)
    
    # Bias voltage (0.8-1.2× original, but must keep above Vth=0.22V)
    # Original was 0.42V (Vth + 0.2V), range: 0.336V-0.504V
    'v_bias': {'min': 0.336, 'max': 0.504, 'log': False},
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 10e-6,    # Original M1 width
    'w_m2': 10e-6,    # Original M2 width
    'w_m5': 20e-6,    # Original M5 width (tail current)
    'w_m3': 20e-6,    # Original M3 width (PMOS load)
    'w_m4': 20e-6,    # Original M4 width (PMOS load)
    'v_bias': 0.42,   # Original bias voltage (Vth + 0.2V)
}

# Parameter descriptions
"""
Parameter Descriptions:
- w_m1, w_m2: Widths of NMOS differential pair transistors (affects transconductance and matching)
- w_m5: Width of tail current source NMOS (sets bias current for the differential pair)
- w_m3, w_m4: Widths of PMOS active load transistors (affects gain and output impedance)
- v_bias: Bias voltage for tail current source (must keep above Vth to ensure proper operation)
"""
```

Key aspects of this implementation:

1. **Fixed Elements**:
   - Power supply (1.2V) remains fixed
   - Input voltages (0.6V) remain fixed for DC analysis
   - All transistor lengths fixed at 45nm (process-defined)
   - MOSFET models remain exactly as provided

2. **Parameterized Elements**:
   - All transistor widths are parameterized with 1-500× length range (45nm-22.5µm)
   - Bias voltage is parameterized with conservative range (0.8-1.2× original)
   - No load capacitors were present in the original circuit

3. **Range Constraints**:
   - All transistor width ranges maintain the 1-500× length ratio
   - Bias voltage range (0.336V-0.504V) maintains headroom above Vth=0.22V
   - All ranges include the original values as starting points

4. **Compatibility**:
   - Function named exactly `create_circuit`
   - Preserves original import statement
   - Initial parameters exactly match original circuit values
   - All initial values are within their respective search ranges

This parameterization allows optimization of:
- Differential pair transconductance (via w_m1/w_m2)
- Tail current (via w_m5 and v_bias)
- Load impedance and gain (via w_m3/w_m4)