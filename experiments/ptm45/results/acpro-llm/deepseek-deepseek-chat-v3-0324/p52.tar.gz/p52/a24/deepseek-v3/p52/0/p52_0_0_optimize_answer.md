Here's the parameterized conversion of your single-stage differential amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed voltages, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn
    
    # Parameterized bias voltage with conservative range
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    
    # Input Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - PMOS Current Mirror - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W ranges from 1-500× length (45nm))
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair transistor 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load transistor 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load transistor 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source
    
    # Bias voltage (conservative range around original 0.42V, staying above threshold)
    # Original bias (0.42V = Vth + 0.2V), range allows Vth + 0.1V to Vth + 0.3V
    'v_bias': {'min': 0.32, 'max': 0.52},  # Vth=0.22V, so 0.22+0.1 to 0.22+0.3
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_M1': 10e-6,  # M1 original width
    'w_M2': 10e-6,  # M2 original width
    'w_M3': 20e-6,  # M3 original width
    'w_M4': 20e-6,  # M4 original width
    'w_M5': 20e-6,  # M5 original width
    
    # Bias voltage (original value)
    'v_bias': 0.42,  # Original bias voltage
}
```

### Explanation of Implementation:

1. **Fixed Parameters**:
   - Power supply (1.2V) and input voltages (0.6V) remain fixed as requested
   - MOSFET length (L) is fixed at 45nm for all transistors

2. **Parameterized Components**:
   - All transistor widths (W) are parameterized with ranges from 1-500× the length (45nm-22.5μm)
   - Bias voltage is parameterized with a conservative range around its original value (0.32V-0.52V)

3. **Physical Meaning of Parameters**:
   - `w_M1`, `w_M2`: Widths of input differential pair NMOS transistors (affects gain and matching)
   - `w_M3`, `w_M4`: Widths of PMOS active load transistors (affects mirroring accuracy and gain)
   - `w_M5`: Width of tail current source (affects bias current and common-mode rejection)
   - `v_bias`: Gate voltage for tail current source (affects bias current)

4. **Conservative Ranges**:
   - Transistor widths cover practical ranges while maintaining reasonable W/L ratios
   - Bias voltage range ensures transistors remain in saturation while allowing optimization
   - All voltages stay well below the 1.2V supply limit

5. **Initial Parameters**:
   - All initial values exactly match the original circuit values
   - All initial values are within their respective search ranges

The implementation follows all your requirements while maintaining the original circuit's functionality and allowing for meaningful optimization within practical constraints.