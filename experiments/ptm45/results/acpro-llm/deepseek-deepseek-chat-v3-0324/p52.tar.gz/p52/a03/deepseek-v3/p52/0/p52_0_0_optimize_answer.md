Here's the parameterized conversion of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies and Bias Voltages (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed DC bias for Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed DC bias for Vinn
    
    # Parameterized bias voltage (Vbiasn must be > Vth for proper operation)
    circuit.V('biasn', 'Vbiasn', circuit.gnd, params['vbiasn']@u_V)
    
    # Differential Input Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1']@u_um, 
                   l=0.045@u_um)  # Fixed 45nm length
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M2']@u_um, 
                   l=0.045@u_um)  # Fixed 45nm length
    
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M3']@u_um, 
                   l=0.045@u_um)  # Fixed 45nm length
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M4']@u_um, 
                   l=0.045@u_um)  # Fixed 45nm length
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbiasn', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M5']@u_um, 
                   l=0.045@u_um)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (constrained to be > Vth and reasonable for 1.2V supply)
    'vbiasn': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (0.8-1.2× range but constrained)
    
    # Differential pair transistor widths (nMOS)
    'w_M1': {'min': 0.045, 'max': 22.5},  # W range: 1-500× length, original: 10um
    'w_M2': {'min': 0.045, 'max': 22.5},  # W range: 1-500× length, original: 10um
    
    # Active load transistor widths (pMOS)
    'w_M3': {'min': 0.045, 'max': 22.5},  # W range: 1-500× length, original: 20um
    'w_M4': {'min': 0.045, 'max': 22.5},  # W range: 1-500× length, original: 20um
    
    # Tail current source transistor width (nMOS)
    'w_M5': {'min': 0.045, 'max': 22.5},  # W range: 1-500× length, original: 20um
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbiasn': 0.42,  # Original bias voltage (V)
    'w_M1': 10.0,    # Original width (um)
    'w_M2': 10.0,    # Original width (um)
    'w_M3': 20.0,    # Original width (um)
    'w_M4': 20.0,    # Original width (um)
    'w_M5': 20.0,    # Original width (um)
}

# Parameter descriptions
"""
Parameter Descriptions:
- vbiasn: Bias voltage for tail current source (Vbiasn). Must be > Vth (0.22V) to keep M5 in saturation.
- w_M1, w_M2: Widths of input differential pair NMOS transistors (M1, M2). Affects gm and input capacitance.
- w_M3, w_M4: Widths of active load PMOS transistors (M3, M4). Affects output resistance and gain.
- w_M5: Width of tail current source NMOS (M5). Sets bias current for the differential pair.

All transistor lengths are fixed at 45nm (process minimum). Widths are constrained to maintain reasonable W/L ratios.
"""
```

Key aspects of this implementation:
1. Strictly followed all your requirements including naming conventions and fixed parameters
2. Voltage ranges are carefully constrained:
   - Vbiasn limited to 0.34-0.50V (conservative around original 0.42V to ensure operation above Vth)
3. Width parameters:
   - Minimum width is 45nm (1× length)
   - Maximum width is 22.5μm (500× length)
   - Original widths (10μm and 20μm) fall within these ranges
4. Used um units for width parameters for better numerical stability during optimization
5. Included detailed parameter descriptions for clear understanding
6. Ensured all initial_params values match exactly the original circuit values
7. Kept all input voltages (Vinp, Vinn) and Vdd fixed as requested
8. No load capacitors were present in original circuit, so none were parameterized

The parameter ranges are designed to:
- Keep transistors in saturation
- Maintain reasonable current densities
- Allow optimization while avoiding unrealistic device sizes
- Preserve circuit functionality throughout the search space