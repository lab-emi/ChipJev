from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp (Parameterized)')
    # MOSFET Models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed supply voltage
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # For M5 (Vth + 0.2V originally)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # For M7 (mid-supply originally)
    # Input voltages (fixed DC bias)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed DC bias
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed DC bias
    # Differential Pair Stage (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load (PMOS M3, M4 - parameterized widths)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Output Stage (parameterized widths)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to stay close to original values, never exceeding 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},     # Original: 0.42V (0.8-1.2× range)
    'vbias2': {'min': 0.48, 'max': 0.72},       # Original: 0.6V (0.8-1.2× range)
    # NMOS transistor widths (1-500× length = 45nm-22.5μm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    'w_M5': {'min': 2.25e-6, 'max': 2.25e-3, 'log': True},  # Original: 5μm (50-500×L)
    # PMOS transistor widths (1-500× length = 45nm-22.5μm)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 20μm
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 20μm
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 40μm
    'w_M7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Original: 10μm
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.6,
    # NMOS widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M5': 5e-6,
    # PMOS widths
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M6': 40e-6,
    'w_M7': 10e-6,
}
