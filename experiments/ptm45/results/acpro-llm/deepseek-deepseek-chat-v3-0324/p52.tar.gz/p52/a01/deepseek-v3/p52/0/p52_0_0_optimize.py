from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
    # Input Signals (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.42V
    circuit.V('inn', 'Vinn', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.42V
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # Input Differential Pair (M1, M2) - widths parameterized
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'],
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M2'],
                  l=0.045e-6)
    # Tail Current Source (M3) - width parameterized
    circuit.MOSFET('3', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M3'],
                  l=0.045e-6)
    # Active Load (M4, M5) - widths parameterized
    circuit.MOSFET('4', 'Drain1', 'Vout', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M4'],
                  l=0.045e-6)
    circuit.MOSFET('5', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M5'],
                  l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W/L ratio is what matters, L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load
    # Bias voltage (constrained to stay near intended operating point)
    # Original = 0.42V (Vth + 0.2V), range allows ±0.084V (20%)
    'vbias': {'min': 0.336, 'max': 0.504, 'log': False},  # 0.8-1.2× original
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,   # Original width for M1
    'w_M2': 10e-6,   # Original width for M2
    'w_M3': 5e-6,    # Original width for M3
    'w_M4': 10e-6,   # Original width for M4
    'w_M5': 10e-6,   # Original width for M5
    'vbias': 0.42,   # Original bias voltage (Vth + 0.2V)
}
"""
Parameter Descriptions:
- w_M1: Width of NMOS input transistor M1 (affects input transconductance)
- w_M2: Width of NMOS input transistor M2 (matched to M1 for symmetry)
- w_M3: Width of NMOS tail current source (sets bias current)
- w_M4: Width of PMOS load transistor M4 (affects load impedance)
- w_M5: Width of PMOS load transistor M5 (matched to M4 for symmetry)
- vbias: Bias voltage for tail current source (must keep above Vth)
"""
