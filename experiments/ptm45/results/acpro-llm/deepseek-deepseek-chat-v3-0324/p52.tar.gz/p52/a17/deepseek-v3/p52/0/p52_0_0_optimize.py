from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Tail current bias
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed DC common-mode input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed DC common-mode input
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1_M2'],
                   l=0.045e-6)  # Length fixed by 45nm process
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1_M2'],
                   l=0.045e-6)  # Length fixed by 45nm process
    # Active Load (M3, M4) - Current Mirror
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M3_M4'],
                   l=0.045e-6)  # Length fixed by 45nm process
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M3_M4'],
                   l=0.045e-6)  # Length fixed by 45nm process
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M5'],
                   l=0.045e-6)  # Length fixed by 45nm process
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all lengths fixed at 45nm)
    'w_M1_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair width range: 1-500×45nm
    'w_M3_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load width range: 1-500×45nm
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},     # Tail current width range: 1-500×45nm
    # Bias voltage
    'vbias': {'min': 0.336, 'max': 0.504},  # Tail current bias: 0.8-1.2× original (0.42V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1_M2': 10e-6,  # Original width for M1 and M2
    'w_M3_M4': 20e-6,  # Original width for M3 and M4
    'w_M5': 20e-6,     # Original width for M5
    # Bias voltage
    'vbias': 0.42,     # Original tail current bias voltage
}
# Parameter descriptions:
# - w_M1_M2: Width of differential pair transistors (M1, M2), affects transconductance and gain
# - w_M3_M4: Width of PMOS load transistors (M3, M4), affects mirroring accuracy and output impedance
# - w_M5: Width of tail current source (M5), sets the bias current for the differential pair
# - vbias: Tail current bias voltage, controls the operating point of the differential pair
