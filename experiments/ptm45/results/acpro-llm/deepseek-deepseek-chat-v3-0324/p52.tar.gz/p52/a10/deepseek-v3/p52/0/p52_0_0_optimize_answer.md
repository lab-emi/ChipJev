Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.42)  # Common-mode input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.42)  # Common-mode input (fixed)
    
    # Parameterized Bias Voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Bias for tail current source
    
    # Differential Pair - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    
    # Active Load (PMOS Current Mirror) - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    
    # Tail Current Source - parameterized width
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # MOSFET widths (W) - range 1-500× length (45nm = 0.045um)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (differential pair)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (differential pair)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (PMOS load)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (PMOS load)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (tail current)
    
    # Bias voltage - constrained to stay near intended operating point
    # Original was Vth + 0.2V = 0.42V, range is 0.8-1.2× but capped at 1.2V
    'vbias': {'min': 0.336, 'max': 0.504, 'log': False},  # Vbias range: 0.8-1.2× 0.42V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # MOSFET widths
    'w_m1': 10e-6,   # Original M1 width
    'w_m2': 10e-6,   # Original M2 width
    'w_m3': 20e-6,   # Original M3 width
    'w_m4': 20e-6,   # Original M4 width
    'w_m5': 20e-6,   # Original M5 width
    
    # Bias voltage
    'vbias': 0.42,   # Original Vbias value (Vth + 0.2V)
}

"""
Parameter Descriptions:
- w_m1, w_m2: Widths of differential pair NMOS transistors (M1, M2)
- w_m3, w_m4: Widths of PMOS current mirror load transistors (M3, M4)
- w_m5: Width of tail current source NMOS transistor (M5)
- vbias: Bias voltage for tail current source - critical for setting operating current

Note: All transistor lengths are fixed at 45nm (0.045um) as per 45nm technology node.
Input voltages (Vinp, Vinn) are fixed at 0.42V (Vth + 0.2V) for common-mode operation.
Supply voltage Vdd is fixed at 1.2V for 45nm technology.
"""
```

Key features:
1. All transistor widths are parameterized while keeping lengths fixed at 45nm
2. Bias voltage (Vbias) is parameterized with a conservative range around the original value
3. Power supply (Vdd) and input voltages (Vinp, Vinn) remain fixed
4. The initial_params dictionary contains exactly the original values from your circuit
5. All initial values fall within their respective search ranges
6. Search ranges are set according to your specifications (1-500× length for widths, 0.8-1.2× for bias voltage)
7. The circuit creation function is named `create_circuit` as required
8. No capacitors were included in your original circuit, so none were parameterized
9. The import statement for nmos_params and pmos_params is preserved exactly as specified