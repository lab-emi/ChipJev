from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Input Signals (fixed, mid-supply for common-mode)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Differential Pair (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Tail Current Source (parameterized width)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load - PMOS Current Mirror (parameterized widths)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (Vbias)
    'v_bias': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Vth + 0.2V ±20% (but ≤1.2V)
    # NMOS differential pair widths
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    # NMOS tail current source width
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    # PMOS current mirror widths
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_bias': 0.42,       # Original bias voltage (V)
    'w_M1': 5e-6,         # Original M1 width
    'w_M2': 5e-6,         # Original M2 width
    'w_M5': 10e-6,        # Original M5 width
    'w_M3': 10e-6,        # Original M3 width
    'w_M4': 10e-6,        # Original M4 width
}
