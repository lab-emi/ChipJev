Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (fixed)
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    
    # Input Signals (fixed, mid-supply for common-mode)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    
    # Differential Pair (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Tail Current Source (parameterized width)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Active Load - PMOS Current Mirror (parameterized widths)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (Vbias)
    'v_bias': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Vth + 0.2V ±20% (but ≤1.2V)
    
    # NMOS differential pair widths
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    
    # NMOS tail current source width
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    
    # PMOS current mirror widths
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6},  # 1-500× length (45nm to 22.5µm)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_bias': 0.42,       # Original bias voltage (V)
    'w_M1': 5e-6,         # Original M1 width
    'w_M2': 5e-6,         # Original M2 width
    'w_M5': 10e-6,        # Original M5 width
    'w_M3': 10e-6,        # Original M3 width
    'w_M4': 10e-6,        # Original M4 width
}
```

### Parameter Descriptions:
1. **v_bias**: Tail current source bias voltage (0.42V original). Range set to ±20% of original but capped at 1.2V (supply voltage). Conservative range maintains operation above threshold (Vth = 0.22V).

2. **w_M1, w_M2**: Widths of NMOS differential pair transistors (5µm original). Range spans 1-500× the fixed 45nm length (45nm to 22.5µm).

3. **w_M5**: Width of NMOS tail current source (10µm original). Same 1-500× range as differential pair.

4. **w_M3, w_M4**: Widths of PMOS current mirror load transistors (10µm original). Same 1-500× range as other devices.

### Key Features:
- Fixed 45nm channel length for all transistors (as per your requirement)
- All initial values exactly match your original circuit
- All parameter ranges are physically reasonable:
  - Bias voltage stays within safe operating region
  - Transistor widths allow for sufficient current while avoiding excessive capacitance
- No load capacitors present in your original circuit, so none were parameterized

The parameter ranges allow optimization to explore:
- Current mirror ratios (via M3/M4 widths)
- Differential pair gm (via M1/M2 widths)
- Tail current (via M5 width and Vbias)
while maintaining realistic device dimensions for 45nm technology.