from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Parameterized bias voltage for tail current source
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    # Fixed input voltages (not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Positive input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Negative input
    # Differential Pair (M1, M2) and Tail Current Source (M5)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load (PMOS Current Mirror: M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500× L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500× L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500× L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500× L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500× L)
    # Bias voltage (constrained to maintain proper operation)
    'v_bias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original 0.42V, constrained below 1.2V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original M1 width
    'w_M2': 10e-6,    # Original M2 width
    'w_M3': 20e-6,    # Original M3 width
    'w_M4': 20e-6,    # Original M4 width
    'w_M5': 5e-6,     # Original M5 width
    'v_bias': 0.42,   # Original bias voltage (Vth + 0.2V = 0.22V + 0.2V)
}
# Physical meaning of each parameter:
"""
w_M1: Width of input NMOS transistor M1 (differential pair)
w_M2: Width of input NMOS transistor M2 (differential pair)
w_M3: Width of PMOS load transistor M3 (current mirror)
w_M4: Width of PMOS load transistor M4 (current mirror)
w_M5: Width of NMOS tail current source transistor M5
v_bias: Bias voltage for tail current source (M5 gate voltage)
"""
