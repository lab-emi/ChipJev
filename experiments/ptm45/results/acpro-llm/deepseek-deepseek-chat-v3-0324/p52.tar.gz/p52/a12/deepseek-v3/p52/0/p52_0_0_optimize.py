from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
    # Input and Bias Voltages (fixed inputs, parameterized bias)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.42)  # Fixed input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.42)  # Fixed input
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias
    # Differential Pair (M1, M2) and Tail Current Source (M5)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'], 
                   l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m2'], 
                   l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m5'], 
                   l=0.045e-6)
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m3'], 
                   l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m4'], 
                   l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W range: 1-500× length = 45e-9 to 22.5e-6)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (differential pair NMOS)
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (differential pair NMOS)
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (tail current NMOS)
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (active load PMOS)
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (active load PMOS)
    # Bias voltage (conservative range near threshold)
    'vbias': {'min': 0.34, 'max': 0.5},  # Original 0.42V, range 0.8-1.2× (but limited to Vdd-Vth)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor dimensions
    'w_m1': 5e-6,    # Original M1 width
    'w_m2': 5e-6,    # Original M2 width
    'w_m5': 10e-6,   # Original M5 width
    'w_m3': 10e-6,   # Original M3 width
    'w_m4': 10e-6,   # Original M4 width
    # Bias voltage
    'vbias': 0.42,   # Original bias voltage
}
