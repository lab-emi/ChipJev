from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (fixed and parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    # Parameterized bias voltage (Vth + 0.2V = 0.42V original)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Input voltages (fixed, not parameterized)
    circuit.V('in_p', 'Vinp', circuit.gnd, 0.6)  # Fixed common-mode input
    circuit.V('in_n', 'Vinn', circuit.gnd, 0.6)  # Fixed common-mode input
    # Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    # Active Load (M3, M4) - PMOS current mirror - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping L fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (nmos)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (nmos)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (pmos)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (pmos)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (nmos)
    # Bias voltage (conservative range around Vth + 0.2V)
    'v_bias': {'min': 0.336, 'max': 0.504, 'log': False},  # 0.8-1.2× original (0.42V), keeping <1.2V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 10e-6,    # Original M1 width
    'w_m2': 10e-6,    # Original M2 width
    'w_m3': 20e-6,    # Original M3 width
    'w_m4': 20e-6,    # Original M4 width
    'w_m5': 10e-6,    # Original M5 width
    'v_bias': 0.42,   # Original bias voltage
}
# Parameter descriptions for reference:
"""
w_m1: Width of NMOS differential pair transistor M1 (input device)
w_m2: Width of NMOS differential pair transistor M2 (input device)
w_m3: Width of PMOS current mirror load transistor M3
w_m4: Width of PMOS current mirror load transistor M4
w_m5: Width of NMOS tail current source transistor M5
v_bias: Bias voltage for tail current source (Vth + overdrive voltage)
"""
