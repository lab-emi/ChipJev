Here's the parameterized version of your single-stage differential amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Common-mode input voltage
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Common-mode input voltage
    
    # Bias Voltage for Tail Current Source (M5) - parameterized
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    
    # Differential Pair (M1, M2) and Tail Current Source (M5) - widths parameterized
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Active Load (M3, M4) - Current Mirror - widths parameterized
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500×L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500×L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500×L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500×L)
    
    # Bias voltage (conservative range around original value)
    'v_bias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original (0.42V), keeping above Vth (0.22V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,  # Original M1 width
    'w_M2': 10e-6,  # Original M2 width
    'w_M3': 20e-6,  # Original M3 width
    'w_M4': 20e-6,  # Original M4 width
    'w_M5': 20e-6,  # Original M5 width
    
    # Bias voltage
    'v_bias': 0.42,  # Original bias voltage
}

# Parameter descriptions
"""
Parameter Descriptions:
- w_M1: Width of differential pair transistor M1 (Vinp input)
- w_M2: Width of differential pair transistor M2 (Vinn input)
- w_M3: Width of PMOS current mirror transistor M3
- w_M4: Width of PMOS current mirror transistor M4 (output branch)
- w_M5: Width of tail current source transistor M5
- v_bias: Bias voltage for tail current source (must keep above threshold voltage)
"""
```

Key features of this implementation:
1. All transistor widths are parameterized while keeping length fixed at 45nm
2. Bias voltage is parameterized with conservative range (0.8-1.2× original value)
3. Power supply (Vdd) and input voltages (Vinp/Vinn) remain fixed
4. Initial parameters exactly match the original circuit values
5. All initial values are within their respective search ranges
6. Width ranges allow 1-500× the minimum length (45nm)
7. Bias voltage range ensures operation above threshold voltage (Vth = 0.22V)
8. No capacitors were included in the original circuit, so none were parameterized

The parameter ranges are designed to:
- Allow sufficient exploration of transistor sizing while maintaining reasonable W/L ratios
- Keep bias voltages in a safe operating range
- Maintain circuit functionality during optimization
- Preserve the original circuit behavior as the starting point