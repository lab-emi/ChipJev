from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Using 45nm models
circuit = Circuit('Working_Single_Stage_Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Proper Biasing Scheme
# Tail current bias (Vth + 200mV overdrive)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
# Differential inputs at optimal CM level (~Vdd/2)
circuit.V('inp', 'Vinp', circuit.gnd, 0.65@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.65@u_V)
# Main Circuit Components
# Differential Pair NMOS (W=10um, L=45nm)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# Current Mirror PMOS Load (W=25um for proper current matching)
circuit.MOSFET('3', 'Vout', 'Vout', 'Vdd', 'Vdd',
               model='pmos_model', w=25e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vout', 'Vdd', 'Vdd',
               model='pmos_model', w=25e-6, l=0.045e-6)
# Strong Tail Current Source (W=30um)
circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd,
               model='nmos_model', w=30e-6, l=0.045e-6)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
