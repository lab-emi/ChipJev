from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input Bias Voltages (Assume Vth = 0.22V)
# Tail current bias: Vbias = Vth + 0.2V = 0.42V
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  
# Differential Input Voltages (for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for common-mode
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for common-mode
# Differential Pair with Current Mirror Load
# M1 (NMOS): Vinp input
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M2 (NMOS): Vinn input
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M3 (PMOS): Current mirror (left side, connected to output)
circuit.MOSFET('3', 'Vout', 'Vout', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M4 (PMOS): Current mirror (right side, diode-connected)
circuit.MOSFET('4', 'Drain2', 'Vout', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M5 (NMOS): Tail current source
circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
