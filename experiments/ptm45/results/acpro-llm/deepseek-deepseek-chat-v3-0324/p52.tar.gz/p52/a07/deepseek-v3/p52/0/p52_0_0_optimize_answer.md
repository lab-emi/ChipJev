Here's the parameterized version of your single-stage differential opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltage for Tail Current Source (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Differential Input Voltages (fixed at mid-rail: 0.6V)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1_m2'],
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1_m2'],
                  l=0.045e-6)
    
    # Active Load (M3, M4) - PMOS Current Mirror
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m3_m4'],
                  l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m3_m4'],
                  l=0.045e-6)
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'],
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_m1_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for diff pair
    'w_m3_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for PMOS load
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},     # 1-500×L for tail current
    
    # Bias voltage (Vth + 0.2V = 0.42V original, range ±20% but always > Vth)
    'vbias': {'min': 0.35, 'max': 0.5}  # Conservative range around original 0.42V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1_m2': 5e-6,    # Original width for M1, M2
    'w_m3_m4': 10e-6,   # Original width for M3, M4
    'w_m5': 5e-6,       # Original width for M5
    'vbias': 0.42,      # Original bias voltage (Vth + 0.2V)
}

"""
Parameter Descriptions:
- w_m1_m2: Width of differential pair transistors (M1, M2)
- w_m3_m4: Width of PMOS active load transistors (M3, M4)
- w_m5: Width of tail current source transistor (M5)
- vbias: Bias voltage for tail current source (conservative range around Vth+0.2V)

Note:
1. All MOSFET lengths are fixed at 45nm (technology constraint)
2. Power supply (1.2V) and input voltages (0.6V) are fixed
3. All initial parameter values are within their search ranges
4. Bias voltage range is conservative (0.35-0.5V) to ensure proper operation
   (original 0.42V within range, and all values > Vth=0.22V)
"""
```

This implementation:
1. Maintains all original circuit functionality while making it parameterized
2. Keeps fixed voltages (Vdd, Vinp, Vinn) as specified
3. Parameterizes all transistor widths and bias voltage
4. Includes conservative search ranges that respect your constraints
5. Preserves all original values in initial_params
6. Provides clear documentation of each parameter

The parameter ranges are set to:
- Transistor widths: 1-500× their length (45nm to 22.5μm)
- Bias voltage: ±16% around original value (0.35-0.5V), safely above Vth=0.22V

All initial parameter values match exactly what was in your original circuit.