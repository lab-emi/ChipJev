from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # This import must be available in your environment
circuit = Circuit('Single-Stage Opamp')
# ====================== MODEL DEFINITIONS ======================
# Critical Fix: Add explicit .model statements using the imported parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# ====================== POWER SUPPLY ======================
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# ====================== INPUT BIASING ======================
# Changed: Added proper units (@u_V) and adjusted bias points
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail bias
# ====================== BIAS CIRCUIT ======================
# Changed: Improved bias network - now generates its own bias voltage
circuit.V('bias_gen', 'Vbias_gen', circuit.gnd, 0.42@u_V)
circuit.MOSFET('6', 'VbiasLoad', 'VbiasLoad', 'Vdd', 'Vdd', 
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# ====================== DIFFERENTIAL PAIR ======================
# Changed: Added proper units to dimensions and ensured bulk connections
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=10@u_um, l=0.045@u_um)
# ====================== ACTIVE LOAD ======================
# Changed: Properly connected to bias network
circuit.MOSFET('3', 'Vout', 'VbiasLoad', 'Vdd', 'Vdd', 
               model='pmos_model', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'VbiasLoad', 'Vdd', 'Vdd', 
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# ====================== TAIL CURRENT SOURCE ======================
# Changed: Using the generated bias voltage
circuit.MOSFET('5', 'SourcePair', 'Vbias_gen', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=20@u_um, l=0.045@u_um)
# ====================== SIMULATION SETUP ======================
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
