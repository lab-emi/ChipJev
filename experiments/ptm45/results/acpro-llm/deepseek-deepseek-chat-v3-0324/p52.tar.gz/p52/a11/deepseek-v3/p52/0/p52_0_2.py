from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp')
# ========== CRITICAL: MUST ADD THESE MODEL DEFINITIONS ==========
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# ========== POWER SUPPLY ==========
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# ========== PROPER BIAS GENERATION ==========
# Bias for tail current source (Vth_n + 0.2V overdrive)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Vth_n = 0.22V + 0.2V overdrive
# Bias for active load (Vdd - |Vth_p| - 0.2V overdrive)
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78@u_V)  # 1.2V - 0.22V - 0.2V
# ========== INPUT STAGE ==========
# Differential pair biased at 0.6V (mid-rail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# ========== DIFFERENTIAL PAIR ==========
# NMOS input pair (10um/45nm)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
               model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd,
               model='nmos_model', w=10@u_um, l=0.045@u_um)
# ========== ACTIVE LOAD ==========
# PMOS current mirror load
circuit.MOSFET('3', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=20@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# ========== TAIL CURRENT SOURCE ==========
# NMOS tail current (20um/45nm)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20@u_um, l=0.045@u_um)
# ========== BIAS GENERATION FOR ACTIVE LOAD ==========
# Diode-connected PMOS to generate Vbiasp (optional, now using fixed bias)
circuit.MOSFET('6', 'Vbiasp', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# ========== SIMULATION SETUP ==========
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
