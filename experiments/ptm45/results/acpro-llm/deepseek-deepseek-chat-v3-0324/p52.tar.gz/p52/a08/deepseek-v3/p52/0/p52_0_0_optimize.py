from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Bias Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos_diff'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos_diff'], 
                  l=0.045e-6)
    # Active Load (M3, M4) - PMOS current mirror
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos_load'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos_load'], 
                  l=0.045e-6)
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos_tail'], 
                  l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_nmos_diff': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair width (1-500×L)
    'w_pmos_load': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load width (1-500×L)
    'w_nmos_tail': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current width (1-500×L)
    # Bias voltage (constrained to safe operating range)
    'vbias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original (0.42V), keeping Vgs > Vth (0.22V) and < 1.2V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos_diff': 5e-6,     # Original NMOS differential pair width
    'w_pmos_load': 10e-6,    # Original PMOS load width
    'w_nmos_tail': 10e-6,    # Original tail current width
    'vbias': 0.42,           # Original bias voltage
}
"""
Parameter Descriptions:
1. w_nmos_diff: Width of NMOS transistors in differential pair (M1, M2)
   - Affects input transconductance and matching
   - Range: 45nm (minimum feature size) to 22.5μm (500×L)
2. w_pmos_load: Width of PMOS active load transistors (M3, M4)
   - Affects mirroring accuracy and output impedance
   - Range: 45nm (minimum feature size) to 22.5μm (500×L)
3. w_nmos_tail: Width of tail current source transistor (M5)
   - Determines bias current and common-mode rejection
   - Range: 45nm (minimum feature size) to 22.5μm (500×L)
4. vbias: Bias voltage for tail current source
   - Sets operating point of differential pair
   - Range: 0.336V-0.504V (0.8-1.2× original, constrained by Vth and Vdd)
"""
