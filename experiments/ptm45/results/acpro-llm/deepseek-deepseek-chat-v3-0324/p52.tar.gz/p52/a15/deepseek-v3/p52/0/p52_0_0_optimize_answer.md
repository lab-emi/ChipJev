Here's the parameterized version of your single-stage differential opamp following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Parameterized Bias Voltage (scaled from original 0.42V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Input Differential Pair (M1, M2) - Width parameterized
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - Width parameterized
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5) - Width parameterized
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5um)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (input pair 1)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (input pair 2)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (PMOS load 1)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (PMOS load 2)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (tail current)
    
    # Bias voltage (0.8-1.2× original 0.42V, but must stay below 1.2V)
    'vbias': {'min': 0.336, 'max': 0.504, 'log': False},  # Vth + 0.2V = ~0.42V ±20%
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,   # Original M1 width
    'w_M2': 10e-6,   # Original M2 width
    'w_M3': 20e-6,   # Original M3 width
    'w_M4': 20e-6,   # Original M4 width
    'w_M5': 5e-6,    # Original M5 width
    'vbias': 0.42,   # Original bias voltage (0.42V)
}
```

### Explanation:

1. **Parameterized Elements**:
   - All transistor widths (w_M1-w_M5) are parameterized with ranges between 1× and 500× the 45nm length
   - The bias voltage (vbias) is parameterized with a conservative ±20% range around 0.42V

2. **Fixed Elements**:
   - Supply voltage (1.2V) remains fixed
   - Input voltages (0.6V) remain fixed for common-mode analysis
   - All transistor lengths fixed at 45nm (technology constraint)

3. **Parameter Ranges**:
   - Width ranges cover 45nm to 22.5μm (1-500× length) with logarithmic scaling
   - Bias voltage range (0.336V to 0.504V) maintains proper biasing while allowing optimization
     - Stays well below 1.2V supply and above threshold voltage (0.22V)

4. **Initial Values**:
   - Preserves all original circuit values exactly as provided
   - All initial values are within their respective search ranges

This implementation follows all your requirements while maintaining appropriate constraints for proper circuit operation in 45nm technology. The bias voltage range in particular is carefully chosen to keep the transistors in saturation while allowing optimization flexibility.