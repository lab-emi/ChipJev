from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Corrected Single-Stage Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail input
# Reference current generator (for proper biasing)
circuit.MOSFET('ref_p', 'vbias_p', 'vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.I('ref', 'vbias_p', circuit.gnd, 20@u_uA)  # Reference current
# NMOS current mirror for tail current
circuit.MOSFET('bias_n1', 'vbias_n', 'vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('bias_n2', 'vbias_n2', 'vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.I('ref_n', 'Vdd', 'vbias_n', 20@u_uA)  # Reference current for NMOS mirror
# Differential pair
circuit.MOSFET('1', 'drain1', 'Vinp', 'tail', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'drain2', 'Vinn', 'tail', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active loads
circuit.MOSFET('3', 'drain1', 'vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current source
circuit.MOSFET('5', 'tail', 'vbias_n2', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Compensation capacitor (for stability)
circuit.C('c', 'Vout', 'drain1', 1@u_pF)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
