from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Differential Amplifier with Active Load')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.42)  # Fixed input (Vth + 0.2V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.42)  # Fixed input (Vth + 0.2V)
    # Parameterized bias voltage (Vth + 0.2V ±15%)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias_val'])
    # Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed 45nm length
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Active Load (M3, M4) - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M3'], 
                  l=0.045e-6)  # Fixed 45nm length
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M4'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M5'], 
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5μm, log scale)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (differential pair)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (differential pair)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (PMOS load)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (PMOS load)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (current source)
    # Bias voltage (0.8-1.2× original, constrained to safe range)
    'vbias_val': {'min': 0.336, 'max': 0.504},  # Original 0.42V (Vth + 0.2V) ±20%
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original M1 width (differential pair)
    'w_M2': 10e-6,    # Original M2 width (differential pair)
    'w_M3': 20e-6,    # Original M3 width (PMOS load)
    'w_M4': 20e-6,    # Original M4 width (PMOS load)
    'w_M5': 10e-6,    # Original M5 width (current source)
    'vbias_val': 0.42, # Original bias voltage (Vth + 0.2V)
}
"""
Parameter Descriptions:
- w_M1, w_M2: Widths of NMOS differential pair transistors (affects gain, bandwidth)
- w_M3, w_M4: Widths of PMOS active load transistors (affects gain, output impedance)
- w_M5: Width of tail current source transistor (sets bias current)
- vbias_val: Bias voltage for tail current source (0.42V = Vth + 0.2V typical)
Note: All transistor lengths fixed at 45nm (technology minimum).
Power supply (1.2V) and input voltages (0.42V) remain fixed.
All initial values are within their respective search ranges.
"""
