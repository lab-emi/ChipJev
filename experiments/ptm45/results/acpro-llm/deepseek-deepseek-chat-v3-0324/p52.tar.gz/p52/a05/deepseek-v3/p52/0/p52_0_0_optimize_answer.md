Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp (Differential Pair with Active Load)')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltage for Tail Current Source (M5)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Input Voltages (fixed, common-mode = 0.6V for mid-rail)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - PMOS Current Mirror
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500x length, keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair input transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair input transistor 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source
    
    # Bias voltage (Vth + 0.1V to Vth + 0.3V, keeping above threshold but conservative)
    'vbias': {'min': 0.32, 'max': 0.52, 'log': False}  # Original was Vth + 0.2V (0.42V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original M1 width
    'w_M2': 10e-6,    # Original M2 width
    'w_M3': 20e-6,    # Original M3 width
    'w_M4': 20e-6,    # Original M4 width
    'w_M5': 20e-6,    # Original M5 width
    'vbias': 0.42,    # Original Vbias value (0.42V)
}
```

### Parameter Description:
1. **Transistor Widths (w_M1 to w_M5)**:
   - Range: 45nm (minimum feature size) to 22.5µm (500× length)
   - Log-scale recommended for MOSFET sizing optimization
   - M1/M2: Differential pair transistors (affects Gm, input capacitance)
   - M3/M4: Active load PMOS current mirror (affects gain, output impedance)
   - M5: Tail current source (affects bias current, PSRR)

2. **Bias Voltage (vbias)**:
   - Range: 0.32V to 0.52V (Vth + 0.1V to Vth + 0.3V)
   - Conservative range around original 0.42V (Vth + 0.2V)
   - Controls the tail current and thus the operating point

### Notes:
- All MOS lengths are fixed at 45nm (process-defined minimum)
- Power supply and input voltages remain fixed as requested
- All initial values are exactly preserved from original circuit
- No load capacitors were present in original circuit (as per requirements)
- Bias voltage range is conservative to maintain proper operation while allowing optimization
- Width ranges maintain 1-500× length ratio constraint
- Voltage ranges never exceed 1.2V supply voltage