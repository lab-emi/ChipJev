from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High CMRR Differential Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Tail current source bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.9@u_V)   # Current mirror bias (Vdd - Vth - 0.1V)
# Input Stage - Differential Pair with Tail Current Source
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Load Stage - Current Mirror
circuit.MOSFET('3', 'Drain1', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
