from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Fully Balanced Differential Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
circuit.V('bias_mirror', 'Vbias_mirror', circuit.gnd, 0.9@u_V)  # Vdd - Vth - 0.1V
# Input Signals (Common-mode at 0.6V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for balanced operation
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for balanced operation
# Differential Pair with Proper Biasing
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
              model='nmos_model', w=20e-6, l=0.045e-6)  # Vgs = 0.6 - (0.6-0.2) = 0.2V > Vth
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
              model='nmos_model', w=20e-6, l=0.045e-6)  # Vgs = 0.6 - (0.6-0.2) = 0.2V > Vth
# Tail Current Source (Vgs = 0.42V)
circuit.MOSFET('5', 'Tail', 'Vbias_tail', circuit.gnd, circuit.gnd,
              model='nmos_model', w=40e-6, l=0.045e-6)  # Properly biased
# Active Load - Current Mirror
circuit.MOSFET('3', 'Drain1', 'Vbias_mirror', 'Vdd', 'Vdd',
              model='pmos_model', w=30e-6, l=0.045e-6)  # Vsg = 1.2-0.9 = 0.3V > |Vth|
circuit.MOSFET('4', 'Vout', 'Vbias_mirror', 'Vdd', 'Vdd',
              model='pmos_model', w=30e-6, l=0.045e-6)  # Vsg = 1.2-0.9 = 0.3V > |Vth|
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p52/0/p52_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
