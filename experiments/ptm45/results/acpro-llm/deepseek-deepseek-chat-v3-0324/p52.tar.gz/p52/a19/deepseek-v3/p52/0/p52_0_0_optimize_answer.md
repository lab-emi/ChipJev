Here's the parameterized version of your single-stage differential amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')

    # Define the MOSFET models (same as original)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (Vdd = 1.2V, fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Differential Input Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M1'], 
                   l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M2'], 
                   l=0.045e-6)
    
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M3'], 
                   l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_M4'], 
                   l=0.045e-6)
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_M5'], 
                   l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500× length)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (same as M1)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (pmos load)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (pmos load)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (tail current)
    
    # Bias voltage (0.336-0.504V, 0.8-1.2× original within Vth constraints)
    'vbias': {'min': 0.336, 'max': 0.504},  # Must keep Vgs > Vth (0.22V) but < Vdd-Vth (0.98V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original M1 width
    'w_M2': 10e-6,    # Original M2 width
    'w_M3': 20e-6,    # Original M3 width
    'w_M4': 20e-6,    # Original M4 width
    'w_M5': 5e-6,     # Original M5 width
    'vbias': 0.42,    # Original bias voltage
}
```

### Parameter Descriptions:

1. **Transistor Widths (w_M1 to w_M5)**:
   - Controls transconductance and current handling capability of each transistor
   - Range is 45nm to 22.5µm (1-500× the minimum length)
   - Logarithmic scaling for better optimization across orders of magnitude

2. **Bias Voltage (vbias)**:
   - Sets the tail current source operating point
   - Range is 0.8-1.2× original (0.336-0.504V)
   - Constrained to ensure M5 remains in saturation (Vgs > Vth = 0.22V)
   - Upper limit prevents exceeding Vdd (1.2V) minus Vth (0.22V)

Key Features:
- Maintains all original MOSFET lengths (45nm) as fixed values
- Preserves all initial values exactly as in the original circuit
- Uses conservative ranges for bias voltage to maintain proper operation
- All MOS widths can vary within manufacturable limits (1-500× length)
- Follows all your specified requirements precisely

The circuit function is named exactly as required (`create_circuit`) and will be compatible with optimization frameworks. All parameter ranges include the original values, and voltage limits ensure safe operation within the 45nm technology constraints.