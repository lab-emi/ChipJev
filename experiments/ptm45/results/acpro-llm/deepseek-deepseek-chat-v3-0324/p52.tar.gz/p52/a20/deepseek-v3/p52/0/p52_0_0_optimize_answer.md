Here's the parameterized version of your single-stage differential opamp circuit with all requirements met:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Opamp')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Signals (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Bias Voltage for Tail Current Source (M5) - parameterized
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - PMOS Current Mirror - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (widths in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS diff pair 1 (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS diff pair 2 (1-500×L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 1 (1-500×L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 2 (1-500×L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS tail current source (1-500×L)
    
    # Bias voltage (conservative range around original value 0.42V)
    'v_bias': {'min': 0.336, 'max': 0.504},  # Vth + 0.1V to Vth + 0.3V (0.8-1.2× original)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,      # Original M1 width
    'w_M2': 10e-6,      # Original M2 width
    'w_M3': 20e-6,      # Original M3 width
    'w_M4': 20e-6,      # Original M4 width
    'w_M5': 20e-6,      # Original M5 width
    'v_bias': 0.42,     # Original bias voltage
}

# Parameter descriptions (for reference)
param_descriptions = {
    'w_M1': "Width of NMOS differential pair transistor M1 (Drain1 to SourcePair)",
    'w_M2': "Width of NMOS differential pair transistor M2 (Vout to SourcePair)",
    'w_M3': "Width of PMOS current mirror transistor M3 (Drain1 to Vdd)",
    'w_M4': "Width of PMOS current mirror transistor M4 (Vout to Vdd)",
    'w_M5': "Width of NMOS tail current source transistor M5 (SourcePair to GND)",
    'v_bias': "Bias voltage for tail current source (0.8-1.2× original 0.42V)"
}
```

Key features of this implementation:

1. **Fixed Values**:
   - Power supply (1.2V) and input voltages (0.6V) remain fixed
   - All transistor lengths fixed at 45nm (0.045μm)

2. **Parameterized Values**:
   - All transistor widths are parameterized with 1-500×L range
   - Bias voltage has conservative range (0.8-1.2× original value, limited to Vth + 0.1V to Vth + 0.3V)

3. **Initial Parameters**:
   - Contains exact original values from your circuit
   - All initial values are within their respective search ranges

4. **Physical Constraints**:
   - All voltage parameters limited to ≤1.2V
   - Bias voltage range maintains reasonable overdrive voltage
   - Transistor widths constrained to practical ranges

The function is named `create_circuit` as required, and maintains all the original imports including the `from model import nmos_params, pmos_params` statement. No load capacitors were present in the original circuit, so none were parameterized (as per your requirements).