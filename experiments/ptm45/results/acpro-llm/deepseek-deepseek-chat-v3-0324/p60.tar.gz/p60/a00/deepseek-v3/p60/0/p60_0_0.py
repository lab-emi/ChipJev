from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Opamp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Signals (DC bias for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for differential pair
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for differential pair
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS cascode bias
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Tail current bias
# MOSFET Definitions (45nm technology)
# NMOS: M1, M2 (diff pair), M3, M4 (cascode), M8 (tail current)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain6', 'Vbias1', 'Drain2', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('8', 'SourcePair', 'Vbias3', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS: M5, M6 (current mirror), M7 (cascode)
circuit.MOSFET('5', 'Vout', 'Drain6', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain6', 'Drain6', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain6', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
