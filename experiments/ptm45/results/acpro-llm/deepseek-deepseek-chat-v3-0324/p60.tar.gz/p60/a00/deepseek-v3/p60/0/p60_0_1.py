from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
   circuit.model('nmos_model', 'nmos', **nmos_params)
   circuit.model('pmos_model', 'pmos', **pmos_params)

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
