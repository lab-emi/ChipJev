from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
# Create circuit with proper indentation
circuit = Circuit('Telescopic Cascode Opamp')
# 1. Define MOSFET models (critical fix - was missing)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# 2. Power supplies and biasing
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Main supply
# Differential input bias at mid-rail (600mV)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Bias voltages for optimal operation:
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS cascode
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS cascode 
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.42@u_V)  # Tail current
# 3. Differential pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
# 4. NMOS cascode transistors (M3, M4)
circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain6', 'Vbias1', 'Drain2', circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
# 5. PMOS active load (M5-M7)
circuit.MOSFET('5', 'Vout', 'Drain6', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain6', 'Drain6', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain6', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=10e-6, l=0.045e-6)
# 6. Tail current source (M8)
circuit.MOSFET('8', 'SourcePair', 'Vbias3', circuit.gnd, circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
# Simulation setup
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
