from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Opamp')
    # 1. Define MOSFET models (using imported params)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # 2. Power supplies and biasing (fixed inputs)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed input bias
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed input bias
    # Parameterized bias voltages (0.8-1.2× original, max 1.2V)
    v_bias1 = min(params['v_bias1'], 1.2)
    v_bias2 = min(params['v_bias2'], 1.2)
    v_bias3 = min(params['v_bias3'], 1.2)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{v_bias1}@u_V")  # NMOS cascode
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{v_bias2}@u_V")  # PMOS cascode
    circuit.V('bias3', 'Vbias3', circuit.gnd, f"{v_bias3}@u_V")  # Tail current
    # 3. Differential pair with parameterized widths (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # 4. NMOS cascode transistors (M3, M4)
    circuit.MOSFET('3', 'Vout', 'Vbias1', 'Drain1', circuit.gnd,
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain6', 'Vbias1', 'Drain2', circuit.gnd,
                  model='nmos_model', w=params['w_M4'], l=0.045e-6)
    # 5. PMOS active load (M5-M7)
    circuit.MOSFET('5', 'Vout', 'Drain6', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Drain6', 'Drain6', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain6', 'Vbias2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M7'], l=0.045e-6)
    # 6. Tail current source (M8)
    circuit.MOSFET('8', 'SourcePair', 'Vbias3', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M8'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original, constrained to [Vth, 1.2V])
    'v_bias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # NMOS cascode bias
    'v_bias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # PMOS cascode bias
    'v_bias3': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Tail current bias
    # Differential pair (M1-M2)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    # NMOS cascode (M3-M4)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    # PMOS load (M5-M7)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    # Tail current source (M8)
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'v_bias1': 0.42,
    'v_bias2': 0.78,
    'v_bias3': 0.42,
    # Differential pair
    'w_M1': 5e-6,
    'w_M2': 5e-6,
    # NMOS cascode
    'w_M3': 5e-6,
    'w_M4': 5e-6,
    # PMOS load
    'w_M5': 10e-6,
    'w_M6': 10e-6,
    'w_M7': 10e-6,
    # Tail current
    'w_M8': 10e-6,
}
