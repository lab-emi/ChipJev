from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp (Corrected)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltage Generation (adjusted higher)
circuit.V('bias', 'Vbias', circuit.gnd, 0.5) # 0.5V bias for tail current
# Input Signals (DC bias adjusted higher)
circuit.V('inp', 'Vinp', circuit.gnd, 0.65) # 0.65V input bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.65) # 0.65V input bias
# Differential Pair and Active Load
# M1 and M2: Input differential pair (slightly wider)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
# M3: Diode-connected PMOS (narrower than M4)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M4: Active load PMOS (wider than M3)
circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# M5: Tail current source (larger to provide enough current)
circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
# M6: Bias generation for tail current
circuit.MOSFET('6', 'Vbias', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
