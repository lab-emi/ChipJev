from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    # Input Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-rail for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-rail for differential input
    # Transistors
    # Input Differential Pair
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Current Mirror Load
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source
    circuit.MOSFET('5', 'Source12', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Bias Generation
    circuit.MOSFET('6', 'Vbias', circuit.gnd, 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Compensation Network (parameterized)
    circuit.C('c', 'Vout', 'Drain1', f"{params['c_comp1']}p")
    circuit.R('c', 'Vout', 'NodeCc', f"{params['r_comp']}k")
    circuit.C('c2', 'NodeCc', 'Drain1', f"{params['c_comp2']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W range: 1-500× length (45nm))
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input diff pair transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input diff pair transistor 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Current mirror load transistor 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Current mirror load transistor 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source transistor
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Bias generation transistor
    # Bias voltage (constrained around original Vth + 0.2V = 0.42V)
    'vbias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original (0.42V), but must stay <1.2V
    # Compensation network
    'r_comp': {'min': 0.5, 'max': 2.0},         # 0.5-2× original (1kΩ)
    'c_comp1': {'min': 0.5, 'max': 5.0},        # 0.5-5× original (1pF)
    'c_comp2': {'min': 0.5, 'max': 5.0},        # 0.5-5× original (1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (um)
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 5e-6,
    'w_M4': 5e-6,
    'w_M5': 20e-6,
    'w_M6': 5e-6,
    # Bias voltage
    'vbias': 0.42,  # Original bias voltage
    # Compensation network
    'r_comp': 1.0,    # Original resistance (kΩ)
    'c_comp1': 1.0,   # Original capacitance (pF)
    'c_comp2': 1.0,   # Original capacitance (pF)
}
