from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltage (Vbias = Vth + 0.2V = 0.22 + 0.2 = 0.42V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)
# Input Voltages (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-rail for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-rail for differential input
# Transistors
# Input Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source12', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vout', 'Vinn', 'Source12', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Current Mirror Load
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)
# Tail Current Source
circuit.MOSFET('5', 'Source12', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Bias Generation
circuit.MOSFET('6', 'Vbias', circuit.gnd, 'Vdd', 'Vdd', model='pmos_model', w=5e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Vout', 'Drain1', 1@u_pF)
circuit.R('c', 'Vout', 'NodeCc', 1@u_kΩ)
circuit.C('c2', 'NodeCc', 'Drain1', 1@u_pF)  # Ensure proper compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
