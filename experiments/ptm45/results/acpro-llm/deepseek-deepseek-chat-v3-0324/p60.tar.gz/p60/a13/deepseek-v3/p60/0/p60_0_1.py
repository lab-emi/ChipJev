from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp (Corrected)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # For tail current M5 (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.8)   # For output load M7
# Differential Pair (M1, M2) and Tail Current (M5)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Output Stage (M6) with Load (M7)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
