from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp (Parameterized)')
    # Define MOSFET models (fixed parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (Vdd fixed, bias voltages parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Main supply (fixed)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])  # Tail current
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])  # Output load
    # Input voltages (fixed for DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.5)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.5)
    # Differential Pair (M1,M2) with Tail Current (M5)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Active Load (M3,M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Output Stage (M6) with Load (M7)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_m7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm-22.5µm)
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input transistor M1
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Input transistor M2
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load M3
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS load M4
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current M5
    'w_m6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output PMOS M6
    'w_m7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output NMOS M7
    # Bias voltages (0.8-1.2× original but ≤1.2V)
    'v_bias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (tail current)
    'v_bias2': {'min': 0.48, 'max': 0.72},    # Original: 0.6V (output load)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_m1': 12e-6,
    'w_m2': 12e-6,
    'w_m3': 25e-6,
    'w_m4': 25e-6,
    'w_m5': 25e-6,
    'w_m6': 45e-6,
    'w_m7': 18e-6,
    # Bias voltages (original values)
    'v_bias1': 0.42,
    'v_bias2': 0.6,
}
