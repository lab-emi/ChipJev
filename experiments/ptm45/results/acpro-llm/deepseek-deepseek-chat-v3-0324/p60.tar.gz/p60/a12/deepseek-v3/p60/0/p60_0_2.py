from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (1.2V typical for 45nm)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V assumed)
# Tail current bias: Vgs = Vth + 0.2V = 0.42V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  
# PMOS output stage bias: Vdd - (|Vth| + 0.2V) = 0.78V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  
# Input Differential Pair (NMOS)
# W/L = 10u/0.045u for input pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
# W/L = 20u/0.045u for current mirror
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (NMOS)
# W/L = 5u/0.045u for tail current
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
# Output Stage (PMOS Common-Source)
# W/L = 30u/0.045u for output stage
circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
               model='pmos_model', w=30e-6, l=0.045e-6)
# DC Path for Output (100kΩ resistor)
circuit.R('load', 'Vout', circuit.gnd, 100@u_kΩ)
# Miller Compensation (500fF with 1kΩ series resistor)
circuit.C('c', 'Vout', 'CompNode', 500@u_fF)  # Corrected unit from u_fF to u_pF
circuit.R('c', 'CompNode', 'Drain2', 1@u_kΩ)  # Series resistor for compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
