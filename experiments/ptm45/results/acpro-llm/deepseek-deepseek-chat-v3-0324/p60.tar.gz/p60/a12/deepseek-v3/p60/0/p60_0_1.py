from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages (Vth = 0.22V assumed)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # Vth + 0.2V = 0.42V for tail current
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.85)  # Vdd - (|Vth| + 0.2V) = 1.2 - 0.42 = 0.78V
                                                 # Adjusted to 0.85V for better Vds in M6
# Input Differential Pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Output Stage (PMOS Common-Source) - Now properly biased
circuit.MOSFET('6', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Additional biasing resistor to set output DC level
circuit.R('load', 'Vout', circuit.gnd, 100@u_kΩ)
# Miller Compensation Capacitor (reduced value for stability)
circuit.C('c', 'Vout', 'Drain2', 500@u_fF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
