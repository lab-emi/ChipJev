from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Power Supply and Bias Voltages (Vdd = 1.2V, Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # M5 bias (Vth + 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # M3/M4/M6 bias (Vdd - |Vth| - 0.2V)
# Input Signals (DC operating point, no AC yet)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for symmetry
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for symmetry
# Transistors (45nm technology, nominal sizing)
# Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Current Source (M5)
circuit.MOSFET('5', 'SourcePair', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Cascode Load (M3, M4)
circuit.MOSFET('3', 'Vout', 'Vbias_p', 'Drain1', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Drain2', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Current Mirror Load (M6)
circuit.MOSFET('6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
