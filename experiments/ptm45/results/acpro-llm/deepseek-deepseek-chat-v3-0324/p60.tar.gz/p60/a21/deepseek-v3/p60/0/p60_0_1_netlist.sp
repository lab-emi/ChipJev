Vdd Vdd 0 1.2V
Vbias_n Vbias_n 0 0.42V
Vbias_p Vbias_p 0 0.78V
Vinp Vinp 0 0.6V
Vinn Vinn 0 0.6V
M1 Drain1 Vinn SourcePair 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain2 Vinp SourcePair 0 nmos_model l=4.5e-08 w=5e-06
M5 SourcePair Vbias_n 0 0 nmos_model l=4.5e-08 w=1e-05
M3 Vout Vbias_p Drain1 Vdd pmos_model l=4.5e-08 w=1e-05
M4 Vout Vbias_p Drain2 Vdd pmos_model l=4.5e-08 w=1e-05
M6 Vout Vbias_p Vdd Vdd pmos_model l=4.5e-08 w=1e-05
.model nmos_model nmos (CGDO=1e-12 CGSO=1e-12 KP=0.0002 LAMBDA=0.1 VTO=0.22)
.model pmos_model pmos (CGDO=1e-12 CGSO=1e-12 KP=8e-05 LAMBDA=0.1 VTO=-0.22)

