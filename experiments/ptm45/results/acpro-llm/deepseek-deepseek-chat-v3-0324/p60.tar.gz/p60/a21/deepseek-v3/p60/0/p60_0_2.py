from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Telescopic Cascode Amplifier (Corrected)')
# Define MOSFET models (45nm technology)
circuit.model('nmos_model', 'nmos', 
              KP=200e-6, VTO=0.22, LAMBDA=0.1, CGSO=1e-12, CGDO=1e-12)
circuit.model('pmos_model', 'pmos', 
              KP=80e-6, VTO=-0.22, LAMBDA=0.1, CGSO=1e-12, CGDO=1e-12)
# Power Supply and Bias Voltages (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # M5 bias (Vth + 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.3@u_V)   # M3/M4/M6 bias (adjusted for PMOS saturation)
# Input Signals (Raised to 0.7V to ensure PMOS V_DS < V_GS - V_TH)
circuit.V('inp', 'Vinp', circuit.gnd, 0.7@u_V)  # 0.7V input
circuit.V('inn', 'Vinn', circuit.gnd, 0.7@u_V)  # 0.7V input
# Differential Pair (NMOS M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
# Tail Current Source (NMOS M5)
circuit.MOSFET('5', 'SourcePair', 'Vbias_n', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
# Cascode Load (PMOS M3, M4)
circuit.MOSFET('3', 'Vout', 'Vbias_p', 'Drain1', 'Vdd', 
              model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Drain2', 'Vdd', 
              model='pmos_model', w=10e-6, l=0.045e-6)
# Current Mirror Load (PMOS M6)
circuit.MOSFET('6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
              model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
