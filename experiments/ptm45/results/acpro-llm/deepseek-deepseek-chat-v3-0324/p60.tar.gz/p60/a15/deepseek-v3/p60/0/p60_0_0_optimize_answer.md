Here's the parameterized version of your single-stage differential amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier (Max GBW/Power)')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply and Bias Voltages
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed common-mode input voltage
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed common-mode input voltage
    
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (min: 45nm (1×L), max: 22.5um (500×L), logarithmic scale)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width
    
    # Bias voltage (conservative range around original 0.42V, staying above Vth but below 1.2V)
    'vbias': {'min': 0.336, 'max': 0.504, 'log': False},  # 0.8-1.2× original (0.42V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,   # Original M1 width (Differential pair)
    'w_M2': 10e-6,   # Original M2 width (Differential pair)
    'w_M3': 20e-6,   # Original M3 width (Active load)
    'w_M4': 20e-6,   # Original M4 width (Active load)
    'w_M5': 5e-6,    # Original M5 width (Tail current)
    'vbias': 0.42,   # Original bias voltage
}

# Parameter descriptions (for reference)
'''
Parameter descriptions:
- w_M1: Width of M1 (nMOS differential pair transistor 1)
- w_M2: Width of M2 (nMOS differential pair transistor 2)
- w_M3: Width of M3 (pMOS active load transistor 1)
- w_M4: Width of M4 (pMOS active load transistor 2)
- w_M5: Width of M5 (nMOS tail current source)
- vbias: Bias voltage for tail current source (should keep M5 in saturation)
'''
```

Key points about this implementation:
1. The `create_circuit` function takes a `params` dictionary and constructs the circuit with parameterized values
2. All transistor widths are parameterized while keeping length fixed at 45nm
3. The bias voltage is parameterized with a conservative range (0.8-1.2× original value) that won't push the circuit too far out of its operating region
4. Power supply (1.2V) and input voltages (0.6V) remain fixed as requested
5. Initial parameters exactly match the original circuit values
6. Parameter ranges are set according to your constraints (1-500× length for widths, etc.)
7. All initial parameter values are within their respective search ranges
8. No load capacitors were present in the original circuit, so none were parameterized

The parameter ranges are designed to:
- Keep transistors in their intended operating regions
- Maintain reasonable power consumption
- Allow optimization while preventing unrealistic device sizes
- Keep bias points within safe operating ranges (especially important for the tail current source)