from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # Input Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'Source12', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-100× minimum width for 45nm technology)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS width
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS width
    'w_M3': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # PMOS mirror width
    'w_M4': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # PMOS mirror width
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS width
    # Bias voltage (conservative range around original bias point)
    # Original 0.42V is Vth (0.22V) + 0.2V, so we keep within Vth + 0.1V to Vth + 0.3V
    'vbias': {'min': 0.32, 'max': 0.52, 'log': False},  # Vbias voltage
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original input pair width (M1)
    'w_M2': 10e-6,    # Original input pair width (M2)
    'w_M3': 20e-6,    # Original PMOS mirror width (M3)
    'w_M4': 20e-6,    # Original PMOS mirror width (M4)
    'w_M5': 10e-6,    # Original tail current width (M5)
    'vbias': 0.42,    # Original bias voltage (0.42V)
}
# Parameter descriptions for optimization documentation
parameter_descriptions = {
    'w_M1': "Width of input NMOS transistor M1 (Vinp side)",
    'w_M2': "Width of input NMOS transistor M2 (Vinn side)",
    'w_M3': "Width of PMOS load transistor M3 (current mirror)",
    'w_M4': "Width of PMOS load transistor M4 (current mirror)",
    'w_M5': "Width of tail current source NMOS transistor M5",
    'vbias': "Bias voltage for tail current source (Vth + overdrive)"
}
