Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp (Parameterized)')
    
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    
    # Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.5)  # Fixed input bias
    circuit.V('inn', 'Vinn', circuit.gnd, 0.5)  # Fixed input bias
    
    # Differential Input Stage
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    
    # Active Load (PMOS Current Mirror)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    
    # Second Gain Stage (PMOS Common-Source)
    circuit.MOSFET('6', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m6'], l=0.045e-6)
    
    # Load Resistor (parameterized)
    circuit.R('load', 'Vout', circuit.gnd, f"{params['r_load']}k")
    
    # Compensation Network (parameterized)
    circuit.C('c', 'Drain1', 'Vout', f"{params['c_comp']}p")
    circuit.R('c', 'Drain1', 'Vout', f"{params['r_comp']}k")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W ranges: 1-500× length (45nm))
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input diff pair NMOS 1
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input diff pair NMOS 2
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 1
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS current mirror 2
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output stage PMOS
    
    # Bias voltage (constrained to maintain proper operation)
    'vbias': {'min': 0.34, 'max': 0.50},  # Original 0.42V (Vth + 0.2V), range ±20%
    
    # Passive components
    'r_load': {'min': 5, 'max': 20, 'log': False},      # Load resistor: 0.5-2× original (10kΩ)
    'r_comp': {'min': 0.5, 'max': 2, 'log': False},     # Compensation resistor: 0.5-2× original (1kΩ)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True}       # Compensation cap: 0.5-5× original (1pF)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 10e-6,    # Original M1 width
    'w_m2': 10e-6,    # Original M2 width
    'w_m3': 20e-6,    # Original M3 width
    'w_m4': 20e-6,    # Original M4 width
    'w_m5': 5e-6,     # Original M5 width
    'w_m6': 20e-6,    # Original M6 width
    
    # Bias voltage
    'vbias': 0.42,    # Original Vbias value
    
    # Passive components
    'r_load': 10,     # Original load resistor (kΩ)
    'r_comp': 1,      # Original compensation resistor (kΩ)
    'c_comp': 1       # Original compensation capacitor (pF)
}
```

### Parameter Descriptions:

1. **Transistor Widths (w_m1-w_m6)**:
   - Controls current drive capability and gm for each transistor
   - Range: 1-500× minimum length (45nm) → 45nm to 22.5μm
   - Logarithmic scaling preferred due to wide dynamic range

2. **Bias Voltage (vbias)**:
   - Sets tail current source bias (Vth + 200mV in original)
   - Constrained to 0.34-0.50V to ensure proper saturation while staying <1.2V
   - Linear scaling as voltage offsets are more absolute

3. **Load Resistor (r_load)**:
   - Sets output impedance and DC gain
   - 0.5-2× original value (5-20kΩ) range to maintain proper biasing

4. **Compensation Network (r_comp, c_comp)**:
   - r_comp: 0.5-2kΩ range around original 1kΩ
   - c_comp: 0.5-5pF range around original 1pF (Miller capacitor)
   - Logarithmic scaling for capacitor due to wide typical ranges

### Note:
- All initial parameter values are exactly preserved from your original circuit
- All initial values fall within their specified search ranges
- Voltage bias ranges are conservative (±20%) to maintain proper operation
- Transistor lengths are fixed at 45nm (process minimum)
- Input voltages remain fixed as requested
- Power supply remains fixed at 1.2V