Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')

    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input Bias Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for differential input
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])

    # Differential Input Pair (M1, M2) - widths parameterized
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)

    # Active Load (M3, M4) - widths parameterized
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)

    # Tail Current Source (M5) - width parameterized
    circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)

    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W parameter, L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS (1-500× L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS (1-500× L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS (1-500× L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS (1-500× L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS (1-500× L)
    
    # Bias voltage (conservative range around original)
    'vbias': {'min': 0.34, 'max': 0.50},  # Original 0.42V (Vth + 0.2V), range ±0.08V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,  # Original width for M1
    'w_M2': 10e-6,  # Original width for M2
    'w_M3': 20e-6,  # Original width for M3
    'w_M4': 20e-6,  # Original width for M4
    'w_M5': 20e-6,  # Original width for M5
    'vbias': 0.42,  # Original bias voltage
}

# Brief parameter descriptions:
# w_M1, w_M2: Input differential pair transistor widths - affects transconductance and matching
# w_M3, w_M4: Active load PMOS widths - affects output impedance and gain
# w_M5: Tail current source width - sets bias current through differential pair
# vbias: Bias voltage for tail current - sets operating point (Vth + overdrive)
```

Key aspects of this implementation:
1. All transistor widths are parameterized while keeping lengths fixed at 45nm
2. Bias voltage is parameterized with conservative bounds (0.34-0.50V)
3. All initial parameter values match exactly with your original circuit
4. Power supply and input voltages remain fixed as required
5. Search ranges are set following your constraints:
   - Widths at 1-500× length (45nm to 22.5μm)
   - Bias voltage within ±0.08V of original (0.42V)
6. No load capacitors were present in your original circuit

The parameter ranges are designed to:
- Maintain meaningful device operation (W/L ratios between 1 and 500)
- Keep bias voltages in safe operating regions
- Allow sufficient exploration for optimization while staying physically reasonable