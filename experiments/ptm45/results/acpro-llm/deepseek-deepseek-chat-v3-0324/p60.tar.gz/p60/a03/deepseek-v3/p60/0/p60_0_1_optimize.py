from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Corrected Single-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('b', 'Vb', circuit.gnd, f"{params['v_b']}")  # Original: 0.42V (Vth + 0.2V)
    circuit.V('cm', 'Vcm', circuit.gnd, f"{params['v_cm']}")  # Original: 0.6V (Vdd/2)
    # Input Voltages (fixed DC operating points)
    circuit.V('inp', 'Vinp', 'Vcm', 0.01@u_V)  # Small differential offset
    circuit.V('inn', 'Vinn', 'Vcm', -0.01@u_V)  # Small differential offset
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    # Active Load (M3, M4 - diode-connected PMOS)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vb', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Output Stage (M6 - NMOS with pull-up resistor)
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W in meters, L fixed at 45nm)
    # Width range: 1-500× length (45nm-22.5µm), log scale
    'w_m1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (differential pair)
    'w_m2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (differential pair)
    'w_m3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (diode-connected PMOS load)
    'w_m4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (diode-connected PMOS load)
    'w_m5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (tail current source)
    'w_m6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M6 width (output stage)
    # Passive components
    'r_load': {'min': 5, 'max': 20, 'log': True},  # Load resistor (0.5-2× original 10kΩ)
    # Bias voltages (0.8-1.2× original, not exceeding 1.2V)
    'v_b': {'min': 0.34, 'max': 0.50},  # Vb (Vth + 0.2V original=0.42V)
    'v_cm': {'min': 0.48, 'max': 0.72},  # Vcm (Vdd/2 original=0.6V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 20e-6,
    'w_m6': 40e-6,
    # Passive components
    'r_load': 10,  # 10kΩ
    # Bias voltages
    'v_b': 0.42,  # Vb
    'v_cm': 0.6,  # Vcm
}
