from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Corrected Single-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('b', 'Vb', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
circuit.V('cm', 'Vcm', circuit.gnd, 0.6@u_V)  # Common-mode voltage (~Vdd/2)
# Input Voltages (DC operating points)
circuit.V('inp', 'Vinp', 'Vcm', 0.01@u_V)  # Small differential offset
circuit.V('inn', 'Vinn', 'Vcm', -0.01@u_V)  # Small differential offset
# Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (M3, M4 - diode-connected PMOS)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (M5)
circuit.MOSFET('5', 'SourcePair', 'Vb', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=20e-6, l=0.045e-6)
# Output Stage (M6 - NMOS with pull-up resistor)
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=40e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
