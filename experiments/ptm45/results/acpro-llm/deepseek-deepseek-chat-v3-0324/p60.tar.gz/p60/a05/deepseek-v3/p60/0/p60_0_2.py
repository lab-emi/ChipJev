from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Optimized Single-Stage Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For NMOS current source (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # For PMOS current mirror (Vdd - |Vth| - 0.2V)
# Input Signals (Mid-rail for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd,
              model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd,
              model='nmos_model', w=5@u_um, l=0.045@u_um)
# Current Mirror Load
circuit.MOSFET('3', 'Drain1', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=10@u_um, l=0.045@u_um)
# Tail Current Source
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd,
              model='nmos_model', w=20@u_um, l=0.045@u_um)
# Output Stage with Proper Biasing
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd',
              model='pmos_model', w=15@u_um, l=0.045@u_um)
# Bias Network for Output Stage
circuit.MOSFET('7', 'BiasNode', 'Vbias2', 'Vdd', 'Vdd',
              model='pmos_model', w=5@u_um, l=0.045@u_um)
circuit.R('1', 'BiasNode', 'Drain2', 50@u_kΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
