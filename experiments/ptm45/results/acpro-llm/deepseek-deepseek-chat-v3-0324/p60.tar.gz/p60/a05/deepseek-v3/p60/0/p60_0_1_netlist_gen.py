from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Single-Stage Opamp (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.42V
# Input Signals (DC bias at mid-rail for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Differential+ input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Differential- input
# Input Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# Active Load (M3, M4) - PMOS current mirror
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# Tail Current Source (M5)
circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=20@u_um, l=0.045@u_um)
# Output Stage (M6) - Corrected connection
# Gate connected to Drain2 to ensure proper V_GS (< Vth)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
               model='pmos_model', w=15@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
