from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage OTA')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply (fixed)
    # Bias Voltage for Tail Current Source (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail for differential input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail for differential input (fixed)
    # Differential Input Pair (M1, M2) - widths parameterized
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Tail Current Source (M3) - width parameterized
    circuit.MOSFET('3', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M3'], l=0.045e-6)
    # Active Load (M4, M5) - widths parameterized
    circuit.MOSFET('4', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M5'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500×L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500×L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500×L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500×L)
    # Bias voltage (0.8-1.2× original but <1.2V)
    'v_bias': {'min': 0.34, 'max': 0.5, 'log': False},  # Original was 0.42V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,   # Original M1 width
    'w_M2': 10e-6,   # Original M2 width
    'w_M3': 5e-6,    # Original M3 width
    'w_M4': 20e-6,   # Original M4 width
    'w_M5': 20e-6,   # Original M5 width
    'v_bias': 0.42,  # Original bias voltage
}
# Parameter descriptions:
# w_M1: Width of input transistor M1 (affects transconductance and input pair matching)
# w_M2: Width of input transistor M2 (affects transconductance and input pair matching)
# w_M3: Width of tail current source (sets bias current for differential pair)
# w_M4: Width of PMOS active load (affects output impedance and gain)
# w_M5: Width of PMOS active load (affects output impedance and gain)
# v_bias: Bias voltage for tail current source (sets operating point)
