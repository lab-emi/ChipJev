from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias (Vdd and inputs fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed mid-rail for operating point
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed mid-rail for operating point
    # Differential Pair and Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    # Tail Current Source
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Common-Source Amplifier and Bias
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (width only, length fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS diff pair
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS diff pair
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS active load
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS active load
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS tail current
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS CS stage
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS CS stage
    # Bias voltage (conservative range around original 0.42V)
    'vbias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original, staying above Vth
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 10e-6,    # Original width for M1
    'w_m2': 10e-6,    # Original width for M2
    'w_m3': 20e-6,    # Original width for M3
    'w_m4': 20e-6,    # Original width for M4
    'w_m5': 5e-6,     # Original width for M5
    'w_m6': 20e-6,    # Original width for M6
    'w_m7': 10e-6,    # Original width for M7
    'vbias': 0.42,    # Original bias voltage
}
