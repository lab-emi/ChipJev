from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp for Maximum GBW/Power')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
    # Bias Voltage for Tail Current Source (M3) - parameterized
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}@u_V")
    # Differential Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Common-mode voltage
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Common-mode voltage
    # Input Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Tail Current Source (M3) - parameterized width
    circuit.MOSFET('3', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    # Active Loads (M4, M5) - PMOS Current Mirror - parameterized widths
    circuit.MOSFET('4', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M5'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS (1-500×L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS (1-500×L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS (1-500×L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS (1-500×L)
    # Bias voltage
    'v_bias': {'min': 0.336, 'max': 0.504, 'log': False},  # Vth+0.2V ×0.8-1.2 (0.22V+0.2V=0.42V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 5e-6,    # Original M1 width
    'w_M2': 5e-6,    # Original M2 width
    'w_M3': 10e-6,   # Original M3 width
    'w_M4': 10e-6,   # Original M4 width
    'w_M5': 10e-6,   # Original M5 width
    # Bias voltage
    'v_bias': 0.42,  # Original bias voltage (Vth + 0.2V)
}
