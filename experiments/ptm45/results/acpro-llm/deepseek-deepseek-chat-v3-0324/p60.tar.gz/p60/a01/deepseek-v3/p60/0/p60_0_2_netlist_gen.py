from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Telescopic Cascode Opamp (Fixed)')
# Define MOSFET models (45nm parameters)
circuit.model('nmos_model', 'nmos', 
              LEVEL=1,
              VTO=0.22,      # Threshold voltage (V)
              KP=100e-6,     # Transconductance (A/V^2)
              LAMBDA=0.1)    # Channel-length modulation
circuit.model('pmos_model', 'pmos',
              LEVEL=1,
              VTO=-0.22,     # Negative threshold voltage
              KP=50e-6,
              LAMBDA=0.1)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # 1.2V supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)     # Tail current bias (Vth + 0.2V)
# Input Bias Voltages (Critical Fix!)
# Set Vinp slightly higher than Vinn to split current asymmetrically.
# This ensures M3's gate voltage is low enough for saturation.
circuit.V('inp', 'Vinp', circuit.gnd, 0.65)       # Slightly above mid-rail
circuit.V('inn', 'Vinn', circuit.gnd, 0.55)       # Slightly below mid-rail
# Differential Pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
# M4's gate connected to M3's gate (Drain2) to mirror current.
# M3's drain is Vout (output node).
circuit.MOSFET('3', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)  # Wider for better saturation
circuit.MOSFET('4', 'Drain2', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
