from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Telescopic Cascode Opamp')
# Define MOSFET models explicitly (since 'model.py' import may fail)
circuit.model('nmos_model', 'nmos', 
              LEVEL=1, 
              VTO=0.22,    # Threshold voltage (V)
              KP=100e-6,   # Transconductance parameter (A/V^2)
              LAMBDA=0.1,  # Channel-length modulation (1/V)
              GAMMA=0.5,   # Body effect parameter (sqrt(V))
              PHI=0.6)     # Surface potential (V)
circuit.model('pmos_model', 'pmos', 
              LEVEL=1, 
              VTO=-0.22,   # Negative threshold voltage for PMOS
              KP=50e-6,    # Lower KP for PMOS
              LAMBDA=0.1, 
              GAMMA=0.5, 
              PHI=0.6)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # Bias for tail current (Vth + 0.2V)
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-rail bias (Vdd/2)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-rail bias (Vdd/2)
# Differential Pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
# NOTE: M3 and M4 gates must be connected properly to avoid positive feedback!
circuit.MOSFET('3', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
