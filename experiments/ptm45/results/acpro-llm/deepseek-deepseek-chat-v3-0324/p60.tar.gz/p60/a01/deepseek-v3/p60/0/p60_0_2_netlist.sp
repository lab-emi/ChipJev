Vdd Vdd 0 1.2
Vbias Vbias 0 0.42
Vinp Vinp 0 0.65
Vinn Vinn 0 0.55
M1 Drain1 Vinp SourcePair 0 nmos_model l=4.5e-08 w=1e-05
M2 Drain2 Vinn SourcePair 0 nmos_model l=4.5e-08 w=1e-05
M3 Vout Drain2 Vdd Vdd pmos_model l=4.5e-08 w=2.5e-05
M4 Drain2 Drain2 Vdd Vdd pmos_model l=4.5e-08 w=2.5e-05
M5 SourcePair Vbias 0 0 nmos_model l=4.5e-08 w=5e-06
.model nmos_model nmos (KP=0.0001 LAMBDA=0.1 LEVEL=1 VTO=0.22)
.model pmos_model pmos (KP=5e-05 LAMBDA=0.1 LEVEL=1 VTO=-0.22)

