Here's the parameterized conversion of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp (GBW/Power Optimized)')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply and Input Voltages (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed input bias at Vdd/2
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed input bias at Vdd/2
    
    # Parameterized Bias Voltage (0.8-1.2× original, but ≤1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    
    # Input Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4 - PMOS Current Mirror)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5 - NMOS)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (original 0.42V, keeping conservative range around Vth + 0.2V)
    'vbias': {'min': 0.34, 'max': 0.50, 'log': False},  # 0.8-1.2× original
    
    # Input pair transistor widths (original 10µm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    
    # PMOS load transistor widths (original 20µm)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    
    # Tail current source width (original 5µm)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias': 0.42,    # Original bias voltage
    'w_M1': 10e-6,    # Original M1 width
    'w_M2': 10e-6,    # Original M2 width
    'w_M3': 20e-6,    # Original M3 width
    'w_M4': 20e-6,    # Original M4 width
    'w_M5': 5e-6,     # Original M5 width
}

### Parameter Descriptions:
# vbias: Tail current source bias voltage (Vth + overdrive). Critical for setting operating current.
# w_M1, w_M2: Input differential pair widths. Affects gm, noise, and input capacitance.
# w_M3, w_M4: PMOS active load widths. Sets load impedance and affects gain.
# w_M5: Tail current source width. Directly controls bias current and power consumption.
```

Key features of this implementation:
1. **Fixed Parameters**: Supply voltage and input voltages remain fixed at their original values
2. **Conservative Bias Range**: Vbias range (0.34-0.50V) keeps operation near Vth + overdrive while staying well below Vdd
3. **Transistor Sizing**: All widths are parameterized with 1-500× length range (45nm-22.5µm)
4. **Valid Initial Values**: All initial values exactly match the original circuit
5. **Physical Considerations**: All parameter ranges respect the 45nm technology constraints and maintain proper circuit operation

The optimization can now adjust transistor widths to trade off gain, bandwidth, power, and other performance metrics while maintaining proper bias conditions.