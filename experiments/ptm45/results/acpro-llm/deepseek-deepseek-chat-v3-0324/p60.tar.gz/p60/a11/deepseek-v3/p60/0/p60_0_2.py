from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier (Final Corrected)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages (Vth = 0.22V, Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45)  # Tail current bias (raised slightly)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.4)   # Lowered to ensure PMOS activation
circuit.V('inp', 'Vinp', circuit.gnd, 0.8)      # Increased input bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.8)      # Increased input bias
# Input Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
              model='nmos_model', w=12e-6, l=0.045e-6)  # Slightly wider
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
              model='nmos_model', w=12e-6, l=0.045e-6)
# Tail Current Source (M5)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
              model='nmos_model', w=5e-6, l=0.045e-6)
# Cascode Load (M3, M4) - PMOS devices
# Now properly biased with Vbias2=0.4V < Drain1/Drain2 (~0.7V)
circuit.MOSFET('3', 'Vout', 'Vbias2', 'Drain1', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias2', 'Drain2', 'Vdd', 
              model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
