from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Bias Voltage for Tail Current Source (M5) - parameterized
    circuit.V('bias', 'Vbias', circuit.gnd, params['bias_voltage'])
    # Differential Input Voltages (fixed DC operating points)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # 0.6V DC bias for Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # 0.6V DC bias for Vinn
    # Differential Pair (M1, M2) - widths parameterized
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Current Mirror Load (M3, M4) - widths parameterized
    circuit.MOSFET('3', 'Drain1', 'Vout', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vout', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (M5) - width and bias voltage parameterized
    circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage (0.42V original, constrained to stay near Vth + overdrive)
    'bias_voltage': {'min': 0.35, 'max': 0.5},  # Vth=0.22V + overdrive (0.13V to 0.28V)
    # Differential pair transistor widths (10μm original)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    # PMOS current mirror widths (20μm original)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
    # Tail current source width (20μm original)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'bias_voltage': 0.42,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
}
# Physical meaning of each parameter:
# - bias_voltage: Sets the tail current source operating point (Vth + overdrive voltage)
# - w_M1/w_M2: Widths of input differential pair NMOS transistors (affects gm, noise)
# - w_M3/w_M4: Widths of PMOS current mirror load (affects gain and output impedance)
# - w_M5: Width of tail current source NMOS (sets bias current for differential pair)
