Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)

    # Bias Voltage for Tail Current Source (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])

    # Common-Mode Input Voltages (fixed for operating point analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)

    # Differential Pair and Tail Current Source (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)

    # Active Load (parameterized widths)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)

    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (width only, length fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (nmos)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (nmos)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (nmos)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (pmos)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (pmos)
    
    # Bias voltage (conservative range around original Vth + 0.2V = 0.42V)
    'vbias': {'min': 0.34, 'max': 0.50},  # 0.8-1.2× original, staying above Vth (0.22V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original width of M1
    'w_M2': 10e-6,    # Original width of M2
    'w_M5': 20e-6,    # Original width of M5
    'w_M3': 20e-6,    # Original width of M3
    'w_M4': 20e-6,    # Original width of M4
    'vbias': 0.42,    # Original bias voltage (Vth + 0.2V)
}

# Parameter descriptions
"""
Parameter Descriptions:
- w_M1, w_M2: Widths of differential pair NMOS transistors (affects transconductance and matching)
- w_M5: Width of tail current source NMOS (sets bias current for the entire amplifier)
- w_M3, w_M4: Widths of active load PMOS transistors (sets load impedance and gain)
- vbias: Bias voltage for tail current source (controls operating current, but must stay above Vth)
"""
```

Key features of this implementation:

1. **Parameterized Elements**:
   - All transistor widths (W) are parameterized while keeping length (L) fixed at 45nm
   - Bias voltage (Vbias) is parameterized with conservative range to maintain proper operation

2. **Fixed Elements**:
   - Power supply (1.2V) remains fixed
   - Input common-mode voltages (0.6V) remain fixed
   - MOSFET models remain fixed (imported from external module)

3. **Search Ranges**:
   - Transistor widths: 1-500× the minimum length (45nm)
   - Bias voltage: ±20% of original value (0.42V), but constrained to stay above threshold voltage (0.22V)

4. **Compatibility**:
   - Function named exactly `create_circuit` as required
   - Maintains original import statement format
   - Initial parameters match all original values exactly

The ranges were chosen to:
- Keep transistors in moderate inversion (W/L between 1 and 500)
- Maintain reasonable bias conditions (Vbias stays above threshold)
- Allow sufficient exploration space for optimization while preventing unrealistic values
- Keep all voltages within the 1.2V supply constraint