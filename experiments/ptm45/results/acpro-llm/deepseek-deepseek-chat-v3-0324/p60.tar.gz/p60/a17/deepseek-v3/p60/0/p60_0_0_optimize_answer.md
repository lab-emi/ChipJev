Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input Signals (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Input signal Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Input signal Vinn
    
    # Bias Voltage for Tail Current Source (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    
    # Input Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - Diode-connected PMOS - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vout', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (L fixed at 45nm)
    'w_M1': {'min': 0.1e-6, 'max': 20e-6, 'log': True},  # Input pair width range: 0.1-20um (2.2-444×L)
    'w_M2': {'min': 0.1e-6, 'max': 20e-6, 'log': True},  # Input pair width range: 0.1-20um (2.2-444×L)
    'w_M3': {'min': 0.1e-6, 'max': 40e-6, 'log': True},  # PMOS load width range: 0.1-40um (2.2-888×L)
    'w_M4': {'min': 0.1e-6, 'max': 40e-6, 'log': True},  # PMOS load width range: 0.1-40um (2.2-888×L)
    'w_M5': {'min': 0.1e-6, 'max': 10e-6, 'log': True},  # Tail current width range: 0.1-10um (2.2-222×L)
    
    # Bias voltage
    'vbias': {'min': 0.34, 'max': 0.50, 'log': False},  # Bias voltage range (0.8-1.2× original, keeping above Vth)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,    # Original width value for M1
    'w_M2': 10e-6,    # Original width value for M2
    'w_M3': 20e-6,    # Original width value for M3
    'w_M4': 20e-6,    # Original width value for M4
    'w_M5': 5e-6,     # Original width value for M5
    'vbias': 0.42,    # Original bias voltage (Vth + 0.2V = 0.42V)
}

# Parameter descriptions
param_descriptions = {
    'w_M1': "Width of input transistor M1 (affects gm and input capacitance)",
    'w_M2': "Width of input transistor M2 (affects gm and input capacitance)",
    'w_M3': "Width of PMOS load transistor M3 (affects gain and output impedance)",
    'w_M4': "Width of PMOS load transistor M4 (affects gain and output impedance)",
    'w_M5': "Width of tail current transistor M5 (affects bias current and CMRR)",
    'vbias': "Bias voltage for tail current source (affects operating point and linear range)"
}
```

Key features of this implementation:

1. **Complete parameterization**:
   - All transistor widths are parameterized while keeping lengths fixed at 45nm
   - Bias voltage is parameterized with a conservative range around the original value

2. **Proper search ranges**:
   - Width ranges are set to 0.1um-20um for input pair (M1,M2) and tail current (M5)
   - PMOS loads (M3,M4) have slightly wider range (0.1um-40um) since they were originally larger
   - Bias voltage is constrained between 0.34V-0.50V (0.8-1.2× original, keeping above Vth)

3. **Original values preserved**:
   - initial_params contains exactly the values from your original circuit
   - All initial values are within their respective search ranges

4. **Safety constraints**:
   - Power supply (1.2V) and input voltages (0.6V) remain fixed
   - All voltage ranges are below 1.2V supply
   - Bias voltage ranges maintain proper circuit operation above threshold voltage

5. **Physical meanings**:
   - Each parameter has a clear description of its effect on circuit performance
   - Width parameters affect gm, gain, output impedance, and bias current
   - Bias voltage affects operating point and common-mode range

The parameter ranges are designed to allow meaningful optimization while keeping the circuit in its intended operating region. The logarithmic scales for width parameters help explore orders of magnitude efficiently during optimization.