Here's the parameterized implementation of your folded cascode opamp:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Folded Cascode Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Differential Input Pair (NMOS)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_n1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_n2'], l=0.045e-6)
    
    # Active Load (PMOS)
    circuit.MOSFET('3', 'Drain1', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_p3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_p4'], l=0.045e-6)
    
    # Cascode Transistor (NMOS)
    circuit.MOSFET('5', 'Vout', 'Vbias2', 'Drain2', circuit.gnd, 
                   model='nmos_model', w=params['w_n5'], l=0.045e-6)
    
    # Tail Current Source (NMOS)
    circuit.MOSFET('6', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_n6'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, keeping L=45nm fixed)
    'w_n1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS (M1)
    'w_n2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS (M2)
    'w_p3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS (M3)
    'w_p4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS (M4)
    'w_n5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Cascode NMOS (M5)
    'w_n6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS (M6)
    
    # Bias voltages (0.8-1.2× original, staying within 0-1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original 0.42V (Vth+0.2V)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original 0.78V (Vdd-|Vth|-0.2V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_n1': 5e-6,    # Original M1 width
    'w_n2': 5e-6,    # Original M2 width
    'w_p3': 10e-6,   # Original M3 width
    'w_p4': 10e-6,   # Original M4 width
    'w_n5': 5e-6,    # Original M5 width
    'w_n6': 10e-6,   # Original M6 width
    
    # Bias voltages
    'vbias1': 0.42,  # Original Vbias1 value
    'vbias2': 0.78,  # Original Vbias2 value
}

# Parameter descriptions
param_descriptions = {
    'w_n1': 'Width of NMOS input transistor M1 (Vinp path)',
    'w_n2': 'Width of NMOS input transistor M2 (Vinn path)',
    'w_p3': 'Width of PMOS active load M3 (Drain1 branch)',
    'w_p4': 'Width of PMOS active load M4 (output branch)',
    'w_n5': 'Width of NMOS cascode transistor M5',
    'w_n6': 'Width of NMOS tail current source M6',
    'vbias1': 'Bias voltage for tail current source (Vth + overdrive)',
    'vbias2': 'Bias voltage for cascode and active load (Vdd - |Vth| - overdrive)',
}
```

Key details about this implementation:

1. **Transistor Widths**: All widths are parameterized with a range of 1-500× the minimum length (45nm), giving a range of 45nm to 22.5μm. The logarithmic scale is appropriate for transistor sizing optimization.

2. **Bias Voltages**: 
   - Vbias1 (tail current source) original value was 0.42V (Vth + 0.2V). Range is 0.8-1.2× this value (0.336-0.504V), keeping enough overdrive.
   - Vbias2 (cascode/load) original value was 0.78V (Vdd - Vth - 0.2V). Range is 0.8-1.2× this value (0.624-0.936V), maintaining proper operation.

3. **Fixed Values**: Power supply (1.2V) and input voltages (0.6V) remain fixed as requested.

4. **Initial Parameters**: All original values are preserved exactly as in your circuit.

5. **Physical Constraints**: All parameters respect the fundamental constraints:
   - Max voltage ≤ 1.2V
   - Conservative bias ranges to maintain proper operation
   - W/L ratios within practical limits

The parameter descriptions provide clear documentation of each parameter's role in the circuit for optimization purposes.