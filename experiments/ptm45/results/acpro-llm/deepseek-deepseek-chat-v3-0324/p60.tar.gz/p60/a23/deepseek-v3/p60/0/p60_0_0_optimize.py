from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['Vbias']}V")  
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, f"{params['Vbias_p']}V")  
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed mid-rail bias
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed mid-rail bias
    # Differential Pair and Tail Current Source (W parameterized, L fixed)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Source_pair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'Source_pair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load (PMOS Current Mirror)
    circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Bias Circuit
    circuit.MOSFET('6', 'Vbias_p', 'Vbias_p', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× 45nm length → 45nm to 22.5μm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS mirror left
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS mirror right
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Bias PMOS
    # Bias voltages (conservative ranges around original values)
    'Vbias': {'min': 0.336, 'max': 0.504},  # Original 0.42V, ±20% (Vth + 0.2V ±20%)
    'Vbias_p': {'min': 0.624, 'max': 0.936},  # Original 0.78V, ±20% (Vdd - |Vth| - 0.2V ±20%)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 10e-6,
    'w_M5': 5e-6,
    'w_M6': 5e-6,
    # Bias voltages (original values)
    'Vbias': 0.42,
    'Vbias_p': 0.78,
}
"""
Parameter descriptions:
- w_M1, w_M2: Widths of differential pair NMOS transistors (affects Gm and matching)
- w_M3, w_M4: Widths of active load PMOS transistors (affects output impedance and mirror ratio)
- w_M5: Width of tail current source NMOS (sets bias current for differential pair)
- w_M6: Width of bias PMOS transistor (sets reference current)
- Vbias: Tail current bias voltage (sets operating point current)
- Vbias_p: PMOS current mirror bias voltage (sets load transistor operating point)
Note: All transistor lengths are fixed at 45nm (minimum feature size for this technology)
"""
