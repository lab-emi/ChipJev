from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (Vdd is fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")  # Cascode bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")  # Tail current bias
    # Input Signals (fixed for DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed mid-supply
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed mid-supply
    # Differential Pair (parameterized widths)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    # Cascode Transistors (parameterized widths)
    circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd, 
                   model='nmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vbias1', 'Drain2', circuit.gnd, 
                   model='nmos_model', w=params['w_m4'], l=0.045e-6)
    # Current Mirror Load (parameterized widths)
    circuit.MOSFET('5', 'Drain3', 'Drain3', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vout', 'Drain3', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    # Tail Current Source (parameterized width)
    circuit.MOSFET('7', 'SourcePair', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2x original, not exceeding 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504, 'log': False},  # Cascode bias voltage (V)
    'vbias2': {'min': 0.336, 'max': 0.504, 'log': False},  # Tail current bias (V)
    # Differential pair transistors (1-500x L)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (m)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (m)
    # Cascode transistors (1-500x L)
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (m)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (m)
    # PMOS current mirror load (1-500x L)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (m)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (m)
    # Tail current source (1-500x L)
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (m)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,    # Original cascode bias voltage (V)
    'vbias2': 0.42,    # Original tail current bias (V)
    'w_m1': 10e-6,     # Original M1 width (m)
    'w_m2': 10e-6,     # Original M2 width (m)
    'w_m3': 5e-6,      # Original M3 width (m)
    'w_m4': 5e-6,      # Original M4 width (m)
    'w_m5': 20e-6,     # Original M5 width (m)
    'w_m6': 20e-6,     # Original M6 width (m)
    'w_m7': 5e-6,      # Original M7 width (m)
}
