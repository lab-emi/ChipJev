from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Cascode bias
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # Tail current bias
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for DC analysis
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for DC analysis
# Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Cascode Transistors
circuit.MOSFET('3', 'Drain3', 'Vbias1', 'Drain1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias1', 'Drain2', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Current Mirror Load
circuit.MOSFET('5', 'Drain3', 'Drain3', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Vout', 'Drain3', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source
circuit.MOSFET('7', 'SourcePair', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
