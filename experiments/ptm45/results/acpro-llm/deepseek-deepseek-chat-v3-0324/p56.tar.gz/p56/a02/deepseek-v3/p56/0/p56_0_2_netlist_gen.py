from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Differential Amplifier with Zero Common-Mode Gain')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Input Stage - Differential Pair
# Matched NMOS transistors with identical sizing
circuit.MOSFET('1', 'drain1', 'Vinn', 'tail_node', circuit.gnd, 
              model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'drain2', 'Vinp', 'tail_node', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load - Perfect Current Mirror
# Diode-connected PMOS
circuit.MOSFET('3', 'drain1', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# Mirror PMOS (exact match)
circuit.MOSFET('4', 'drain2', 'drain1', 'Vdd', 'Vdd',
              model='pmos_model', w=20e-6, l=0.045e-6)
# Ideal Tail Current Source
# Using large channel length for high output impedance
circuit.MOSFET('5', 'tail_node', 'Vbias', circuit.gnd, circuit.gnd,
              model='nmos_model', w=10e-6, l=1e-6)
# Bias Voltage (Vth + 200mV overdrive)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
# Output Stage
circuit.R('load', 'drain2', 'Vout', 1@u_Ω)  # Small resistor for numerical stability
circuit.C('load', 'Vout', circuit.gnd, 1@u_pF)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
