from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp with High GBW and Zero Common-Mode Gain')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # Bias for tail current source (Vth + 0.2V)
# Input Differential Pair (Critical for CMRR)
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (Current Mirror with Matched Devices)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Diode-connected
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Mirror
# Tail Current Source (High Output Impedance)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Compensation Network (Ensures Stability)
circuit.C('c', 'Drain2', 'Drain1', 1@u_pF)  # Miller capacitor
circuit.R('z', 'Drain2', 'NodeZ', 1@u_kΩ)   # Nulling resistor
circuit.C('cz', 'NodeZ', 'Drain1', 0.1@u_pF)  # Zero cancellation
# Output Node
circuit.R('load', 'Drain2', 'Vout', 1@u_Ω)  # Small resistor to avoid floating node
circuit.C('load', 'Vout', circuit.gnd, 1@u_pF)  # Load capacitance
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
