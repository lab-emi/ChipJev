from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Telescopic Cascode Opamp (Fixed)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (NMOS: 0.5V, PMOS: 0.78V)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.5@u_V)  # Increased for saturation
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V
# Differential Inputs (0.55V for robust biasing)
circuit.V('inp', 'Vinp', circuit.gnd, 0.55@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.55@u_V)
# Differential Pair (M1, M2) and Tail Current (M5)
circuit.MOSFET('1', 'Vx1', 'Vinp', 'tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vx2', 'Vinn', 'tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'tail', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS Cascode Load (M3, M4)
circuit.MOSFET('3', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Connect NMOS drains to PMOS drains via 0Ω resistors
circuit.R('short1', 'Vx1', 'Vout', 0@u_Ω)
circuit.R('short2', 'Vx2', 'Vout', 0@u_Ω)
# Compensation Network (Cc = 0.1pF + Rc = 1kΩ for stability)
circuit.C('c', 'tail', 'Vout', 0.1@u_pF)
circuit.R('c', 'tail', 'Vmid', 1@u_kΩ)  # Series resistor for numerical stability
circuit.C('c2', 'Vmid', 'Vout', 0.1@u_pF)  # Split capacitor
# DC Path for Output Node (Rout = 1MΩ)
circuit.R('out', 'Vout', circuit.gnd, 1@u_MΩ)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
