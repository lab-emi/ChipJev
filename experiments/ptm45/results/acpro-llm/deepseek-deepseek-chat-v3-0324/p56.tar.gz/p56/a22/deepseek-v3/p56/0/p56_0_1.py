from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Telescopic Cascode Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages (NMOS: Vth + 0.2V, PMOS: Vdd - |Vth| - 0.2V)
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42)  # Tail current bias
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)  # Cascode load bias
# Differential Inputs (mid-supply for DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Common-mode voltage
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Differential Pair (M1, M2) and Tail Current Source (M5)
circuit.MOSFET('1', 'Vout_cascode1', 'Vinp', 'Source_common', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vout_cascode2', 'Vinn', 'Source_common', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source_common', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Cascode Load (M3, M4) 
# Drains explicitly connected to Vout (merged node)
circuit.MOSFET('3', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Capacitor (Cc) between output and common source
circuit.C('c', 'Source_common', 'Vout', 1@u_pF)
# Connect cascode outputs to Vout using 0-ohm resistors (SPICE-friendly)
circuit.R('short1', 'Vout_cascode1', 'Vout', 0@u_Ω)  # M1 drain to Vout
circuit.R('short2', 'Vout_cascode2', 'Vout', 0@u_Ω)  # M2 drain to Vout
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
