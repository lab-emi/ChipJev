from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp with Maximized GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (Vdd = 1.2V) - Fixed, not parameterized
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltage for M6 - Parameterized with conservative range
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}@u_V")
    # Input Voltages - Fixed, not parameterized
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Active Load (M3, M4) - Current Mirror
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (M5) and Biasing (M6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    circuit.MOSFET('6', 'Vbias', 'Vbias', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - 1-500× length (45nm), log scale
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair transistor 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Bias transistor
    # Bias voltage - Conservative range (0.8-1.2× original but ≤1.2V)
    'v_bias': {'min': 0.336, 'max': 0.504},  # Original: 0.42V, range: 0.8-1.2× with Vth=0.22V consideration
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 20e-6,    # Original width of M1
    'w_M2': 20e-6,    # Original width of M2
    'w_M3': 10e-6,    # Original width of M3
    'w_M4': 10e-6,    # Original width of M4
    'w_M5': 10e-6,    # Original width of M5
    'w_M6': 5e-6,     # Original width of M6
    # Bias voltage
    'v_bias': 0.42,   # Original bias voltage (Vth + 0.2V = 0.42V)
}
