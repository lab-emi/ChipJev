from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
     circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)
     circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
