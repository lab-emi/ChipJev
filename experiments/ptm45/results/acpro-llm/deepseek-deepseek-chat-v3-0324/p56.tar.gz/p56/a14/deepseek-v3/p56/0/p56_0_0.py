from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Folded Cascode Opamp')
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42) # Bias for NMOS tail current (Vth + 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78) # Bias for PMOS cascode load (Vdd - |Vth| - 0.2V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Differential input Vinp (set to mid-rail for DC analysis)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Differential input Vinn (set to mid-rail for DC analysis)
# Differential Pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (PMOS Folded Cascode)
circuit.MOSFET('3', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Output Connection
circuit.MOSFET('6', 'Vout', 'Drain1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6) # Cascode device
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
