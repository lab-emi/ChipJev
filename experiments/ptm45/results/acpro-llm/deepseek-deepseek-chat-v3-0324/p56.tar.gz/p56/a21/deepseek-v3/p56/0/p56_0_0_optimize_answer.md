Here's the parameterized version of your single-stage differential opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    
    # Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    
    # Bias Voltage for Tail Current Source (M5) - parameterized
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - PMOS Current Mirror - parameterized widths
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (1-500×L)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (1-500×L)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (1-500×L)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (1-500×L)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (1-500×L)
    
    # Bias voltage
    'vbias': {'min': 0.336, 'max': 0.504},  # Vbias range: 0.8-1.2× original (0.42V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original M1 width
    'w_M2': 5e-6,    # Original M2 width
    'w_M3': 10e-6,   # Original M3 width
    'w_M4': 10e-6,   # Original M4 width
    'w_M5': 10e-6,   # Original M5 width
    'vbias': 0.42,   # Original Vbias value
}

# Parameter descriptions:
# - w_M1, w_M2: Differential pair transistor widths - affects gain, bandwidth, and matching
# - w_M3, w_M4: Active load PMOS widths - affects output impedance and current mirror matching
# - w_M5: Tail current source width - sets bias current and affects common-mode rejection
# - vbias: Tail current source bias voltage - controls operating point and current
```

This implementation:
1. Maintains all fixed values (Vdd, Vinp, Vinn) as specified
2. Parameterizes all transistor widths (keeping L fixed at 45nm)
3. Parameterizes the bias voltage (Vbias) with a conservative range (0.8-1.2× original)
4. Uses logarithmic scaling for transistor widths (covering 3 orders of magnitude)
5. Preserves all original values exactly in initial_params
6. Includes detailed descriptions of each parameter's physical meaning
7. Ensures all initial values are within their respective search ranges

The ranges are designed to:
- Keep W/L ratios between 1 and 500 (45nm to 22.5μm)
- Maintain bias voltages within ±20% of original but never exceeding 1.2V
- Allow for significant optimization flexibility while keeping reasonable constraints