Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed common-mode input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed common-mode input

    # Parameterized bias voltage (original value: 0.42V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])

    # Differential Pair and Tail Current Source
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed 45nm channel length
    circuit.MOSFET('2', 'Vout', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed 45nm channel length
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M5'], 
                  l=0.045e-6)  # Fixed 45nm channel length

    # Active Load (PMOS Current Mirror)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M3'], 
                  l=0.045e-6)  # Fixed 45nm channel length
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M4'], 
                  l=0.045e-6)  # Fixed 45nm channel length

    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm) for input pair
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm) for input pair
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm) for PMOS load
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm) for PMOS load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm) for tail current
    
    # Bias voltage (original 0.42V, constrained to 0.8-1.2× but <1.2V)
    'v_bias': {'min': 0.336, 'max': 0.504, 'log': False},  # 0.8-1.2× original, below Vdd (1.2V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,   # Original width for M1
    'w_M2': 10e-6,   # Original width for M2
    'w_M3': 20e-6,   # Original width for M3
    'w_M4': 20e-6,   # Original width for M4
    'w_M5': 20e-6,   # Original width for M5
    'v_bias': 0.42,  # Original bias voltage (Vth + 0.2V)
}

"""
Parameter descriptions:
- w_M1, w_M2: Input differential pair transistor widths (affects gm and matching)
- w_M3, w_M4: PMOS current mirror/load transistor widths (sets load impedance)
- w_M5: Tail current source width (sets bias current)
- v_bias: Bias voltage for tail current (affects operating point and current)

Design constraints:
- All transistor lengths fixed at 45nm (technology minimum)
- Widths searchable from 1-500× length (45nm to 22.5μm)
- Bias voltage constrained to ±20% of original (0.42V) but never exceeds 1.2V supply
- Input voltages fixed at 0.6V (mid-rail)
- Power supply fixed at 1.2V (technology limit)
"""
```

Key features of this implementation:
1. **Preserved all original values** in `initial_params` exactly as specified
2. **Kept voltage sources fixed** for supply (1.2V) and inputs (0.6V) as requested
3. **Parameterized all transistor widths** with 1-500×L search ranges
4. **Conservative bias voltage range** (0.336-0.504V) maintaining Vth + overdrive
5. **No load capacitors** were present in original code so none were parameterized
6. **Maintained all MOSFET models** and connections from original design
7. **Documented all parameters** with their physical significance
8. **Kept exact import statement** from your requirements

The parameter ranges were set to ensure:
- All initial values are within their search ranges
- MOSFET operation remains in saturation region
- Bias points stay within reasonable operating conditions (Vth = 0.22V considered)
- No voltage exceeds the 1.2V supply limit
- Geometric constraints (1-500×L) maintained for all transistors