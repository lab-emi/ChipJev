from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage OpAmp with High GBW')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (Vth = 0.22V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                # Fixed 1.2V power supply
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Tail current bias (parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)              # Fixed DC bias for Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)              # Fixed DC bias for Vinn
    # Input Differential Pair (M1, M2) - NMOS
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'Source12', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Tail Current Source (M5) - NMOS
    circuit.MOSFET('5', 'Source12', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load (M3, M4) - PMOS (current mirror)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Pull-down resistor for proper Drain2 biasing (parameterized)
    circuit.R('1', 'Drain2', circuit.gnd, f"{params['r_1']}k")
    # Output Stage (M6) - PMOS (common-source amplifier)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Load resistor for output stage (parameterized)
    circuit.R('2', 'Vout', circuit.gnd, f"{params['r_2']}k")
    # Compensation Capacitor (Cc) for stability (parameterized)
    circuit.C('c', 'Drain2', 'Vout', f"{params['c_c']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W) - all lengths fixed at 45nm
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1: Input pair NMOS
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2: Input pair NMOS
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3: PMOS load
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4: PMOS load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5: Tail current NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6: Output stage PMOS
    # Passive components
    'r_1': {'min': 25, 'max': 100, 'log': True},     # Drain2 pull-down resistor (kΩ)
    'r_2': {'min': 10, 'max': 40, 'log': True},      # Output load resistor (kΩ)
    # Compensation capacitor
    'c_c': {'min': 0.5, 'max': 5.0, 'log': True},    # Compensation capacitance (pF)
    # Bias voltage (must stay within 0.8-1.2× original and below Vdd)
    'v_bias': {'min': 0.336, 'max': 0.504}           # Tail current bias voltage (V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 30e-6,
    # Passive components
    'r_1': 50,       # 50kΩ
    'r_2': 20,       # 20kΩ
    'c_c': 1,        # 1pF
    # Bias voltage
    'v_bias': 0.42   # Original 0.42V bias
}
# Physical meaning of each parameter:
# - w_M1, w_M2: Input differential pair transistor widths (affects gm and matching)
# - w_M3, w_M4: Active load PMOS widths (sets mirror ratio and load impedance)
# - w_M5: Tail current source width (sets bias current)
# - w_M6: Output stage width (affects gain and drive capability)
# - r_1: Pull-down resistor for proper Drain2 biasing
# - r_2: Output load resistor (sets DC operating point and gain)
# - c_c: Compensation capacitor (key for stability and phase margin)
# - v_bias: Tail current bias voltage (must stay above Vth to keep M5 in saturation)
