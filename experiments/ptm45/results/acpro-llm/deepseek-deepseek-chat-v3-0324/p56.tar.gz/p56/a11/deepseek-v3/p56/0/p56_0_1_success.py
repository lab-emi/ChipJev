from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # MOSFET parameters
circuit = Circuit('Telescopic Cascode Amplifier (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42@u_V)  # M3: Vth + 0.2V
circuit.V('bias_load', 'Vbias_load', circuit.gnd, 0.78@u_V)   # M4/M5: Vdd - |Vth| - 0.2V
# Input Common-Mode Voltage (0.7V to ensure M6 activation)
circuit.V('inp', 'Vinp', circuit.gnd, 0.7@u_V)  
circuit.V('inn', 'Vinn', circuit.gnd, 0.7@u_V)  
# Differential Pair (M1, M2) and Tail Current Source (M3)
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'SourcePair', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror: M4, M5)
circuit.MOSFET('4', 'Drain1', 'Vbias_load', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Drain2', 'Vbias_load', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Output Stage (M6: NMOS, M7: PMOS Diode-Connected Load)
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vout', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
