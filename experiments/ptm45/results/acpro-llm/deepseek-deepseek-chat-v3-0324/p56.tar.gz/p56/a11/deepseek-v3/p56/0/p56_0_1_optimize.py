from PySpice.Spice.Netlist import Circuit
from PySpice.Sspice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Telescopic Cascode Amplifier (Parameterized)')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, f"{params['v_bias_tail']}@u_V")
    circuit.V('bias_load', 'Vbias_load', circuit.gnd, f"{params['v_bias_load']}@u_V")
    # Input Common-Mode Voltage (fixed at 0.7V for M6 activation)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.7@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.7@u_V)
    # Differential Pair (M1, M2) and Tail Current Source (M3)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd,
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'SourcePair', 'Vbias_tail', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M3'], l=0.045e-6)
    # Active Load (PMOS Current Mirror: M4, M5)
    circuit.MOSFET('4', 'Drain1', 'Vbias_load', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Drain2', 'Vbias_load', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M5'], l=0.045e-6)
    # Output Stage (M6: NMOS, M7: PMOS Diode-Connected Load)
    circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd,
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vout', 'Vdd', 'Vdd',
                  model='pmos_model', w=params['w_M7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages
    'v_bias_tail': {'min': 0.33, 'max': 0.50},  # Original: 0.42V (Vth + 0.2V). Keep near threshold
    'v_bias_load': {'min': 0.62, 'max': 0.90},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
    # Transistor Widths (W ranges: 1-500× L = 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair transistor 2
    'w_M3': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # Tail current source (original 20um)
    'w_M4': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # PMOS load 1 (original 20um)
    'w_M5': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # PMOS load 2 (original 20um)
    'w_M6': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # Output stage NMOS (original 20um)
    'w_M7': {'min': 0.045e-6, 'max': 45e-6, 'log': True},    # Diode-connected PMOS (original 20um)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'v_bias_tail': 0.42,
    'v_bias_load': 0.78,
    # Transistor Widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
    'w_M6': 20e-6,
    'w_M7': 20e-6,
}
