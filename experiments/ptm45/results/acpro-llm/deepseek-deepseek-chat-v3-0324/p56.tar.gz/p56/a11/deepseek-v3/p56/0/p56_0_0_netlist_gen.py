from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Amplifier')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltage
circuit.V('bias', 'Vbias', circuit.gnd, 0.42) # 0.42V bias for tail current source
# Input Signals (DC bias for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Common-mode input voltage
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Common-mode input voltage
# Differential Pair and Tail Current Source
circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
circuit.MOSFET('4', 'Drain1', 'Drain5', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Drain5', 'Drain5', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Output Stage (Common-Source with PMOS Load)
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vout', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
