from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp (Fully Corrected)')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)               # Fixed 1.2V supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # Tail current bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # M6 bias
    # Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)             # Fixed DC bias
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)             # Fixed DC bias
    # Differential Pair Stage (widths parameterized)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Active Load (PMOS current mirror - widths parameterized)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Common-Source Stage with Stabilization (width parameterized)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Feedback resistors (parameterized)
    circuit.R('1', 'Vout', 'Vbias2', f"{params['r1']}@u_MΩ")   # DC feedback resistor
    circuit.R('2', 'Vout', circuit.gnd, f"{params['r2']}@u_kΩ") # Pull-down resistor
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to maintain proper operation)
    'vbias1': {'min': 0.4, 'max': 0.6},     # Tail current bias (Vth + 0.18V to Vth + 0.38V)
    'vbias2': {'min': 0.4, 'max': 0.6},     # M6 bias (Vdd - |Vth| - 0.7V to Vdd - |Vth| - 0.3V)
    # NMOS transistor widths (1-500× length = 45nm-22.5µm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair transistor 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair transistor 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current source
    # PMOS transistor widths (1-500× length = 45nm-22.5µm)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Current mirror load 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Current mirror load 2
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Output stage
    # Resistors (0.5-2× original values)
    'r1': {'min': 0.5, 'max': 2},           # DC feedback resistor (original 1MΩ)
    'r2': {'min': 50, 'max': 200},          # Pull-down resistor (original 100kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.5,
    'vbias2': 0.5,
    # NMOS widths
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M5': 10e-6,
    # PMOS widths
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_M6': 80e-6,
    # Resistors
    'r1': 1,        # Original 1MΩ
    'r2': 100,      # Original 100kΩ
}
