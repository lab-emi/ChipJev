from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp (Fully Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)               # 1.2V supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5@u_V)         # Tail current bias (Vth + 0.28V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.5@u_V)         # M6 bias (Vdd - |Vth| - 0.5V)
# Input Signals (DC bias for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)             # DC bias (mid-rail)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)             # DC bias (mid-rail)
# Differential Pair Stage
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (PMOS current mirror)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Common-Source Stage with Stabilization
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vbias2', 1@u_MΩ)                  # DC feedback for bias stability
circuit.R('2', 'Vout', circuit.gnd, 100@u_kΩ)             # Pull-down resistor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
