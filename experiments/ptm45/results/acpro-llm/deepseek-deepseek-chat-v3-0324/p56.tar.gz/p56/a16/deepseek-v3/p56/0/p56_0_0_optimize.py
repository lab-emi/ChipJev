from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp with High GBW')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Signal Sources (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias_n', 'Vbias_n', circuit.gnd, params['vbias_n']@u_V)
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['vbias_p']@u_V)
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'Tail', 'Vbias_n', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Bias Current Mirror (M6)
    circuit.MOSFET('6', 'Vbias_p', 'Vbias_p', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W ranges: 45nm-22.5μm, 1-500× length)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 1
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 2
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS 1
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS 2
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Bias mirror PMOS
    # Bias voltages (0.8-1.2× original, not exceeding 1.2V, staying above Vth)
    'vbias_n': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2), 'log': False},  # NMOS tail bias
    'vbias_p': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2), 'log': False},  # PMOS mirror bias
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 10e-6,
    # Bias voltages
    'vbias_n': 0.42,    # Original Vth + 0.2V (0.22V + 0.2V)
    'vbias_p': 0.78,    # Original Vdd - |Vth| - 0.2V (1.2 - 0.22 - 0.2)
}
