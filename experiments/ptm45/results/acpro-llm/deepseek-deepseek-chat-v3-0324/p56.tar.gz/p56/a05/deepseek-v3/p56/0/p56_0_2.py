from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Stabilized Single-Stage Opamp')
# 1. MOSFET MODEL DEFINITIONS (45nm technology)
circuit.model('nmos_model', 'nmos', 
              VTO=0.22, KP=100e-6, LAMBDA=0.05, GAMMA=0.3, PHI=0.9)  # Added finite output resistance (LAMBDA)
circuit.model('pmos_model', 'pmos', 
              VTO=-0.22, KP=50e-6, LAMBDA=0.05, GAMMA=0.3, PHI=0.9)
# 2. POWER SUPPLIES (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias voltages with small series resistors for convergence
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
circuit.R('bias_r', 'Vbias', 'Vbias_r', 1@u_Ω)  # Small resistor helps convergence
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)
circuit.R('bias_p_r', 'Vbias_p', 'Vbias_p_r', 1@u_Ω)
# 3. DIFFERENTIAL INPUT PAIR (NMOS M1, M2) with gate resistors
circuit.R('g1', 'Vinp', 'Vinp_g', 100@u_Ω)  # Gate resistors prevent floating nodes
circuit.MOSFET('1', 'Drain1', 'Vinp_g', 'Source_pair', circuit.gnd,
               model='nmos_model', w=10@u_um, l=0.045@u_um)
circuit.R('g2', 'Vinn', 'Vinn_g', 100@u_Ω)
circuit.MOSFET('2', 'Drain2', 'Vinn_g', 'Source_pair', circuit.gnd,
               model='nmos_model', w=10@u_um, l=0.045@u_um)
# 4. ACTIVE LOAD (PMOS M3, M4) with improved sizing
circuit.MOSFET('3', 'Drain1', 'Vbias_p_r', 'Vdd', 'Vdd',
               model='pmos_model', w=25@u_um, l=0.045@u_um)  # Increased width for better matching
circuit.MOSFET('4', 'Drain2', 'Vbias_p_r', 'Vdd', 'Vdd',
               model='pmos_model', w=25@u_um, l=0.045@u_um)
# 5. TAIL CURRENT SOURCE (NMOS M5) with degeneration resistor
circuit.MOSFET('5', 'Source_pair', 'Vbias_r', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5@u_um, l=0.045@u_um)
circuit.R('deg', 'Source_pair', 'Source_degen', 100@u_Ω)  # Degeneration improves stability
# 6. OUTPUT STAGE (PMOS M6) with stabilizing capacitor
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd',
               model='pmos_model', w=30@u_um, l=0.045@u_um)
circuit.C('load', 'Vout', circuit.gnd, 1@u_pF)  # Essential for stability
# 7. DUMMY LOAD (Prevents floating output)
circuit.R('load', 'Vout', circuit.gnd, 1@u_MΩ)  # High impedance load
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
