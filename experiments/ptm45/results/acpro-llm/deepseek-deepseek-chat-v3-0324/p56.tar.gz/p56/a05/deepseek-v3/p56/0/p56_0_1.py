from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Opamp')
# Define MOSFET models (45nm technology)
circuit.model('nmos_model', 'nmos', 
              VTO=0.22, KP=100e-6, LAMBDA=0.1, GAMMA=0.3, PHI=0.9)  # NMOS parameters
circuit.model('pmos_model', 'pmos', 
              VTO=-0.22, KP=50e-6, LAMBDA=0.1, GAMMA=0.3, PHI=0.9)  # PMOS parameters
# Power Supplies (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Vth_n + 0.2V = 0.42V for NMOS biasing
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # Vdd - |Vth_p| - 0.2V = 0.78V for PMOS biasing
# Differential Input Pair (NMOS M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, 
               model='nmos_model', w=10@u_um, l=0.045@u_um)  # W/L = 10µm/45nm
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd, 
               model='nmos_model', w=10@u_um, l=0.045@u_um)
# Active Load (PMOS M3, M4)
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', 
               model='pmos_model', w=20@u_um, l=0.045@u_um)  # Wider PMOS for current matching
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd', 
               model='pmos_model', w=20@u_um, l=0.045@u_um)
# Tail Current Source (NMOS M5)
circuit.MOSFET('5', 'Source_pair', 'Vbias', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)  # Smaller W for tail current
# Output Stage (PMOS M6)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
               model='pmos_model', w=30@u_um, l=0.045@u_um)  # Larger W for higher gain
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
