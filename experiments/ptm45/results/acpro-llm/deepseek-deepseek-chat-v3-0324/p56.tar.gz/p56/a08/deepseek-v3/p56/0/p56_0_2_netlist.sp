Vdd Vdd 0 1.2V
Vbias Vbias 0 0.42V
Vbias_p Vbias_p 0 0.78V
M1 Drain1 Vinp Source_pair 0 nmos_model l=4.5e-08 w=1e-05
M2 Drain2 Vinn Source_pair 0 nmos_model l=4.5e-08 w=1e-05
M5 Source_pair Vbias 0 0 nmos_model l=4.5e-08 w=5e-06
M3 Drain1 Vbias_p Vdd Vdd pmos_model l=4.5e-08 w=1.5e-05
M4 Drain2 Vbias_p Vdd Vdd pmos_model l=4.5e-08 w=1.5e-05
M6 Vout Drain2 Vdd Vdd pmos_model l=4.5e-08 w=3e-05
Cc Vout Drain2 2pF
Rc Drain2 Vout 1kOhm
Vinp Vinp 0 0.6V
Vinn Vinn 0 0.6V
.model nmos_model nmos (kp=0.0001 lambd=0.05 level=1 vto=0.22)
.model pmos_model pmos (kp=4e-05 lambd=0.05 level=1 vto=-0.22)

