from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Telescopic Cascode Op-Amp')
# --------------------------
# 1. MODEL DEFINITIONS (CRITICAL FIX)
# --------------------------
# Define MOSFET models with correct parameter names
circuit.model('nmos_model', 'nmos',
              level=1,
              kp=100e-6,    # Transconductance parameter
              vto=0.22,     # Threshold voltage
              lambd=0.05)   # Channel-length modulation (FIXED: was lambda)
circuit.model('pmos_model', 'pmos',
              level=1,
              kp=40e-6,
              vto=-0.22,    # Negative for PMOS
              lambd=0.05)   # Channel-length modulation (FIXED: was lambda)
# --------------------------
# 2. POWER SUPPLY & BIASING
# --------------------------
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)    # Main supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # NMOS bias = Vth + 0.2V
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS bias = Vdd-|Vth|-0.2V
# --------------------------
# 3. DIFFERENTIAL INPUT PAIR
# --------------------------
# M1: NMOS input transistor (Vinp)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
# M2: NMOS input transistor (Vinn)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd,
              model='nmos_model', w=10e-6, l=0.045e-6)
# M5: NMOS tail current source
circuit.MOSFET('5', 'Source_pair', 'Vbias', circuit.gnd, circuit.gnd,
              model='nmos_model', w=5e-6, l=0.045e-6)
# --------------------------
# 4. ACTIVE LOAD (PMOS CURRENT MIRROR)
# --------------------------
# M3: PMOS load transistor
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=15e-6, l=0.045e-6)
# M4: PMOS load transistor
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd',
              model='pmos_model', w=15e-6, l=0.045e-6)
# --------------------------
# 5. OUTPUT STAGE
# --------------------------
# M6: PMOS output driver
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd',
              model='pmos_model', w=30e-6, l=0.045e-6)
# --------------------------
# 6. COMPENSATION NETWORK
# --------------------------
circuit.C('c', 'Vout', 'Drain2', 2@u_pF)  # Miller compensation capacitor
circuit.R('c', 'Drain2', 'Vout', 1@u_kΩ)  # Nulling resistor
# --------------------------
# 7. INPUT STIMULI (DC operating point)
# --------------------------
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # DC bias at mid-rail
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # DC bias at mid-rail
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
