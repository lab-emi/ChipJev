from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Telescopic Cascode Op-Amp')
# --------------------------
# 1. MODEL DEFINITIONS (CRITICAL FIX)
# --------------------------
# Define MOSFET models explicitly instead of relying on external import
circuit.model('nmos_model', 'nmos', 
              level=1, kp=100e-6, vto=0.22, lambda=0.05)
circuit.model('pmos_model', 'pmos', 
              level=1, kp=40e-6, vto=-0.22, lambda=0.05)
# --------------------------
# 2. POWER SUPPLY & BIASING
# --------------------------
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Main supply
# Bias voltages (now with proper units)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # NMOS bias
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS bias
# --------------------------
# 3. INPUT STAGE
# --------------------------
# Differential pair (NMOS)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('5', 'Source_pair', 'Vbias', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# --------------------------
# 4. ACTIVE LOAD
# --------------------------
# PMOS current mirrors
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=15e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=15e-6, l=0.045e-6)
# --------------------------
# 5. OUTPUT STAGE
# --------------------------
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd',
               model='pmos_model', w=30e-6, l=0.045e-6)
# --------------------------
# 6. COMPENSATION NETWORK
# --------------------------
circuit.C('c', 'Vout', 'Drain2', 2@u_pF)  # Miller compensation
circuit.R('c', 'Drain2', 'Vout', 1@u_kΩ)  # Nulling resistor
# --------------------------
# 7. INPUT STIMULI (for testing)
# --------------------------
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # DC operating point
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
