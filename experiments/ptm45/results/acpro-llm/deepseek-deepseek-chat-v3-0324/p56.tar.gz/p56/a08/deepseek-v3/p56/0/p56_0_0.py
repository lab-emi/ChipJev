from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Telescopic Cascode Op-Amp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # Bias for tail current source (M5)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)  # Bias for PMOS active load (M3, M4)
# Input Signals
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Differential input (set to mid-rail for DC analysis)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Differential input
# MOSFET Definitions (45nm technology)
# Input Differential Pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (PMOS)
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (NMOS)
circuit.MOSFET('5', 'Source_pair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Output Stage (PMOS)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Vout', 'Drain2', 1@u_pF)  # Compensation capacitor
circuit.R('c', 'Drain2', 'Node_rc', 1@u_kΩ)  # Compensation resistor
circuit.C('c1', 'Node_rc', 'Vout', 1@u_pF)  # Additional capacitor to complete the network
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
