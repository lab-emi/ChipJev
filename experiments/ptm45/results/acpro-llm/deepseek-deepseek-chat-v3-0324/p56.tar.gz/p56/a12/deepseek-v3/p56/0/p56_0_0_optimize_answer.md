Here's the parameterized version of your folded-cascode opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Folded-Cascode Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Input Signals (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    
    # Differential Pair (M1, M2) and Tail Current Source (M5)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)
    circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m5'], 
                  l=0.045e-6)
    
    # Active Load (M3, M4 - PMOS Current Mirrors)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m3'], 
                  l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m4'], 
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltage
    'v_bias': {'min': 0.336, 'max': 0.504},  # 0.8-1.2× original 0.42V, staying above Vth
    
    # NMOS transistor widths
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    
    # PMOS transistor widths
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (45nm)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'v_bias': 0.42,
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m5': 20e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
}

"""
Parameter Descriptions:
- v_bias: Bias voltage for tail current source (M5). Kept within 0.8-1.2× original to maintain proper biasing.
- w_m1, w_m2: Differential pair transistor widths. Affects transconductance and matching.
- w_m5: Tail current source width. Controls bias current and thus power consumption.
- w_m3, w_m4: Active load transistor widths. Affects load impedance and current mirror matching.
All widths are optimized while keeping length fixed at 45nm (technology minimum).
"""
```

Key features of this implementation:
1. Strictly followed all your requirements including:
   - Fixed Vdd (1.2V) and input voltages (0.6V)
   - Parameterized all transistor widths (W) while keeping L fixed at 45nm
   - Parameterized bias voltage with conservative range (0.8-1.2× original)
   - Preserved exact original values in initial_params
2. Physical considerations:
   - Bias voltage range ensures transistors stay in saturation
   - Width ranges allow for reasonable current densities
   - Logarithmic scales for width parameters (common in transistor sizing)
3. Organization:
   - Clear separation between circuit function and parameter definitions
   - Documented parameter meanings and ranges
   - Proper unit handling throughout

The optimization framework can now use these definitions to explore the design space while maintaining physically reasonable operating conditions.