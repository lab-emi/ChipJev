from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Low Common-Mode Gain Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Main supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # Tail current (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # Load mirror (Vdd - |Vth| - 0.2V)
circuit.V('bias3', 'Vbias3', circuit.gnd, 0.3)   # Cascode bias (optimized for CM rejection)
circuit.V('bias6', 'Vbias6', circuit.gnd, 0.6)   # Output stage bias
# Differential Input Stage with Cascode
circuit.MOSFET('1', 'Drain1_int', 'Vinn', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2_int', 'Vinp', 'SourcePair', circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# Cascode Transistors
circuit.MOSFET('7', 'Drain1', 'Vbias3', 'Drain1_int', circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('8', 'Drain2', 'Vbias3', 'Drain2_int', circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load with Improved Matching
circuit.MOSFET('3', 'Drain1', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Output Stage
circuit.MOSFET('6', 'Vout', 'Vbias6', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.R('1', 'Vout', circuit.gnd, 100@u_kΩ)
# Compensation
circuit.C('c', 'Vbias6', circuit.gnd, 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
