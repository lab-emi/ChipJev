from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Opamp with High GBW')
# Define MOSFET models explicitly (since 'from model import...' may not work)
# Using simplified models for 45nm technology
# (Approximate parameters - adjust as needed for your technology)
circuit.model('nmos', 'nmos', level=1, vto=0.22, kp=100e-6, lambda=0.1)
circuit.model('pmos', 'pmos', level=1, vto=-0.22, kp=40e-6, lambda=0.1)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # Bias for tail current (Vth + 0.2V)
# Differential Input Stage (M1, M2, M3, M4, M5)
circuit.MOSFET('1', 'Vx', 'Vinp', 'Dtail', circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)  # M1
circuit.MOSFET('2', 'Vy', 'Vinn', 'Dtail', circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)  # M2
circuit.MOSFET('3', 'Vx', 'Vx', 'Vdd', 'Vdd', model='pmos', w=20e-6, l=0.045e-6)  # M3 (diode-connected)
circuit.MOSFET('4', 'Vy', 'Vx', 'Vdd', 'Vdd', model='pmos', w=20e-6, l=0.045e-6)  # M4
circuit.MOSFET('5', 'Dtail', 'Vbias', circuit.gnd, circuit.gnd, model='nmos', w=5e-6, l=0.045e-6)  # M5 (tail)
# Second Stage (Common-Source Amplifier, M6)
circuit.MOSFET('6', 'Vout', 'Vx', 'Vdd', 'Vdd', model='pmos', w=40e-6, l=0.045e-6)  # M6
# Compensation Capacitor
circuit.C('c', 'Vx', 'Vout', 1e-12)  # Cc = 1pF (for stability)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
