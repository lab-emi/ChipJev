from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Opamp with High GBW')
# Define MOSFET models explicitly (avoiding Python keywords)
# Model parameters for 45nm technology (approximate)
circuit.model('nmos', 'nmos', 
    level=1,
    vto=0.22,      # Threshold voltage (V)
    kp=100e-6,     # Transconductance parameter (A/V^2)
    lambda_=0.1    # Channel-length modulation (replaces 'lambda')
)
circuit.model('pmos', 'pmos', 
    level=1,
    vto=-0.22,     # Negative threshold voltage for PMOS
    kp=40e-6,      # Lower transconductance for PMOS
    lambda_=0.1
)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)   # 1.2V supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Tail bias (Vth + 0.2V)
# Differential Input Stage (M1-M5)
circuit.MOSFET('1', 'Vx', 'Vinp', 'Dtail', circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)  # M1 (NMOS input pair)
circuit.MOSFET('2', 'Vy', 'Vinn', 'Dtail', circuit.gnd, model='nmos', w=10e-6, l=0.045e-6)  # M2 (NMOS input pair)
circuit.MOSFET('3', 'Vx', 'Vx', 'Vdd', 'Vdd', model='pmos', w=20e-6, l=0.045e-6)  # M3 (Diode-connected PMOS load)
circuit.MOSFET('4', 'Vy', 'Vx', 'Vdd', 'Vdd', model='pmos', w=20e-6, l=0.045e-6)  # M4 (PMOS load)
circuit.MOSFET('5', 'Dtail', 'Vbias', circuit.gnd, circuit.gnd, model='nmos', w=5e-6, l=0.045e-6)  # M5 (Tail current source)
# Second Stage (Common-Source Amplifier, M6)
circuit.MOSFET('6', 'Vout', 'Vx', 'Vdd', 'Vdd', model='pmos', w=40e-6, l=0.045e-6)  # M6 (PMOS CS stage)
# Compensation Capacitor
circuit.C('c', 'Vx', 'Vout', 1@u_pF)  # 1pF for stability
# Run Simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
