from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters
circuit = Circuit('Single-Stage Opamp with CMRR Fix')
# MOSFET Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42@u_V)  # Vth + 0.2V (NMOS)
circuit.V('bias_pmos', 'Vbias_pmos', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V (PMOS)
# Differential Pair (M1, M2) with Matched Sizing
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.18e-6)  # Longer L for CMRR
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.18e-6)
# Current Mirror Load (M3, M4) - Identical Sizing
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
# Cascode Tail Current Source (M5, M5c) for High CMRR
circuit.MOSFET('5', 'Tail', 'Vbias_tail', 'Source5', circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.18e-6)
circuit.MOSFET('5c', 'Source5', 'Vbias_casc', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.18e-6)
circuit.V('bias_casc', 'Vbias_casc', circuit.gnd, 0.3@u_V)  # Cascode bias
# Output Stage (M6) with Load Resistor
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)  # DC operating point
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
