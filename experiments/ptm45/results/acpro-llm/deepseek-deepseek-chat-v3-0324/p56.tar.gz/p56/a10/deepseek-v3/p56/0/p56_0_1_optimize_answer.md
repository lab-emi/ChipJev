Here's the parameterized version of your single-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp with Maximized GBW (Parameterized)')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies and Bias Voltages (fixed inputs)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Fixed mid-rail bias for differential pair
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Fixed mid-rail bias for differential pair
    
    # Parameterized bias voltages
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)  # Tail current bias
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['vbias_p']@u_V)  # PMOS bias
    
    # Differential Pair (M1, M2) - parameterized widths
    circuit.MOSFET('1', 'Vout', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Bias1', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (M3, M4) - parameterized widths
    circuit.MOSFET('3', 'Vout', 'Bias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Bias1', 'Bias1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (M5) - parameterized width
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Output Stabilization Resistor - parameterized
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W in meters, L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width: 1-500×45nm
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width: 1-500×45nm
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width: 1-500×45nm
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width: 1-500×45nm
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width: 1-500×45nm
    
    # Bias voltages (V)
    'vbias': {'min': 0.336, 'max': 0.504},  # Vbias: ±20% of 0.42V (Vth + 0.2V)
    'vbias_p': {'min': 0.624, 'max': 0.936},  # Vbias_p: ±20% of 0.78V (Vdd - |Vth| - 0.2V)
    
    # Passive components
    'r_load': {'min': 50, 'max': 200, 'log': True},  # R1: 0.5-2× original 100kΩ
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    
    # Bias voltages
    'vbias': 0.42,
    'vbias_p': 0.78,
    
    # Passive components
    'r_load': 100,  # Original 100kΩ
}
```

### Physical Meaning of Parameters:
1. **Transistor Widths (w_M1-w_M5)**:
   - Control transconductance (gm) and current through each transistor
   - M1/M2 form the differential pair (input stage)
   - M3/M4 form the active load (PMOS current mirror)
   - M5 sets the tail current for the differential pair

2. **Bias Voltages**:
   - `vbias`: Sets the tail current bias voltage (Vth + 0.2V = 0.42V)
   - `vbias_p`: Sets the PMOS current mirror bias (Vdd - |Vth| - 0.2V = 0.78V)

3. **Passive Components**:
   - `r_load`: Output resistor (100kΩ) provides DC path while minimally loading the output

### Notes:
- All initial parameter values are exactly preserved from your original circuit
- Transistor lengths are fixed at 45nm (your specified technology node)
- Bias voltage ranges are constrained to ±20% of original values to maintain proper operation
- Width ranges allow 1-500× the minimum length (45nm) for reasonable device sizing
- The resistor range (50-200kΩ) ensures it doesn't become too small (loading) or too large (DC bias issues)
- No load capacitors were present in your original circuit, so none were parameterized