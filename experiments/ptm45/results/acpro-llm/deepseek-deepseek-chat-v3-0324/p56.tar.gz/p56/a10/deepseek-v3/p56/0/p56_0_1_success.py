from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp with Maximized GBW (Fixed)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail bias (for differential pair)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail bias (for differential pair)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Tail current bias (Vth + 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V = 0.78V)
# Differential Pair (M1, M2)
circuit.MOSFET('1', 'Vout', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Bias1', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (M3, M4) - PMOS current mirror with proper biasing
circuit.MOSFET('3', 'Vout', 'Bias1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Bias1', 'Bias1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (M5)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Output Stabilization Resistor (ensures DC path)
circuit.R('1', 'Vout', 'Vdd', 100@u_kΩ)  # High resistance to avoid loading the output
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
