Here's the parameterized version of your single-stage differential amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Differential Amplifier')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # 0.6V input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # 0.6V input (fixed)
    
    # Parameterized bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    
    # Differential Pair (M1, M2)
    circuit.MOSFET('1', 'Drain1', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1_M2'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1_M2'], l=0.045e-6)
    
    # Active Load (M3, M4)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3_M4'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3_M4'], l=0.045e-6)
    
    # Tail Current Source (M5)
    circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Biasing (M6)
    circuit.MOSFET('6', 'Vbias', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    
    # Compensation Capacitor (fixed at original value)
    circuit.C('1', 'Vout', 'Drain1', 1@u_pF)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # MOSFET widths (1-500× length (45nm))
    'w_M1_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Differential pair
    'w_M3_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},     # Tail current source
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},     # Bias transistor
    
    # Bias voltage (conservative range around original 0.42V)
    # Range is 0.8-1.2× original but stays above Vth (0.22V) and below Vdd (1.2V)
    'vbias': {'min': 0.34, 'max': 0.5, 'log': False},  # Original was 0.42V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1_M2': 10e-6,    # Original width for M1, M2
    'w_M3_M4': 20e-6,    # Original width for M3, M4
    'w_M5': 20e-6,       # Original width for M5
    'w_M6': 10e-6,       # Original width for M6
    'vbias': 0.42,       # Original bias voltage
}

"""
Parameter Descriptions:
- w_M1_M2: Width of input differential pair transistors (M1, M2)
- w_M3_M4: Width of active load PMOS transistors (M3, M4)
- w_M5: Width of tail current source transistor (M5)
- w_M6: Width of bias transistor (M6)
- vbias: Bias voltage for tail current source (M5)

Note: All MOSFET lengths are fixed at 45nm (technology minimum)
      Compensation capacitor is fixed at 1pF (original value)
      Power supply (1.2V) and input voltages (0.6V) are fixed
"""
```

Key features of this implementation:
1. All transistor lengths are fixed at 45nm (technology minimum)
2. Only transistor widths are parameterized, with ranges of 1-500× the length (45nm-22.5μm)
3. Bias voltage is parameterized with a conservative range (0.34V-0.5V) that:
   - Stays above threshold voltage (0.22V)
   - Doesn't exceed supply voltage (1.2V)
   - Provides enough current for proper operation
4. The compensation capacitor remains fixed at its original value (1pF)
5. Power supply (1.2V) and input voltages (0.6V) are fixed as requested
6. All initial parameter values match exactly the original circuit values
7. Each parameter has a reasonable search range as specified in your requirements

The parameter ranges are designed to maintain proper circuit operation while allowing sufficient flexibility for optimization. The logarithmic scales for transistor widths help explore orders of magnitude efficiently during optimization.