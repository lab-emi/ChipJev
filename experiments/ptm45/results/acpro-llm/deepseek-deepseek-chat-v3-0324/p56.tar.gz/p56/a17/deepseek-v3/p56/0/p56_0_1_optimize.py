from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Opamp')
    # Define the MOSFET models (fixed parameters from imported module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Bias Voltage for Tail Current Source (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    # Differential Input Voltages (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-supply for common-mode
    circuit.V('inn', 'Vinn', circuit.gnd, 0.65) # Slightly higher to bias M6 properly
    # Differential Pair and Active Load (transistor widths parameterized)
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    # Tail Current Source (parameterized)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Output Stage (parameterized)
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    # Load resistor (parameterized)
    circuit.R('1', 'Vout', circuit.gnd, f"{params['r_load']}k")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor Widths (1-500× length = 45e-9 to 22.5e-6)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS width
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Differential pair NMOS width
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Active load PMOS width
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Active load PMOS width
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current NMOS width
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Output stage PMOS width
    # Bias Voltage (0.8-1.2× original value, clamped to 0.42V-0.62V for proper operation)
    'vbias1': {'min': 0.42, 'max': 0.62},  # Tail current bias (Vth + 0.2V to Vth + 0.4V)
    # Load resistor (0.5-2× original value)
    'r_load': {'min': 5, 'max': 20},  # Load resistance in kΩ
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,  # Original M1 width
    'w_M2': 10e-6,  # Original M2 width
    'w_M3': 20e-6,  # Original M3 width
    'w_M4': 20e-6,  # Original M4 width
    'w_M5': 20e-6,  # Original M5 width
    'w_M6': 40e-6,  # Original M6 width
    # Bias voltage
    'vbias1': 0.52,  # Original tail current bias voltage
    # Load resistor
    'r_load': 10,    # Original load resistance (kΩ)
}
