from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp with Maximized GBW (Corrected)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages (Vth = 0.22V, Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # Vth + 0.2V
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V
circuit.V('bias_p2', 'Vbias_p2', circuit.gnd, 0.78@u_V)  # Additional bias for M6
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-rail DC bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-rail DC bias
# Input Differential Pair (M1, M2) - NMOS
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_common', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_common', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (M5) - NMOS
circuit.MOSFET('5', 'Source_common', 'Vbias_n', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
# Active Loads (M3, M4) - PMOS (Current Mirror)
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
# Output Stage (M6) - PMOS (Common-Source)
circuit.MOSFET('6', 'Vout', 'Vbias_p2', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)  # Gate tied to Vbias_p2
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
