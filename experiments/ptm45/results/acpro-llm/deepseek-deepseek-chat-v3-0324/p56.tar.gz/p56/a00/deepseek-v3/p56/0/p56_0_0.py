from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Opamp with Maximized GBW')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42)  # Bias for NMOS tail current source (Vth + 0.2V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)  # Bias for PMOS current mirror (Vdd - |Vth| - 0.2V)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp (mid-rail for differential input)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn (mid-rail for differential input)
# Input Differential Pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_common', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_common', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Tail Current Source (M5)
circuit.MOSFET('5', 'Source_common', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Loads (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Output Stage (M6)
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
