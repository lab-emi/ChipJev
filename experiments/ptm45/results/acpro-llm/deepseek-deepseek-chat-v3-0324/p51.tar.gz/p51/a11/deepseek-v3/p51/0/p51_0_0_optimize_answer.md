Here's the parameterized conversion of your single-stage amplifier with active load, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    
    # Parameterized bias voltage (constrained around original value)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Amplifying Transistor (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_nmos'], 
                   l=0.045e-6)
    
    # Active Load (PMOS) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model', 
                   w=params['w_pmos'], 
                   l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_nmos': {
        'min': 0.045e-6,  # 1× minimum width (L=45nm)
        'max': 22.5e-6,   # 500× length (500*45nm = 22.5μm)
        'log': True       # Logarithmic sampling for wide range
    },
    'w_pmos': {
        'min': 0.045e-6,  # 1× minimum width (L=45nm)
        'max': 22.5e-6,   # 500× length
        'log': True
    },
    
    # Bias voltage (constrained to stay near saturation region)
    'v_bias': {
        'min': 0.78 * 0.8,  # 0.8× original bias
        'max': min(0.78 * 1.2, 1.2),  # 1.2× original bias, but ≤ supply voltage
        'log': False
    }
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,      # Original NMOS width (5μm)
    'w_pmos': 10e-6,     # Original PMOS width (10μm)
    'v_bias': 0.78       # Original bias voltage (0.78V)
}
```

### Parameter Descriptions:
1. **w_nmos**: Width of NMOS amplifying transistor (M1). Affects transconductance and gain.
   - Range: 45nm to 22.5μm (1-500× length)
   - Original: 5μm

2. **w_pmos**: Width of PMOS active load (M2). Affects output impedance and gain.
   - Range: 45nm to 22.5μm (1-500× length)
   - Original: 10μm

3. **v_bias**: Bias voltage for PMOS gate. Controls operating point of active load.
   - Range: 0.624V to 0.936V (0.8-1.2× original, capped at supply voltage)
   - Original: 0.78V (Vdd - |Vth| - 0.2V)

### Implementation Notes:
- Kept all fixed values (Vdd, Vin) as specified in original circuit
- Maintained MOSFET lengths at 45nm (as per 45nm technology)
- Used conservative ranges for bias voltage to ensure PMOS stays in saturation
- Included MOSFET width ranges from 1× to 500× length (as requested)
- All initial parameter values are within their respective ranges
- No load capacitors were present in original circuit, so none were parameterized

The parameter ranges were chosen to:
- Keep bias voltages within safe operating regions (considering Vth=0.22V)
- Allow sufficient variation for optimization while preventing unrealistic geometries
- Maintain reasonable power consumption and operating points