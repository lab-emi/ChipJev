Here's the parameterized version of your single-stage amplifier with active load, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    
    # Parameterized bias voltage (original value 0.78V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  
    
    # Main Amplifying Transistor (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'], 
                   l=0.045e-6)  # Fixed 45nm length
    
    # Active Load (PMOS) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m2'], 
                   l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range: 1-500× 45nm
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range: 1-500× 45nm
    
    # Bias voltage (conservative range around original)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), but capped at 1.2V-Vth
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # Original NMOS width
    'w_m2': 10e-6,   # Original PMOS width
    'v_bias': 0.78,  # Original bias voltage
}
```

### Parameter Descriptions:
1. **w_m1**: Width of the NMOS input transistor (M1). Original value: 5µm. Search range: 45nm to 22.5µm (1-500× length).
2. **w_m2**: Width of the PMOS active load transistor (M2). Original value: 10µm. Search range: 45nm to 22.5µm (1-500× length).
3. **v_bias**: Bias voltage for the PMOS active load. Original value: 0.78V. Search range: 0.624V to 0.936V (0.8-1.2× original).

### Notes:
- The MOSFET lengths are fixed at 45nm as specified
- The input voltage (Vin) and supply voltage (Vdd) remain fixed
- The bias voltage range is constrained to stay within 20% of the original value (0.78V ± 20%) while never exceeding 1.2V - Vth (0.22V) = 0.98V
- Width ranges follow the 1-500× length guideline you specified
- All initial values exactly match your original circuit values
- Log scaling is used for transistor widths since they typically span several orders of magnitude

This parameterized form maintains all the original circuit functionality while allowing automated optimization of the key design parameters. The ranges are set conservatively to ensure the circuit remains functional during optimization.