from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with Active Load')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias voltage (Vth + 0.2V = 0.22 + 0.2 = 0.42V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)  # Bias for PMOS (Vdd - |Vth| - 0.2V = 1.2 - 0.22 - 0.2 = 0.78V)
# Main Amplifying Transistor (NMOS)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Active Load (PMOS)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
