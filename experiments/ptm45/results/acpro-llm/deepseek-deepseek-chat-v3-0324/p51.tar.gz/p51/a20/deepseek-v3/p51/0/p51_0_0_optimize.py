from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Common-Source Amplifier with Active Load')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    # Input voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed bias for NMOS
    # Bias voltage for PMOS (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}@u_V")
    # Transistors
    # M1: NMOS (common-source amplifier)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model',
                  w=params['w_m1'],  # Parameterized width
                  l=0.045e-6)        # Fixed length (45nm)
    # M2: PMOS (active load)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],  # Parameterized width
                  l=0.045e-6)        # Fixed length (45nm)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length for NMOS (original: 5um)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length for PMOS (original: 10um)
    # Bias voltage for PMOS (conservative range around original)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), below Vdd=1.2V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,      # Original NMOS width
    'w_m2': 10e-6,     # Original PMOS width
    'v_bias': 0.78,    # Original PMOS bias voltage
}
"""
Parameter Descriptions:
1. w_m1: Width of NMOS transistor M1 (common-source amplifier)
   - Affects transconductance and current capability
   - Original: 5um, Range: 45nm (1×L) to 22.5um (500×L)
2. w_m2: Width of PMOS transistor M2 (active load)
   - Affects load impedance and gain
   - Original: 10um, Range: 45nm (1×L) to 22.5um (500×L)
3. v_bias: Bias voltage for PMOS load
   - Should keep PMOS in saturation as active load
   - Original: 0.78V (Vdd - Vth - 0.2V)
   - Conservative range: ±20% (0.624-0.936V), keeping below Vdd=1.2V
"""
