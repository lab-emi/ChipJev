Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.78V
M1 Vout Vin 0 0 nmos_model l=4.5e-08m w=5e-06m
M2 Vout Vbias Vdd Vdd pmos_model l=4.5e-08m w=1e-05m
.model nmos_model nmos (kp=4e-05 lambd=0.1 level=54 vto=0.22)
.model pmos_model pmos (kp=2e-05 lambd=0.1 level=54 vto=-0.22)

