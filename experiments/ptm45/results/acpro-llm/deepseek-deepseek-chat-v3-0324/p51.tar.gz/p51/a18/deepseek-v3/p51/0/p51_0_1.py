from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Amplifier with Active Load')
# Define NMOS and PMOS models directly in the circuit (no external dependency)
# Using BSIM4 models for 45nm technology (simplified for PySpice compatibility)
circuit.model('nmos_model', 'nmos', 
    level=54,    # BSIM4
    vto=0.22,    # Threshold voltage (V)
    kp=4e-5,     # Transconductance parameter (A/V²)
    lambda=0.1,  # Channel-length modulation (1/V)
)
circuit.model('pmos_model', 'pmos', 
    level=54,    # BSIM4
    vto=-0.22,   # Threshold voltage (V)
    kp=2e-5,     # Transconductation parameter (A/V²)
    lambda=0.1,  # Channel-length modulation (1/V)
)
# Power Supplies (Fixed: Ensure Vbias sets M2 in saturation)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vin = Vth_nmos + 0.2V = 0.42V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Vbias = Vdd - |Vth_pmos| - 0.2V = 0.78V
# Transistors (Critical fixes: Bulk connections and units)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6@u_m, l=45e-9@u_m)  # NMOS (M1)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6@u_m, l=45e-9@u_m)  # PMOS (M2)
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p51/0/p51_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
