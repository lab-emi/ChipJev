from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply for 45nm technology
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    # Common-Source Stage with Active Load (PMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Length fixed by 45nm process
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'], 
                  l=0.045e-6)  # Length fixed by 45nm process
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping length fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length
    # Bias voltage
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original value (0.78V), capped at Vdd
                                             # Original was Vdd - |Vth| - 0.2V = 0.78V
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original width for M1
    'w_m2': 10e-6,    # Original width for M2
    'v_bias': 0.78,   # Original bias voltage (V)
}
# Brief description of parameters:
# - w_m1: Width of NMOS transistor (M1), affects transconductance and gain
# - w_m2: Width of PMOS transistor (M2), acts as active load and affects output impedance
# - v_bias: Bias voltage for PMOS gate, sets operating point of active load
