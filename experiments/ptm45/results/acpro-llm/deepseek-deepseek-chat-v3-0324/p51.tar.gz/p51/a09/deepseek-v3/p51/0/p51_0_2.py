from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
   analysis = simulator.operating_point()
   print(f"Vout = {float(analysis.Vout):.3f} V")

simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p51/0/p51_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
