Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply and Bias Voltages (Vdd and Vin fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    
    # Parameterized bias voltage (Vbias)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['vbias']}V")
    
    # Common-Source Stage with Active Load
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=45e-9)  # M1 (NMOS) - Length fixed at 45nm
    
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=45e-9)  # M2 (PMOS) - Length fixed at 45nm
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (L fixed at 45nm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS: 1-500× length (original 5um)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS: 1-500× length (original 10um)
    
    # Bias voltage (constrained to maintain reasonable operation)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), keeping within 0.2V of Vdd-Vth
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width (M1)
    'w_M2': 10e-6,    # Original PMOS width (M2)
    'vbias': 0.78,    # Original bias voltage (Vbias)
}
```

### Parameter Descriptions:

1. **Transistor Widths**:
   - `w_M1`: NMOS transistor width (M1) - Original value: 5µm
   - `w_M2`: PMOS transistor width (M2) - Original value: 10µm
   - Both have a range of 45nm to 22.5µm (1-500× the fixed 45nm length)
   - Logarithmic scale recommended for width optimization

2. **Bias Voltage**:
   - `vbias`: PMOS gate bias voltage (Vbias) - Original value: 0.78V
   - Constrained to 80-120% of original value (0.624V to 0.936V)
   - This keeps Vbias in a safe range between (Vdd - Vth - 0.42V) and (Vdd - Vth)

### Implementation Notes:
- All initial values exactly match your original circuit
- MOSFET lengths are fixed at 45nm (as per your 45nm technology requirement)
- Vdd (1.2V) and Vin (0.42V) remain fixed as required
- The bias voltage range is carefully constrained to maintain proper operation:
  - Minimum (0.624V) ensures the PMOS remains in saturation with reasonable overdrive
  - Maximum (0.936V) keeps it below Vdd while allowing some flexibility
- No load capacitors are present in your original circuit, so none were parameterized

This implementation is ready for use with optimization frameworks like Optuna, where you would use `param_ranges_definition` to specify the search space and `initial_params` as the starting point.