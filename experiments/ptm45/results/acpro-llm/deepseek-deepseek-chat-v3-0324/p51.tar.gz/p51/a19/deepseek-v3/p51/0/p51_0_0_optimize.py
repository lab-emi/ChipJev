from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply and Bias Voltages (Vdd and Vin fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    # Parameterized bias voltage (Vbias)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['vbias']}V")
    # Common-Source Stage with Active Load
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=45e-9)  # M1 (NMOS) - Length fixed at 45nm
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=45e-9)  # M2 (PMOS) - Length fixed at 45nm
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (L fixed at 45nm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS: 1-500× length (original 5um)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS: 1-500× length (original 10um)
    # Bias voltage (constrained to maintain reasonable operation)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), keeping within 0.2V of Vdd-Vth
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width (M1)
    'w_M2': 10e-6,    # Original PMOS width (M2)
    'vbias': 0.78,    # Original bias voltage (Vbias)
}
