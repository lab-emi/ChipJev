from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # MOSFET models (using imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply (1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Fixed input voltage (0.42V, set for NMOS saturation)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # Parameterized bias voltage (original 0.78V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    # NMOS M1: Common-Source Amplifier (width parameterized)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                  model='nmos_model', 
                  w=params['w_m1'],
                  l=0.045e-6)  # Fixed 45nm length
    # PMOS M2: Active Load (width parameterized)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width: 1-500× length (45nm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width: 1-500× length (45nm)
    # Bias voltage (conservative range around original 0.78V, ensuring PMOS saturation)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (but <1.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original NMOS width (5um)
    'w_m2': 10e-6,    # Original PMOS width (10um)
    'v_bias': 0.78,   # Original bias voltage (0.78V)
}
