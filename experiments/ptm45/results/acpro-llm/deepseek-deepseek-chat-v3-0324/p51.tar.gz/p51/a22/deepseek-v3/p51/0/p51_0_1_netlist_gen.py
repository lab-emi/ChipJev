from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Assumes model.py defines nmos_params and pmos_params
circuit = Circuit('Single-Stage Amplifier with Active Load')
# ===== FIX 1: EXPLICITLY DEFINE MOSFET MODELS =====
# Before using MOSFETs, we must define their models.
# Parameters (e.g., VTO=0.22V) should match the 45nm technology.
circuit.model('nmos_model', 'nmos', VTO=0.22, KP=100e-6, LAMBDA=0.1)
circuit.model('pmos_model', 'pmos', VTO=-0.22, KP=50e-6, LAMBDA=0.1)
# NOTE: If `model.py` provides exact params, use them instead.
# ===== FIX 2: CORRECT BIAS VOLTAGES (SATURATION) =====
# Vdd = 1.2V (given)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Vbias for PMOS: Vdd - |Vth| - 0.2V = 1.2 - 0.22 - 0.2 = 0.78V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)
# Vin for NMOS: Vth + 0.2V = 0.42V (to ensure saturation)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
# ===== FIX 3: MOSFET DEFINITIONS (CORRECT NODES & MODELS) =====
# NMOS M1: Common-Source Amplifier
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS M2: Active Load (Current Source)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
# ===== FIX 4: PROPER SPICE DIRECTIVES =====
# Ensure ground node '0' is explicitly defined (PySpice handles this automatically)
# No further changes needed beyond model declaration.
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p51/0/p51_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
