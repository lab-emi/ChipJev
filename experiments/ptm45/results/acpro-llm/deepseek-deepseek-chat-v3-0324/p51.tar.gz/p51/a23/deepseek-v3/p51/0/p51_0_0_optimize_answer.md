Here's the parameterized version of your single-stage amplifier with active load according to your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power Supply (Vdd = 1.2V) and Bias Voltages (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias (Vth + 0.2V)
    
    # Parameterized bias voltage for M2 (PMOS current source)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)

    # Main Amplifying Transistor (M1) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'],
                  l=0.045e-6)  # Fixed 45nm length

    # Active Load (M2 - PMOS Current Source) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_m2'],
                  l=0.045e-6)  # Fixed 45nm length
        
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # NMOS width (5e-6 original)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # PMOS width (10e-6 original)
    
    # Bias voltage for PMOS current source (0.8-1.2× original, but must be < 1.2V)
    'vbias': {'min': 0.624, 'max': 0.936},  # Original was 0.78V (Vdd - |Vth| - 0.2V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original NMOS width
    'w_m2': 10e-6,    # Original PMOS width
    'vbias': 0.78,    # Original bias voltage
}
```

### Parameter Descriptions:
1. **w_m1**: Width of NMOS input transistor (M1). Affects transconductance and gain.
   - Original: 5 µm
   - Range: 45 nm to 22.5 µm (1-500× the 45nm length)

2. **w_m2**: Width of PMOS active load (M2). Determines output impedance and gain.
   - Original: 10 µm
   - Range: 45 nm to 22.5 µm (1-500× the 45nm length)

3. **vbias**: Bias voltage for PMOS current source (M2). Sets operating point.
   - Original: 0.78V (1.2V - |Vth| - 0.2V)
   - Range: 0.624V to 0.936V (0.8-1.2× original, constrained below 1.2V)

### Key Implementation Notes:
- Fixed 45nm channel length (constant) for both transistors
- Input voltage (Vin) remains fixed at 0.42V (Vth + 0.2V)
- Power supply (Vdd) remains fixed at 1.2V
- Bias voltage range is carefully constrained to maintain proper operation:
  - Lower bound ensures |Vgs| > Vth for PMOS
  - Upper bound prevents gate voltage exceeding supply (1.2V)
- Width parameters use logarithmic scaling for optimization efficiency
- All initial parameter values exactly match the original circuit values
- No load capacitors present in this circuit to parameterize

This implementation provides a robust parameter space for optimization while maintaining reasonable operating conditions for the amplifier.