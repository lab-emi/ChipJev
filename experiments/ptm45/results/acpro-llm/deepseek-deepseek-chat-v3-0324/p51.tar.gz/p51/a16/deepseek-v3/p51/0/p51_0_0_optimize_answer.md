Here's the parameterized version of your single-stage common-source amplifier with active load, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Common-Source Amplifier with Active Load')

    # Define the MOSFET models (fixed models)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias M1
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)  # Bias M2
    
    # Transistors (45nm technology)
    # M1: NMOS (common-source amplifier)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed at 45nm
    
    # M2: PMOS (active load)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed at 45nm
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (constrained to 1-500×L where L = 45nm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # 1-500×45nm (NMOS)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # 1-500×45nm (PMOS)
    
    # Bias voltage (constrained to 0.8-1.2× original value, but must stay below 1.2V)
    # Original was 0.78V (Vdd - |Vth| - 0.2V), with Vth=0.22V, Vdd=1.2V
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2×0.78V (stays < 1.2V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,     # Original NMOS width
    'w_M2': 10e-6,    # Original PMOS width
    'v_bias': 0.78,   # Original bias voltage (V)
}

"""
Parameter Descriptions:
- w_M1: Width of NMOS transistor M1 (common-source amplifier device)
- w_M2: Width of PMOS transistor M2 (active load device)
- v_bias: Bias voltage for PMOS load (must keep PMOS in saturation)

Parameter Constraints:
- All transistor widths must be between 1-500× the fixed length (45nm)
- Bias voltage must stay within 0.8-1.2× the original design value (0.78V)
  to maintain proper biasing while allowing some optimization flexibility
- All voltage parameters must remain ≤1.2V (45nm supply voltage)
"""
```

Key features of this implementation:
1. Preserves all original values in `initial_params` exactly as requested
2. Keeps Vdd and Vin as fixed values (not parameterized)
3. Parameterizes the transistor widths (W) while keeping lengths (L) fixed at 45nm
4. Parameterizes the bias voltage with conservative constraints (0.8-1.2× original value)
5. All initial parameter values are within their respective search ranges
6. Maintains all original imports and model definitions
7. Includes clear documentation of parameter meanings and constraints

The ranges were chosen based on:
- NMOS/PMOS widths: 1-500×L (45nm-22.5μm) to cover reasonable device sizes
- Vbias: 0.624-0.936V (0.8-1.2× original 0.78V) to maintain proper PMOS operation without exceeding 1.2V

This configuration should provide good optimization flexibility while keeping the circuit in its intended operating region.