from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Single-Stage Amplifier with Active Load')
# Define MOSFET models (45nm technology typical parameters)
circuit.model('nmos_model', 'nmos', 
              kp=200e-6, vto=0.22, lambd=0.05, gamma=0.5, phi=0.6, tox=1e-9)  # Fixed: Replaced 'lambda' with 'lambd'
circuit.model('pmos_model', 'pmos', 
              kp=80e-6, vto=-0.22, lambd=0.05, gamma=0.5, phi=0.6, tox=1e-9)  # Fixed: Replaced 'lambda' with 'lambd'
# Power Supplies and Biases (Vdd = 1.2V, Vth = 0.22V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2 @ u_V)  # Power supply
circuit.V('in', 'Vin', circuit.gnd, 0.42 @ u_V)  # NMOS bias: Vth + 0.2V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78 @ u_V)  # PMOS bias: Vdd - |Vth| - 0.2V
# Main Amplifying NMOS (M1)
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=45e-9)  # W/L = 5um/45nm
# Active Load PMOS (M2)
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=45e-9)  # W/L = 10um/45nm
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p51/0/p51_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
