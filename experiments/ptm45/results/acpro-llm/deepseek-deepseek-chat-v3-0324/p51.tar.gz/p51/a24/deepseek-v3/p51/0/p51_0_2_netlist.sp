Vdd Vdd 0 1.2V
Vin Vin 0 0.42V
Vbias Vbias 0 0.78V
M1 Vout Vin 0 0 nmos_model l=4.5e-08 w=5e-06
M2 Vout Vbias Vdd Vdd pmos_model l=4.5e-08 w=1e-05
.model nmos_model nmos (gamma=0.5 kp=0.0002 lambd=0.05 phi=0.6 tox=1e-09 vto=0.22)
.model pmos_model pmos (gamma=0.5 kp=8e-05 lambd=0.05 phi=0.6 tox=1e-09 vto=-0.22)

