Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 45nm technology standard Vdd
    
    # Input Voltage (fixed at 0.42V = Vth + 0.2V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed bias for proper operation
    
    # PMOS Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Will be optimized
    
    # Main Amplifying Transistor (NMOS) - only width is parameterized
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Fixed at 45nm length
    
    # Active Load (PMOS Current Source) - only width is parameterized
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],
                  l=0.045e-6)  # Fixed at 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale for wide range)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (5µm original)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (10µm original)
    
    # Bias voltage range (conservative around original design)
    'v_bias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), staying 0.2V above |Vth|
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,      # Original NMOS width
    'w_m2': 10e-6,     # Original PMOS width
    'v_bias': 0.78,    # Original bias voltage (Vdd - |Vth| - 0.2V)
}

# Parameter descriptions for reference:
"""
w_m1: Width of NMOS amplifying transistor (affects transconductance and gain)
w_m2: Width of PMOS active load (affects output impedance and gain)
v_bias: Bias voltage for PMOS current source (affects operating point and output swing)
"""
```

Key features of this implementation:

1. **Transistor Sizing**:
   - Both NMOS (M1) and PMOS (M2) widths are parameterized with a range of 1-500× their length (45nm)
   - Length is fixed at 45nm as requested
   - Initial values match exactly your original circuit (5µm NMOS, 10µm PMOS)

2. **Bias Voltage**:
   - PMOS bias voltage (Vbias) is parameterized with a conservative range (0.62-0.94V)
   - Range ensures the PMOS stays in saturation (Vgs < Vth + 0.2V safety margin)
   - Initial value is exactly your original 0.78V calculation

3. **Fixed Parameters**:
   - Power supply Vdd remains fixed at 1.2V
   - Input bias Vin remains fixed at 0.42V (Vth + 0.2V)
   - All transistor lengths fixed at 45nm
   - No load capacitors were in your original circuit, so none were added

4. **Search Ranges**:
   - Transistor widths use logarithmic scaling due to wide possible range
   - Bias voltage uses linear scaling within safe operating limits

The implementation maintains all your original circuit values in `initial_params` while providing reasonable search ranges for optimization that respect the physical constraints of 45nm technology.