from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 45nm technology standard Vdd
    # Input Voltage (fixed at 0.42V = Vth + 0.2V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed bias for proper operation
    # PMOS Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Will be optimized
    # Main Amplifying Transistor (NMOS) - only width is parameterized
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'], 
                  l=0.045e-6)  # Fixed at 45nm length
    # Active Load (PMOS Current Source) - only width is parameterized
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],
                  l=0.045e-6)  # Fixed at 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale for wide range)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (5µm original)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (10µm original)
    # Bias voltage range (conservative around original design)
    'v_bias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), staying 0.2V above |Vth|
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,      # Original NMOS width
    'w_m2': 10e-6,     # Original PMOS width
    'v_bias': 0.78,    # Original bias voltage (Vdd - |Vth| - 0.2V)
}
# Parameter descriptions for reference:
"""
w_m1: Width of NMOS amplifying transistor (affects transconductance and gain)
w_m2: Width of PMOS active load (affects output impedance and gain)
v_bias: Bias voltage for PMOS current source (affects operating point and output swing)
"""
