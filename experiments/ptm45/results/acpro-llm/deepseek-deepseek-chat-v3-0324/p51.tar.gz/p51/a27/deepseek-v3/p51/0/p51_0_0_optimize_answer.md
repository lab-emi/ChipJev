I'll convert your single-stage amplifier with active load into a parameterized form following your requirements. Here's the implementation:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input Bias (fixed at original value - will be swept during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    
    # Parameterized Bias for PMOS Current Source
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # NMOS (M1) - Common-Source Amplifier (width parameterized)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M1']@u_um, l=0.045@u_um)
    
    # PMOS (M2) - Active Current Source Load (width parameterized)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M2']@u_um, l=0.045@u_um)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_M1': {'min': 0.1, 'max': 22.5, 'log': True},  # 1-500×L: 0.045μm to 22.5μm
    'w_M2': {'min': 0.1, 'max': 22.5, 'log': True},  # 1-500×L: 0.045μm to 22.5μm
    
    # Bias voltage for PMOS current source
    'vbias': {'min': 0.62, 'max': 0.94},  # Vdd - |Vth| ± 0.2V (0.78±0.16V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5.0,    # Original NMOS width (μm)
    'w_M2': 10.0,   # Original PMOS width (μm)
    'vbias': 0.78,  # Original bias voltage (V)
}

"""
Parameter Descriptions:
1. w_M1: Width of NMOS transistor M1 (common-source amplifier)
   - Critical for gain and bandwidth, affects gm and output impedance
   - Range: 0.1-22.5μm (1-500× length of 45nm)

2. w_M2: Width of PMOS transistor M2 (active current source load)
   - Determines output impedance and current drive capability
   - Range: 0.1-22.5μm (1-500× length of 45nm)

3. vbias: Bias voltage for PMOS current source
   - Sets operating point for M2, affects current mirror operation
   - Range: 0.62-0.94V (original 0.78V ± 0.16V, constrained by Vth and Vdd)
"""
```

Key points about this implementation:
1. The `create_circuit` function takes a `params` dictionary and builds the circuit with parameterized values
2. Fixed parameters (Vdd, Vin) remain at their original values as requested
3. Transistor lengths are fixed at 45nm while widths are parameterized
4. The PMOS bias voltage is parameterized with a conservative range that maintains proper operation
5. All original values are preserved in `initial_params`
6. Search ranges are set according to your constraints:
   - Transistor widths can vary from 1-500× their length (0.1μm to 22.5μm)
   - Bias voltage is constrained to ±0.16V around its original value (0.78V)
7. The ranges ensure initial values are within the search space
8. No load capacitors were present in the original circuit (none to fix)

The parameter ranges are designed to:
- Keep the circuit in its intended operating region
- Allow sufficient variation for optimization while maintaining reasonable device sizes
- Respect the 1.2V supply voltage constraint
- Maintain proper biasing conditions considering the threshold voltage of 0.22V