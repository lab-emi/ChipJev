from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Amplifier with Active Load')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Input Bias and Signal (DC only for operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Vth + 0.2V = 0.42V
# Bias for PMOS Current Source
circuit.V('bias', 'Vbias', circuit.gnd, 0.78@u_V)  # Vdd - |Vth| - 0.2V = 0.78V
# NMOS (M1) - Common-Source Amplifier
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5@u_um, l=0.045@u_um)
# PMOS (M2) - Active Current Source Load
circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
               model='pmos_model', w=10@u_um, l=0.045@u_um)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
