from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input Bias (fixed at original value - will be swept during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # Parameterized Bias for PMOS Current Source
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    # NMOS (M1) - Common-Source Amplifier (width parameterized)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M1']@u_um, l=0.045@u_um)
    # PMOS (M2) - Active Current Source Load (width parameterized)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M2']@u_um, l=0.045@u_um)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_M1': {'min': 0.1, 'max': 22.5, 'log': True},  # 1-500×L: 0.045μm to 22.5μm
    'w_M2': {'min': 0.1, 'max': 22.5, 'log': True},  # 1-500×L: 0.045μm to 22.5μm
    # Bias voltage for PMOS current source
    'vbias': {'min': 0.62, 'max': 0.94},  # Vdd - |Vth| ± 0.2V (0.78±0.16V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5.0,    # Original NMOS width (μm)
    'w_M2': 10.0,   # Original PMOS width (μm)
    'vbias': 0.78,  # Original bias voltage (V)
}
"""
Parameter Descriptions:
1. w_M1: Width of NMOS transistor M1 (common-source amplifier)
   - Critical for gain and bandwidth, affects gm and output impedance
   - Range: 0.1-22.5μm (1-500× length of 45nm)
2. w_M2: Width of PMOS transistor M2 (active current source load)
   - Determines output impedance and current drive capability
   - Range: 0.1-22.5μm (1-500× length of 45nm)
3. vbias: Bias voltage for PMOS current source
   - Sets operating point for M2, affects current mirror operation
   - Range: 0.62-0.94V (original 0.78V ± 0.16V, constrained by Vth and Vdd)
"""
