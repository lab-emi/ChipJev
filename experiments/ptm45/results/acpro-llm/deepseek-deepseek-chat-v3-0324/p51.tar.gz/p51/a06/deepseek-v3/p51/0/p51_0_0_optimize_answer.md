Here's the parameterized version of your single-stage amplifier with active load circuit:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    
    # Input voltage (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 0.045μm - 22.5μm)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5μm
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10μm
    
    # Bias voltage (conservative range around original 0.78V)
    # Kept within 0.8-1.2× of original, but constrained to valid operating range
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2×)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,     # Original NMOS width
    'w_pmos': 10e-6,    # Original PMOS width
    'v_bias': 0.78,     # Original bias voltage
}

"""
Parameter Descriptions:
1. w_nmos: Width of the NMOS input transistor (main amplifying device)
   - Affects transconductance (gm) and drain current
   - Original value: 5μm, Range: 0.045-22.5μm (1-500× length)
   
2. w_pmos: Width of the PMOS active load transistor
   - Affects output impedance and voltage gain
   - Original value: 10μm, Range: 0.045-22.5μm (1-500× length)
   
3. v_bias: Bias voltage for PMOS active load
   - Must keep PMOS in saturation while providing proper bias
   - Original value: 0.78V, Range: 0.624-0.936V (0.8-1.2× original)
   - Carefully constrained to avoid PMOS entering linear region
"""
```

Key aspects of this implementation:
1. **Fixed Values**: Supply voltage (1.2V) and input voltage (0.42V) remain fixed as requested
2. **Parameterized Values**:
   - Transistor widths (w_nmos, w_pmos) with 1-500× length constraint
   - Bias voltage (v_bias) with conservative ±20% range around original value
3. **Safety Constraints**:
   - All voltages stay below 1.2V supply limit
   - Bias voltage range (0.624-0.936V) prevents PMOS from entering linear region
   - Width ranges maintain reasonable aspect ratios (1-500× length)
4. **Initial Parameters**: Exactly match original circuit values
5. **Physical Meaning**: Each parameter's role is explained in the docstring

The ranges are designed to allow meaningful optimization while maintaining circuit operation in the intended regions. The logarithmic scaling for transistor widths helps explore different operating regimes effectively.