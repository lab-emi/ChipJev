Here's the parameterized version of your single-stage amplifier with active load, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # Define the MOSFET models (fixed models, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input Voltage (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Bias for NMOS (Vth + 0.2V = 0.42V)
    
    # Bias Voltage (parameterized, with conservative range around original value)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])
    
    # Main Amplifying Transistor (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Active Load (PMOS Current Source) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M2'],
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width: 1-500× length (45nm to 22.5µm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width: 1-500× length (45nm to 22.5µm)
    
    # Bias voltage (conservative range around original 0.78V)
    'vbias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original value (0.78V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original NMOS width (5µm)
    'w_M2': 10e-6,   # Original PMOS width (10µm)
    'vbias': 0.78,   # Original PMOS bias voltage (0.78V)
}
```

### Annotations and Rationale:

1. **Transistor Widths (w_M1, w_M2)**
   - Physical Meaning: Channel width of NMOS (M1) and PMOS (M2) transistors
   - Range: 1-500× the 45nm channel length (0.045µm to 22.5µm)
   - Logarithmic scaling for better coverage of orders of magnitude
   - Original values: 5µm and 10µm respectively

2. **Bias Voltage (vbias)**
   - Physical Meaning: Gate voltage for PMOS current source (Vbias)
   - Conservative range: ±20% of original value (0.78V ±20% → 0.624V-0.936V)
   - Stays within safe limits (Vdd - |Vth| - margin)
   - Ensures PMOS remains in saturation region

3. **Fixed Parameters**
   - Power supply (Vdd) fixed at 1.2V
   - Input bias (Vin) fixed at 0.42V (Vth + 200mV)
   - Channel length fixed at 45nm (technology constraint)
   - MOSFET models fixed (from imported parameters)

This implementation:
- Preserves all original values exactly in initial_params
- Maintains conservative ranges for bias voltages to ensure proper operation
- Allows sufficient exploration of transistor sizing
- Follows all specified constraints and naming requirements
- Is compatible with optimization frameworks like Optuna