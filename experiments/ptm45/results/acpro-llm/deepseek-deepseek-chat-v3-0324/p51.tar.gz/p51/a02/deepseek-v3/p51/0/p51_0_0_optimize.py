from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models (fixed models)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Input voltage (fixed at 0.42V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    # PMOS bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}@u_V")
    # Amplifier Stage - NMOS (parameterized width)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Amplifier Stage - PMOS (active load, parameterized width)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges (for Optuna or similar)
param_ranges_definition = {
    # Transistor widths (1-500× L = 0.045µm to 22.5µm)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width
    # Bias voltage (0.8-1.2× original, but constrained between Vth and Vdd-Vth)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original 0.78V ±20% (Vdd - |Vth| - 0.2V ±20%)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,    # Original NMOS width
    'w_pmos': 10e-6,   # Original PMOS width
    'v_bias': 0.78,    # Original bias voltage (V)
}
