Here's the parameterized version of your single-stage amplifier with active load, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # Define the MOSFET models (fixed models)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Input voltage (fixed at 0.42V)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    
    # PMOS bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, f"{params['v_bias']}@u_V")
    
    # Amplifier Stage - NMOS (parameterized width)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # Amplifier Stage - PMOS (active load, parameterized width)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges (for Optuna or similar)
param_ranges_definition = {
    # Transistor widths (1-500× L = 0.045µm to 22.5µm)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width
    
    # Bias voltage (0.8-1.2× original, but constrained between Vth and Vdd-Vth)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original 0.78V ±20% (Vdd - |Vth| - 0.2V ±20%)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,    # Original NMOS width
    'w_pmos': 10e-6,   # Original PMOS width
    'v_bias': 0.78,    # Original bias voltage (V)
}
```

### Parameter Descriptions:

1. **w_nmos**: Width of the input NMOS transistor (M1). The original value was 5µm. Allowed to vary between 45nm (1×L) to 22.5µm (500×L).

2. **w_pmos**: Width of the active load PMOS transistor (M2). The original value was 10µm. Allowed to vary between 45nm (1×L) to 22.5µm (500×L).

3. **v_bias**: Bias voltage for the PMOS active load. The original value was 0.78V (Vdd - |Vth| - 0.2V). Allowed to vary ±20% (0.624V to 0.936V) to maintain proper biasing while staying below Vdd (1.2V).

### Key Implementation Notes:

1. All fixed values (Vdd, Vin, and transistor lengths) are kept exactly as in the original design.

2. The bias voltage range is carefully constrained to:
   - Minimum: 0.78V * 0.8 = 0.624V (but still above NMOS threshold)
   - Maximum: 0.78V * 1.2 = 0.936V (but still below Vdd - |Vth|)

3. Transistor widths use logarithmic scaling (log=True) since optimal values often span multiple orders of magnitude.

4. Length is fixed at 45nm (0.045µm) as specified for this technology node.

5. The original values are preserved exactly in `initial_params` as required.

6. No load capacitors were present in the original circuit, but if added later they would remain fixed as per your requirements.