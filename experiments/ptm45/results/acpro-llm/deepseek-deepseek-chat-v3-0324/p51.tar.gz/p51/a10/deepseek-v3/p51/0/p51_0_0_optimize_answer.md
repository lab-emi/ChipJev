Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias
    
    # Parameterized bias voltage for M2 (Vbias)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    
    # Transistors - parameterized widths (length fixed at 45nm)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 45nm to 22.5um)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS width
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS width
    
    # Bias voltage ranges (0.8-1.2× original value, but within safe limits)
    'vbias': {'min': 0.624, 'max': 0.936},  # Original 0.78V (Vdd - |Vth| - 0.2V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original NMOS width
    'w_M2': 10e-6,   # Original PMOS width
    'vbias': 0.78,   # Original bias voltage
}

"""
Parameter descriptions:
- w_M1: NMOS (M1) transistor width - directly affects transconductance and loading
- w_M2: PMOS (M2) active load width - affects output impedance and gain
- vbias: Bias voltage for PMOS active load - sets operating point and output swing

Circuit notes:
- Original bias voltages were calculated at Vth + 0.2V for M1 (0.42V) and
  Vdd - |Vth| - 0.2V for M2 (0.78V) to ensure saturation operation
- Bias voltage range is limited to ±20% of original value (0.624V-0.936V) to
  maintain proper operating region while allowing optimization
- Transistor width ranges cover 1×L to 500×L (45nm to 22.5um) which is typical
  for analog circuits in 45nm technology
- Length is fixed at minimum (45nm) for all transistors
"""
```

Key features of this implementation:
1. **Fixed elements**:
   - Power supply (1.2V) remains fixed
   - Input bias (0.42V) remains fixed
   - Transistor lengths (45nm) remain fixed
   - MOSFET models remain unchanged

2. **Parameterized elements**:
   - NMOS and PMOS widths (w_M1, w_M2) with logarithmic scaling over 1-500×L range
   - PMOS bias voltage (vbias) with conservative ±20% range from original 0.78V

3. **Safety constraints**:
   - All voltages stay below 1.2V supply limit
   - Bias voltage stays within safe operating region (0.624V-0.936V)
   - Width ranges cover practical analog design values

4. **Original values preserved**:
   - initial_params contains the exact original values from your circuit
   - All initial values are within their respective search ranges

The parameter ranges were chosen to:
- Allow significant optimization flexibility
- Maintain reasonable physical dimensions for 45nm technology
- Keep the circuit operating in its intended region
- Prevent unrealistic or dangerous parameter combinations