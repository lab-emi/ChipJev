Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed values)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Fixed input bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)  # Parameterized PMOS bias
    
    # Common-Source Amplifier with Active Load
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'],
                  l=0.045e-6)  # Fixed 45nm length
    
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length = 0.045μm to 22.5μm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width range
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width range
    
    # Bias voltage (constrained to stay near original value to maintain operation)
    'v_bias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), but clamped to Vdd=1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,    # Original NMOS width (5μm)
    'w_m2': 10e-6,   # Original PMOS width (10μm)
    'v_bias': 0.78,  # Original bias voltage (0.78V)
}

# Parameter descriptions (for reference)
param_descriptions = {
    'w_m1': 'NMOS transistor width (main amplifier device)',
    'w_m2': 'PMOS transistor width (active load device)',
    'v_bias': 'PMOS gate bias voltage (sets operating point)',
}
```

Key aspects of this implementation:

1. **Fixed Values**: 
   - Power supply (Vdd) remains fixed at 1.2V
   - Input voltage (Vin) remains fixed at 0.42V
   - MOSFET lengths remain fixed at 45nm (0.045μm)

2. **Parameterized Values**:
   - Both NMOS and PMOS widths are parameterized with ranges from 45nm to 22.5μm (1-500× length)
   - PMOS bias voltage (Vbias) is parameterized with a conservative range around the original 0.78V value

3. **Voltage Constraints**:
   - The Vbias range (0.62V to 0.94V) ensures:
     - Doesn't exceed Vdd (1.2V)
     - Keeps the PMOS in saturation (Vbias must be > Vdd - |Vth| - 0.2V ≈ 0.78V)
     - Allows ±20% variation from original value

4. **Initial Values**:
   - All initial values exactly match your original circuit
   - All initial values are within their respective search ranges

5. **Physical Meaning**:
   - The widths (w_m1, w_m2) control transconductance and output resistance
   - The bias voltage (v_bias) sets the operating point and output DC level

Note that your original circuit didn't include any resistors or capacitors that needed parameterization. If you add them later, you would include them following the same pattern as shown in your example format.