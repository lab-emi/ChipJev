Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier (Common-Source with Active Load)')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply (45nm technology)
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Original: 0.78V
    
    # Input Voltage (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias = Vth + 0.2V = 0.42V
    
    # Common-Source Amplifier (M1) - NMOS
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'],  # Width parameterized
                  l=0.045e-6)  # Length fixed at 45nm
    
    # Active Load (M2: PMOS Current Source)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M2'],  # Width parameterized
                  l=0.045e-6)  # Length fixed at 45nm
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keeping L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (original: 5um)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (original: 10um)
    
    # Bias voltage (conservative range around original value)
    'vbias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V) ± Vth considerations
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,    # Original NMOS width (M1)
    'w_M2': 10e-6,   # Original PMOS width (M2)
    'vbias': 0.78,   # Original bias voltage
}

# Parameter descriptions (for reference)
"""
Parameter Descriptions:
- 'w_M1': Width of NMOS transistor M1 (common-source amplifier)
- 'w_M2': Width of PMOS transistor M2 (active load current source)
- 'vbias': Bias voltage for the PMOS current source (M2 gate voltage)

Constraints:
- All transistor widths maintain 1-500× length ratio (45nm)
- Bias voltage constrained to ±20% of original (0.62V-0.94V)
- All voltages remain <1.2V (technology supply voltage)
"""
```

Key aspects of this implementation:

1. **Voltage Sources**:
   - Vdd (1.2V) and Vin (0.42V) remain fixed as requested
   - Vbias is parameterized with a conservative range (0.62V-0.94V) considering:
     - Original value of 0.78V (Vdd - |Vth| - 0.2V)
     - Minimum constrained to be above Vdd - Vth (0.98V) would be too restrictive
     - ±20% range keeps operation near intended bias point

2. **Transistor Dimensions**:
   - Only widths are parameterized (lengths fixed at 45nm)
   - Width ranges set to 1-500× the length (45nm-22.5um)
   - Logarithmic sampling appropriate for device sizing

3. **Initial Values**:
   - All initial parameters exactly match original circuit values
   - All initial values are within their respective search ranges

4. **Constraints**:
   - All parameter ranges respect technology limits (Vdd=1.2V, Vth=0.22V)
   - Bias voltage range prevents deep triode operation of PMOS load
   - Width ranges maintain reasonable device geometries

5. **Missing Components**:
   - Note that your original circuit didn't include any resistors or capacitors
   - If you add these later, they should follow the 0.5-2× and 0.5-5× rules you specified

The parameter ranges are designed to maintain circuit functionality while allowing sufficient exploration space for optimization. The bias voltage range is particularly conservative to ensure the PMOS load remains in saturation.