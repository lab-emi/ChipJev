Here's the parameterized version of your single-stage amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
    
    # Bias Voltage for PMOS current source (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Input Signal (fixed DC bias)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)
    
    # Main Amplifying Transistor (M1 - NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                   model='nmos_model', 
                   w=params['w_m1'], 
                   l=0.045e-6)  # Fixed 45nm channel length
    
    # Active Load (M2 - PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                   model='pmos_model', 
                   w=params['w_m2'], 
                   l=0.045e-6)  # Fixed 45nm channel length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    
    # Bias voltage
    'v_bias': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original (0.78V), but constrained to maintain Vgs > Vth
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original NMOS width
    'w_m2': 10e-6,    # Original PMOS width
    'v_bias': 0.78,   # Original bias voltage (Vdd - |Vth| - 0.2 = 1.2 - 0.22 - 0.2)
}

"""
Parameter descriptions:
1. w_m1: Width of NMOS input transistor (M1). Affects transconductance and current.
   Range: 45nm to 22.5μm (1-500× length)
   
2. w_m2: Width of PMOS active load transistor (M2). Affects output resistance and gain.
   Range: 45nm to 22.5μm (1-500× length)
   
3. v_bias: Bias voltage for PMOS current source. Must keep M2 in saturation.
   Range: 0.62V to 0.94V (0.8-1.2× original, constrained by Vth)
   Note: Original was Vdd - |Vth| - 0.2 = 0.78V. The range maintains 
   Vgs > Vth while preventing too much current variation.
"""
```

Key aspects of this implementation:
1. All your specific requirements were followed precisely
2. The bias voltage range is conservatively set to maintain proper operation:
   - Lower bound (0.62V): ensures Vgs > Vth (0.22V) for the PMOS with Vdd=1.2V
   - Upper bound (0.94V): prevents excessive current while staying below Vdd
3. Transistor widths can vary widely (1-500× length) but must maintain reasonable aspect ratios
4. All initial parameters exactly match your original circuit values
5. The input voltage remains fixed at 0.42V (Vth + 0.2V) as specified
6. No load capacitors were present in the original, so none were parameterized
7. The function is named exactly `create_circuit` as required

This parameterization should allow effective optimization while maintaining circuit stability and intended operation regions.