Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # Define the MOSFET models (fixed, not parameterized)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
    
    # Input Voltage (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Bias for M1
    
    # Bias Voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Main Amplifying Transistor (M1) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'],
                  l=0.045e-6)  # Length fixed by 45nm process
    
    # Active Load (M2) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_M2'],
                  l=0.045e-6)  # Length fixed by 45nm process
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    
    # Bias voltage
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original (0.78V), constrained to <1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,     # Original width value for M1
    'w_M2': 20e-6,     # Original width value for M2
    'v_bias': 0.78,    # Original bias voltage (Vdd - |Vth| - 0.2V)
}

# Parameter descriptions (for reference)
parameter_descriptions = {
    'w_M1': "Width of NMOS amplifying transistor (M1)",
    'w_M2': "Width of PMOS active load transistor (M2)",
    'v_bias': "Bias voltage for PMOS active load (Vbias)",
}
```

Key design decisions:

1. **Transistor Widths**: 
   - Both M1 and M2 widths are parameterized with ranges of 1-500× the minimum length (45nm) as requested
   - Kept logarithmic scaling for better optimization performance

2. **Bias Voltage**:
   - Vbias is parameterized with a conservative range (0.8-1.2× original value)
   - Range limited to 0.624-0.936V to stay below Vdd (1.2V) and maintain proper operation
   - Original value (0.78V) was chosen to be Vdd - |Vth| - 0.2V, so we maintain this relationship

3. **Fixed Parameters**:
   - Power supply (Vdd) remains fixed at 1.2V
   - Input voltage (Vin) remains fixed at 0.42V (Vth + 0.2V)
   - Transistor lengths remain fixed at 45nm
   - No load capacitors were present in the original circuit

4. **Initial Values**:
   - All initial parameters exactly match the original circuit values
   - All initial values are within their respective search ranges

The parameter ranges are designed to maintain circuit functionality while allowing sufficient exploration during optimization. The bias voltage range is particularly constrained to ensure the PMOS load transistor remains in saturation.