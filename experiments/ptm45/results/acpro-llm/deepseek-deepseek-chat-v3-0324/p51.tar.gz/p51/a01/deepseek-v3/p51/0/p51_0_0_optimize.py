from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias = Vth + 0.2 = 0.42V
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    # Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed at 45nm process length
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed at 45nm process length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (only W is parameterized, L is fixed at 45nm)
    'w_M1': {
        'min': 0.045e-6,  # Minimum width (1×L)
        'max': 22.5e-6,   # Maximum width (500×L)
        'log': True       # Logarithmic sampling
    },
    'w_M2': {
        'min': 0.045e-6,  # Minimum width (1×L)
        'max': 22.5e-6,   # Maximum width (500×L)
        'log': True       # Logarithmic sampling
    },
    # Bias voltage (conservative range around original value)
    'vbias': {
        'min': 0.624,     # 0.8× original (0.8*0.78=0.624)
        'max': 0.936,     # 1.2× original (1.2*0.78=0.936), but <1.2V
        'log': False      # Linear sampling for voltages
    }
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,        # Original NMOS width
    'w_M2': 10e-6,       # Original PMOS width
    'vbias': 0.78        # Original bias voltage (Vdd - |Vth| - 0.2)
}
