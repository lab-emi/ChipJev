Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Input bias = Vth + 0.2 = 0.42V
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias'])  # Parameterized bias voltage
    
    # Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed at 45nm process length
    
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed at 45nm process length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (only W is parameterized, L is fixed at 45nm)
    'w_M1': {
        'min': 0.045e-6,  # Minimum width (1×L)
        'max': 22.5e-6,   # Maximum width (500×L)
        'log': True       # Logarithmic sampling
    },
    'w_M2': {
        'min': 0.045e-6,  # Minimum width (1×L)
        'max': 22.5e-6,   # Maximum width (500×L)
        'log': True       # Logarithmic sampling
    },
    
    # Bias voltage (conservative range around original value)
    'vbias': {
        'min': 0.624,     # 0.8× original (0.8*0.78=0.624)
        'max': 0.936,     # 1.2× original (1.2*0.78=0.936), but <1.2V
        'log': False      # Linear sampling for voltages
    }
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,        # Original NMOS width
    'w_M2': 10e-6,       # Original PMOS width
    'vbias': 0.78        # Original bias voltage (Vdd - |Vth| - 0.2)
}
```

### Parameter Descriptions:
1. **w_M1**: Width of the NMOS amplifying transistor (M1). Original value was 5μm. Range is set to 45nm (1×L) to 22.5μm (500×L).
2. **w_M2**: Width of the PMOS active load transistor (M2). Original value was 10μm. Range is set to 45nm (1×L) to 22.5μm (500×L).
3. **vbias**: Bias voltage for the PMOS active load. Original value was 0.78V. Range is set to 0.8-1.2× original value (0.624V-0.936V), keeping it safely below the 1.2V supply and maintaining proper biasing.

### Key Features:
- Maintains all fixed values as requested (Vdd=1.2V, Vin=0.42V, L=45nm)
- Parameterizes all optimizable components (transistor widths and bias voltage)
- Conservative voltage ranges to maintain proper circuit operation
- Preserves exact original values in initial_params
- Transistor width ranges respect the 1-500×L constraint
- All initial values fall within their respective search ranges
- No load capacitors to parameterize (none were present in the original circuit)