from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Input Voltage Sources (fixed values - will be swept during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Bias voltage for NMOS (Vth + 0.2V)
    # Parameterized Bias Voltage for PMOS (0.8-1.2× original, max 1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Main Amplifying Transistor (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed L for 45nm technology
    # Active Load (PMOS Current Source) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed L for 45nm technology
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, logarithmic scale)
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS width (5e-6 original)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS width (10e-6 original)
    # Bias voltage for PMOS (0.8-1.2× original, capped at 1.2V)
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,    # Original NMOS width
    'w_pmos': 10e-6,   # Original PMOS width
    'v_bias': 0.78,    # Original PMOS bias voltage (Vdd - |Vth| - 0.2V)
}
# Physical meaning of each parameter:
# - w_nmos: Width of NMOS input transistor (affects transconductance and gain)
# - w_pmos: Width of PMOS active load (affects output impedance and gain)
# - v_bias: Bias voltage for PMOS current source (affects output DC operating point)
