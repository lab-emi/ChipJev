from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Fixed input bias voltage (Vth + 0.2V)
    # Parameterized PMOS bias voltage
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # PMOS bias voltage
    # Common-Source Amplifier (M1) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_M1'], 
                  l=0.045e-6)  # Fixed 45nm channel length
    # Active Load (M2, PMOS current source) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_M2'], 
                  l=0.045e-6)  # Fixed 45nm channel length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions (keep length fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (NMOS)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (PMOS)
    # Bias voltage (0.8-1.2× original but not exceeding Vdd (1.2V))
    'v_bias': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (Vdd - |Vth| - 0.2V)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 5e-6,   # Original NMOS width
    'w_M2': 10e-6,  # Original PMOS width
    'v_bias': 0.78, # Original PMOS bias voltage
}
"""
Parameter Descriptions:
1. 'w_M1': Width of NMOS transistor M1 (common-source amplifier)
   - Original: 5 μm, Range: 45nm to 22.5 μm (1-500× channel length)
2. 'w_M2': Width of PMOS transistor M2 (active load)
   - Original: 10 μm, Range: 45nm to 22.5 μm (1-500× channel length)
3. 'v_bias': Bias voltage for PMOS current source
   - Original: 0.78V (Vdd - |Vth| - 0.2V), Range: 0.624-0.936V (0.8-1.2× original)
   - Conservative range keeps PMOS in saturation while allowing optimization
   - Never exceeds Vdd (1.2V) constraint
"""
