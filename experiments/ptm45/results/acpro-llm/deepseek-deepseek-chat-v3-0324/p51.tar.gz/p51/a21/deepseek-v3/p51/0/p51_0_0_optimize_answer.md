Here's the parameterized version of your single-stage amplifier with active load circuit, following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')

    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # Power supply (1.2V for 45nm technology)
    
    # Input voltage (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)  # Input bias (Vth + 0.2V)
    
    # Bias voltage (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias']@u_V)
    
    # Main Amplifying Transistor (NMOS)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_m1'],
                  l=0.045e-6)  # Length fixed by 45nm process
    
    # Active Load (PMOS)
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                  model='pmos_model',
                  w=params['w_m2'],
                  l=0.045e-6)  # Length fixed by 45nm process
        
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (keep L fixed at 45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Width range: 1-500× length (45nm)
    
    # Bias voltage (conservative range around original value)
    'v_bias': {'min': 0.624, 'max': 0.936},  # 0.8-1.2× original value (0.78V), capped at 1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_m1': 5e-6,     # Original width for M1
    'w_m2': 10e-6,    # Original width for M2
    'v_bias': 0.78,   # Original bias voltage (Vdd - |Vth| - 0.2V)
}

"""
Parameter Descriptions:
- w_m1: Width of NMOS input transistor (M1). Affects transconductance and current.
- w_m2: Width of PMOS active load (M2). Affects output impedance and gain.
- v_bias: Bias voltage for PMOS active load. Sets operating point and output swing range.
          (Original value calculated as Vdd - |Vth| - 0.2V for saturation)
"""
```

Key aspects of this implementation:
1. Complies with all your requirements:
   - Function is named `create_circuit`
   - Preserves the original `nmos_params` and `pmos_params` import
   - Fixed vdd (1.2V) and input voltage (0.42V) as specified
   - Only parameterizes items you requested (transistor widths and bias voltage)
   - All initial values are preserved exactly and fall within their search ranges

2. Parameter ranges are carefully chosen:
   - Transistor widths range from 1× to 500× the 45nm length (45nm to 22.5µm)
   - Bias voltage has a conservative ±20% range around the original value
   - The range [0.624V, 0.936V] ensures the PMOS stays in saturation while not exceeding 1.2V

3. Physical considerations:
   - The bias voltage range maintains Vgs - Vth ≈ 0.2V for proper operation
   - Width ranges allow for proper current scaling while respecting 45nm process constraints
   - Logarithmic sampling for widths is enabled (log=True) for better optimization

4. Documentation:
   - Includes clear parameter descriptions
   - Comments explain key design choices
   - Follows the exact output format you requested