from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Single-Stage Amplifier with Active Load')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)                     # Fixed 1.2V supply
    circuit.V('in', 'Vin', circuit.gnd, 0.42@u_V)                    # Fixed input bias
    # Parameterized bias voltage (0.8-1.2× original value, ≤1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)     # PMOS bias voltage
    # Common-Source Amplifier (NMOS) - parameterized width
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    # Active Load (PMOS Current Source) - parameterized width
    circuit.MOSFET('2', 'Vout', 'Vbias', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (1-500× length, log scale, min 45nm, max 22.5um)
    'w_nmos': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # NMOS width range
    'w_pmos': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # PMOS width range
    # Bias voltage (0.8-1.2× original, constrained by Vdd and Vth)
    'vbias': {'min': 0.624, 'max': 0.936},                   # Original 0.78V × [0.8,1.2]
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 10e-6,       # Original NMOS width (10um)
    'w_pmos': 20e-6,       # Original PMOS width (20um)
    'vbias': 0.78,         # Original bias voltage (0.78V)
}
"""
Parameter Descriptions:
1. w_nmos - Width of NMOS transistor (common-source amplifier)
   * Affects transconductance, current, and gain of input stage
   * Original: 10um, Range: 45nm-22.5um (1-500× length)
2. w_pmos - Width of PMOS transistor (active load)
   * Determines output impedance and current mirror ratio
   * Original: 20um, Range: 45nm-22.5um (1-500× length)
3. vbias - PMOS gate bias voltage
   * Sets operating point of active load
   * Original: 0.78V, Range: 0.624-0.936V (0.8-1.2× original)
   * Constrained to stay within reasonable operating range (Vth = 0.22V considered)
Note: All transistor lengths fixed at 45nm (technology minimum)
Fixed elements:
- Supply voltage (1.2V)
- Input bias voltage (0.42V)
"""
