Here's the parameterized version of your Single-Stage High-Gain Amplifier circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Single-Stage High-Gain Amplifier')
    
    # Define the MOSFET models (keep fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supplies (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Input voltage source (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # DC bias for NMOS (Vth + 0.2V)
    
    # Bias voltage (parameterized)
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['v_bias_p'])
    
    # Common-Source Amplifier with Active Load
    # M1 (NMOS): Common-source amplifier (only width parameterized)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd, 
                  model='nmos_model', 
                  w=params['w_nmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    # M2 (PMOS): Active current source load (only width parameterized)
    circuit.MOSFET('2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
                  model='pmos_model', 
                  w=params['w_pmos'], 
                  l=0.045e-6)  # Fixed 45nm length
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor dimensions
    'w_nmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    'w_pmos': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× length (45nm)
    
    # Bias voltage (constrained to stay near intended operating point)
    'v_bias_p': {'min': 0.62, 'max': 0.94},  # 0.8-1.2× original, staying below 1.2V
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_nmos': 5e-6,      # Original NMOS width
    'w_pmos': 10e-6,     # Original PMOS width
    'v_bias_p': 0.78,    # Original PMOS bias voltage
}

# Parameter descriptions for reference
parameter_descriptions = {
    'w_nmos': 'Width of NMOS transistor (M1) in common-source configuration',
    'w_pmos': 'Width of PMOS transistor (M2) acting as active load',
    'v_bias_p': 'Gate bias voltage for PMOS load transistor (M2)',
}
```

Key aspects of this implementation:

1. **Fixed Parameters**:
   - Supply voltage (Vdd) remains fixed at 1.2V
   - Input bias voltage (Vin) remains fixed at 0.42V
   - All transistor lengths fixed at 45nm

2. **Parameterized Elements**:
   - NMOS and PMOS transistor widths (M1 and M2)
   - PMOS bias voltage (Vbias_p)

3. **Search Ranges**:
   - Transistor widths range from minimum (45nm) to 500× length (22.5μm) in log scale
   - PMOS bias voltage has ±20% range (0.62-0.94V) but never exceeds 1.2V
   - All initial values are within their respective search ranges

4. **Physical Considerations**:
   - Bias voltage range keeps PMOS in saturation (Vgs < Vdd - |Vth|)
   - Width ranges maintain reasonable aspect ratios (1-500× length)
   - Original operating point is preserved in initial_params

This implementation follows all your requirements while maintaining the circuit's intended functionality for optimization.