Vdd Vdd 0 1.2
Vbias1 Vbias1 0 0.42
Vbias2 Vbias2 0 0.42
Vinp Vinp 0 0.6
Vinn Vinn 0 0.6
M1 Drain1 Vinp Source1 0 nmos_model l=4.5e-08 w=1e-05
M2 Drain2 Vinn Source1 0 nmos_model l=4.5e-08 w=1e-05
M5 Source1 Vbias1 0 0 nmos_model l=4.5e-08 w=2e-05
M3 Drain1 Drain1 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M4 Drain2 Drain1 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
M6 Vout Drain2 Vdd Vdd pmos_model l=4.5e-08 w=4e-05
M7 Vout Vbias2 0 0 nmos_model l=4.5e-08 w=2e-05
Cc Drain2 Vout 1pF
Rc Drain2 Vout 1kOhm
.model nmos_model nmos (kp=0.0001 level=1 vto=0.22)
.model pmos_model pmos (kp=4e-05 level=1 vto=-0.22)

