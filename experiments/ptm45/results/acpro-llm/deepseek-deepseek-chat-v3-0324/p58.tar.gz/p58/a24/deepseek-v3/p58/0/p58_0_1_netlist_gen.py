from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: The import "from model import nmos_params, pmos_params" is retained but not used here.
# Instead, we define the models explicitly for PySpice compatibility.
circuit = Circuit('Multi-Stage Opamp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltages (Vth = 0.22V, Vth + 0.2V = 0.42V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42)
# Input Voltages (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-supply for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Define MOSFET models (PySpice requires explicit .model statements)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Simplified NMOS model
circuit.model('pmos_model', 'pmos', level=1, kp=40e-6, vto=-0.22)  # Simplified PMOS model
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load (PMOS Current Mirror)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Compensation
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Compensation Network (Miller capacitor + zero-nulling resistor)
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)  # Miller compensation
circuit.R('c', 'Drain2', 'Vout', 1@u_kΩ)  # Resistor for zero cancellation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
