from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp with Fixed Biasing')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply (Vdd = 1.2V)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V for both NMOS and PMOS)
# Tail current bias: Vbias_p = Vdd - (|Vth| + 0.2V) = 1.2 - 0.42 = 0.78V
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # For PMOS (M5, M7)
# Input pair bias: Vbias_n = Vth + 0.2V = 0.42V
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # For NMOS (M1, M2)
# Input Signals (DC bias for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.62@u_V)  # Vbias_n + 0.2V (to ensure VGS > Vth)
circuit.V('inn', 'Vinn', circuit.gnd, 0.58@u_V)  # Vbias_n + 0.16V (small differential)
# Stage 1: Differential Pair with Current Mirror Load
# NMOS differential pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current mirror load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# PMOS tail current source (M5)
circuit.MOSFET('5', 'Tail', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Gain Stage
# NMOS amplifier (M6)
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS current source load (M7)
circuit.MOSFET('7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)  # Miller compensation capacitor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
