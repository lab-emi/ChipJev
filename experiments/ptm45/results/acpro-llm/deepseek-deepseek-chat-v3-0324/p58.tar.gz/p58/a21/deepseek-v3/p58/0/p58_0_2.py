from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Fully-Corrected Two-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
# Tail current bias: Vdd - (|Vth| + 0.2V) = 0.78V
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)
# Input stage bias: Vth + 0.25V = 0.47V
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.47@u_V)
# Input Signals (with proper DC biasing)
circuit.V('inp', 'Vinp', circuit.gnd, 0.5@u_V)  # Slightly above bias_n
circuit.V('inn', 'Vinn', circuit.gnd, 0.44@u_V)  # Slightly below bias_n
# Stage 1: Differential Pair with Current Mirror Load
# M1-M2: Input pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# M3-M4: Current mirror load
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M5: Tail current source (reduced width for proper biasing)
circuit.MOSFET('5', 'Tail', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
# M6: Gain transistor (increased width for higher gm)
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
# M7: Current source load
circuit.MOSFET('7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Compensation Network
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
