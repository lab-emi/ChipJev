from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Op-Amp with Corrected Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.45@u_V)  # Slightly higher for better current
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.75@u_V)  # Slightly lower to boost Vout2
# Input DC Bias (mid-rail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Vout1', 'Vinp', 'NodeS', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vout1_bar', 'Vinn', 'NodeS', circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vout1', 'Vout1_bar', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout1_bar', 'Vout1_bar', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('5', 'NodeS', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Vout2', 'Vout1', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Output Buffer
circuit.MOSFET('8', 'Vout', 'Vout2', circuit.gnd, circuit.gnd, model='nmos_model', w=60e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 3@u_kΩ)  # Lower resistance for proper biasing
# Miller Compensation
circuit.C('c', 'Vout2', 'Vout1', 1.5@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
