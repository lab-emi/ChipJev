from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Op-Amp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS bias (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS bias (Vdd - |Vth| - 0.2V)
# Input Voltages (DC bias at mid-rail)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Vout1', 'Vinp', 'NodeS', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vout1_bar', 'Vinn', 'NodeS', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vout1', 'Vout1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout1_bar', 'Vout1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'NodeS', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Vout2', 'Vout1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 3: Output Buffer
circuit.MOSFET('8', 'Vout', 'Vout2', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)
# Compensation Network (Miller)
circuit.C('c', 'Vout2', 'Vout1', 1@u_pF)
circuit.R('c', 'Vout2', 'NodeC', 1@u_kΩ)
circuit.C('c2', 'NodeC', 'Vout1', 1@u_pF)  # Optional: Nested Miller compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
