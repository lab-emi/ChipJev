from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Opamp for High GBW')
# Define MOSFET Models (45nm technology parameters)
# NOTE: 'lambda' is a Python keyword, so we use 'lambd' instead
circuit.model('nmos_model', 'nmos', 
    level=49, 
    vto=0.22,    # Threshold voltage (V)
    kp=200e-6,   # Transconductance parameter (A/V²)
    gamma=0.1,   # Body effect parameter (√V)
    lambd=0.05   # Channel-length modulation (1/V, renamed from 'lambda')
)
circuit.model('pmos_model', 'pmos', 
    level=49,
    vto=-0.22,   # Threshold voltage (V, negative for PMOS)
    kp=80e-6,    # Transconductance parameter (A/V²)
    gamma=0.12,  # Body effect parameter (√V)
    lambd=0.06   # Channel-length modulation (1/V, renamed from 'lambda')
)
# Power Supply and Bias Voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # Bias for M5 (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # Bias for M8 (Vdd - |Vth| - 0.2V)
# Differential Input (DC bias at mid-supply)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  
# Stage 1: Differential Pair with Active Load
# NMOS differential pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS current mirror load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail current source (M5)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-Source Stage with Active Load
# NMOS amplifier (M7)
circuit.MOSFET('7', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS active load (M8)
circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Miller Compensation Network (R1, C1 between gate and drain of M7)
circuit.R('1', 'Drain2', 'Vout', 10@u_kΩ)  # Connects M7 gate (Drain2) to output
circuit.C('1', 'Drain2', 'Vout', 1@u_pF)   # Ensures stability
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
