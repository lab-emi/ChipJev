Vdd Vdd 0 1.2V
Vbias1 Vbias1 0 0.42V
Vbias2 Vbias2 0 0.78V
Vinp Vinp 0 0.6V
Vinn Vinn 0 0.6V
M1 Drain1 Vinp Source1 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain2 Vinn Source1 0 nmos_model l=4.5e-08 w=5e-06
M3 Drain1 Drain1 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M4 Drain2 Drain1 Vdd Vdd pmos_model l=4.5e-08 w=1e-05
M5 Source1 Vbias1 0 0 nmos_model l=4.5e-08 w=1e-05
M7 Vout Drain2 0 0 nmos_model l=4.5e-08 w=2e-05
M8 Vout Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=2e-05
R1 Drain2 Vout 10kOhm
C1 Drain2 Vout 1pF
.model nmos_model nmos (gamma=0.1 kp=0.0002 lambd=0.05 level=49 vto=0.22)
.model pmos_model pmos (gamma=0.12 kp=8e-05 lambd=0.06 level=49 vto=-0.22)

