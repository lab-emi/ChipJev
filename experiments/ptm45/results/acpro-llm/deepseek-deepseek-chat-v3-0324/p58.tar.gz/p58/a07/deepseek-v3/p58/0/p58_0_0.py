from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Opamp')
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V power supply
# Bias Voltages (Vth = 0.22V, Vbias = Vth + 0.2V = 0.42V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # For M5
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # For M7
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for DC bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # Mid-supply for DC bias
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # M3 (PMOS)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # M4 (PMOS)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # M5 (tail current)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)  # M6 (PMOS)
circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)  # M7 (NMOS)
# Stage 3: Omitted (direct output drive with R1)
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)  # Load resistor
# Miller Compensation Capacitor
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)  # Cc = 1pF
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
