from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Input Signals (fixed DC bias for operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-rail for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-rail for differential input
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']) # Original: 0.42V
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']) # Original: 0.78V
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Vout', 'Drain2', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to stay near original values while considering Vth=0.22V)
    'vbias1': {'min': 0.4, 'max': 0.5, 'log': False},  # Original: 0.42V (Vth+0.2V)
    'vbias2': {'min': 0.7, 'max': 0.9, 'log': False},  # Original: 0.78V (Vdd-Vth-0.2V)
    # Transistor widths
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6 (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 30e-6
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 15e-6
    # Compensation capacitor (0.5-5× original value)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.42,
    'vbias2': 0.78,
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 30e-6,
    'w_M7': 15e-6,
    'c_comp': 1.0,
}
