Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])  # Bias for tail current source M5
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])  # Bias for active load M8
    
    # Input Signals (fixed DC operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn
    
    # First Stage: Differential Pair with Current Mirror Load
    circuit.MOSFET('1', 'Vout1', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vout2', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Vout1', 'Vout1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vout2', 'Vout1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Second Stage: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Vout1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M8'], l=0.045e-6)
    
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Vout1', 'Vout', f"{params['c_comp']}p")
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W in meters, L fixed at 45nm)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Input pair NMOS (original 10um)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Input pair NMOS (original 10um)
    'w_M3': {'min': 0.045e-6, 'max': 45e-6, 'log': True},     # PMOS load (original 20um)
    'w_M4': {'min': 0.045e-6, 'max': 45e-6, 'log': True},     # PMOS load (original 20um)
    'w_M5': {'min': 0.045e-6, 'max': 11.25e-6, 'log': True},  # Tail current NMOS (original 5um)
    'w_M6': {'min': 0.045e-6, 'max': 45e-6, 'log': True},     # Second stage NMOS (original 20um)
    'w_M8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},   # Active load PMOS (original 10um)
    
    # Bias voltages (V)
    'v_bias1': {'min': 0.336, 'max': 0.504, 'log': False},  # Original 0.42V (0.8-1.2x)
    'v_bias2': {'min': 0.624, 'max': 0.936, 'log': False},  # Original 0.78V (0.8-1.2x)
    
    # Compensation capacitor (pF)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Original 1pF (0.5-5x)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 10e-6,     # Original: 10um
    'w_M2': 10e-6,     # Original: 10um
    'w_M3': 20e-6,     # Original: 20um
    'w_M4': 20e-6,     # Original: 20um
    'w_M5': 5e-6,      # Original: 5um
    'w_M6': 20e-6,     # Original: 20um
    'w_M8': 10e-6,     # Original: 10um
    
    'v_bias1': 0.42,   # Original: 0.42V
    'v_bias2': 0.78,   # Original: 0.78V
    
    'c_comp': 1.0,     # Original: 1pF
}
```

### Explanation of Parameters:

1. **Transistor Widths (w_M1-w_M8)**:
   - All widths can vary from minimum (45nm, same as length) up to 500× the length (22.5μm)
   - Differential pair transistors (M1,M2) range matches original 10μm value
   - Current mirror load (M3,M4) range centered around original 20μm value
   - Tail current source (M5) range centered around original 5μm value
   - Second stage (M6,M8) ranges match their original 20μm and 10μm values

2. **Bias Voltages (v_bias1, v_bias2)**:
   - Vbias1 (tail current) ranges from 0.336V to 0.504V (0.8-1.2× original 0.42V)
   - Vbias2 (active load) ranges from 0.624V to 0.936V (0.8-1.2× original 0.78V)
   - All voltage ranges stay below 1.2V supply and consider Vth=0.22V

3. **Compensation Capacitor (c_comp)**:
   - Ranges from 0.5pF to 5pF (0.5-5× original 1pF)
   - Critical for stability, so given wider range than other parameters

All initial parameters exactly match the original circuit values and are within their respective search ranges. The function is named `create_circuit` as required, and maintains all the fixed values (power supply, input voltages) as specified.