from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # Bias for tail current source M5
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # Bias for active load M8
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # DC bias for Vinp
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # DC bias for Vinn
# First Stage: Differential Pair with Current Mirror Load
circuit.MOSFET('1', 'Vout1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vout2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Vout1', 'Vout1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vout2', 'Vout1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier with Active Load
circuit.MOSFET('6', 'Vout', 'Vout1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Compensation Capacitor
circuit.C('c', 'Vout1', 'Vout', 1@u_pF)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
