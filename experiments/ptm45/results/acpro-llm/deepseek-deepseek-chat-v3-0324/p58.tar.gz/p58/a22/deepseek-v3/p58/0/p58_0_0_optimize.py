from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supplies and Bias Voltages (Vdd fixed at 1.2V)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Parameterized bias voltages
    circuit.V('bias', 'Vbias', circuit.gnd, params['vbias']@u_V)
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)
    # Input Signals (fixed for DC operating point analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)  # Tail current source
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('6', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Drain1', 'Vout', f"{params['c_comp']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS (1-500×L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Input pair NMOS (1-500×L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load (1-500×L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS load (1-500×L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current (1-500×L)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # PMOS CS stage (1-500×L)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # NMOS CS stage (1-500×L)
    # Bias voltages (all in volts, Vth = 0.22V)
    'vbias': {'min': 0.336, 'max': 0.504},  # Original 0.42V (0.8-1.2×)
    'vbias2': {'min': 0.336, 'max': 0.504}, # Original 0.42V (0.8-1.2×)
    # Compensation capacitor
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Original 1pF (0.5-5×)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 30e-6,
    'w_M7': 15e-6,
    # Bias voltages
    'vbias': 0.42,
    'vbias2': 0.42,
    # Compensation capacitor
    'c_comp': 1.0,
}
