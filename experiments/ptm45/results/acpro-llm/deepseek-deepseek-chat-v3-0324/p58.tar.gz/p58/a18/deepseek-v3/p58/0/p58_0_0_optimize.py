from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply and input signals (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed 1.2V power supply
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Fixed mid-rail differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Fixed mid-rail differential input
    # Parameterized bias voltages
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])  # M5 bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])  # M7 bias
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['v_bias3'])  # M8,M9,M10 bias (not used in original)
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Compensation
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    # Compensation network (parameterized)
    circuit.C('c', 'Vout', 'Drain2', f"{params['c_comp']}p")
    circuit.R('c', 'Vout', 'NodeRc', f"{params['r_comp']}k")
    circuit.C('c2', 'NodeRc', 'Drain2', f"{params['c_comp2']}p")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (0.8-1.2× original values, never exceeding 1.2V)
    'v_bias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Vth + 0.2V for NMOS (M5) (original=0.42V)
    'v_bias2': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # Vth + 0.2V for NMOS (M7) (original=0.42V)
    'v_bias3': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # Vdd - |Vth| - 0.2V for PMOS (original=0.78V)
    # Transistor widths (1-500× the 45nm length -> 45e-9 to 22.5e-6)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 width (original=10e-6)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 width (original=10e-6)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 width (original=20e-6)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M4 width (original=20e-6)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M5 width (original=5e-6)
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M6 width (original=40e-6)
    'w_M7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M7 width (original=20e-6)
    # Compensation network components
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # Main compensation cap (original=1pF)
    'r_comp': {'min': 0.5, 'max': 2.0, 'log': True},  # Nulling resistor (original=1kΩ)
    'c_comp2': {'min': 0.5, 'max': 5.0, 'log': True}, # Second comp cap (original=1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'v_bias1': 0.42,
    'v_bias2': 0.42,
    'v_bias3': 0.78,
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 40e-6,
    'w_M7': 20e-6,
    # Compensation network
    'c_comp': 1.0,
    'r_comp': 1.0,
    'c_comp2': 1.0,
}
