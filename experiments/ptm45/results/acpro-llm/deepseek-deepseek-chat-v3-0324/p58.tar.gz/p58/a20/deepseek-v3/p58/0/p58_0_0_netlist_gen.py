from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Input Signals (DC bias for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-rail bias for differential input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-rail bias for differential input
# Bias Voltage for Tail Current Source (M9)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42) # Vth + 0.2V for M9
# Bias Voltage for Active Load (M6)
circuit.V('bias_load', 'Vbias_load', circuit.gnd, 0.78) # Vdd - Vth - 0.2V for M6
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('9', 'Source_pair', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier with Active Load
circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('6', 'Drain5', 'Vbias_load', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Miller Compensation Capacitor
circuit.C('c', 'Drain5', 'Drain2', 1@u_pF)
# Stage 3: Output Buffer (Optional)
# circuit.MOSFET('7', 'Vout', 'Drain5', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
# circuit.MOSFET('8', 'Vout', 'Drain5', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=0.045e-6)
# Output Node
circuit.R('load', 'Drain5', 'Vout', 1@u_kΩ) # Load resistor for simulation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
