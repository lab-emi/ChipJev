from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6) # Mid-rail bias for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6) # Mid-rail bias for differential input
    # Parameterized Bias Voltages
    circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, params['v_bias_tail']) # Tail current bias
    circuit.V('bias_load', 'Vbias_load', circuit.gnd, params['v_bias_load']) # Active load bias
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source_pair', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source_pair', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('9', 'Source_pair', 'Vbias_tail', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m9'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Active Load
    circuit.MOSFET('5', 'Drain5', 'Drain2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    circuit.MOSFET('6', 'Drain5', 'Vbias_load', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    # Miller Compensation Capacitor
    circuit.C('c', 'Drain5', 'Drain2', f"{params['c_comp']}p")
    # Output Load (fixed)
    circuit.R('load', 'Drain5', 'Vout', 1@u_kΩ) # Load resistor for simulation
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (V)
    'v_bias_tail': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth + 0.2V)
    'v_bias_load': {'min': 0.62, 'max': 0.94},  # Original: 0.78V (Vdd - Vth - 0.2V)
    # Transistor widths (m)
    # Differential pair
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 10e-6
    # PMOS current mirror load
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    # Tail current source
    'w_m9': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 5e-6
    # Second stage NMOS
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 20e-6
    # Second stage PMOS load
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Original: 40e-6
    # Compensation capacitor (pF)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Original: 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'v_bias_tail': 0.42,
    'v_bias_load': 0.78,
    # Transistor widths
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m9': 5e-6,
    'w_m5': 20e-6,
    'w_m6': 40e-6,
    # Compensation capacitor
    'c_comp': 1.0,
}
