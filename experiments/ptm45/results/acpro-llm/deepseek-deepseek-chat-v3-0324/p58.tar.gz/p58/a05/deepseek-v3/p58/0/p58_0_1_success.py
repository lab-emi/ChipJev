from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Imported but unused; redefine models explicitly
circuit = Circuit('Three-Stage Opamp with Miller Compensation')
# Define MOSFET models explicitly (critical fix)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Example parameters
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Example parameters
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages (Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42@u_V)  # NMOS tail: Vth + 0.2V
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78@u_V)  # PMOS load: Vdd - |Vth| - 0.2V
# Input Signals (DC operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # Mid-supply for CM
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# First Stage: Differential Pair with Active Load
# Fixed MOSFET syntax: name, drain, gate, source, bulk, model, w, l
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # PMOS mirror
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # Tail current
# Second Stage: Common-Source Amplifier
circuit.MOSFET('6', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # PMOS load
# Third Stage: Output Buffer
circuit.MOSFET('8', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 1@u_kΩ)  # Load resistor
# Miller Compensation (critical for stability)
circuit.C('c', 'Drain3', 'Drain1', 1@u_pF)  # Compensation capacitor
circuit.R('c', 'Drain3', 'Drain1', 1@u_kΩ)  # Zero cancellation resistor
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
