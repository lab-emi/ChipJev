from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Three-Stage Opamp with Miller Compensation')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, f"{params['vbias1']}V")
    circuit.V('bias2', 'Vbias2', circuit.gnd, f"{params['vbias2']}V")
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
    # First Stage: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', 
                  w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', 
                  w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
                  w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', 
                  w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', 
                  w=params['w_m5'], l=0.045e-6)
    # Second Stage: Common-Source Amplifier
    circuit.MOSFET('6', 'Drain3', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', 
                  w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Drain3', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', 
                  w=params['w_m7'], l=0.045e-6)
    # Third Stage: Output Buffer
    circuit.MOSFET('8', 'Vout', 'Drain3', circuit.gnd, circuit.gnd, model='nmos_model', 
                  w=params['w_m8'], l=0.045e-6)
    # Load resistor (parameterized)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_load']}k")
    # Miller Compensation (parameterized)
    circuit.C('c', 'Drain3', 'Drain1', f"{params['c_comp']}p")
    circuit.R('c', 'Drain3', 'Drain1', f"{params['r_comp']}k")
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (conservative ranges maintaining operation region)
    'vbias1': {'min': 0.34, 'max': 0.50},  # Original: 0.42V (Vth_n + 0.2V ± 20%)
    'vbias2': {'min': 0.70, 'max': 0.94},  # Original: 0.78V (Vdd - |Vth_p| - 0.2V ± 20%)
    # First stage transistor widths
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M1
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M2
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M3
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M4
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M5
    # Second stage transistor widths
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M6
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M7
    # Output stage transistor width
    'w_m8': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500×L for M8
    # Passive components
    'r_load': {'min': 0.5, 'max': 2.0, 'log': True},    # 0.5-2× original (1kΩ)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},    # 0.5-5× original (1pF)
    'r_comp': {'min': 0.5, 'max': 2.0, 'log': True},    # 0.5-2× original (1kΩ)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    # Transistor widths
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 5e-6,
    'w_m6': 20e-6,
    'w_m7': 10e-6,
    'w_m8': 30e-6,
    # Passive components
    'r_load': 1.0,
    'c_comp': 1.0,
    'r_comp': 1.0,
}
