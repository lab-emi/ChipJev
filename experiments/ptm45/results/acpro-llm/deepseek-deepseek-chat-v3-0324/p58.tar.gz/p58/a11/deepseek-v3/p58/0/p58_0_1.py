from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# No need for 'from model import nmos_params, pmos_params' since we define models directly
circuit = Circuit('Multi-Stage Opamp')
# --- Define MOSFET Models (Critical Fix) ---
# Explicitly define NMOS and PMOS models instead of relying on external imports
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Example parameters
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Example parameters
# --- Power Supply ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# --- Bias Voltages ---
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # For NMOS current sources (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # For PMOS (Vdd - |Vth| - 0.2V)
# --- Input Signals (DC bias for operating point) ---
# Mid-supply for differential pair (common-mode voltage)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# --- Stage 1: Differential Pair with Active Load ---
# NMOS differential pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS active load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Tail current source (M5)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# --- Stage 2: Common-Source Amplifier ---
# PMOS amplifying transistor (M6)
circuit.MOSFET('6', 'Drain6', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# NMOS current source load (M7)
circuit.MOSFET('7', 'Drain6', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# --- Stage 3: Output Stage ---
# PMOS output driver (M8)
circuit.MOSFET('8', 'Vout', 'Drain6', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Resistor load (R1)
circuit.R('1', 'Vout', circuit.gnd, 10@u_kΩ)
# --- Compensation Network ---
# Miller capacitor (Cc) for stability
circuit.C('c', 'Drain2', 'Drain6', 1@u_pF)
# --- Analysis Part ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
