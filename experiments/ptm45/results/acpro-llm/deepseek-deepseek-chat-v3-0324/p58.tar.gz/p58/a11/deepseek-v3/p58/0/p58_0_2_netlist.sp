Vdd Vdd 0 1.2
Vbias1 Vbias1 0 0.5
Vbias2 Vbias2 0 0.7
Vinp Vinp 0 0.6
Vinn Vinn 0 0.6
M1 Drain1 Vinp Source1 0 nmos_model l=4.5e-08 w=5e-06
M2 Drain2 Vinn Source1 0 nmos_model l=4.5e-08 w=5e-06
M3 Drain1 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=1.5e-05
M4 Drain2 Vbias2 Vdd Vdd pmos_model l=4.5e-08 w=1.5e-05
M5 Source1 Vbias1 0 0 nmos_model l=4.5e-08 w=1e-05
M6 Drain6 Drain2 Vdd Vdd pmos_model l=4.5e-08 w=2.5e-05
M7 Drain6 Vbias1 Source7 0 nmos_model l=4.5e-08 w=1.5e-05
R2 Source7 0 1kOhm
M8 Vout Drain6 Vdd Vdd pmos_model l=4.5e-08 w=4e-05
R1 Vout 0 5kOhm
Cc Drain2 Drain6 1.5pF
.model nmos_model nmos (kp=0.0001 level=1 vto=0.22)
.model pmos_model pmos (kp=5e-05 level=1 vto=-0.22)

