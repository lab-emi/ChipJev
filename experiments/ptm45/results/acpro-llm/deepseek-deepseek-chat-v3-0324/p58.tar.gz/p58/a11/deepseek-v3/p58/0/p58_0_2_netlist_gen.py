from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Opamp')
# --- Define MOSFET Models ---
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # NMOS: Vth = 0.22V
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # PMOS: Vth = -0.22V
# --- Power Supply ---
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# --- Bias Voltages ---
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.5)  # Increased to 0.5V for better NMOS biasing
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.7)  # Adjusted for PMOS active load
# --- Input Signals (DC bias) ---
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for differential pair
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Symmetric input
# --- Stage 1: Differential Pair with Active Load ---
# NMOS differential pair (M1, M2)
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS active load (M3, M4)
circuit.MOSFET('3', 'Drain1', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)  # Wider for better current matching
circuit.MOSFET('4', 'Drain2', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=15e-6, l=0.045e-6)
# Tail current source (M5)
circuit.MOSFET('5', 'Source1', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# --- Stage 2: Common-Source Amplifier ---
# PMOS amplifying transistor (M6)
circuit.MOSFET('6', 'Drain6', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)  # Wider for higher gain
# NMOS current source load (M7) - Critical Fix
circuit.MOSFET('7', 'Drain6', 'Vbias1', 'Source7', circuit.gnd, model='nmos_model', w=15e-6, l=0.045e-6)  # Added Source7 node
circuit.R('2', 'Source7', circuit.gnd, 1@u_kΩ)  # Degeneration resistor to ensure V_DS > V_GS - V_TH
# --- Stage 3: Output Stage ---
# PMOS output driver (M8)
circuit.MOSFET('8', 'Vout', 'Drain6', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # Larger for driving load
# Resistor load (R1)
circuit.R('1', 'Vout', circuit.gnd, 5@u_kΩ)  # Reduced to improve output swing
# --- Compensation Network ---
circuit.C('c', 'Drain2', 'Drain6', 1.5@u_pF)  # Increased for better stability
# --- Analysis Part ---
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
