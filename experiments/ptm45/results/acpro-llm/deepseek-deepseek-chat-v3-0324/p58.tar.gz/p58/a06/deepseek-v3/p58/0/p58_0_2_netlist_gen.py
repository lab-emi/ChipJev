from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Corrected Multi-Stage Op-Amp with Proper Operating Point')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Bias Voltages
circuit.V('bias_n', 'Vbias_n', circuit.gnd, 0.42@u_V)  # For NMOS tail current (M5)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78@u_V)  # For PMOS load (M7)
# Input Voltages (Equal for operating point check)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)
# Differential Pair Stage (First Stage)
# M1 and M2: Input pair
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', 'SourcePair', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', 'SourcePair', model='nmos_model', w=10e-6, l=0.045e-6)
# M3 and M4: Active load
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M5: Tail current
circuit.MOSFET('5', 'SourcePair', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage (Common-Source with Active Load)
# M6: Amplifying transistor
circuit.MOSFET('6', 'Drain6', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# M7: Active load
circuit.MOSFET('7', 'Drain6', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Third Stage (Proper Source Follower Configuration)
# M8: Output buffer (PMOS source follower)
circuit.MOSFET('8', circuit.gnd, 'Drain6', 'Vout', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Compensation Network 
circuit.C('c', 'Drain6', 'Drain1', 1@u_pF)  # Miller capacitor
circuit.R('z', 'Drain6', 'Drain1', 10@u_kΩ)  # Nulling resistor
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
