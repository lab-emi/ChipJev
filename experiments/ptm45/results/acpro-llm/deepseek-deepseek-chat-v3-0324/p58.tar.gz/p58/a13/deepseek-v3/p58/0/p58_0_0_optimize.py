from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # NMOS current source bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS current source bias
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for differential input
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for differential input
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                  model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Current Source Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_m7'], l=0.045e-6)
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all in meters, 1-500× L constraint)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (PMOS)
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (PMOS)
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (tail current)
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (PMOS)
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (NMOS)
    # Bias voltages (0.8-1.2× original values, but not exceeding 1.2V)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original: 0.42V (0.8-1.2×)
    'vbias2': {'min': 0.624, 'max': 0.936},  # Original: 0.78V (0.8-1.2×)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_m1': 10e-6,   # M1 original width
    'w_m2': 10e-6,   # M2 original width
    'w_m3': 20e-6,   # M3 original width
    'w_m4': 20e-6,   # M4 original width
    'w_m5': 5e-6,    # M5 original width
    'w_m6': 30e-6,   # M6 original width
    'w_m7': 10e-6,   # M7 original width
    # Bias voltages
    'vbias1': 0.42,  # Original Vbias1 value (for NMOS current source)
    'vbias2': 0.78,  # Original Vbias2 value (for PMOS current source)
}
"""
Parameter Descriptions:
- w_m1, w_m2: Input pair NMOS widths (affects input transconductance and matching)
- w_m3, w_m4: Active load PMOS widths (sets first stage gain and pole locations)
- w_m5: Tail current source width (sets bias current for differential pair)
- w_m6: PMOS current source width for second stage (affects output impedance)
- w_m7: NMOS driver width for second stage (main gain stage)
- vbias1: NMOS current source bias (sets operating current for diff pair)
- vbias2: PMOS current source bias (sets operating current for output stage)
All transistor lengths are fixed at 45nm (0.045μm) for this technology.
"""
