from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Opamp')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2V
circuit.V('ss', 'Vss', circuit.gnd, 0)     # Ground
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # Bias for tail current (Vth + 0.2V)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # Bias for M7 (Vdd - |Vth| - 0.2V)
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-supply for DC bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-supply for DC bias
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source with Active Load and Compensation
circuit.MOSFET('6', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.C('c', 'Vout', 'Drain2', 1@u_pF)  # Miller capacitor
circuit.R('c', 'Vout', 'Node_Rc', 1@u_kΩ)  # Nulling resistor
circuit.C('c2', 'Node_Rc', 'Drain2', 1@u_pF)  # Additional capacitor for stability
# Stage 3: Source Follower (Output Buffer)
circuit.MOSFET('8', 'Vdd', 'Vout', 'Source8', 'Source8', model='nmos_model', w=50e-6, l=0.045e-6)
circuit.R('1', 'Source8', 'Vout', 1@u_kΩ)  # Output bias resistor
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
