from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp (Final Corrected)')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Proper Bias Generation Network
# Current source for bias generation
circuit.MOSFET('bias_p', 'Vbias_p', 'Vbias_n', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('bias_n', 'Vbias_n', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.V('bias_ctrl', 'Vbias_n', circuit.gnd, 0.5)  # Sets proper bias current
# Bias Voltage for main circuit (properly scaled from bias_n)
circuit.MOSFET('8', 'Vbias', 'Vbias_n', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.R('bias', 'Vbias', 'Vbias_n', 2@u_kΩ)  # Proper voltage division
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Source1', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'Source1', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Active Load for M9 (if needed)
circuit.MOSFET('10', 'Drain9', 'Vbias', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Miller Compensation
circuit.C('c', 'Vout', 'Drain2', 1@u_pF)
# Input Bias (Mid-supply for differential pair)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
