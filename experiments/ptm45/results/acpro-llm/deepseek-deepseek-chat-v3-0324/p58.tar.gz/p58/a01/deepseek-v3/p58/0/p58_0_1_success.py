from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp')
# Define the MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
# Bias Voltages (properly set for saturation)
# Tail current source bias (Vgs = Vth + 200mV = 0.42V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)
# Input common mode voltage (mid-supply)
circuit.V('cm', 'Vcm', circuit.gnd, 0.6)
# PMOS current mirror bias (Vdd - |Vth| - 200mV = 0.78V)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)
# Input Signals (using common mode as DC bias)
circuit.V('inp', 'Vinp', 'Vcm', 0) # Differential inputs
circuit.V('inn', 'Vinn', 'Vcm', 0)
# First Stage: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('3', 'Drain1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6) # Diode-connected
circuit.MOSFET('4', 'Drain2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('5', 'SourcePair', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Second Stage: Common-Source Amplifier with Active Load
circuit.MOSFET('6', 'Vbias_p', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6) # Diode-connected
circuit.MOSFET('7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('8', 'Vout', 'Drain2', circuit.gnd, circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# Compensation Network (Miller compensation)
circuit.C('c', 'Drain2', 'Vout', 1@u_pF)
circuit.R('c', 'Drain2', 'Vout', 1@u_kΩ) # Series resistor for lead compensation
# Analysis Part
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
