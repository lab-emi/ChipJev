from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    # Define the MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']) 
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']) 
    # Input Signals (fixed DC operating point)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_m1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_m2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m4'], l=0.045e-6)
    circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m5'], l=0.045e-6)
    # Stage 2: Common-Source Amplifier with Compensation
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_m6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_m7'], l=0.045e-6)
    circuit.C('c', 'Vout', 'Drain2', f"{params['c_comp']}p") # Compensation capacitor
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (W ranges from 1× to 500× L=45nm)
    'w_m1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 1
    'w_m2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS 2
    'w_m3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS 1
    'w_m4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Active load PMOS 2
    'w_m5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Tail current NMOS
    'w_m6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage PMOS
    'w_m7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # CS stage NMOS
    # Bias voltages (0.8-1.2× original, staying between Vth and Vdd)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Original 0.42V (Vth + 0.2V overdrive)
    'vbias2': {'min': 0.336, 'max': 0.504},  # Original 0.42V (Vth + 0.2V overdrive)
    # Compensation capacitor (0.5-5× original)
    'c_comp': {'min': 0.5, 'max': 5.0, 'log': True},  # Original 1pF
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (original values)
    'w_m1': 10e-6,
    'w_m2': 10e-6,
    'w_m3': 20e-6,
    'w_m4': 20e-6,
    'w_m5': 5e-6,
    'w_m6': 40e-6,
    'w_m7': 20e-6,
    # Bias voltages (original values)
    'vbias1': 0.42,
    'vbias2': 0.42,
    # Compensation capacitor (original value)
    'c_comp': 1.0,
}
# Physical meaning of parameters:
# - w_m1/w_m2: Widths of differential pair NMOS transistors (affects gain, noise)
# - w_m3/w_m4: Widths of active load PMOS transistors (affects mirroring accuracy)
# - w_m5: Width of tail current source (sets bias current for diff pair)
# - w_m6: Width of CS stage PMOS load (affects 2nd stage gain)
# - w_m7: Width of CS stage NMOS (affects output drive capability)
# - vbias1/vbias2: Bias voltages (set operating points for current sources)
# - c_comp: Compensation capacitor (key for frequency stability)
