from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp for Max GBW')
    # Define MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])  # NMOS bias
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])  # PMOS bias
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-rail for DC operating point
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-rail for DC operating point
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)  # Tail current
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)  # Active load
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)  # Active load
    # Stage 2: Common-Source Amplifier
    circuit.MOSFET('6', 'Vout', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)  # PMOS driver
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)  # NMOS current source
    # Miller Compensation (parameterized)
    circuit.C('c', 'Drain1', 'Vout', f"{params['c_comp']}p")  # Miller capacitor
    return circuit
# Optimization parameter search ranges
param_ranges_definition = {
    # Bias Voltages (0.8-1.2× original, constrained by Vth=0.22V and Vdd=1.2V)
    'vbias1': {'min': 0.42*0.8, 'max': min(0.42*1.2, 1.2)},  # NMOS bias (original: 0.42V)
    'vbias2': {'min': 0.78*0.8, 'max': min(0.78*1.2, 1.2)},  # PMOS bias (original: 0.78V)
    # Stage 1 Transistor Widths (1-500× length, L=45nm → 45nm-22.5μm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS (original: 10μm)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Diff pair NMOS (original: 10μm)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Active load PMOS (original: 20μm)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Active load PMOS (original: 20μm)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # Tail current (original: 5μm)
    # Stage 2 Transistor Widths
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # PMOS driver (original: 40μm)
    'w_M7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # NMOS current source (original: 20μm)
    # Compensation Capacitor (0.5-5× original)
    'c_comp': {'min': 0.5, 'max': 5, 'log': True},  # Miller cap (original: 1pF)
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Bias Voltages
    'vbias1': 0.42,
    'vbias2': 0.78,
    # Transistor Widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 5e-6,
    'w_M6': 40e-6,
    'w_M7': 20e-6,
    # Compensation Capacitor
    'c_comp': 1.0,
}
