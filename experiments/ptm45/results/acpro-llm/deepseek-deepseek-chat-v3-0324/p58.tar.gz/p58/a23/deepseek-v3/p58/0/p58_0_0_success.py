from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
circuit = Circuit('Multi-Stage Opamp for Max GBW')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # 1.2V power supply
# Bias Voltages (assume Vth = 0.22V)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.42)  # Vth + 0.2 = 0.42V for NMOS
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)  # Vdd - |Vth| - 0.2 = 0.78V for PMOS
# Input Signals (DC operating point only)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Mid-rail for DC operating point
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Mid-rail for DC operating point
# Stage 1: Differential Pair with Active Load
circuit.MOSFET('1', 'Drain1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Drain2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # Tail current
circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Active load
circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # Active load
# Stage 2: Common-Source Amplifier
circuit.MOSFET('6', 'Vout', 'Drain1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # PMOS driver
circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)  # NMOS current source
# Miller Compensation
circuit.C('c', 'Drain1', 'Vout', 1@u_pF)  # Miller capacitor
# Simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
