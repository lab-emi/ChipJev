from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Stabilized Multi-Stage Opamp')
# 1. MODEL DEFINITIONS (Critical for convergence)
circuit.model('nmos_model', 'nmos', 
              level=1, kp=100e-6, vto=0.22, lambda=0.1)  # Added channel modulation
circuit.model('pmos_model', 'pmos', 
              level=1, kp=50e-6, vto=-0.22, lambda=0.1)  # Added channel modulation
# 2. POWER SUPPLIES WITH STARTUP NODES (Helps convergence)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)
circuit.V('startup', 'startup_node', circuit.gnd, 0)  # Dummy node for initialization
# 3. DIFFERENTIAL PAIR (Stage 1) with IMPROVED BIASING
circuit.MOSFET('1', 'Node1', 'Vinp', 'Tail', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Node2', 'Vinn', 'Tail', circuit.gnd, 
               model='nmos_model', w=10e-6, l=0.045e-6)
# Current mirror load with STARTUP HELPERS
circuit.MOSFET('3', 'Node1', 'Node1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Node2', 'Node1', 'Vdd', 'Vdd', 
               model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current with GATE PROTECTION
circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
# 4. COMMON-SOURCE STAGE (Stage 2) with STABILITY FIXES
circuit.MOSFET('6', 'Vout', 'Node1', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
# 5. BIAS NETWORK with IMPROVED STARTUP
circuit.MOSFET('8', 'Vbias_p', 'Vbias_p', 'Vdd', 'Vdd', 
               model='pmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('9', 'Vbias_p', 'Vbias', circuit.gnd, circuit.gnd, 
               model='nmos_model', w=5e-6, l=0.045e-6)
# 6. COMPENSATION & STABILITY COMPONENTS
circuit.C('c', 'Node1', 'Vout', 1@u_pF)  # Miller capacitor
circuit.R('z', 'Node1', 'Vout', 1@u_kΩ)  # Nulling resistor (improves phase margin)
# 7. INPUT/OUTPUT LOADS FOR REALISM (Critical for GBW simulation)
circuit.R('inp', 'Vinp', circuit.gnd, 1@u_MΩ)  # Input impedance
circuit.R('inn', 'Vinn', circuit.gnd, 1@u_MΩ)
circuit.C('out', 'Vout', circuit.gnd, 100@u_fF)  # Output load
# 8. INITIAL CONDITIONS (Helps convergence)
circuit.ic(node='Vout', voltage=0.6)  # Mid-rail startup
circuit.ic(node='Node1', voltage=0.6)
# Analysis command
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
