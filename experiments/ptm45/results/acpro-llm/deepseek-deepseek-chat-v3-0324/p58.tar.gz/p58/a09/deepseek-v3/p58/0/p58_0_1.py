from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
circuit = Circuit('Multi-Stage Opamp with High GBW')
# Define MOSFET Models (critical fix: add .model statements)
circuit.model('nmos_model', 'nmos', level=1, kp=100e-6, vto=0.22)  # Example NMOS params
circuit.model('pmos_model', 'pmos', level=1, kp=50e-6, vto=-0.22)  # Example PMOS params
# Power Supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)  # 1.2V supply
circuit.V('bias', 'Vbias', circuit.gnd, 0.42@u_V)  # Bias voltage (Vth + 0.2V)
# Differential Pair (Stage 1)
circuit.MOSFET('1', 'Node1', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # M1
circuit.MOSFET('2', 'Node2', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)  # M2
circuit.MOSFET('3', 'Node1', 'Node1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # M3 (diode-connected)
circuit.MOSFET('4', 'Node2', 'Node1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # M4 (mirror)
circuit.MOSFET('5', 'Tail', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # M5 (tail current)
# Common-Source Stage (Stage 2)
circuit.MOSFET('6', 'Vout', 'Node1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)  # M6
circuit.MOSFET('7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # M7 (active load)
# Bias Network (critical fix: ensure M8/M9 generate Vbias_p)
circuit.MOSFET('8', 'Vbias_p', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)  # M8 (diode-connected)
circuit.MOSFET('9', 'Vbias_p', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)  # M9
# Compensation Capacitor (critical fix: ensure Cc is connected)
circuit.C('c', 'Node1', 'Vout', 1@u_pF)  # Miller capacitor
# Analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
