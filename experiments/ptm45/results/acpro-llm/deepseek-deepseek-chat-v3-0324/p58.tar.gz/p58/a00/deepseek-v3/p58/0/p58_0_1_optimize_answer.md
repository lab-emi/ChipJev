Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp (Zero Common-Mode Gain)')
    
    # Define MOSFET models (fixed)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
    
    # Biasing Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1']@u_V)  # M5: Vth + 2*Vdsat
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2']@u_V)  # M7: Vth + Vdsat
    
    # Input Sources (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # DC bias for Vinp (mid-rail)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # DC bias for Vinn (mid-rail)
    
    # Differential Pair (parameterized widths)
    circuit.MOSFET('1', 'Vx', 'Vinp', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Vy', 'Vinn', 'Tail', circuit.gnd, 
                  model='nmos_model', w=params['w_M2'], l=0.045e-6)
    
    # Active Load (parameterized widths)
    circuit.MOSFET('3', 'Vx', 'Vy', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Vy', 'Vy', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M4'], l=0.045e-6)
    
    # Tail Current Source (parameterized width)
    circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Second Stage (parameterized widths)
    circuit.MOSFET('6', 'Vout', 'Vx', 'Vdd', 'Vdd', 
                  model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                  model='nmos_model', w=params['w_M7'], l=0.045e-6)
    
    # Compensation Capacitor (parameterized)
    circuit.C('c', 'Vx', 'Vout', params['c_comp']@u_pF)  # Miller compensation
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Bias voltages (constrained to maintain proper operation)
    'vbias1': {'min': 0.5, 'max': 0.74},  # Original: 0.62V (0.8-1.2×, capped at 1.2V)
    'vbias2': {'min': 0.34, 'max': 0.5},  # Original: 0.42V (0.8-1.2×, capped at 1.2V)
    
    # Differential pair widths (M1, M2 - identical)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L (0.045µm)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Must match M1
    
    # Active load widths (M3, M4 - matched pair)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # Must match M3
    
    # Tail current source width (M5)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    
    # Second stage widths (M6, M7)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # 1-500× L
    
    # Compensation capacitor
    'c_comp': {'min': 1.0, 'max': 10.0, 'log': True},  # 0.5-5× original 2pF
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    'vbias1': 0.62,    # Original bias voltage for M5
    'vbias2': 0.42,    # Original bias voltage for M7
    
    'w_M1': 10e-6,     # Original width for M1
    'w_M2': 10e-6,     # Original width for M2
    'w_M3': 20e-6,     # Original width for M3
    'w_M4': 20e-6,     # Original width for M4
    'w_M5': 5e-6,      # Original width for M5
    'w_M6': 40e-6,     # Original width for M6
    'w_M7': 20e-6,     # Original width for M7
    
    'c_comp': 2.0,     # Original compensation capacitance
}

# Parameter descriptions
"""
Parameter descriptions:
- vbias1: Bias voltage for tail current source (M5), critical for proper biasing
- vbias2: Bias voltage for output stage NMOS (M7), affects output swing
- w_M1, w_M2: Widths of input differential pair NMOS transistors
- w_M3, w_M4: Widths of active load PMOS transistors (current mirror)
- w_M5: Width of tail current source NMOS transistor
- w_M6: Width of output stage PMOS transistor
- w_M7: Width of output stage NMOS transistor
- c_comp: Miller compensation capacitor for stability
"""
```

Key features of this implementation:
1. All voltage sources except power supply and inputs are parameterized with conservative ranges (0.8-1.2× original values)
2. All transistor widths are parameterized with 1-500× length constraints (45nm process)
3. Compensation capacitor has 0.5-5× original value range
4. Initial parameters exactly match original circuit values
5. Function named exactly `create_circuit` as required
6. Load capacitors are not included since none were explicitly defined as load capacitors in your original circuit
7. Voltage ranges carefully constrained to stay below 1.2V and above threshold voltage (0.22V)
8. All parameters have meaningful ranges that maintain circuit functionality while allowing optimization