from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage Opamp (Zero Common-Mode Gain)')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power Supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2@u_V)
# Biasing Voltages (Critical for zero CM gain)
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.62@u_V)  # M5: Vth + 2*Vdsat = 0.22 + 0.4
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.42@u_V)  # M7: Vth + Vdsat = 0.22 + 0.2
# Input Sources (Required for CM gain simulation)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6@u_V)  # DC bias for Vinp (mid-rail)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6@u_V)  # DC bias for Vinn (mid-rail)
# Differential Pair (Identical Sizing)
circuit.MOSFET('1', 'Vx', 'Vinp', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('2', 'Vy', 'Vinn', 'Tail', circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Active Load (Perfectly Matched PMOS Mirror)
circuit.MOSFET('3', 'Vx', 'Vy', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('4', 'Vy', 'Vy', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail Current Source (Ensures Symmetry)
circuit.MOSFET('5', 'Tail', 'Vbias1', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second Stage (High Gain)
circuit.MOSFET('6', 'Vout', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Compensation Capacitor (Suppresses CM gain)
circuit.C('c', 'Vx', 'Vout', 2@u_pF)  # Miller compensation
# Analysis Part (Simulates DC operating point)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("deepseek-v3/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
