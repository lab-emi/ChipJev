Here's the parameterized version of your multi-stage opamp circuit following all your requirements:

```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    circuit = Circuit('Multi-Stage Opamp')
    
    # Define the MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    
    # Power Supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2) # 1.2V power supply
    
    # Bias Voltages (parameterized)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['vbias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['vbias2'])
    circuit.V('bias3', 'Vbias3', circuit.gnd, params['vbias3'])
    
    # Input Signals (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    
    # Stage 1: Differential Pair with Active Load
    circuit.MOSFET('1', 'Drain1', 'Vinp', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M1'], l=0.045e-6)
    circuit.MOSFET('2', 'Drain2', 'Vinn', 'SourcePair', circuit.gnd, 
                   model='nmos_model', w=params['w_M2'], l=0.045e-6)
    circuit.MOSFET('3', 'Drain1', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M3'], l=0.045e-6)
    circuit.MOSFET('4', 'Drain2', 'Drain1', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M4'], l=0.045e-6)
    circuit.MOSFET('5', 'SourcePair', 'Vbias1', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M5'], l=0.045e-6)
    
    # Stage 2: Common-Source Amplifier with Current Source Load
    circuit.MOSFET('6', 'Vout', 'Drain2', 'Vdd', 'Vdd', 
                   model='pmos_model', w=params['w_M6'], l=0.045e-6)
    circuit.MOSFET('7', 'Vout', 'Vbias2', circuit.gnd, circuit.gnd, 
                   model='nmos_model', w=params['w_M7'], l=0.045e-6)
    
    # Miller Compensation (fixed)
    circuit.C('c', 'Vout', 'Drain2', 1@u_pF)
    
    return circuit

# Optimization parameter search ranges
param_ranges_definition = {
    # Transistor widths (all in meters)
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M1 width (1-500× L)
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M2 width (1-500× L)
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M3 width (1-500× L)
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M4 width (1-500× L)
    'w_M5': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M5 width (1-500× L)
    'w_M6': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M6 width (1-500× L)
    'w_M7': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # M7 width (1-500× L)
    
    # Bias voltages (all in volts)
    'vbias1': {'min': 0.336, 'max': 0.504},  # Vbias1 (0.8-1.2× 0.42V, ≤1.2V)
    'vbias2': {'min': 0.336, 'max': 0.504},  # Vbias2 (0.8-1.2× 0.42V, ≤1.2V)
    'vbias3': {'min': 0.624, 'max': 0.936},  # Vbias3 (0.8-1.2× 0.78V, ≤1.2V)
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 20e-6,
    'w_M6': 30e-6,
    'w_M7': 15e-6,
    
    # Bias voltages
    'vbias1': 0.42,
    'vbias2': 0.42,
    'vbias3': 0.78,
}
```

### Parameter Descriptions:

1. **Transistor Widths (w_M1-w_M7)**:
   - Controls current drive capability and transconductance of each transistor
   - Initial values preserve the relative sizing (e.g., M6 wider than others for higher drive)
   - Range allows 1-500× the 45nm channel length (0.045μm)

2. **Bias Voltages (vbias1-vbias3)**:
   - vbias1: Tail current source bias (M5) - critical for input pair operation
   - vbias2: Current source load bias (M7) - affects gain stage biasing
   - vbias3: PMOS current source bias (not used but included for completeness)
   - Ranges limited to ±20% of original values to maintain proper operation
   - All constrained to stay below 1.2V supply

### Notes:
- The Miller compensation capacitor (1pF) is kept fixed as requested
- All initial values are exactly preserved from your original circuit
- Voltage ranges are conservative to maintain proper transistor operation regions
- Transistor lengths are fixed at 45nm as per your requirements
- Parameter ranges use logarithmic scaling for widths (common in analog optimization)