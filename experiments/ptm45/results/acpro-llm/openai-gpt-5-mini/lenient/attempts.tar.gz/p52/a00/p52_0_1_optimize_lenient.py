from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized Single-Stage Differential OpAmp circuit.
    Required: the module `model` must provide nmos_params and pmos_params.
    - vdd and input voltages are kept fixed (not parameterized).
    - Transistor channel lengths (L) are fixed per the original circuit.
    - Only transistor widths (W) and the tail bias voltage are parameterized.
    """
    circuit = Circuit('Single-Stage Differential OpAmp (Parameterized)')
    # MOSFET models (unchanged)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply and input voltages (fixed per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd fixed at 1.2 V (DO NOT PARAMETERIZE)
    circuit.V('vinp', 'Vinp', circuit.gnd, 0.6)       # Input+ fixed at 0.6 V (swept externally)
    circuit.V('vinn', 'Vinn', circuit.gnd, 0.6)       # Input- fixed at 0.6 V (swept externally)
    # Tail bias (parameterized)
    circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, params['Vbias_tail'])
    # Node naming:
    # - Vout : left drain / explicit amplifier output
    # - Vmid : right drain / mirror reference drain
    # - S    : common source (tail drain) of the input pair
    # NMOS differential pair (input devices)
    # Length fixed at 45e-9 (45 nm); widths parameterized
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=45e-9)   # left input transistor
    circuit.MOSFET('M2', 'Vmid', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=45e-9)   # right input transistor (mirror reference drain = Vmid)
    # NMOS tail current source - bulk tied to ground, longer L for higher output resistance
    circuit.MOSFET('Mtail', 'S', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=90e-9)   # tail device (L = 90 nm per original)
    # PMOS active mirror load (diode-connected reference and mirror output)
    # PMOS bulks tied to Vdd (their sources). Lengths are 90 nm per original.
    circuit.MOSFET('Mp_ref', 'Vmid', 'Vmid', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_Mp_ref'],
                   l=90e-9)   # diode-connected PMOS on reference node
    circuit.MOSFET('Mp_out', 'Vout', 'Vmid', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_Mp_out'],
                   l=90e-9)   # mirrored PMOS to output node
    return circuit
# Parameter ranges definition (for the optimizer to sample from)
# Suggest using log sampling for widths (covers many decades effectively).
param_ranges_definition = {
    # NMOS input pair (L = 45e-9 in original)
    'w_M1': {'min': 45e-9 * 1.0,       'max': 45e-9 * 500.0,  'log': True},  # original W = 12e-6
    'w_M2': {'min': 45e-9 * 1.0,       'max': 45e-9 * 500.0,  'log': True},  # original W = 12e-6
    # NMOS tail (L = 90e-9 in original)
    'w_Mtail': {'min': 90e-9 * 1.0,    'max': 90e-9 * 500.0,  'log': True},  # original W = 4e-6
    # PMOS mirror devices (L = 90e-9 in original)
    'w_Mp_ref': {'min': 90e-9 * 1.0,   'max': 90e-9 * 500.0,  'log': True},  # original W = 12e-6
    'w_Mp_out': {'min': 90e-9 * 1.0,   'max': 90e-9 * 500.0,  'log': True},  # original W = 12e-6
    # Tail bias voltage: 0.8 - 1.2 × original (but never exceed 1.2 V supply)
    # original Vbias_tail = 0.42 V -> range = [0.336, 0.504]
    'Vbias_tail': {'min': max(0.8 * 0.42, 0.0), 'max': min(1.2 * 0.42, 1.2), 'log': False}
}
initial_params = {
    # Transistor widths (exact values from your provided netlist)
    'w_M1': 12e-6,     # left input transistor original width
    'w_M2': 12e-6,     # right input transistor original width
    'w_Mtail': 4e-6,   # tail transistor original width
    'w_Mp_ref': 12e-6, # diode-connected PMOS original width
    'w_Mp_out': 12e-6, # mirrored PMOS original width
    # Tail bias (exact original)
    'Vbias_tail': 0.42
}
