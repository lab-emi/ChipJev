from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
# Fixed process length (45 nm)
L = 0.045e-6  # 45 nm in meters
def create_circuit(params):
    """
    Create the Single-Stage Differential Amplifier with PMOS Active Load,
    parameterized for optimization. Uses params dict for transistor widths
    and the tail voltage. Vdd, Vinp and Vinn are kept fixed (not parameterized).
    """
    circuit = Circuit('Single-Stage Differential Amplifier with PMOS Active Load')
    # MOSFET models (provided externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and DC bias sources
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd fixed at 1.2 V (not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp fixed at 0.6 V (swept externally)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn fixed at 0.6 V (swept externally)
    # Tail bias - parameterized (must remain <= 1.2 V)
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])
    # Differential pair (NMOS) - lengths are fixed, widths parameterized
    circuit.MOSFET('M1', 'D1', 'Vinp', 'SS', 'SS',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'SS', 'SS',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS active load (current mirror)
    # M3: diode-connected PMOS (drain tied to gate at D1)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # M4: mirror PMOS (gate tied to D1)
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('M5', 'SS', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    return circuit
# Process length used (fixed)
L_fixed = 0.045e-6   # 45 nm
# Width search bounds follow rule: 1×L to 500×L
w_min = L_fixed
w_max = 500.0 * L_fixed  # 22.5e-6
# Tail voltage original = 0.6 V -> allowed 0.8-1.2× original but never > 1.2 V
v_tail_min = max(0.8 * 0.6, 0.0)  # 0.48 V
v_tail_max = min(1.2 * 0.6, 1.2)  # 0.72 V
param_ranges_definition = {
    # Transistor widths (in meters). Sampling can be log-uniform or uniform;
    # log sampling often helps explore many decades of W.
    'w_M1': {'min': w_min, 'max': w_max, 'log': True},
    'w_M2': {'min': w_min, 'max': w_max, 'log': True},
    'w_M3': {'min': w_min, 'max': w_max, 'log': True},
    'w_M4': {'min': w_min, 'max': w_max, 'log': True},
    'w_M5': {'min': w_min, 'max': w_max, 'log': True},
    # Tail bias voltage (in volts) - linear sampling recommended
    'v_tail': {'min': v_tail_min, 'max': v_tail_max, 'log': False},
}
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 10e-6,   # M1 original width
    'w_M2': 10e-6,   # M2 original width
    'w_M3': 20e-6,   # M3 original width
    'w_M4': 20e-6,   # M4 original width
    'w_M5': 2e-6,    # M5 original width
    # Tail bias (exact original value)
    'v_tail': 0.6,   # Tail bias original value
}
