from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: model import is required exactly as written inside the create_circuit function per requirements
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('High-Gain Multi-Stage Opamp (no positive feedback)')
    # Attach device models (assumed defined in model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and DC bias sources
    # Vdd is fixed and must remain 1.2V per requirements
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                          # Vdd = 1.2 V
    # Input voltages are fixed (will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)                        # Vinp DC (common-mode)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)                        # Vinn DC (common-mode)
    # Parameterized bias voltages (constrained ranges provided separately)
    circuit.V('bpc', 'Vb_pcas', circuit.gnd, params['Vb_pcas'])       # PMOS cascode gate bias
    circuit.V('btail', 'Vb_tail', circuit.gnd, params['Vb_tail'])    # NMOS tail gate bias
    # Technology nominal length (fixed)
    L = 0.045e-6  # 45 nm process - keep L fixed (only W is parameterized)
    # First stage: NMOS differential pair with NMOS tail
    circuit.MOSFET('M1', 'Out1', 'Vinp', 'SN', circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'Out2', 'Vinn', 'SN', circuit.gnd,
                   model='nmos_model', w=params['w_M2'], l=L)
    circuit.MOSFET('Mtail', 'SN', 'Vb_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L)
    # PMOS cascode + mirror load stack on both branches
    circuit.MOSFET('MPpc1', 'node_pc1', 'Vb_pcas', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_MPpc1'], l=L)
    circuit.MOSFET('MPpc2', 'node_pc2', 'Vb_pcas', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_MPpc2'], l=L)
    # PMOS mirror loads: sources/bulks tied to node_pcX
    circuit.MOSFET('MPL1', 'Out1', 'Out2', 'node_pc1', 'node_pc1',
                   model='pmos_model', w=params['w_MPL1'], l=L)
    circuit.MOSFET('MPL2', 'Out2', 'Out2', 'node_pc2', 'node_pc2',
                   model='pmos_model', w=params['w_MPL2'], l=L)
    # Second stage: NMOS common-source amplifier (driven by Out1)
    circuit.MOSFET('M7', 'Vout', 'Out1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M7'], l=L)
    # PMOS cascode + diode-connected load for the second stage
    circuit.MOSFET('MPpc_out', 'node_pcout', 'Vb_pcas', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_MPpc_out'], l=L)
    circuit.MOSFET('MPout', 'Vout', 'Vout', 'node_pcout', 'node_pcout',
                   model='pmos_model', w=params['w_MPout'], l=L)
    return circuit
param_ranges_definition = {
    # Transistor widths (W). Length L = 45e-9 is fixed in create_circuit.
    # The nominal constraint requested: W within 1x - 500x L -> [L, 500*L] = [45e-9, 22.5e-6].
    # However several original widths exceed 22.5e-6. To satisfy the requirement that
    # initial_params must be inside the search range, we extend the upper bound to
    # at least the original value when needed (see per-parameter max below).
    'w_M1'       : {'min': 45e-9,      'max': max(500*45e-9, 20e-6), 'log': True},  # original 20e-6
    'w_M2'       : {'min': 45e-9,      'max': max(500*45e-9, 20e-6), 'log': True},  # original 20e-6
    'w_Mtail'    : {'min': 45e-9,      'max': max(500*45e-9, 8e-6),  'log': True},  # original 8e-6
    'w_MPpc1'    : {'min': 45e-9,      'max': max(500*45e-9, 60e-6), 'log': True},  # original 60e-6
    'w_MPpc2'    : {'min': 45e-9,      'max': max(500*45e-9, 60e-6), 'log': True},  # original 60e-6
    'w_MPL1'     : {'min': 45e-9,      'max': max(500*45e-9, 40e-6), 'log': True},  # original 40e-6
    'w_MPL2'     : {'min': 45e-9,      'max': max(500*45e-9, 40e-6), 'log': True},  # original 40e-6
    'w_M7'       : {'min': 45e-9,      'max': max(500*45e-9, 30e-6), 'log': True},  # original 30e-6
    'w_MPpc_out' : {'min': 45e-9,      'max': max(500*45e-9, 60e-6), 'log': True},  # original 60e-6
    'w_MPout'    : {'min': 45e-9,      'max': max(500*45e-9, 40e-6), 'log': True},  # original 40e-6
    # Bias voltages (parameterized). All other voltage sources must be within 0.8-1.2x original
    # and not exceed 1.2 V. Vth = 0.22 V considered for conservative ranges. Use linear sampling.
    'Vb_pcas'    : {'min': max(0.8 * 0.78, 0.22 + 0.05), 'max': min(1.2 * 0.78, 1.2), 'log': False},
    'Vb_tail'    : {'min': max(0.8 * 0.42, 0.22 + 0.05), 'max': min(1.2 * 0.42, 1.2), 'log': False},
}
initial_params = {
    # Transistor widths (exact original values)
    'w_M1'       : 20e-6,
    'w_M2'       : 20e-6,
    'w_Mtail'    : 8e-6,
    'w_MPpc1'    : 60e-6,
    'w_MPpc2'    : 60e-6,
    'w_MPL1'     : 40e-6,
    'w_MPL2'     : 40e-6,
    'w_M7'       : 30e-6,
    'w_MPpc_out' : 60e-6,
    'w_MPout'    : 40e-6,
    # Bias voltages (exact original values)
    'Vb_pcas'    : 0.78,
    'Vb_tail'    : 0.42,
}
