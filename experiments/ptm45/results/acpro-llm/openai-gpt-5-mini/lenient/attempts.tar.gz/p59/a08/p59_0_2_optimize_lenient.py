from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import must appear exactly as written inside create_circuit()
# (the optimization framework will provide the module at runtime).
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage CS Amplifier - Parameterized')
    # Load external MOS models (provided by the environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd fixed at 1.2 V (do not include in search)
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.60)     # Vin fixed at 0.60 V (swept externally during DC analysis)
    # Bias voltage for PMOS gate (parameterized)
    # Note: all voltage parameters must remain <= 1.2 V and should be conservative around original values.
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # MOSFETs (lengths are fixed; only widths are parameterized)
    # M1: NMOS common-source (input)
    # Keep L fixed as in original netlist for each device (so initial values remain exact);
    # optimization will vary W only.
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=45e-9)   # L fixed (original M1 L)
    # M2: PMOS active load
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=180e-9)  # L fixed (original M2 L)
    # Bleed resistor to prevent floating node (parameterized)
    circuit.R('bleed', 'Vout', circuit.gnd, params['r_bleed'])
    return circuit
# Parameter ranges definition
# Note: units are SI (W in meters, R in ohms, V in volts)
param_ranges_definition = {
    # Transistor widths (W). Constraints: 1–500 × device L (L kept fixed per-device as in original netlist).
    # M1 original L = 45e-9 -> W range = [45e-9, 22.5e-6]
    'w_M1': { 'min': 1 * 45e-9,    'max': 500 * 45e-9,    'log': True },
    # M2 original L = 180e-9 -> W range = [180e-9, 90e-6]
    'w_M2': { 'min': 1 * 180e-9,   'max': 500 * 180e-9,   'log': True },
    # Bias voltage for PMOS gate (Vbias).
    # Rule: 0.8–1.2 × original, but never exceed 1.2 V.
    # Original Vbias = 0.20 V -> range = [0.16, 0.24] V
    # (This keeps PMOS Vsg = Vdd - Vbias comfortably > Vth=0.22 V for typical biases;
    # Vbias upper = 0.24 still keeps Vsg = 0.96 V > 0.22 V)
    'v_bias': { 'min': 0.8 * 0.20,  'max': min(1.2 * 0.20, 1.2), 'log': False },
    # Bleed resistor: 0.5–2 × original
    # Original Rbleed = 1e9 ohm -> range = [0.5e9, 2e9] ohm
    'r_bleed': { 'min': 0.5e9,      'max': 2e9,             'log': True },
}
# Initial parameter values (EXACT original circuit values; these must not be modified)
initial_params = {
    'w_M1': 12e-6,     # Original M1 width (12 µm)
    'w_M2': 24e-6,     # Original M2 width (24 µm)
    'v_bias': 0.20,    # Original bias voltage (0.20 V)
    'r_bleed': 1e9,    # Original bleed resistor (1 GΩ)
}
