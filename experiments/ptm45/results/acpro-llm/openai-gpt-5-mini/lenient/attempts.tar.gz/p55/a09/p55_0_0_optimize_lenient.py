from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage CS Amplifier Optimized for GBW')
    # MOS models (provided by the environment via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, NOT part of optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V (fixed)
    # Input source (fixed, will be externally swept)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)          # Vin DC bias (fixed)
    # Parameterized bias source (allowed to vary within constrained range)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # bias for PMOS gate
    # Process length (fixed for 45 nm technology)
    L_min = 45e-9     # 45 nm, kept constant (only W is optimized)
    # MOSFETs (W taken from params, L fixed)
    # Single-stage common-source NMOS (M1)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)
    # PMOS current-source load (M2) - gate biased by Vbias
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_min)
    # (No load capacitances were present in the original netlist;
    # any load caps are intentionally kept fixed per instructions.)
    return circuit
param_ranges_definition = {
    # Transistor widths (W). Length fixed at 45e-9.
    # The requested 1-500×L gives an upper bound of 500*45e-9 = 22.5e-6,
    # but original widths exceed that. To ensure the initial values remain in-range,
    # the max is chosen as max(500*L, original_value).
    'w_M1': {
        'min': 1 * 45e-9,                               # 1×L
        'max': max(500 * 45e-9, 30e-6),                 # ensure original (30e-6) is included
        'log': True
    },
    'w_M2': {
        'min': 1 * 45e-9,
        'max': max(500 * 45e-9, 60e-6),                 # ensure original (60e-6) is included
        'log': True
    },
    # Bias voltages (0.8-1.2× original, clipped at <= 1.2 V)
    'v_bias': {
        'min': max(0.0, 0.8 * 0.78),                    # 0.624 V
        'max': min(1.2, 1.2 * 0.78),                    # 0.936 V (<= 1.2)
        'log': False
    },
    # No resistors, capacitors or load caps present in the original netlist to parameterize.
    # If later added, follow:
    # - Resistors: 0.5-2× original
    # - Critical caps: 0.5-5× original
    # - Other caps: 0.8-1.5× original
}
initial_params = {
    'w_M1': 30e-6,   # Original NMOS input transistor width = 30 µm
    'w_M2': 60e-6,   # Original PMOS load width = 60 µm
    'v_bias': 0.78,  # Original PMOS gate bias = 0.78 V
}
