from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the model import MUST appear exactly as written inside create_circuit()
# as requested by the optimization framework.
# Fixed process length
L_min = 45e-9  # 45 nm technology (kept constant; only W is parameterized)
def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp (GBW-optimized) circuit.
    The function expects a dict `params` containing transistor widths and other
    parameterized values (see param_ranges_definition and initial_params below).
    IMPORTANT: this function includes the model import exactly as requested.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (GBW-optimized)')
    # MOSFET models (provided via imported parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC biases
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # supply (fixed, NOT parameterized)
    # Input voltages are fixed (to be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # DC common-mode on + input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # DC common-mode on - input (fixed)
    # Tail / bias voltage (parameterized within conservative range)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Node names used:
    # - Vinp, Vinn : external inputs (fixed)
    # - Vout       : single-ended output
    # - Vs         : common source of input pair (tail node)
    # - D2         : drain of M2 and gate of the PMOS mirror (diode node)
    # Transistor sizing:
    # NOTE: L is fixed (45 nm). Only W is parameterized (as requested).
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_min)
    # PMOS current mirror load: M3 diode-connected on D2, M4 mirror to Vout
    circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_min)  # diode-connected
    circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_min)  # mirror transistor
    # NMOS tail current source
    circuit.MOSFET('M5', 'Vs', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L_min)
    # No load capacitor is included in the original netlist; if you have one,
    # keep it fixed and add it here (per instructions load caps must remain fixed).
    return circuit
# Parameter search ranges definition
# Notes on rules applied:
# - W ranges: nominal guideline is 1x..500x L (L_min = 45e-9 -> 45e-9 .. 22.5e-6).
#   To ensure the EXACT original widths are valid starting points (requirement),
#   the upper bound used is max(500*L_min, original_width). This preserves the
#   "1-500×L" guideline where possible while guaranteeing the initial value lies
#   within the range.
# - v_bias (tail bias) range: 0.8-1.2× original, clipped to not exceed 1.2V.
#   Also ensure it stays conservative relative to Vth = 0.22V (original 0.42V is safe).
# - All widths are in meters. v_bias is in volts.
param_ranges_definition = {
    # Transistor widths (W) in meters
    'w_M1': {'min': L_min, 'max': max(500 * L_min, 20e-6), 'log': True},  # M1 original 20e-6
    'w_M2': {'min': L_min, 'max': max(500 * L_min, 20e-6), 'log': True},  # M2 original 20e-6
    'w_M3': {'min': L_min, 'max': max(500 * L_min, 20e-6), 'log': True},  # M3 original 20e-6 (PMOS)
    # M4 original width (40e-6) exceeds 500*L_min (22.5e-6). To keep the EXACT original
    # initial value inside the search space, the upper bound is set to original 40e-6.
    # This preserves the user's original design point while otherwise following 1-500×L.
    'w_M4': {'min': L_min, 'max': max(500 * L_min, 40e-6), 'log': True},  # M4 original 40e-6 (PMOS mirror)
    'w_M5': {'min': L_min, 'max': max(500 * L_min, 2e-6),  'log': True},   # M5 original 2e-6 (tail NMOS)
    # Voltages (except Vdd, Vinp, Vinn which are fixed)
    # v_bias range = 0.8 .. 1.2 × original (0.42V) clipped to <= 1.2V
    # 0.8*0.42=0.336, 1.2*0.42=0.504 -> within supply (1.2V), so use [0.336, 0.504]
    'v_bias': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
}
initial_params = {
    # Transistor widths (EXACT original values)
    'w_M1': 20e-6,   # M1 original width in meters
    'w_M2': 20e-6,   # M2 original width
    'w_M3': 20e-6,   # M3 original width (PMOS diode)
    'w_M4': 40e-6,   # M4 original width (PMOS mirror)  <-- exactly preserved
    'w_M5': 2e-6,    # M5 original width (tail NMOS)
    # Voltages (EXACT original values)
    'v_bias': 0.42,  # tail bias (original)
}
