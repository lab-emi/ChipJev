from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    # Keep the requested import exactly as written
    from model import nmos_params, pmos_params
    circuit = Circuit('Three-Stage Cascoded CS Amplifier (Max Gain)')
    # MOSFET models (provided by external module 'model')
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and bias supplies
    # Vdd is fixed (do not include in optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V (fixed)
    # Input voltage is fixed (will be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC bias = Vth + 0.2 = 0.42 V (fixed)
    # Parameterized bias voltages (searchable)
    # These ranges are enforced externally via the optimizer using param_ranges_definition below
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['Vbias_p'])   # PMOS current device gate bias (parameterized)
    circuit.V('biaspc', 'Vbias_pc', circuit.gnd, params['Vbias_pc'])# PMOS cascode gate bias (parameterized)
    # Process length (fixed for 45nm technology)
    L = 0.045e-6  # 45 nm (fixed)
    # Stage 1 (input)
    # M1: NMOS common-source (drain = n1, gate = Vin, source = gnd, bulk = gnd)
    circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    # M2a: PMOS current device (top), drain = pcas1, gate = Vbias_p, source = Vdd, bulk = Vdd
    circuit.MOSFET('M2a', 'pcas1', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2a'], l=L)
    # M2c: PMOS cascode (lower), drain = n1, gate = Vbias_pc, source = pcas1, bulk tied to its source (pcas1)
    circuit.MOSFET('M2c', 'n1', 'Vbias_pc', 'pcas1', 'pcas1',
                   model='pmos_model', w=params['w_M2c'], l=L)
    # Stage 2 (middle)
    # M3: NMOS common-source (drain = n2, gate = n1, source = gnd, bulk = gnd)
    circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L)
    # M4a: PMOS current device (top), drain = pcas2, gate = Vbias_p, source = Vdd, bulk = Vdd
    circuit.MOSFET('M4a', 'pcas2', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4a'], l=L)
    # M4c: PMOS cascode (lower), drain = n2, gate = Vbias_pc, source = pcas2, bulk = pcas2
    circuit.MOSFET('M4c', 'n2', 'Vbias_pc', 'pcas2', 'pcas2',
                   model='pmos_model', w=params['w_M4c'], l=L)
    # Stage 3 (output)
    # M5: NMOS common-source (drain = Vout, gate = n2, source = gnd, bulk = gnd)
    circuit.MOSFET('M5', 'Vout', 'n2', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=L)
    # M6a: PMOS current device (top), drain = pcas3, gate = Vbias_p, source = Vdd, bulk = Vdd
    circuit.MOSFET('M6a', 'pcas3', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M6a'], l=L)
    # M6c: PMOS cascode (lower), drain = Vout, gate = Vbias_pc, source = pcas3, bulk = pcas3
    circuit.MOSFET('M6c', 'Vout', 'Vbias_pc', 'pcas3', 'pcas3',
                   model='pmos_model', w=params['w_M6c'], l=L)
    # No load capacitors were in the original netlist; if present, keep them fixed as requested.
    return circuit
# Process length (fixed): L = 0.045e-6 (45 nm)
L = 0.045e-6
param_ranges_definition = {
    # Transistor widths (W) in meters
    # Constraint: W in [1×L, 500×L] as requested (i.e., [L, 500*L])
    # Use log-scale search for device widths (recommended)
    'w_M1' :  {'min': L,        'max': 500*L,  'log': True},  # original 2e-6
    'w_M2a':  {'min': L,        'max': 500*L,  'log': True},  # original 10e-6
    'w_M2c':  {'min': L,        'max': 500*L,  'log': True},  # original 8e-6
    'w_M3' :  {'min': L,        'max': 500*L,  'log': True},  # original 3e-6
    'w_M4a':  {'min': L,        'max': 500*L,  'log': True},  # original 10e-6
    'w_M4c':  {'min': L,        'max': 500*L,  'log': True},  # original 8e-6
    'w_M5' :  {'min': L,        'max': 500*L,  'log': True},  # original 6e-6
    'w_M6a':  {'min': L,        'max': 500*L,  'log': True},  # original 12e-6
    'w_M6c':  {'min': L,        'max': 500*L,  'log': True},  # original 10e-6
    # Bias voltages (conservative variation: 0.8–1.2× original, but never > 1.2 V)
    # Note: optimizer must ensure values do not exceed 1.2 V (supply).
    # These ranges are computed as [max(0, 0.8*orig), min(1.2, 1.2*orig)]
    'Vbias_p' : {'min': 0.8 * 0.78, 'max': min(1.2, 1.2 * 0.78), 'log': False},  # original 0.78 V
    'Vbias_pc': {'min': 0.8 * 0.58, 'max': min(1.2, 1.2 * 0.58), 'log': False},  # original 0.58 V
}
# IMPORTANT: These initial parameter values are EXACTLY the original values from your netlist.
initial_params = {
    # Transistor widths (exact originals)
    'w_M1' :  2e-6,
    'w_M2a': 10e-6,
    'w_M2c':  8e-6,
    'w_M3' :  3e-6,
    'w_M4a': 10e-6,
    'w_M4c':  8e-6,
    'w_M5' :  6e-6,
    'w_M6a': 12e-6,
    'w_M6c': 10e-6,
    # Bias voltages (exact originals)
    'Vbias_p' : 0.78,
    'Vbias_pc': 0.58,
}
