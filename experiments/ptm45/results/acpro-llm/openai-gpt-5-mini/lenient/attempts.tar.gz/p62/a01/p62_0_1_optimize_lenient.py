from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized Multi-Stage GBW/Power Optimized Opamp - Fixed Tail.
    The function expects a dict `params` containing transistor widths (in meters),
    bias voltages (in volts) and the compensation capacitance (in Farads).
    Keep Vdd and input voltages fixed as required.
    """
    circuit = Circuit('Multi-Stage GBW/Power Optimized Opamp - Fixed Tail')
    # MOS models (provided externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC biases (fixed supply and input biases)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V (fixed)
    # Input common-mode DC biases (fixed; will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)         # Vinp = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)         # Vinn = 0.6 V (fixed)
    # Parameterized bias voltages (conservative ranges applied externally)
    circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, params['v_bias_tail'])  # NMOS tail gate
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['v_bias_p'])          # PMOS load gate
    # Use fixed length for all devices (45 nm process as in provided netlist)
    L = 0.045e-6
    # First stage: NMOS differential pair (M1, M2)
    circuit.MOSFET('M1', 'X', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Y', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS current mirror active load (M3 diode-connected on Y, M4 mirror to X)
    circuit.MOSFET('M3', 'Y', 'Y', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)  # diode-connected reference
    circuit.MOSFET('M4', 'X', 'Y', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)  # mirror leg
    # Tail NMOS current source (sink to ground)
    circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)
    # Second stage: common-source NMOS (M5) with PMOS active load (M6)
    circuit.MOSFET('M5', 'Vout', 'X', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L)
    # Compensation capacitor between first-stage output (X) and final output (Vout).
    # This is the critical compensation capacitor (subject to optimization).
    circuit.C('comp', 'X', 'Vout', params['c_comp'])
    return circuit
# Process length (fixed)
L = 0.045e-6  # 45 nm
# Compute a base 1-500*L range (for documentation)
min_W = 1 * L
max_W_500x = 500 * L
# Original widths from your netlist (EXACT original values must appear in initial_params)
orig_w = {
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_Mtail': 20e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
}
# Global maximum width selected to ensure all original widths are inside ranges.
# Prefer 500*L but extend if needed to include original values (see note above).
global_max_w = max(max_W_500x, max(orig_w.values()))
param_ranges = {
    # Transistor widths (meters). Log scale recommended for optimization.
    'w_M1': {'min': min_W, 'max': global_max_w, 'log': True},
    'w_M2': {'min': min_W, 'max': global_max_w, 'log': True},
    'w_M3': {'min': min_W, 'max': global_max_w, 'log': True},  # original 40e-6 > 500*L -> upper bound extended
    'w_M4': {'min': min_W, 'max': global_max_w, 'log': True},  # same as M3
    'w_Mtail': {'min': min_W, 'max': global_max_w, 'log': True},
    'w_M5': {'min': min_W, 'max': global_max_w, 'log': True},
    'w_M6': {'min': min_W, 'max': global_max_w, 'log': True},
    # Bias voltages (volts) - 0.8 - 1.2 × original, clipped to not exceed 1.2 V
    # Also keep conservative lower bounds considering Vth = 0.22 V (we do not push biases below ~Vth).
    'v_bias_tail': {
        'min': max(0.8 * 0.6, 0.0),     # 0.48 V
        'max': min(1.2 * 0.6, 1.2),     # 0.72 V
        'log': False
    },
    'v_bias_p': {
        'min': max(0.8 * 0.78, 0.0),    # 0.624 V
        'max': min(1.2 * 0.78, 1.2),    # 0.936 V
        'log': False
    },
    # Compensation capacitor (critical) - 0.5 - 5× original (Farads). Log sampling recommended.
    'c_comp': {
        'min': 0.5 * 2e-12,   # 1e-12 F
        'max': 5.0 * 2e-12,   # 1e-11 F
        'log': True
    }
}
initial_params = {
    # EXACT original widths (meters) from your netlist
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_Mtail': 20e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
    # EXACT original bias voltages (volts)
    'v_bias_tail': 0.6,
    'v_bias_p': 0.78,
    # EXACT original compensation cap (Farads)
    'c_comp': 2e-12,
}
