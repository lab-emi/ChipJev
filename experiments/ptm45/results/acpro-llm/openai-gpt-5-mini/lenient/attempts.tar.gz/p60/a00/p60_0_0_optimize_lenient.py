from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    # NOTE: keep this import exactly as written for the execution environment
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (NMOS input, PMOS mirror load)')
    # MOSFET models (provided by environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC nodes (Vdd and inputs are fixed per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Supply (fixed)
    circuit.V('vinp', 'Vinp', circuit.gnd, 0.60)   # Input + (fixed, swept externally)
    circuit.V('vinn', 'Vinn', circuit.gnd, 0.60)   # Input - (fixed, swept externally)
    # Parameterized bias source (allowed to vary within conservative bounds)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Technology length is fixed (45 nm). Only widths are parameterized.
    L = 0.045e-6  # 45 nm, fixed
    # Input NMOS transistors (left and right/output)
    circuit.MOSFET('M1', 'Node_NL', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS current mirror load: M3 diode-connected, M4 mirrored device
    circuit.MOSFET('M3', 'Node_NL', 'Node_NL', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    circuit.MOSFET('M4', 'Vout', 'Node_NL', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    # Tail current source (NMOS) from Iss to ground, gate tied to Vbias
    circuit.MOSFET('Mtail', 'Iss', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)
    return circuit
param_ranges_definition = {
    # Transistor widths (W) - constrained to 1×L .. 500×L (L = 45e-9 => min=45e-9, max=22.5e-6)
    # Use log sampling for device widths to cover wide dynamic range efficiently.
    'w_M1':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M1 input NMOS (left)
    'w_M2':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M2 input NMOS (right/output)
    'w_M3':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M3 PMOS diode (left)
    'w_M4':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M4 PMOS mirror (right/output)
    'w_Mtail': {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # Mtail NMOS tail device
    # Bias voltage: 0.8 - 1.2 × original, but not exceeding 1.2 V (original Vbias = 0.42 V)
    # 0.8*0.42 = 0.336 V, 1.2*0.42 = 0.504 V -> both below 1.2 V so upper bound = 0.504 V
    'v_bias':  {'min': 0.336,     'max': 0.504,      'log': False},  # Tail/gate bias (conservative linear sampling)
}
initial_params = {
    'w_M1':    10e-6,   # original M1 width
    'w_M2':    10e-6,   # original M2 width
    'w_M3':    20e-6,   # original M3 width (PMOS diode)
    'w_M4':    20e-6,   # original M4 width (PMOS mirror)
    'w_Mtail': 2e-6,    # original tail NMOS width
    'v_bias':  0.42,    # original bias voltage
}
