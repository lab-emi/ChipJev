from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Single-Stage Differential Op-Amp (Active PMOS Mirror Load)
    parameterized by transistor widths and the tail bias voltage.
    Required exact import from model: "from model import nmos_params, pmos_params"
    (kept exactly as requested).
    """
    circuit = Circuit('Single-Stage Differential Op-Amp (Active PMOS Mirror Load)')
    # Device models (assumed provided by the model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (not part of optimization)
    # Input voltages (fixed, to be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.5)  # Vinp fixed at 0.5 V
    circuit.V('inn', 'Vinn', circuit.gnd, 0.5)  # Vinn fixed at 0.5 V
    # Tail bias (parameterized; must remain <= 1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Process length (fixed for 45 nm technology)
    L = 0.045e-6  # 45 nm (length kept constant as requested)
    # Transistors (widths parameterized). Only W varies for optimization; L is fixed.
    circuit.MOSFET('M1', 'NodeL', 'Vinp', 'NodeS', circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'NodeS', circuit.gnd,
                   model='nmos_model', w=params['w_M2'], l=L)
    # PMOS current mirror load: M3 (diode-connected) and M4 (mirror)
    circuit.MOSFET('M3', 'NodeL', 'NodeL', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)  # diode-connected
    circuit.MOSFET('M4', 'Vout', 'NodeL', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)
    # NMOS tail current source
    circuit.MOSFET('M5', 'NodeS', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=L)
    # Note: There were no explicit resistors or capacitors in the original netlist
    # (except the implicit device parasitics). If you add load/compensation caps or resistors
    # later, follow the specified parameterization rules.
    return circuit
# Optimization parameter search ranges (annotated)
# All ranges chosen to satisfy the constraints:
# - Transistor Width (W): 1xL .. 500xL   (L = 45e-9 m -> range = [45e-9, 22.5e-6])
# - All voltages (except Vdd, Vinp, Vinn) scaled 0.8..1.2× original but <= 1.2V
#   (Original Vbias = 0.80 V -> range 0.8*0.80 .. 1.2*0.80 = [0.64, 0.96] V)
# - Use log-scale for widths to allow wide dynamic searching; linear for voltages.
param_ranges_definition = {
    # NMOS input pair widths (meters): original = 8e-6
    'w_M1': {'min': 1 * 0.045e-6, 'max': 500 * 0.045e-6, 'log': True},  # 45e-9 .. 22.5e-6
    'w_M2': {'min': 1 * 0.045e-6, 'max': 500 * 0.045e-6, 'log': True},  # same range
    # PMOS mirror widths (meters): original = 20e-6
    'w_M3': {'min': 1 * 0.045e-6, 'max': 500 * 0.045e-6, 'log': True},
    'w_M4': {'min': 1 * 0.045e-6, 'max': 500 * 0.045e-6, 'log': True},
    # NMOS tail width (meters): original = 2e-6
    'w_M5': {'min': 1 * 0.045e-6, 'max': 500 * 0.045e-6, 'log': True},
    # Tail bias voltage (V): original = 0.80 V
    # Range = 0.8..1.2 x original, but conservatively bounded and <= Vdd (1.2 V)
    # 0.8 * 0.80 = 0.64 V ; 1.2 * 0.80 = 0.96 V
    'v_bias': {'min': 0.64, 'max': 0.96, 'log': False},
}
# Initial parameter values (EXACT original values from your netlist)
initial_params = {
    # Transistor widths (meters) - EXACT original values (no modification)
    'w_M1': 8e-6,   # M1 original width
    'w_M2': 8e-6,   # M2 original width
    'w_M3': 20e-6,  # M3 original width
    'w_M4': 20e-6,  # M4 original width
    'w_M5': 2e-6,   # M5 original width
    # Tail bias voltage (V) - EXACT original value
    'v_bias': 0.80,  # Vbias original
}
