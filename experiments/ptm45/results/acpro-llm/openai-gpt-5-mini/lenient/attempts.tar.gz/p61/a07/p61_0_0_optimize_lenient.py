from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Two-Stage GBW/Power-Optimized Amplifier')
    # MOSFET models provided externally (model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and input supplies (fixed per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd fixed at 1.2 V (do not parameterize)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)     # Vin fixed at 0.42 V (swept externally)
    # Parameterized bias voltage (other voltages must be parameterized, within 0.8-1.2x original)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])  # original = 0.78 V
    # Fixed channel length for 45 nm process
    L = 45e-9
    # Stage 1: Common-source NMOS (M1) with PMOS active load (M2)
    circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'N1', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)
    # Stage 2: Common-source NMOS (M3) with PMOS active load (M4)
    circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M3'],
                   l=L)
    circuit.MOSFET('M4', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    return circuit
# Note on W ranges:
# - Recommended W range is 1×L .. 500×L (L = 45e-9 => 45e-9 .. 22.5e-6).
# - The original w_M2 = 40e-6 is larger than 500×L (40e-6 > 22.5e-6). To satisfy the
#   requirement that initial_params remain EXACT and inside the ranges, w_M2's upper bound
#   is set to the original value (40e-6). This is an explicit accommodation of the original
#   netlist; all other transistor widths obey the 1..500×L bound.
param_ranges_definition = {
    # Transistor widths (meters). Sampling log-scale is often useful for sizes over orders of magnitude.
    'w_M1': {'min': 1 * 45e-9, 'max': 500 * 45e-9, 'log': True},         # original 20e-6 (within 1..500×L)
    'w_M2': {'min': 1 * 45e-9, 'max': max(500 * 45e-9, 40e-6), 'log': True},  # original 40e-6 (exceeds 500×L)
    'w_M3': {'min': 1 * 45e-9, 'max': 500 * 45e-9, 'log': True},         # original 10e-6
    'w_M4': {'min': 1 * 45e-9, 'max': 500 * 45e-9, 'log': True},         # original 20e-6
    # Bias voltage ranges: 0.8 - 1.2 × original, but never exceed 1.2 V (supply).
    # Original Vbias = 0.78 V -> range = [0.624, 0.936] (0.936 < 1.2 so OK).
    'Vbias': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
}
# EXACT original values from the provided netlist (must be unchanged)
initial_params = {
    'w_M1': 20e-6,   # original M1 width
    'w_M2': 40e-6,   # original M2 width (note: exceeds 500×L; range was expanded to include it)
    'w_M3': 10e-6,   # original M3 width
    'w_M4': 20e-6,   # original M4 width
    'Vbias': 0.78,   # original PMOS gate bias
}
