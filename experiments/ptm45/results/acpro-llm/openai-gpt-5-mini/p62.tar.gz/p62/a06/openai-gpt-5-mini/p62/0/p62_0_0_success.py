from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage OpAmp Maximizing GBW/Power')
# MOSFET models (provided externally in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('tailbias', 'Vtail', circuit.gnd, 0.42)  # NMOS tail bias (Vth + 0.2)
circuit.V('pbias', 'Vp_bias', circuit.gnd, 0.78)   # PMOS gate bias (Vdd - |Vth| - 0.2)
# Input DC operating points (must exist for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # Vinp nominal DC
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # Vinn nominal DC
# Technology length (45 nm)
L = 0.045e-6
# First stage: differential NMOS pair
# M1: positive input transistor
circuit.MOSFET('M1', 'IntOut', 'Vinp', 'TailNode', circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# M2: negative input transistor
circuit.MOSFET('M2', 'D2', 'Vinn', 'TailNode', circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'TailNode', 'Vtail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=L)
# PMOS active load: diode-connected PMOS (M3) on branch 2 and mirror M4 to branch 1
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=L)   # diode-connected
circuit.MOSFET('M4', 'IntOut', 'D2', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)   # mirror transistor
# Second stage: single-ended common-source NMOS with PMOS current-source load
circuit.MOSFET('M5', 'Vout', 'IntOut', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)    # second-stage NMOS
circuit.MOSFET('M6', 'Vout', 'Vp_bias', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)   # PMOS load (current source)
# Miller compensation capacitor between second-stage output and first-stage output
circuit.C('ccomp', 'Vout', 'IntOut', 2@u_pF)
# The required input and output node names are present: Vinp, Vinn, Vout
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
