from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Differential Two-Stage Op-Amp (GBW/Power optimized)')
# MOSFET models (provided by external model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input common-mode DC biases (DC operating points only, no AC excitations)
# Use a reasonable common-mode bias ~ Vdd/2
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
# Bias voltages derived from Vth (Vth = 0.22 V per problem statement)
circuit.V('bias_tail', 'VbiasTail', circuit.gnd, 0.42)  # Vth + 0.2
circuit.V('bias_p', 'VbiasP', circuit.gnd, 0.78)        # Vdd - |Vth| - 0.2
# First stage: differential NMOS pair (M1, M2) with PMOS current mirror active load (M3 diode, M4 mirror)
# Node naming: D1 (drain of M1 and diode-connected PMOS), Vmid (single-ended first-stage output)
# Tail node: Tail
# M1: NMOS (Vinp)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Tail', 'Tail',
               model='nmos_model', w=4e-6, l=0.045e-6)
# M2: NMOS (Vinn)
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Tail', 'Tail',
               model='nmos_model', w=4e-6, l=0.045e-6)
# M3: PMOS diode-connected (drain = gate = D1), source = Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)
# M4: PMOS mirror transistor (gate tied to D1), drains to Vmid
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)
# Tail current sink Mtail: NMOS between Tail and ground, gate = VbiasTail
circuit.MOSFET('Mtail', 'Tail', 'VbiasTail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=1.2e-6, l=0.045e-6)
# Second stage: common-source NMOS (M6) with PMOS current source load (M7)
# M6: NMOS amplifier, gate = Vmid, drain = Vout
circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
               model='nmos_model', w=6e-6, l=0.045e-6)
# M7: PMOS current source load for second stage, gate biased by VbiasP
circuit.MOSFET('M7', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)
# Miller compensation capacitor between Vout and Vmid (dominant pole)
# Small value to favor GBW while ensuring dominance; tune as needed (2 fF chosen)
circuit.C('ccomp', 'Vout', 'Vmid', 2e-15)
# (Optional) You can add a small load at the output if desired; omitted to keep FoM focused on intrinsic stages.
# Create simulator (end of file per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)