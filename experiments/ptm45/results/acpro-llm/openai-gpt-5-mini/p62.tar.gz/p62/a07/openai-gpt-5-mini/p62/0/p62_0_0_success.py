from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Differential Two-Stage Op-Amp (GBW/Power optimized)')
# MOSFET models (provided by external model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input common-mode DC biases (DC operating points only, no AC excitations)
# Use a reasonable common-mode bias ~ Vdd/2
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Bias voltages derived from Vth (Vth = 0.22 V per problem statement)
circuit.V('bias_tail', 'VbiasTail', circuit.gnd, 0.42)  # Vth + 0.2
circuit.V('bias_p', 'VbiasP', circuit.gnd, 0.78)        # Vdd - |Vth| - 0.2
# First stage: differential NMOS pair (M1, M2) with PMOS current mirror active load (M3 diode, M4 mirror)
# Node naming: D1 (drain of M1 and diode-connected PMOS), Vmid (single-ended first-stage output)
# Tail node: Tail
# M1: NMOS (Vinp)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Tail', 'Tail',
               model='nmos_model', w=4e-6, l=0.045e-6)
# M2: NMOS (Vinn)
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Tail', 'Tail',
               model='nmos_model', w=4e-6, l=0.045e-6)
# M3: PMOS diode-connected (drain = gate = D1), source = Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)
# M4: PMOS mirror transistor (gate tied to D1), drains to Vmid
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)
# Tail current sink Mtail: NMOS between Tail and ground, gate = VbiasTail
circuit.MOSFET('Mtail', 'Tail', 'VbiasTail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=1.2e-6, l=0.045e-6)
# Second stage: common-source NMOS (M6) with PMOS current source load (M7)
# M6: NMOS amplifier, gate = Vmid, drain = Vout
circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
               model='nmos_model', w=6e-6, l=0.045e-6)
# M7: PMOS current source load for second stage, gate biased by VbiasP
circuit.MOSFET('M7', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)
# Miller compensation capacitor between Vout and Vmid (dominant pole)
# Small value to favor GBW while ensuring dominance; tune as needed (2 fF chosen)
circuit.C('ccomp', 'Vout', 'Vmid', 2e-15)
# (Optional) You can add a small load at the output if desired; omitted to keep FoM focused on intrinsic stages.
# Create simulator (end of file per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
