```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Differential Two-Stage Op-Amp (GBW/Power optimized)')

    # MOSFET models (provided by external model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V (fixed)

    # Input common-mode DC biases (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)

    # Bias voltages (parameterized; ranges are defined externally)
    circuit.V('bias_tail', 'VbiasTail', circuit.gnd, params['v_bias_tail'])  # original 0.42 V
    circuit.V('bias_p', 'VbiasP', circuit.gnd, params['v_bias_p'])            # original 0.78 V

    # Transistor dimensions: length fixed at 45 nm (0.045e-6 m); width parameterized.
    L = 0.045e-6

    # First stage: differential NMOS pair (M1, M2) with PMOS current mirror active load (M3 diode, M4 mirror)
    # M1: NMOS (Vinp)
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Tail', 'Tail',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # M2: NMOS (Vinn)
    circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Tail', 'Tail',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # M3: PMOS diode-connected (drain = gate = D1), source = Vdd
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)

    # M4: PMOS mirror transistor (gate tied to D1), drains to Vmid
    circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # Tail current sink Mtail: NMOS between Tail and ground, gate = VbiasTail
    circuit.MOSFET('Mtail', 'Tail', 'VbiasTail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)

    # Second stage: common-source NMOS (M6) with PMOS current source load (M7)
    # M6: NMOS amplifier, gate = Vmid, drain = Vout
    circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M6'],
                   l=L)

    # M7: PMOS current source load for second stage, gate biased by VbiasP
    circuit.MOSFET('M7', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M7'],
                   l=L)

    # Miller compensation capacitor between Vout and Vmid (dominant pole)
    # Keep the capacitor value parameterized within the allowed range
    circuit.C('ccomp', 'Vout', 'Vmid', params['c_comp'])

    return circuit


# =========================
# Optimization parameter search ranges (for Optuna or similar)
# =========================

L = 0.045e-6                     # device length (fixed)
W_min = L                        # 1×L
W_max = 500 * L                  # 500×L

param_ranges_definition = {
    # Transistor widths (meters) - search multiplicatively across wide range
    'w_M1':    {'min': W_min,      'max': W_max,      'log': True},  # original 4e-6
    'w_M2':    {'min': W_min,      'max': W_max,      'log': True},  # original 4e-6
    'w_M3':    {'min': W_min,      'max': W_max,      'log': True},  # original 8e-6 (pmos)
    'w_M4':    {'min': W_min,      'max': W_max,      'log': True},  # original 8e-6 (pmos)
    'w_Mtail': {'min': W_min,      'max': W_max,      'log': True},  # original 1.2e-6
    'w_M6':    {'min': W_min,      'max': W_max,      'log': True},  # original 6e-6
    'w_M7':    {'min': W_min,      'max': W_max,      'log': True},  # original 8e-6 (pmos)

    # Bias voltages (conservative 0.8-1.2× original, clipped to <= 1.2V)
    # Note: these are linear ranges (not log-scaled). They are chosen conservatively
    # to keep devices biased reasonably relative to Vth = 0.22 V and Vdd = 1.2 V.
    'v_bias_tail': {
        'min': max(0.8 * 0.42, 0.0),   # 0.336
        'max': min(1.2 * 0.42, 1.2),   # 0.504
        'log': False
    },
    'v_bias_p': {
        'min': max(0.8 * 0.78, 0.0),   # 0.624
        'max': min(1.2 * 0.78, 1.2),   # 0.936
        'log': False
    },

    # Compensation capacitor (critical): 0.5 - 5 × original (2e-15 F)
    'c_comp': {
        'min': 0.5 * 2e-15,   # 1e-15 F
        'max': 5.0 * 2e-15,   # 1e-14 F
        'log': True
    },
}

# =========================
# Initial parameter values (EXACT original circuit values from provided netlist)
# =========================
initial_params = {
    # Transistor widths (exact original values)
    'w_M1':    4e-6,
    'w_M2':    4e-6,
    'w_M3':    8e-6,
    'w_M4':    8e-6,
    'w_Mtail': 1.2e-6,
    'w_M6':    6e-6,
    'w_M7':    8e-6,

    # Bias voltages (exact original values)
    'v_bias_tail': 0.42,
    'v_bias_p':    0.78,

    # Compensation capacitor (exact original value)
    'c_comp': 2e-15,
}

# =========================
# Brief description of each parameter (physical meaning)
# =========================
# w_M1, w_M2   : Width of the input differential NMOS transistors (sets gm, Ic)
# w_M3, w_M4   : Width of the PMOS current-mirror load transistors in first stage
# w_Mtail      : Width of the NMOS tail current sink (sets tail current for first stage)
# w_M6         : Width of the NMOS second-stage amplifier transistor (sets gm of stage 2)
# w_M7         : Width of the PMOS load transistor for second stage (current source)
# v_bias_tail  : Gate bias for tail current sink (Mtail). Original = 0.42 V (Vth + 0.2)
# v_bias_p     : Gate bias for PMOS current source (M7). Original = 0.78 V (Vdd - |Vth| - 0.2)
# c_comp       : Miller (dominant) compensation capacitor between Vout and Vmid. Original = 2e-15 F
#
# Notes:
# - Vdd (1.2 V) and input voltages Vinp/Vinn (0.6 V) are kept fixed and are not part of the search.
# - All transistor channel lengths (L) are fixed at 45 nm (0.045e-6 m). Only widths (W) are optimized,
#   since circuit behavior in first order depends on W/L ratios.
# - All bias voltage ranges were chosen conservatively (0.8–1.2× original) while ensuring they never
#   exceed Vdd = 1.2 V and remain compatible with Vth = 0.22 V.
# - The initial_params dictionary contains exactly the original values provided in your netlist.
```