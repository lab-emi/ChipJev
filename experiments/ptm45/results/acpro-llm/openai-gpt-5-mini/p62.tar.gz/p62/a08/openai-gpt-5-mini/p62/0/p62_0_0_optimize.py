from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Two-Stage OpAmp circuit with parameterized transistor widths,
    bias voltages and the compensation capacitor.
    Important:
      - The import line `from model import nmos_params, pmos_params` is kept
        exactly as requested (above).
      - Vdd and input voltages (Vinp, Vinn) are fixed and NOT parameterized.
      - Transistor channel length (L) is fixed for the process (45 nm).
      - The Miller compensation capacitor (Ccomp) is parameterized (pF).
      - Load capacitors (if any) must be kept fixed and are not included here.
    """
    # Fixed technology length (45 nm expressed as used in original netlist)
    L = 0.045e-6  # 45e-9 m
    circuit = Circuit('Two-Stage OpAmp for High GBW/Power FoM')
    # MOSFET models (provided externally as requested)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V (fixed)
    # Input voltages (fixed, not parameterized; will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)          # Vinp = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)          # Vinn = 0.6 V (fixed)
    # Parameterized bias voltages (subject to optimization)
    # params['Vbias_n'] and params['Vbias_p'] are expected in volts
    circuit.V('biasn', 'Vbias_n', circuit.gnd, params['Vbias_n'])
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['Vbias_p'])
    # Node names:
    # Iss  - tail/source node of input pair
    # Vmid - single-ended first-stage output
    # Vnode_right - right branch drain and diode node for PMOS mirror
    # Vout - final output
    # First stage: NMOS differential pair (M1, M2)
    circuit.MOSFET('M1', 'Vmid', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'Vnode_right', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model', w=params['w_M2'], l=L)
    # PMOS current mirror load
    # M4 is diode-connected (drain = gate = Vnode_right)
    circuit.MOSFET('M4', 'Vnode_right', 'Vnode_right', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)
    # M3 is mirror transistor supplying the left branch (drain -> Vmid, gate tied to Vnode_right)
    circuit.MOSFET('M3', 'Vmid', 'Vnode_right', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Iss', 'Vbias_n', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L)
    # Second stage: common-source NMOS (M6) with PMOS active load (M7)
    circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M6'], l=L)
    circuit.MOSFET('M7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M7'], l=L)
    # Miller compensation capacitor between first-stage output and final output
    # Ccomp is parameterized in pF; create with pF suffix for PySpice
    circuit.C('Ccomp', 'Vmid', 'Vout', f"{params['Ccomp']}p")
    # (No explicit load capacitor added here per original netlist)
    return circuit
# -----------------------------
# Optimization parameter ranges
# -----------------------------
# Fixed channel length
L = 0.045e-6  # 45 nm (kept constant)
# Original widths in the provided netlist (used to ensure initial_params are valid):
_original_widths = {
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 40e-6,
    'w_M4': 20e-6,
    'w_Mtail': 4e-6,
    'w_M6': 20e-6,
    'w_M7': 40e-6,
}
_max_original_w = max(_original_widths.values())
# Per-stated rule: transistor width should be within 1-500× L.
# 500 * L = 22.5e-6 in this process. However, several original widths (40e-6)
# exceed 500×L. To satisfy the user's strict requirement that initial_params
# EXACTLY equal the original values AND be inside the search ranges, we allow
# the upper bound to be raised above 500×L where necessary to include the
# original design point. This is noted here for transparency.
#
# If strict enforcement of 1-500×L is required instead, change the max to 500*L;
# doing so would exclude the original W=40e-6 points from the search range,
# violating the "initial_params must equal original values and be within ranges" rule.
w_min = L                      # 1 × L
w_max = max(500 * L, _max_original_w * 1.2)  # allow some headroom beyond originals if needed
# Bias voltages - apply 0.8x to 1.2x original, capped at 1.2 V, and consider Vth.
Vth = 0.22  # MOS threshold voltage (given)
def bias_range(orig):
    low = max(0.8 * orig, Vth + 0.05)  # conservative lower bound not too close to Vth
    high = min(1.2 * orig, 1.2)        # do not exceed supply (1.2V)
    return low, high
param_ranges = {
    # Transistor widths (meters). Log-scale search is recommended for wide dynamic range.
    'w_M1': {'min': w_min, 'max': w_max, 'log': True},
    'w_M2': {'min': w_min, 'max': w_max, 'log': True},
    'w_M3': {'min': w_min, 'max': w_max, 'log': True},
    'w_M4': {'min': w_min, 'max': w_max, 'log': True},
    'w_Mtail': {'min': w_min, 'max': w_max, 'log': True},
    'w_M6': {'min': w_min, 'max': w_max, 'log': True},
    'w_M7': {'min': w_min, 'max': w_max, 'log': True},
    # Bias voltages (volts). Linear sampling is typical for voltages.
    # Ranges follow 0.8-1.2× original, constrained by supply and Vth consideration.
    'Vbias_n': {'min': bias_range(0.42)[0], 'max': bias_range(0.42)[1], 'log': False},
    'Vbias_p': {'min': bias_range(0.78)[0], 'max': bias_range(0.78)[1], 'log': False},
    # Compensation capacitor Ccomp (pF).
    # Critical compensation capacitors: 0.5-5× original (original = 2 pF)
    'Ccomp': {'min': 0.5 * 2.0, 'max': 5.0 * 2.0, 'log': True},  # in pF
}
# -----------------------------
# Initial parameter values (EXACT original values)
# -----------------------------
# These are the exact numeric values from the original netlist and MUST be preserved
# as the optimizer's starting point (per the user's instructions).
initial_params = {
    # Transistor widths (meters) - exact originals
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 40e-6,
    'w_M4': 20e-6,
    'w_Mtail': 4e-6,
    'w_M6': 20e-6,
    'w_M7': 40e-6,
    # Bias voltages (volts) - exact originals
    'Vbias_n': 0.42,
    'Vbias_p': 0.78,
    # Compensation capacitor (pF) - exact original
    'Ccomp': 2.0,
}
# Sanity check note (non-executable comment): all initial_params are ensured to be
# inside the corresponding param_ranges above. If your optimization framework
# requires different units (e.g., widths in micrometers), convert accordingly before use.
# -----------------------------
# Short descriptions of parameters
# -----------------------------
param_descriptions = {
    'w_M1':  "Width of NMOS input transistor M1 (meters). Sets gm and input pair current division.",
    'w_M2':  "Width of NMOS input transistor M2 (meters). Complementary to M1; differential pair.",
    'w_M3':  "Width of PMOS mirror transistor M3 (meters). Sets load current to left branch.",
    'w_M4':  "Width of PMOS diode-connected transistor M4 (meters). Mirror reference device.",
    'w_Mtail': "Width of NMOS tail device Mtail (meters). Sets tail current and tail output impedance.",
    'w_M6':  "Width of NMOS second-stage transistor M6 (meters). Sets gm of second stage.",
    'w_M7':  "Width of PMOS load transistor M7 for second stage (meters). Sets load and output swing.",
    'Vbias_n': "Tail bias voltage (volts) feeding Mtail gate. Controls tail current; keep > Vth for proper bias.",
    'Vbias_p': "PMOS load gate bias (volts). Controls second-stage load current; kept below Vdd (1.2V).",
    'Ccomp':  "Miller (compensation) capacitor between Vmid and Vout (pF). Critical for stability/GBW.",
}
# Expose the parameter metadata for external tooling (optional)
optimization_metadata = {
    'param_ranges': param_ranges,
    'initial_params': initial_params,
    'param_descriptions': param_descriptions,
    # note about L and Vdd for reference:
    'fixed': {'L': L, 'Vdd': 1.2, 'Vin(s)': {'Vinp': 0.6, 'Vinn': 0.6}, 'Vth': Vth},
}
