from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage OpAmp for High GBW/Power FoM')
# MOSFET models (provided via the external 'model' module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)          # Vinp DC common-mode (0.6 V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)          # Vinn DC common-mode (0.6 V)
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.42)    # NMOS tail bias (Vth + 0.2 = 0.42 V)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)    # PMOS load bias (Vdd - |Vth| - 0.2 = 0.78 V)
# Node names:
# Iss  - tail/source node of input pair
# Vmid - single-ended first-stage output
# Vnode_right - right branch drain and diode node for PMOS mirror
# Vout - final output
# First stage: NMOS differential pair (M1, M2)
# circuit.MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'Vmid', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vnode_right', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current mirror load
# M4 is diode-connected (drain = gate = Vnode_right)
circuit.MOSFET('M4', 'Vnode_right', 'Vnode_right', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M3 is the mirror transistor supplying the left branch (drain -> Vmid, gate tied to Vnode_right)
circuit.MOSFET('M3', 'Vmid', 'Vnode_right', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=0.045e-6)
# Second stage: common-source NMOS (M6) with PMOS active load (M7)
circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Miller compensation capacitor between first-stage output and final output
circuit.C('Ccomp', 'Vmid', 'Vout', 2@u_pF)
# A small load can be optionally connected at Vout if needed in experiments (not added here).
# Create simulator for operating point / further analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
