from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import MUST appear inside create_circuit exactly as requested:
# from model import nmos_params, pmos_params
# Fixed process length (keep L constant)
L = 0.045e-6  # 45 nm
def create_circuit(params):
    from model import nmos_params, pmos_params  # required import (kept exactly as requested)
    circuit = Circuit('Two-Stage Low-Power High-FoM OpAmp')
    # MOS models (external)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd fixed at 1.2 V (do not include in optimization)
    # Input sources (fixed, not parameterized; these will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp fixed at 0.6 V
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn fixed at 0.6 V
    # Bias voltages (parameterized; kept conservative within 0.8-1.2× original, <= 1.2V)
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p'])  # PMOS bias for active loads
    circuit.V('biasn', 'Vbias_n', circuit.gnd, params['v_bias_n'])  # NMOS tail bias
    # First stage: differential NMOS input pair
    # M1: drain N1, gate Vinp, source Tail, bulk = Tail
    circuit.MOSFET('M1', 'N1', 'Vinp', 'Tail', 'Tail',
                   model='nmos_model', w=params['w_M1'], l=L)
    # M2: drain N2, gate Vinn, source Tail, bulk = Tail
    circuit.MOSFET('M2', 'N2', 'Vinn', 'Tail', 'Tail',
                   model='nmos_model', w=params['w_M2'], l=L)
    # Tail current source (NMOS)
    # Mtail: drain Tail, gate Vbias_n, source gnd, bulk gnd
    circuit.MOSFET('Mtail', 'Tail', 'Vbias_n', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L)
    # PMOS active loads for differential pair (high impedance loads)
    # Mp1: drain N1, gate Vbias_p, source Vdd, bulk Vdd
    circuit.MOSFET('Mp1', 'N1', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_Mp1'], l=L)
    # Mp2: drain N2, gate Vbias_p, source Vdd, bulk Vdd
    circuit.MOSFET('Mp2', 'N2', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_Mp2'], l=L)
    # Second stage: single-ended NMOS common-source amplifier (driven from N1)
    # M3: drain Vout, gate N1, source gnd, bulk gnd
    circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L)
    # PMOS active load for second stage
    # Mp3: drain Vout, gate Vbias_p, source Vdd, bulk Vdd
    circuit.MOSFET('Mp3', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_Mp3'], l=L)
    # Miller compensation capacitor between Vout and the first-stage output node N1
    # This is a critical compensation cap (parameterized). Keep as parameterized critical cap.
    circuit.C('comp', 'Vout', 'N1', params['c_comp'])
    # No load capacitors explicit in original netlist (if present, they must remain fixed per requirements)
    return circuit
# ========== Optimization parameter search ranges ==========
# Note on width limits:
# - Nominal constraint: W ∈ [1×L, 500×L] => min_W = L, max_W_recommended = 500*L
# - To preserve the original starting point exactly (required), any transistor whose original W
#   exceed 500×L has its upper bound raised to include the original. Such exceptions are noted below.
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling due to wide dynamic range.
    'w_M1':  {'min': 1 * L,          'max': 500 * L,               'log': True},  # original 10e-6
    'w_M2':  {'min': 1 * L,          'max': 500 * L,               'log': True},  # original 10e-6
    'w_Mtail':{'min': 1 * L,         'max': 500 * L,               'log': True},  # original 5e-6
    'w_Mp1': {'min': 1 * L,          'max': 500 * L,               'log': True},  # original 20e-6
    'w_Mp2': {'min': 1 * L,          'max': 500 * L,               'log': True},  # original 20e-6
    'w_M3':  {'min': 1 * L,          'max': 500 * L,               'log': True},  # original 15e-6
    # Mp3 original width (30e-6) exceeds 500*L = 22.5e-6. To preserve initial_params EXACT value,
    # we extend the upper bound to include the original. This is an exception to the 500×L recommendation.
    'w_Mp3': {'min': 1 * L,          'max': max(500 * L, 30e-6),   'log': True},  # original 30e-6 (exception)
    # Bias voltages (V) - parameterized, conservative 0.8-1.2× original, clipped to <=1.2 V
    # All ranges are linear (not log).
    'v_bias_p': {'min': max(0.0, 0.8 * 0.78), 'max': min(1.2, 1.2 * 0.78), 'log': False},  # original 0.78 V
    'v_bias_n': {'min': max(0.0, 0.8 * 0.42), 'max': min(1.2, 1.2 * 0.42), 'log': False},  # original 0.42 V
    # Compensation capacitor (critical) - allow 0.5–5× original (original = 2e-15 F)
    'c_comp': {'min': 0.5 * 2e-15,   'max': 5.0 * 2e-15,         'log': True},  # original 2e-15 F
}
# ========== Initial parameter values (EXACT original values from the provided netlist) ==========
# IMPORTANT: these are the EXACT values taken from the original circuit code (no modifications).
initial_params = {
    # Transistor widths (meters) - EXACT original values
    'w_M1':   10e-6,   # M1 original width
    'w_M2':   10e-6,   # M2 original width
    'w_Mtail':5e-6,    # Mtail original width
    'w_Mp1':  20e-6,   # Mp1 original width
    'w_Mp2':  20e-6,   # Mp2 original width
    'w_M3':   15e-6,   # M3 original width
    'w_Mp3':  30e-6,   # Mp3 original width  (note: > 500×L; search upper bound was extended to include this)
    # Bias voltages (V) - EXACT original values
    'v_bias_p': 0.78,  # biasp original
    'v_bias_n': 0.42,  # biasn original
    # Compensation capacitor (F) - EXACT original value
    'c_comp': 2e-15,   # comp original
}
# ========== Parameter descriptions ==========
parameter_descriptions = {
    # Transistor widths (W), lengths (L fixed at 45 nm in code)
    'w_M1':   'Width of input NMOS M1 (N-side of differential pair). Affects gm, current, and input pole.',
    'w_M2':   'Width of input NMOS M2 (P-side of differential pair). Matches M1 for symmetry.',
    'w_Mtail':'Width of NMOS tail current source. Controls tail current magnitude and headroom.',
    'w_Mp1':  'Width of PMOS active load Mp1 for differential node N1. Sets load resistance and DC gain.',
    'w_Mp2':  'Width of PMOS active load Mp2 for differential node N2. Sets load resistance and DC gain.',
    'w_M3':   'Width of second-stage NMOS M3 (common-source). Affects gm of second stage and output drive.',
    'w_Mp3':  'Width of PMOS load Mp3 for second stage. Affects second-stage load current and gain. '
               'NOTE: original value (30e-6) exceeds 500×L; upper bound was extended to include the original start point.',
    # Bias voltages
    'v_bias_p':'PMOS bias voltage applied to gates of Mp1/Mp2/Mp3. Sets their operating point (must be <= Vdd).',
    'v_bias_n':'NMOS bias voltage driving tail transistor gate. Sets tail current (must be > Vth to turn on tail device).',
    # Compensation capacitor
    'c_comp': 'Miller compensation capacitor between Vout and N1 (dominant pole compensation). Critical: controls stability/GBW tradeoff.',
}
# Quick verification note (for integrator/optimizer):
# - All initial_params values are included exactly as provided by the original netlist.
# - All initial values are within the respective param_ranges_definition entries. (Mp3 was accommodated by extending its upper bound.)
