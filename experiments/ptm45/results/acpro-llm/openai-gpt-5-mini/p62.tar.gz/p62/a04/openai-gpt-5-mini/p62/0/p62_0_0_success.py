from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-FoM Two-Stage Opamp')
# Define MOSFET models (provided via imported parameter dicts)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp common-mode DC
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn common-mode DC
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.42) # NMOS tail gate bias (~Vth+0.2)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78) # PMOS gate bias (~Vdd - Vth - 0.2)
# Nodes used in the topology:
# Ss   : common source node of the differential pair
# D1   : diode/mirror reference node (drain of M1, gate of M3 and gate of M4)
# Vmid : single-ended intermediate node (drain of M2) -> feeds second stage
# Vout : final output node
# First stage: Differential pair with PMOS current mirror active load
# M1: input NMOS (left)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Ss', 'Ss', model='nmos_model', w=20e-6, l=45e-9)
# M2: input NMOS (right)
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Ss', 'Ss', model='nmos_model', w=20e-6, l=45e-9)
# M3: PMOS diode-connected (reference for mirror) - sets mirror current
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=45e-9)
# M4: PMOS mirror that forces mirrored current into Vmid node (single-ended conversion)
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=45e-9)
# Tail current source for differential pair (NMOS)
circuit.MOSFET('Mtail', 'Ss', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=45e-9)
# Second stage: Common-source NMOS amplifier with PMOS active load
# M5: second-stage NMOS
circuit.MOSFET('M5', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=45e-9)
# M6: PMOS current-source load for the second stage
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)
# End of topology. Prepare simulator (operating point / AC or transient can be run by user).
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
