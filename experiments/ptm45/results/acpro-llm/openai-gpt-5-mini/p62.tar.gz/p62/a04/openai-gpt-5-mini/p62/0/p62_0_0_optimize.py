from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following function MUST contain the line
# "from model import nmos_params, pmos_params" exactly as requested.
def create_circuit(params):
    """
    Create the two-stage op-amp circuit using parameter dictionary `params`.
    Required keys in params:
      - w_M1, w_M2, w_M3, w_M4, w_Mtail, w_M5, w_M6  (widths in meters)
      - v_bias_n, v_bias_p                          (voltages in volts)
    The function imports the MOSFET model parameter dictionaries from model.py
    (nmos_params, pmos_params) as required by the environment.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('High-FoM Two-Stage Opamp')
    # Attach transistor models (model dicts provided by environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power supply and input sources (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)     # Vdd fixed at 1.2 V (do not parameterize)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # Vinp fixed (swept externally)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # Vinn fixed (swept externally)
    # Parameterized bias voltage sources (constrained to be <= 1.2 V)
    circuit.V('biasn', 'Vbias_n', circuit.gnd, params['v_bias_n'])  # NMOS tail gate bias
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p'])  # PMOS gate bias
    # Technology length (fixed)
    L = 45e-9  # 45 nm process (kept constant, W is parameterized)
    # First stage: Differential pair with PMOS current mirror active load
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Ss', 'Ss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Ss', 'Ss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS diode-connected reference (mirror reference)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # PMOS mirror device that biases Vmid (single-ended conversion)
    circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    # Tail current source for differential pair
    circuit.MOSFET('Mtail', 'Ss', 'Vbias_n', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)
    # Second stage: Common-source NMOS amplifier with PMOS active load
    circuit.MOSFET('M5', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L)
    # No load capacitors are parameterized here; keep fixed if present externally.
    return circuit
# ---------------------------
# Parameter search ranges
# ---------------------------
# Length used for ratio calculations
_L = 45e-9
_max500L = 500 * _L  # recommended 1-500xL guideline (22.5e-6 m)
# Original widths (from the provided netlist) — these exact values will also be used
# as initial parameter values below. Note: some original widths exceed 500*L; to
# satisfy the requirement that initial values are inside the search range we expand
# the per-device upper bound to include the original value if necessary.
_original_widths = {
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_Mtail': 5e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
}
# For each transistor, set min = 1*L, max = max(500*L, original_width) to keep the
# initial (original) value inside the allowed search range while preserving the
# intended 1-500×L guideline where possible.
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling recommended for wide dynamic range.
    'w_M1': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_M1']), 'log': True},
    'w_M2': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_M2']), 'log': True},
    'w_M3': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_M3']), 'log': True},
    'w_M4': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_M4']), 'log': True},
    'w_Mtail': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_Mtail']), 'log': True},
    'w_M5': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_M5']), 'log': True},
    'w_M6': {'min': 1 * _L, 'max': max(_max500L, _original_widths['w_M6']), 'log': True},
    # Voltage biases (volts)
    # Rule: 0.8-1.2× original, but never exceed 1.2V (supply), keep conservative around Vth=0.22V.
    # Original bias voltages: biasn = 0.42 V, biasp = 0.78 V
    'v_bias_n': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
    'v_bias_p': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
}
# ---------------------------
# Initial parameters (EXACT original values)
# ---------------------------
# IMPORTANT: These initial_params entries are EXACTLY the values from the original
# netlist provided and are preserved without modification per the specification.
initial_params = {
    # Transistor widths from original netlist (meters)
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_Mtail': 5e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
    # Bias voltages from original netlist (volts)
    'v_bias_n': 0.42,
    'v_bias_p': 0.78,
}
# Sanity check: ensure initial values are within the declared ranges.
# (This check is illustrative; in the optimization environment you may validate similarly.)
for key, val in initial_params.items():
    rng = param_ranges_definition.get(key)
    if rng is not None:
        assert rng['min'] <= val <= rng['max'], (
            f"Initial parameter {key}={val} not in range [{rng['min']}, {rng['max']}]"
        )
# ---------------------------
# Parameter descriptions
# ---------------------------
param_descriptions = {
    # Transistor widths (W)
    'w_M1': "Width of input NMOS M1 (left diff pair). L fixed at 45 nm. Affects gm, current and output resistance.",
    'w_M2': "Width of input NMOS M2 (right diff pair). L fixed at 45 nm.",
    'w_M3': "Width of diode-connected PMOS M3 (mirror reference). Sets mirror reference current with M1/M2.",
    'w_M4': "Width of PMOS mirror device M4 that forces mirrored current into Vmid node.",
    'w_Mtail': "Width of NMOS tail transistor (Mtail). Controls tail current and common-mode operation.",
    'w_M5': "Width of second-stage NMOS (M5). Affects second stage gain and bias current.",
    'w_M6': "Width of PMOS load device for second stage (M6). Sets load current and Vout operating point.",
    # Bias voltages
    'v_bias_n': "NMOS bias voltage applied to the tail gate (Vbias_n). Range limited to 0.8-1.2× original and <= 1.2V. Keep > Vth (~0.22V) to maintain current source conduction.",
    'v_bias_p': "PMOS gate bias (Vbias_p) for second-stage load. Range limited to 0.8-1.2× original and <= 1.2V.",
}
# Exported objects for convenience in an optimization framework:
# - create_circuit(params)
# - param_ranges_definition
# - initial_params
# - param_descriptions
