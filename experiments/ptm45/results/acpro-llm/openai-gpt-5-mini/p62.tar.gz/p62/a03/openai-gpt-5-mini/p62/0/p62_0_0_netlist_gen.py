from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Differential OpAmp Optimized for GBW/Power')
# Models (imported parameters)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input nodes (DC bias only; no AC sources per instruction)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # mid-rail DC bias on positive input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # mid-rail DC bias on negative input
# Bias voltages using Vth = 0.22 V guideline
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)  # PMOS load bias (Vdd - Vth - 0.2)
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.42)  # NMOS tail bias (Vth + 0.2)
# Intermediate nodes
# N1: drain/diode node of left input branch (also gate of M3 diode)
# N2: single-ended first-stage output (drain of right input NMOS and drain of M4)
# Scommon: joined sources of M1/M2 (connected to drain of tail Mtail)
# Vcomp: series node between Vout and the compensation capacitor
# Vout: final amplifier output node (as required)
# First stage: differential NMOS pair
circuit.MOSFET('M1', 'N1', 'Vinp', 'Scommon', circuit.gnd,
                model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M2', 'N2', 'Vinn', 'Scommon', circuit.gnd,
                model='nmos_model', w=20e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Scommon', 'Vbias_n', circuit.gnd, circuit.gnd,
                model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS current-mirror active load for the differential pair
# M3 is diode-connected on the N1 side (drain tied to gate at N1)
circuit.MOSFET('M3', 'N1', 'N1', 'Vdd', 'Vdd',
                model='pmos_model', w=40e-6, l=0.045e-6)
# M4 mirrors M3, gate tied to N1, drain at N2
circuit.MOSFET('M4', 'N2', 'N1', 'Vdd', 'Vdd',
                model='pmos_model', w=40e-6, l=0.045e-6)
# Second stage: NMOS common-source amplifier
circuit.MOSFET('M5', 'Vout', 'N2', circuit.gnd, circuit.gnd,
                model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current-source load for second stage (gate biased by Vbias_p)
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                model='pmos_model', w=20e-6, l=0.045e-6)
# Series-RC Miller compensation: Vout -- Rcomp -- Vcomp -- Cc -- N2
circuit.R('comp', 'Vout', 'Vcomp', 50@u_Ohm)
circuit.C('c', 'Vcomp', 'N2', 2@u_pF)
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
