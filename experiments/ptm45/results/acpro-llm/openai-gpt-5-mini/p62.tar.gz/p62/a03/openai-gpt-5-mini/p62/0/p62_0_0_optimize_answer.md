```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the parameterized two-stage differential op-amp circuit.
    - `params` is a dictionary containing the tunable parameters.
    Notes:
      - Vdd and input sources (Vinp, Vinn) are fixed as in the original netlist.
      - Transistor lengths are fixed (45 nm / 0.045e-6 m) per the original netlist.
      - All transistor widths are taken from params in meters.
      - r_comp is in ohms (Ω).
      - c_comp is provided in pF in params; it is converted to Farads when creating the capacitor.
    """
    circuit = Circuit('Two-Stage Differential OpAmp Optimized for GBW/Power')

    # Preserve model import names exactly as required
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed supply (1.2 V)

    # Input nodes (fixed, will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # Fixed input bias (original)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # Fixed input bias (original)

    # Bias voltages (parameterized but constrained to <= 1.2 V)
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p'])
    circuit.V('biasn', 'Vbias_n', circuit.gnd, params['v_bias_n'])

    # Fixed device length (process minimum) - keep as in original
    L = 0.045e-6  # 45 nm in meters

    # First stage: differential NMOS pair (parameterized widths)
    circuit.MOSFET('M1', 'N1', 'Vinp', 'Scommon', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'N2', 'Vinn', 'Scommon', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # Tail current source (NMOS) - width parameterized
    circuit.MOSFET('Mtail', 'Scommon', 'Vbias_n', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)

    # PMOS current-mirror active load for the differential pair
    # M3 is diode-connected on the N1 side (drain tied to gate at N1)
    circuit.MOSFET('M3', 'N1', 'N1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # M4 mirrors M3, gate tied to N1, drain at N2
    circuit.MOSFET('M4', 'N2', 'N1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # Second stage: NMOS common-source amplifier (width parameterized)
    circuit.MOSFET('M5', 'Vout', 'N2', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)

    # PMOS current-source load for second stage (gate biased by Vbias_p)
    circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L)

    # Series-RC Miller compensation: Vout -- Rcomp -- Vcomp -- Cc -- N2
    # r_comp is given in ohms; c_comp is provided in pF in params (converted to F)
    circuit.R('comp', 'Vout', 'Vcomp', params['r_comp'])
    circuit.C('c', 'Vcomp', 'N2', params['c_comp'] * 1e-12)  # params['c_comp'] is in pF

    return circuit


# -------------------------
# Optimization parameter search ranges and initial values
# -------------------------
# Fixed / reference values from the original netlist (these are the EXACT original values)
# Note: initial_params must match the original values exactly (per requirements).
initial_params = {
    # Transistor widths (original values from netlist, in meters)
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_Mtail': 5e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,

    # Compensation network (original values)
    'r_comp': 50,    # original 50 ohms (from 50@u_Ohm)
    'c_comp': 2,     # original 2 pF (from 2@u_pF)

    # Bias voltages (original values)
    'v_bias_p': 0.78,  # original Vbias_p
    'v_bias_n': 0.42,  # original Vbias_n
}

# Device length (fixed in circuit)
L = 0.045e-6  # 45 nm

# Helper to compute W bounds according to 1-500×L rule, but ensure initial value is included.
def w_bounds(initial_w):
    min_w = L * 1.0
    max_w_rule = L * 500.0
    # Ensure initial value is inside the bounds. If the original initial value exceeds 500*L,
    # extend the upper bound to include it (so initial_params lie within search range).
    max_w = max(max_w_rule, initial_w)
    return min_w, max_w

param_ranges_definition = {
    # Transistor widths (meters). Use log-scale sampling recommended for geometries.
    'w_M1': {
        'min': w_bounds(initial_params['w_M1'])[0],
        'max': w_bounds(initial_params['w_M1'])[1],
        'log': True
    },
    'w_M2': {
        'min': w_bounds(initial_params['w_M2'])[0],
        'max': w_bounds(initial_params['w_M2'])[1],
        'log': True
    },
    'w_Mtail': {
        'min': w_bounds(initial_params['w_Mtail'])[0],
        'max': w_bounds(initial_params['w_Mtail'])[1],
        'log': True
    },
    # Note: For M3 and M4 the original widths (40e-6 m) exceed 500×L (22.5e-6 m).
    # To comply with the requirement that initial values be inside the search range,
    # the upper bound is set to include the initial value. This means max >= original.
    'w_M3': {
        'min': w_bounds(initial_params['w_M3'])[0],
        'max': w_bounds(initial_params['w_M3'])[1],
        'log': True
    },
    'w_M4': {
        'min': w_bounds(initial_params['w_M4'])[0],
        'max': w_bounds(initial_params['w_M4'])[1],
        'log': True
    },
    'w_M5': {
        'min': w_bounds(initial_params['w_M5'])[0],
        'max': w_bounds(initial_params['w_M5'])[1],
        'log': True
    },
    'w_M6': {
        'min': w_bounds(initial_params['w_M6'])[0],
        'max': w_bounds(initial_params['w_M6'])[1],
        'log': True
    },

    # Resistors: 0.5 - 2 × original (r_comp original = 50 Ω)
    'r_comp': {
        'min': 0.5 * initial_params['r_comp'],
        'max': 2.0 * initial_params['r_comp'],
        'log': True
    },

    # Compensation capacitor (critical): 0.5 - 5 × original (c_comp original = 2 pF)
    # Stored in params as pF; convert only when building the circuit.
    'c_comp': {
        'min': 0.5 * initial_params['c_comp'],   # pF
        'max': 5.0 * initial_params['c_comp'],   # pF
        'log': True
    },

    # Bias voltages (except Vdd and inputs which are fixed)
    # Range: 0.8 - 1.2 × original, but never exceeding 1.2 V (supply).
    # Also keep conservative ranges to maintain intended operating points.
    'v_bias_p': {
        'min': max(0.8 * initial_params['v_bias_p'], 0.0),
        'max': min(1.2 * initial_params['v_bias_p'], 1.2),
        'log': False
    },
    'v_bias_n': {
        'min': max(0.8 * initial_params['v_bias_n'], 0.0),
        'max': min(1.2 * initial_params['v_bias_n'], 1.2),
        'log': False
    },
}

# A small explanatory note about bounds that were adapted to include the original values:
# - The specification requested transistor widths in 1-500×L. Most original widths satisfy this,
#   but the original values for M3 and M4 (40e-6 m) exceed 500×L (which is 22.5e-6 m).
#   To strictly satisfy the requirement that initial_params lie within the search ranges,
#   the upper bound for those devices has been set to at least the initial value.
#   If you want to enforce strictly 500×L for all devices, reduce 'w_M3' and 'w_M4' initial
#   values accordingly before starting optimization.

# -------------------------
# Brief description of each parameter (physical meaning)
# -------------------------
param_descriptions = {
    # Transistor widths (meters)
    'w_M1': "Width of NMOS input transistor M1 (left differential leg). Affects gm and input pair current density.",
    'w_M2': "Width of NMOS input transistor M2 (right differential leg).",
    'w_Mtail': "Width of NMOS tail current-source transistor (sets tail current together with bias).",
    'w_M3': "Width of PMOS diode-connected load device (left leg of current mirror).",
    'w_M4': "Width of PMOS mirrored load device (right leg of current mirror).",
    'w_M5': "Width of NMOS second-stage driver transistor (common-source).",
    'w_M6': "Width of PMOS active load for second stage (current source).",

    # Passive compensation elements
    'r_comp': "Series resistor in the Miller compensation path between Vout and Vcomp (ohms). Affects pole/zero placement and damping.",
    'c_comp': "Miller compensation capacitor between Vcomp and N2 (in pF in the params dictionary). Critical for stability and GBW.",

    # Bias voltages
    'v_bias_p': "PMOS load gate bias voltage (Vbias_p). Sets operating point of PMOS current source (must be <= Vdd).",
    'v_bias_n': "NMOS tail gate bias voltage (Vbias_n). Sets tail current; chosen with Vth ~ 0.22 V in mind.",
}

# -------------------------
# Usage tips:
# - Pass a params dict to create_circuit(params). Use initial_params as starting point.
# - The optimizer should sample values within param_ranges_definition.
# - c_comp is specified in pF in the parameter dictionary (to match original 2 pF notation).
# - All voltages are in volts, resistor in ohms, widths in meters.
# -------------------------
```