from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # EXACT original widths (meters) from your netlist
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_Mtail': 20e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,
    # EXACT original bias voltages (volts)
    'v_bias_tail': 0.6,
    'v_bias_p': 0.78,
    # EXACT original compensation cap (Farads)
    'c_comp': 2e-12,
}
