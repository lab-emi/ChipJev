from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Opamp - Fixed Tail')
# MOS models (provided externally via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V
# Input common-mode DC bias (no AC sources)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)         # Vinp = 0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)         # Vinn = 0.6 V
# Bias voltages
# Tail gate for NMOS tail (now NMOS tail) - chosen to provide modest sink current
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.6)  # 0.6 V for NMOS tail gate
# PMOS current-source gate bias for second-stage load (unchanged)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)       # 0.78 V for PMOS loads
# Node names:
# Iss  - input pair source / tail node (drain of NMOS tail)
# X    - left drain of pair (first-stage single-ended output)
# Y    - right drain of pair (diode-connected mirror node)
# Vout - final single-ended output
# First stage: NMOS differential pair (M1, M2)
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'X', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Y', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS current mirror active load (M3 diode-connected on Y, M4 mirror to X)
circuit.MOSFET('M3', 'Y', 'Y', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # diode-connected reference
circuit.MOSFET('M4', 'X', 'Y', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)  # mirror leg
# Tail NMOS current source (sink to ground) - changed from PMOS to NMOS
circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# Second stage: common-source NMOS (M5) with PMOS active load (M6)
circuit.MOSFET('M5', 'Vout', 'X', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Miller compensation capacitor between first-stage output (X) and final output (Vout).
circuit.C('comp', 'X', 'Vout', 2e-12)  # 2 pF (adjustable)
# Create simulator (stop here as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
