from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Miller-Compensated OpAmp (GBW/Power optimized)')
# Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Bias voltages (DC biases, no AC)
# Vth = 0.22 V used to set bias nodes per problem statement
circuit.V('b_tail', 'Vb_tail', circuit.gnd, 0.52)   # tail bias ~ Vth + 0.3
circuit.V('b_p',    'Vbias_p', circuit.gnd, 0.78)  # PMOS bias ~ Vdd - |Vth| - 0.2
# Input common-mode DC (for operating point). Both inputs at same DC for OP.
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# First stage differential pair and mirror load
# Node naming:
#  - Vs : common source node (tail node)
#  - Vd1: drain of left input device (diode-connected PMOS sets mirror gate)
#  - Vint: drain of right input device and first-stage single-ended output
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vb_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=0.045e-6)
# Differential pair (NMOS)
circuit.MOSFET('M1', 'Vd1', 'Vinp', 'Vs', 'Vs',
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vint', 'Vinn', 'Vs', 'Vs',
               model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS current mirror load:
# M3 diode-connected (gate tied to drain Vd1)
circuit.MOSFET('M3', 'Vd1', 'Vd1', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# M4 mirrors current into Vint (gate tied to Vd1)
circuit.MOSFET('M4', 'Vint', 'Vd1', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Miller compensation between Vint (first stage output) and Vout (second stage output)
circuit.C('Ccomp', 'Vint', 'Vout', 2@u_pF)
# Second stage: common-source NMOS with PMOS active load
circuit.MOSFET('M7', 'Vout', 'Vint', circuit.gnd, circuit.gnd,
               model='nmos_model', w=30e-6, l=0.045e-6)
circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=60e-6, l=0.045e-6)
# Ensure the input and output node names exist in the circuit (they are already created
# by the voltage sources and MOSFETs above): Vinp, Vinn, Vout
# Simulator object (end of netlist)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
