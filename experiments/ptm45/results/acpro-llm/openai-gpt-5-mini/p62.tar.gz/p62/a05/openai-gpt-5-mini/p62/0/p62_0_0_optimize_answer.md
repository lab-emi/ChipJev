```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

# Fixed process length used throughout (exact original value)
L = 0.045e-6  # 45 nm (original netlist uses l=0.045e-6)

def create_circuit(params):
    """
    Create the parameterized Two-Stage Miller-Compensated OpAmp circuit.

    Required: params is a dictionary containing the following keys:
      - W_Mtail, W_M1, W_M2, W_M3, W_M4, W_M7, W_M8 : transistor widths (in meters)
      - Vb_tail, Vbias_p : bias voltages (in volts)
      - Ccomp : Miller compensation capacitance (in pF)

    Notes:
      - vdd and input voltages (Vinp, Vinn) are kept fixed as in the original netlist.
      - All transistor lengths are fixed to the original L (45 nm).
      - This function requires `from model import nmos_params, pmos_params` to be available.
    """
    circuit = Circuit('Two-Stage Miller-Compensated OpAmp (GBW/Power optimized)')

    # Models (imported from model module as required)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V (fixed)

    # Input common-mode DC (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)

    # Parameterized bias voltages (subject to constrained search ranges)
    circuit.V('b_tail', 'Vb_tail', circuit.gnd, params['Vb_tail'])   # tail bias
    circuit.V('b_p',    'Vbias_p', circuit.gnd, params['Vbias_p'])   # PMOS bias

    # First stage / differential pair and mirror load (widths parameterized; lengths fixed)
    circuit.MOSFET('Mtail', 'Vs', 'Vb_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['W_Mtail'],
                   l=L)

    circuit.MOSFET('M1', 'Vd1', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['W_M1'],
                   l=L)

    circuit.MOSFET('M2', 'Vint', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['W_M2'],
                   l=L)

    # PMOS current mirror load (M3 diode-connected, M4 mirror)
    circuit.MOSFET('M3', 'Vd1', 'Vd1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['W_M3'],
                   l=L)

    circuit.MOSFET('M4', 'Vint', 'Vd1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['W_M4'],
                   l=L)

    # Miller compensation cap: parameterized (value in pF)
    # Keep load caps (if any) fixed per requirements; this is the compensation capacitor and is optimized.
    circuit.C('Ccomp', 'Vint', 'Vout', f"{params['Ccomp']}p")

    # Second stage: common-source NMOS and PMOS active load
    circuit.MOSFET('M7', 'Vout', 'Vint', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['W_M7'],
                   l=L)

    circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['W_M8'],
                   l=L)

    # Return the built circuit
    return circuit


# ======================================================================================
# Optimization parameter search ranges (for Optuna or similar)
# Notes on general rules applied:
#  - Transistor widths: nominally 1 - 500 × L (L = 45 nm). If the original device width
#    exceeds 500×L, the upper bound is extended to include the original value (so the
#    initial point is inside the search range). This preserves the user's original
#    design as a valid starting point while recommending the 1-500×L guideline.
#  - All biased voltages (except vdd and Vin/Vinp/Vinn) are allowed to vary 0.8-1.2×
#    their original values, but never exceeding 1.2 V (the supply).
#  - Compensation capacitor is varied 0.5-5× the original (critical comp cap range).
#  - All initial_params below are EXACTLY the original values from your netlist.
# ======================================================================================

# Helper constants
L_nominal = L
W500L = 500 * L_nominal  # 500 * L (recommended upper limit)

def _upper_for_width(original_w):
    """
    Return an upper bound for width search that respects 500*L where possible,
    but expands to include the original value if the original exceeds 500*L.
    Provide a small headroom (20%) if expansion is required so the optimizer can move.
    """
    if original_w <= W500L:
        return W500L
    else:
        return original_w * 1.2  # extend above original so initial point is inside range

param_ranges_definition = {
    # Transistor widths (units: meters). Log scaling recommended for sizes.
    'W_Mtail': {'min': L_nominal, 'max': _upper_for_width(2e-6),    'log': True},  # original 2e-6
    'W_M1':    {'min': L_nominal, 'max': _upper_for_width(20e-6),   'log': True},  # original 20e-6
    'W_M2':    {'min': L_nominal, 'max': _upper_for_width(20e-6),   'log': True},  # original 20e-6
    'W_M3':    {'min': L_nominal, 'max': _upper_for_width(40e-6),   'log': True},  # original 40e-6 (PMOS diode)
    'W_M4':    {'min': L_nominal, 'max': _upper_for_width(40e-6),   'log': True},  # original 40e-6 (PMOS mirror)
    'W_M7':    {'min': L_nominal, 'max': _upper_for_width(30e-6),   'log': True},  # original 30e-6 (2nd stage NMOS)
    'W_M8':    {'min': L_nominal, 'max': _upper_for_width(60e-6),   'log': True},  # original 60e-6 (2nd stage PMOS)

    # Bias voltages: 0.8 - 1.2 × original, but never above 1.2 V (supply)
    'Vb_tail': {'min': max(0.0, 0.8 * 0.52), 'max': min(1.2, 1.2 * 0.52), 'log': False},  # original 0.52 V
    'Vbias_p': {'min': max(0.0, 0.8 * 0.78), 'max': min(1.2, 1.2 * 0.78), 'log': False},  # original 0.78 V

    # Compensation capacitor (critical): 0.5x - 5x original (original units: pF)
    'Ccomp':   {'min': 0.5 * 2.0, 'max': 5.0 * 2.0, 'log': True},  # original 2 pF
}

# ======================================================================================
# Initial parameter values (EXACT original circuit values — DO NOT CHANGE THESE)
# These are the starting point for optimization and are required to match the original netlist.
# ======================================================================================

initial_params = {
    # Transistor widths (meters) --- EXACT original values
    'W_Mtail': 2e-6,
    'W_M1':    20e-6,
    'W_M2':    20e-6,
    'W_M3':    40e-6,
    'W_M4':    40e-6,
    'W_M7':    30e-6,
    'W_M8':    60e-6,

    # Bias voltages (volts) --- EXACT original values
    'Vb_tail': 0.52,
    'Vbias_p': 0.78,

    # Compensation capacitor (pF) --- EXACT original value
    'Ccomp':   2.0,
}

# ======================================================================================
# Parameter descriptions (brief physical meaning)
# ======================================================================================
# W_Mtail  : Width of tail NMOS current source (controls tail current & Veff headroom)
# W_M1     : Width of left input NMOS (differential pair left device)
# W_M2     : Width of right input NMOS (differential pair right device)
# W_M3     : Width of diode-connected PMOS (current mirror reference device)
# W_M4     : Width of PMOS mirror device (mirrors current into the first-stage output)
# W_M7     : Width of second-stage NMOS (gain device for the second stage)
# W_M8     : Width of second-stage PMOS active load (bias & headroom for second stage)
# Vb_tail  : Tail bias voltage (sets current through the input differential pair)
# Vbias_p  : PMOS gate bias for second-stage active load (sets second-stage operating point)
# Ccomp    : Miller compensation capacitor between first-stage output (Vint) and final output (Vout)
#
# Units:
#  - Widths (W_*) are in meters.
#  - Voltages (Vb_*) are in volts.
#  - Ccomp is in pF (the create_circuit function writes it into the netlist using "<value>p").
#
# Notes on sampling:
#  - For transistor widths and the compensation capacitor, log sampling is recommended
#    (these entries have 'log': True) because device sizes span orders of magnitude.
#  - For bias voltages, linear sampling is recommended ('log': False).
#
# ======================================================================================
```

Notes and rationale:
- vdd and the input DC voltages (Vinp, Vinn) are fixed exactly as in the original netlist.
- All other originally fixed values (transistor widths, bias voltages, comp cap) are turned into parameters and included in both create_circuit(params) and the parameter range dictionary.
- The initial_params dictionary preserves the EXACT original numerical values from your netlist (per your IMPORTANT requirement).
- To satisfy the requirement that initial values lie inside the ranges, devices whose original width exceeds 500×L have an expanded upper bound (original × 1.2). This keeps the optimizer able to start at your original design while still documenting and generally recommending the 1–500×L guideline.