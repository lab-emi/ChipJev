from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High FoM Two-Stage OpAmp')
# MOSFET models (from external provided module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and input/common-mode/bias voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp common-mode (DC operating point)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn common-mode (DC operating point)
circuit.V('biasn', 'Vbn', circuit.gnd, 0.42)     # NMOS tail bias (Vth + ~0.2V)
circuit.V('biasp', 'Vbp', circuit.gnd, 0.78)     # PMOS gate bias (Vdd - (Vth + ~0.2V))
# Node naming:
# Vs  = tail/source node for input pair
# Vd1 = single-ended first-stage output (drain of M1 and M3)
# Vd2 = diode/mirror node (drain of M2 and gate of M3)
# Vout = final output node
# First stage: differential NMOS pair (M1, M2) with PMOS current-mirror load (M3, M4)
# M1: drain Vd1, gate Vinp, source Vs, bulk Vs
circuit.MOSFET('M1', 'Vd1', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=3e-6, l=0.045e-6)
# M2: drain Vd2 (diode node), gate Vinn, source Vs, bulk Vs
circuit.MOSFET('M2', 'Vd2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=3e-6, l=0.045e-6)
# PMOS current mirror load
# M3: mirror device, drain Vd1, gate tied to Vd2, source Vdd, bulk Vdd
circuit.MOSFET('M3', 'Vd1', 'Vd2', 'Vdd', 'Vdd', model='pmos_model', w=6e-6, l=0.045e-6)
# M4: diode-connected PMOS reference, drain & gate Vd2, source Vdd, bulk Vdd
circuit.MOSFET('M4', 'Vd2', 'Vd2', 'Vdd', 'Vdd', model='pmos_model', w=6e-6, l=0.045e-6)
# Tail current source (NMOS)
# Mtail: drain Vs, gate Vbn, source ground, bulk ground
circuit.MOSFET('Mtail', 'Vs', 'Vbn', circuit.gnd, circuit.gnd, model='nmos_model', w=1e-6, l=0.045e-6)
# Second stage: single-ended common-source NMOS (M5) with PMOS active load (M6)
# M5: drain Vout, gate Vd1, source ground, bulk ground
circuit.MOSFET('M5', 'Vout', 'Vd1', circuit.gnd, circuit.gnd, model='nmos_model', w=6e-6, l=0.045e-6)
# M6: PMOS load, drain Vout, gate Vbp, source Vdd, bulk Vdd
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.045e-6)
# Miller compensation cap between Vout and Vd1 (dominant-pole compensation)
circuit.C('ccomp', 'Vout', 'Vd1', 1@u_pF)
# Ensure input nodes exist (already created by voltage sources)
# Ensure output node exists (created by M5/M6 drain)
# The circuit is now defined; run simulator for operating-point / AC as needed
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
