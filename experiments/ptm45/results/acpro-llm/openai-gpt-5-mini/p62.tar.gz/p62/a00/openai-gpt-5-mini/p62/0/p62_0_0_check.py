from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High FoM Two-Stage OpAmp')
# MOSFET models (from external provided module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and input/common-mode/bias voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('biasn', 'Vbn', circuit.gnd, 0.42)     # NMOS tail bias (Vth + ~0.2V)
circuit.V('biasp', 'Vbp', circuit.gnd, 0.78)     # PMOS gate bias (Vdd - (Vth + ~0.2V))
# Node naming:
# Vs  = tail/source node for input pair
# Vd1 = single-ended first-stage output (drain of M1 and M3)
# Vd2 = diode/mirror node (drain of M2 and gate of M3)
# Vout = final output node
# First stage: differential NMOS pair (M1, M2) with PMOS current-mirror load (M3, M4)
# M1: drain Vd1, gate Vinp, source Vs, bulk Vs
circuit.MOSFET('M1', 'Vd1', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=3e-6, l=0.045e-6)
# M2: drain Vd2 (diode node), gate Vinn, source Vs, bulk Vs
circuit.MOSFET('M2', 'Vd2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=3e-6, l=0.045e-6)
# PMOS current mirror load
# M3: mirror device, drain Vd1, gate tied to Vd2, source Vdd, bulk Vdd
circuit.MOSFET('M3', 'Vd1', 'Vd2', 'Vdd', 'Vdd', model='pmos_model', w=6e-6, l=0.045e-6)
# M4: diode-connected PMOS reference, drain & gate Vd2, source Vdd, bulk Vdd
circuit.MOSFET('M4', 'Vd2', 'Vd2', 'Vdd', 'Vdd', model='pmos_model', w=6e-6, l=0.045e-6)
# Tail current source (NMOS)
# Mtail: drain Vs, gate Vbn, source ground, bulk ground
circuit.MOSFET('Mtail', 'Vs', 'Vbn', circuit.gnd, circuit.gnd, model='nmos_model', w=1e-6, l=0.045e-6)
# Second stage: single-ended common-source NMOS (M5) with PMOS active load (M6)
# M5: drain Vout, gate Vd1, source ground, bulk ground
circuit.MOSFET('M5', 'Vout', 'Vd1', circuit.gnd, circuit.gnd, model='nmos_model', w=6e-6, l=0.045e-6)
# M6: PMOS load, drain Vout, gate Vbp, source Vdd, bulk Vdd
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.045e-6)
# Miller compensation cap between Vout and Vd1 (dominant-pole compensation)
circuit.C('ccomp', 'Vout', 'Vd1', 1@u_pF)
# Ensure input nodes exist (already created by voltage sources)
# Ensure output node exists (created by M5/M6 drain)
# The circuit is now defined; run simulator for operating-point / AC as needed
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)