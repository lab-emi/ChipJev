from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized two-stage op-amp circuit.
    params: dictionary containing the following keys (see param_ranges_definition
            and initial_params for exact names and starting values):
      - w_M1, w_M2, w_M3, w_M4, w_Mtail, w_M5, w_M6 : transistor widths (meters)
      - v_biasn, v_biasp : bias voltages (volts)
      - c_ccomp : Miller compensation capacitance (pF)
    Notes:
      - Vdd, Vinp, Vinn are left fixed (not parameterized) per requirements.
      - All MOSFET channel lengths are kept fixed at the original value (45 nm).
      - c_ccomp is interpreted in pF in params; the code converts it to Farads.
    """
    circuit = Circuit('High FoM Two-Stage OpAmp (parameterized)')
    # Keep the provided compact model import exactly as required
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed supply and input/common-mode voltages (NOT parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd fixed at 1.2 V (do not parameterize)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp fixed (swept externally during analysis)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn fixed (swept externally during analysis)
    # Parameterized bias voltages (must remain <= 1.2 V)
    circuit.V('biasn', 'Vbn', circuit.gnd, params['v_biasn'])  # NMOS tail bias
    circuit.V('biasp', 'Vbp', circuit.gnd, params['v_biasp'])  # PMOS gate bias
    # Channel length kept constant (original circuit used 0.045e-6 m)
    L_chan = 0.045e-6  # 45 nm; fixed for this technology
    # First stage: differential NMOS pair (M1, M2)
    circuit.MOSFET('M1', 'Vd1', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model', w=params['w_M1'], l=L_chan)
    circuit.MOSFET('M2', 'Vd2', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model', w=params['w_M2'], l=L_chan)
    # PMOS current mirror load (M3, M4)
    circuit.MOSFET('M3', 'Vd1', 'Vd2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L_chan)
    circuit.MOSFET('M4', 'Vd2', 'Vd2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L_chan)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Vs', 'Vbn', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L_chan)
    # Second stage: common-source NMOS (M5) with PMOS active load (M6)
    circuit.MOSFET('M5', 'Vout', 'Vd1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=L_chan)
    circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M6'], l=L_chan)
    # Miller compensation capacitor: params['c_ccomp'] is specified in pF
    # Convert pF -> F for PySpice (1 pF = 1e-12 F)
    ccomp_F = params['c_ccomp'] * 1e-12
    circuit.C('ccomp', 'Vout', 'Vd1', ccomp_F)
    return circuit
# ------------------------------
# Optimization parameter search ranges (for Optuna or similar)
# All widths are constrained to 1x - 500x the channel length (L = 0.045e-6 m)
# Voltage ranges are 0.8-1.2× original but capped at 1.2 V (and chosen conservatively
# with awareness of Vth = 0.22 V so the lower bounds are not below threshold-era values).
# Compensation cap is considered a "critical" cap and allowed 0.5-5× original.
# ------------------------------
# Technology and helper values
L_chan = 0.045e-6           # 45 nm (fixed)
W_min = L_chan * 1.0        # 1× L
W_max = L_chan * 500.0      # 500× L
# Original values from the provided netlist (used to compute 0.8-1.2 ranges).
orig_biasn = 0.42
orig_biasp = 0.78
orig_c_ccomp_pF = 1.0       # ccomp = 1 pF
# Parameter ranges definition (suitable for random/log sampling in an optimizer)
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling recommended for wide ranges.
    'w_M1':   {'min': W_min, 'max': W_max, 'log': True},  # M1 input NMOS
    'w_M2':   {'min': W_min, 'max': W_max, 'log': True},  # M2 input NMOS
    'w_M3':   {'min': W_min, 'max': W_max, 'log': True},  # M3 PMOS mirror
    'w_M4':   {'min': W_min, 'max': W_max, 'log': True},  # M4 PMOS diode
    'w_Mtail':{'min': W_min, 'max': W_max, 'log': True},  # Tail NMOS
    'w_M5':   {'min': W_min, 'max': W_max, 'log': True},  # Second-stage NMOS
    'w_M6':   {'min': W_min, 'max': W_max, 'log': True},  # Second-stage PMOS load
    # Bias voltages (volts). 0.8 - 1.2 × original, capped at 1.2 V.
    # Consideration: Vth = 0.22 V, so ranges are chosen conservatively to keep devices
    # biased in expected operating region.
    'v_biasn': {
        'min': max(0.8 * orig_biasn, 0.22 + 0.04),  # ensure safely above threshold (~Vth+~40mV)
        'max': min(1.2 * orig_biasn, 1.2),
        'log': False
    },
    'v_biasp': {
        'min': max(0.8 * orig_biasp, 0.22 + 0.04),
        'max': min(1.2 * orig_biasp, 1.2),
        'log': False
    },
    # Compensation capacitor (pF). Critical compensation cap: 0.5 - 5× original.
    'c_ccomp': {
        'min': 0.5 * orig_c_ccomp_pF,
        'max': 5.0 * orig_c_ccomp_pF,
        'log': True
    },
}
# ------------------------------
# Initial parameter values (EXACT original circuit values)
# These values are the starting point for the optimizer and MUST match the
# original netlist values exactly (as provided in the user's input).
# ------------------------------
initial_params = {
    # Transistor widths exactly as in the original netlist (meters)
    'w_M1':    3e-6,    # M1 width (original)
    'w_M2':    3e-6,    # M2 width (original)
    'w_M3':    6e-6,    # M3 width (original)
    'w_M4':    6e-6,    # M4 width (original)
    'w_Mtail': 1e-6,    # Mtail width (original)
    'w_M5':    6e-6,    # M5 width (original)
    'w_M6':    12e-6,   # M6 width (original)
    # Bias voltages exactly as in the original netlist (volts)
    'v_biasn': 0.42,    # NMOS tail bias (original)
    'v_biasp': 0.78,    # PMOS gate bias (original)
    # Compensation capacitor exactly as in original netlist (pF)
    'c_ccomp': 1.0,     # ccomp = 1 pF (original)
}
# ------------------------------
# Brief physical meaning of each parameter
# ------------------------------
# w_M1, w_M2:    Input pair NMOS widths (m). Larger widths increase gm and current,
#                lower output resistance; affect input pair transconductance and noise.
# w_M3, w_M4:    PMOS mirror/diode widths (m). Set mirror current, headroom and output resistance.
# w_Mtail:       Tail NMOS width (m). Controls tail current for the differential pair.
# w_M5:          Second-stage NMOS width (m). Affects gain and output swing of the second stage.
# w_M6:          PMOS active load width (m). Sets bias and load for second stage; affects gain.
# v_biasn:       Gate bias voltage for tail current source (Vbn) (V). Tunes tail current; must be > Vth.
# v_biasp:       Gate bias voltage for PMOS load (Vbp) (V). Tunes PMOS operating point.
# c_ccomp:       Miller compensation capacitor (pF). Dominant pole compensation; controls stability (pole/zero).
#
# Notes:
# - Vdd = 1.2 V and input/common-mode voltages (Vinp, Vinn = 0.6 V) are intentionally fixed
#   and should be swept externally for DC/operating-point analysis as required.
# - All voltage ranges are constrained so that values do not exceed the supply (1.2 V).
# - All initial parameter values above are exactly the values taken from the original netlist.
