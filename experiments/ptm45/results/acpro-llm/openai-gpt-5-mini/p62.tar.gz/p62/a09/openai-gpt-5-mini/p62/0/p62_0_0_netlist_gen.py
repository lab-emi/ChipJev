from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Miller-Compensated OpAmp (GBW/Power Optimized)')
# MOS models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # supply
# Inputs (DC operating point bias, no AC here)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)         # input + (common-mode ~0.6 V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)         # input - (common-mode ~0.6 V)
# Bias voltages (set to values that ensure transistor conduction given Vth=0.22 V)
circuit.V('btail', 'Vbias_tail', circuit.gnd, 0.55)  # tail NMOS gate bias
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.78)        # PMOS load/mirror gate bias
# Nodes used:
# Iss  - tail node (sources of input pair)
# Vx   - drain of M1 (diode-connected PMOS gate)
# Vint - single-ended first-stage output (drain of M2, gate of second stage)
# Vout - overall amplifier output
# First stage: differential NMOS pair
circuit.MOSFET('M1', 'Vx', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vint', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=3e-6, l=0.045e-6)
# PMOS current mirror (active load)
# M3 is diode-connected on the M1 side (sets mirror gate)
circuit.MOSFET('M3', 'Vx', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M4 mirrors current to the M2 side (first-stage single-ended node)
circuit.MOSFET('M4', 'Vint', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Second stage: common-source NMOS amplifier
circuit.MOSFET('M5', 'Vout', 'Vint', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS active load for second stage (current source)
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Miller compensation capacitor between first stage single-ended node and output
circuit.C('c1', 'Vint', 'Vout', 2@u_pF)
# End of circuit definition; ready for DC/OP/AC/small-signal analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p62/0/p62_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
