from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: The following import MUST appear exactly as written inside create_circuit (see function)
# (also safe to have it at module scope if desired, but requirement requested it inside the function)
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Two-Stage Miller-Compensated OpAmp (GBW/Power Optimized)')
    # MOS models (provided by external model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and DC bias supplies (fixed or parameterized per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # supply (fixed 1.2 V)
    # Inputs (fixed as required; they will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)         # input + (fixed common-mode ~0.6 V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)         # input - (fixed common-mode ~0.6 V)
    # Bias voltages (parameterized; ranges defined externally)
    circuit.V('btail', 'Vbias_tail', circuit.gnd, params['v_bias_tail'])  # tail NMOS gate bias
    circuit.V('bp', 'Vbias_p', circuit.gnd, params['v_bias_p'])          # PMOS load/mirror gate bias
    # Nodes used:
    # Iss  - tail node (sources of input pair)
    # Vx   - drain of M1 (diode-connected PMOS gate)
    # Vint - single-ended first-stage output (drain of M2, gate of second stage)
    # Vout - overall amplifier output
    L_fixed = 45e-9  # fixed length (45 nm technology)
    # First stage: differential NMOS pair
    circuit.MOSFET('M1', 'Vx', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)
    circuit.MOSFET('M2', 'Vint', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_fixed)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L_fixed)
    # PMOS current mirror (active load)
    # M3 is diode-connected on the M1 side (sets mirror gate)
    circuit.MOSFET('M3', 'Vx', 'Vx', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_fixed)
    # M4 mirrors current to the M2 side (first-stage single-ended node)
    circuit.MOSFET('M4', 'Vint', 'Vx', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_fixed)
    # Second stage: common-source NMOS amplifier
    circuit.MOSFET('M5', 'Vout', 'Vint', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L_fixed)
    # PMOS active load for second stage (current source)
    circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L_fixed)
    # Miller compensation capacitor between first stage single-ended node and output
    # Keep the load capacitor(s) fixed as originally specified (no parameterization for load caps)
    circuit.C('c1', 'Vint', 'Vout', params['c_c1'] * u_pF)
    return circuit
# Optimization parameter search ranges (for use with Optuna or similar)
# All ranges chosen according to the constraints:
#  - Transistor width W within [1×L, 500×L] where L=45e-9 m
#  - Voltages (except Vdd, Vinp, Vinn) within 0.8-1.2× original but <= 1.2 V (and kept conservative w.r.t Vth)
#  - Critical comp cap within 0.5-5× original
# Notes:
#  - Widths use a log scale recommendation for efficient exploration (many decades).
#  - Voltages use linear sampling (no log).
L_fixed = 45e-9
param_ranges_definition = {
    # Transistor widths (meters) : 1×L .. 500×L
    'w_M1':  {'min': 1.0 * L_fixed,    'max': 500.0 * L_fixed,  'log': True},
    'w_M2':  {'min': 1.0 * L_fixed,    'max': 500.0 * L_fixed,  'log': True},
    'w_Mtail':{'min': 1.0 * L_fixed,   'max': 500.0 * L_fixed,  'log': True},
    'w_M3':  {'min': 1.0 * L_fixed,    'max': 500.0 * L_fixed,  'log': True},
    'w_M4':  {'min': 1.0 * L_fixed,    'max': 500.0 * L_fixed,  'log': True},
    'w_M5':  {'min': 1.0 * L_fixed,    'max': 500.0 * L_fixed,  'log': True},
    'w_M6':  {'min': 1.0 * L_fixed,    'max': 500.0 * L_fixed,  'log': True},
    # Bias voltages: 0.8x .. 1.2x original but never exceeding 1.2 V
    # Original Vbias_tail = 0.55 V  => range: [0.8*0.55, 1.2*0.55] = [0.44, 0.66]
    'v_bias_tail': {'min': max(0.8 * 0.55, 0.22 + 0.05), 'max': min(1.2 * 0.55, 1.2), 'log': False},
    # Original Vbias_p = 0.78 V => range: [0.8*0.78, 1.2*0.78] = [0.624, 0.936]
    # (PMOS gate bias must remain <= Vdd; values here are absolute node voltages as used in the original netlist)
    'v_bias_p':    {'min': max(0.8 * 0.78, 0.22 + 0.05), 'max': min(1.2 * 0.78, 1.2), 'log': False},
    # Compensation capacitor (critical): 0.5x .. 5x original (original = 2 pF)
    'c_c1':  {'min': 0.5 * 2.0,   'max': 5.0 * 2.0,    'unit': 'pF', 'log': True},
}
# Initial parameter values (EXACT original circuit values)
# IMPORTANT: These values are the exact numbers used in the original netlist you provided.
initial_params = {
    # Transistor widths (meters) - EXACT original values
    'w_M1':    10e-6,
    'w_M2':    10e-6,
    'w_Mtail': 3e-6,
    'w_M3':    20e-6,
    'w_M4':    20e-6,
    'w_M5':    20e-6,
    'w_M6':    30e-6,
    # Bias voltages (volts) - EXACT original values
    'v_bias_tail': 0.55,
    'v_bias_p':    0.78,
    # Compensation capacitor (pF) - EXACT original value
    'c_c1': 2.0,
}
# Brief description of each parameter (physical meaning and units)
param_descriptions = {
    # MOSFET widths (W) - meters. L is fixed to 45e-9 m (45 nm). Only W is optimized to adjust device drive currents and gm.
    'w_M1':    'Width of input NMOS M1 (left diff pair device) [m]',
    'w_M2':    'Width of input NMOS M2 (right diff pair device) [m]',
    'w_Mtail': 'Width of tail NMOS Mtail (bias/current source) [m]',
    'w_M3':    'Width of diode-connected PMOS M3 (mirror reference) [m]',
    'w_M4':    'Width of mirror PMOS M4 (active load to M2) [m]',
    'w_M5':    'Width of second-stage NMOS M5 (common-source) [m]',
    'w_M6':    'Width of PMOS load M6 (second-stage current source) [m]',
    # Bias voltages - volts. These bias nodes set operating point and must remain <= Vdd (1.2 V).
    'v_bias_tail': 'Tail NMOS gate bias voltage (Vbias_tail) [V]. Controls tail current and input pair bias.',
    'v_bias_p':    'PMOS load/mirror gate bias voltage (Vbias_p) [V]. Controls PMOS mirror current and headroom.',
    # Compensation capacitor - pF. Miller cap between Vint and Vout.
    'c_c1': 'Miller compensation capacitor C1 between Vint and Vout [pF]. Critical for stability/BW tradeoffs.',
}
# End of parameterized netlist and search ranges.
# Notes to optimizer integrator:
# - Keep Vdd = 1.2 V and input sources Vinp/Vinn = 0.6 V fixed as per requirements.
# - All initial_params values are exactly the numbers from the original netlist.
# - Units:
#     * transistor widths are in meters (m)
#     * voltages are in volts (V)
#     * c_c1 is in picofarads (pF); create_circuit multiplies by u_pF when building the netlist
# - Ranges chosen to respect:
#     * W within [1×L, 500×L] with L=45 nm
#     * bias voltages in 0.8-1.2× original but clamped to <=1.2 V
#     * compensation capacitor in 0.5-5× original
