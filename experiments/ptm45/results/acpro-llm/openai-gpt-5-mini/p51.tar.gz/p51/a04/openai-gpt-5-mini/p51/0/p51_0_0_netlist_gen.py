from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier with Cascoded PMOS Load')
# MOSFET models (provided by the external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC operating-point bias sources (no AC)
# Vin is provided as a DC bias for operating point analysis (node name must exist)
# Choose Vin ~ 0.6 V (Vth = 0.22 V) to bias the NMOS amplifier transistor in saturation
circuit.V('in', 'Vin', circuit.gnd, 0.6)
# PMOS gate bias nodes to set the cascoded active load operating points
# Values chosen to ensure Vsg of PMOS devices > |Vth| while leaving headroom for cascode action
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.6)
circuit.V('biaspc', 'Vbias_pc', circuit.gnd, 0.6)
# Transistor instances
# M1: NMOS amplifier transistor (drain, gate, source, bulk)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=45e-9)
# M3: PMOS cascode (drain, gate, source, bulk) - lower PMOS (closer to Vout)
circuit.MOSFET('M3', 'Vout', 'Vbias_pc', 'Ncas', 'Vdd',
               model='pmos_model', w=40e-6, l=180e-9)
# M2: PMOS top current-source device (drain, gate, source, bulk)
circuit.MOSFET('M2', 'Ncas', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=180e-9)
# End with a simulator call (no AC sources; OP analysis will be done by user)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
