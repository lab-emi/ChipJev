```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the Single-Stage CS Amplifier with Cascoded PMOS Load using parameter dict `params`.

    Notes:
    - vdd and Vin are fixed (not parameterized) as required.
    - MOSFET channel lengths (L) are held constant (as in the original netlist).
    - Only widths (W) and the PMOS bias voltages are parameterized.
    - This function expects params to contain keys:
        'w_M1', 'w_M2', 'w_M3', 'Vbias_p', 'Vbias_pc'
    - The module `model` providing nmos_params and pmos_params is imported exactly as requested.
    """
    circuit = Circuit('Single-Stage CS Amplifier with Cascoded PMOS Load')

    # MOSFET models (provided by the external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V (fixed)

    # Input voltage (fixed, not parameterized). Kept exactly as original to be swept externally.
    circuit.V('in', 'Vin', circuit.gnd, 0.6)  # Vin = 0.6 V (fixed)

    # PMOS gate bias voltages (parameterized; conservative ranges are provided elsewhere)
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['Vbias_p'])
    circuit.V('biaspc', 'Vbias_pc', circuit.gnd, params['Vbias_pc'])

    # Transistor instances
    # M1: NMOS amplifier transistor (drain, gate, source, bulk)
    # Keep L fixed at the original value (45 nm) and vary W via params['w_M1']
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=45e-9)

    # M3: PMOS cascode (lower PMOS, closer to Vout)
    # Keep L fixed at the original value (180 nm) and vary W via params['w_M3']
    circuit.MOSFET('M3', 'Vout', 'Vbias_pc', 'Ncas', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=180e-9)

    # M2: PMOS top current-source device
    # Keep L fixed at the original value (180 nm) and vary W via params['w_M2']
    circuit.MOSFET('M2', 'Ncas', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=180e-9)

    return circuit


# -------------------------
# Optimization parameter search ranges (annotated)
# -------------------------
# Constraints applied:
# - Transistor width W: 1 - 500 × corresponding fixed L (kept per-device as in original netlist).
# - PMOS bias voltages: 0.8 - 1.2 × original value, but never exceeding Vdd = 1.2 V.
# - No resistors or capacitors were present in the original netlist to parameterize.
#
# Note: log=True indicates a logarithmic sampling is often preferable for geometries (W).
param_ranges_definition = {
    # Transistor widths (meters)
    # M1: L = 45e-9 (from original); allowed W range = 1×L .. 500×L
    'w_M1': {
        'min': 1 * 45e-9,
        'max': 500 * 45e-9,
        'log': True,
        'unit': 'm',
        'comment': 'NMOS amplifier transistor width (W). L fixed = 45 nm.'
    },

    # M2 (top PMOS current-source): L = 180e-9 (from original); allowed W = 1×L .. 500×L
    'w_M2': {
        'min': 1 * 180e-9,
        'max': 500 * 180e-9,
        'log': True,
        'unit': 'm',
        'comment': 'PMOS top device width (W). L fixed = 180 nm.'
    },

    # M3 (PMOS cascode): L = 180e-9 (from original); allowed W = 1×L .. 500×L
    'w_M3': {
        'min': 1 * 180e-9,
        'max': 500 * 180e-9,
        'log': True,
        'unit': 'm',
        'comment': 'PMOS cascode width (W). L fixed = 180 nm.'
    },

    # Bias voltages for PMOS gates (unit: V)
    # Original values are 0.6 V. Range = 0.8-1.2×original but clipped to <= 1.2 V.
    # 0.6 * 0.8 = 0.48 V  (lower bound) ; 0.6 * 1.2 = 0.72 V (upper bound)
    # These ranges are conservative and keep voltages well above Vth = 0.22 V while preserving headroom.
    'Vbias_p': {
        'min': 0.6 * 0.8,
        'max': min(0.6 * 1.2, 1.2),
        'log': False,
        'unit': 'V',
        'comment': 'Gate bias for top PMOS (M2).'
    },
    'Vbias_pc': {
        'min': 0.6 * 0.8,
        'max': min(0.6 * 1.2, 1.2),
        'log': False,
        'unit': 'V',
        'comment': 'Gate bias for cascode PMOS (M3).'
    }
}

# -------------------------
# Initial parameter values (EXACT original circuit values; MUST match the original netlist exactly)
# -------------------------
initial_params = {
    # Transistor widths (exactly as in the user's original netlist)
    'w_M1': 20e-6,   # M1 original width
    'w_M2': 40e-6,   # M2 original width
    'w_M3': 40e-6,   # M3 original width

    # PMOS bias voltages (exact original values)
    'Vbias_p': 0.6,   # Vbias_p original value
    'Vbias_pc': 0.6,  # Vbias_pc original value
}

# -------------------------
# Brief description of each parameter (physical meaning)
# -------------------------
parameter_descriptions = {
    'w_M1': "Width of NMOS amplifier transistor M1 (m). L fixed at 45 nm. Changing W changes transconductance and current drive.",
    'w_M2': "Width of PMOS top current-source M2 (m). L fixed at 180 nm. Controls current sourced to the cascode stack.",
    'w_M3': "Width of PMOS cascode transistor M3 (m). L fixed at 180 nm. Affects output resistance and cascode headroom.",
    'Vbias_p': "Gate bias voltage applied to top PMOS (M2) (V). Controls PMOS operating point / tail current.",
    'Vbias_pc': "Gate bias voltage applied to PMOS cascode gate (M3) (V). Controls cascode bias and output node voltage."
}
```

Notes and rationale summary:
- All initial parameter values in initial_params match the original netlist exactly (as required).
- Each width search range is 1–500× its device L (L retained per-device from the original netlist so initial W values lie within ranges).
- PMOS bias voltages are parameterized conservatively to 0.8–1.2× the original 0.6 V value, clipped to be ≤ Vdd (1.2 V). This keeps bias well above Vth = 0.22 V and preserves cascode headroom.
- No load capacitors, resistors, or other passives were present in the original netlist; therefore none were added to the parameter search. If you later add compensation or load capacitors, follow the specified multiplier constraints (comp caps: 0.5–5×, other caps: 0.8–1.5×).
- The create_circuit function uses the requested import "from model import nmos_params, pmos_params" verbatim.