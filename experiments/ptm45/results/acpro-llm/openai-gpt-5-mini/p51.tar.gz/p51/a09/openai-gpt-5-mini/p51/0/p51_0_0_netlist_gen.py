from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load')
# Define the MOSFET models (models provided by the environment)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and DC bias nodes (only DC sources, no AC)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias = Vth + 0.2 = 0.42 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)    # PMOS gate bias = 0.78 V
# Internal node between PMOS current source (M2) and PMOS cascode (M3)
# Named 'NodeP' but not required externally.
# Transistor definitions:
# MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
# M1: NMOS common-source amplifier transistor
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2.0e-6, l=0.09e-6)
# M2: PMOS top current-source transistor (source to Vdd, gate = Vbias_p)
circuit.MOSFET('M2', 'NodeP', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=10.0e-6, l=0.09e-6)
# M3: PMOS cascode transistor (source NodeP, drain Vout, gate = Vbias_p)
circuit.MOSFET('M3', 'Vout', 'Vbias_p', 'NodeP', 'Vdd',
               model='pmos_model', w=5.0e-6, l=0.09e-6)
# Create simulator for DC operating point and subsequent analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
