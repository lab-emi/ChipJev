from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier with PMOS Active Load (fixed OP)')
# Define the MOSFET models (models provided by the environment)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and DC bias nodes (only DC sources, no AC)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.60)           # Vin DC bias (raised to ensure conduction)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)    # PMOS gate bias = 0.78 V
# Transistor definitions:
# MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
# M1: NMOS common-source amplifier transistor
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2.0e-6, l=0.09e-6)
# M2: PMOS current-source load (single PMOS active load)
circuit.MOSFET('M2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=10.0e-6, l=0.09e-6)
# Create simulator for DC operating point and subsequent analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
