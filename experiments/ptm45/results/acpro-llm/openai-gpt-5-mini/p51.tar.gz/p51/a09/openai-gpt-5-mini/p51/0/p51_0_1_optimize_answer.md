```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: The following model import MUST appear inside the create_circuit function
# as required by the optimization environment instruction.

def create_circuit(params):
    """
    Create the parameterized Single-Stage CS Amplifier with PMOS Active Load.
    The model import line below must match exactly the environment expectation.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier with PMOS Active Load (fixed OP)')

    # Transistor models (provided by the environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V (fixed)

    # Input voltage source (fixed, will be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.60)           # Vin DC bias (fixed)

    # Parameterized PMOS gate bias (allowed to vary within conservative range)
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p'])    # Parametrized

    # Notes on lengths:
    # - Length is kept constant (process-defined). We use the original circuit's length
    #   to preserve the original starting operating point.
    L_fixed = 0.09e-6   # Original L from provided netlist (90 nm), kept constant

    # NMOS common-source amplifier transistor (M1)
    # MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)

    # PMOS active load transistor (M2)
    circuit.MOSFET('M2', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_fixed)

    # No resistors or capacitors were present in the original netlist.
    # (If you add loads/comp caps later, follow the constraints in the param ranges.)

    return circuit


# Optimization parameter search ranges (for Optuna or similar frameworks)
# Notes on construction of ranges:
# - Transistor widths (W) are constrained to 1 - 500 × L (L is the fixed length used in the circuit).
#   The original netlist used L = 0.09e-6 (90 nm), so:
L_fixed = 0.09e-6
param_ranges_definition = {
    # Transistor widths (meters). Log-uniform sampling recommended for wide ranges.
    'w_M1': {
        'min': 1.0 * L_fixed,       # 1 × L  = 0.09e-6 m
        'max': 500.0 * L_fixed,     # 500 × L = 45e-6 m
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L_fixed,       # 1 × L
        'max': 500.0 * L_fixed,     # 500 × L
        'log': True
    },

    # PMOS gate bias voltage. Must be within 0.8 - 1.2 × original, and never exceed 1.2 V.
    # Original Vbias_p = 0.78 V -> 0.8*0.78 = 0.624 V ; 1.2*0.78 = 0.936 V (<= 1.2)
    'v_bias_p': {
        'min': 0.8 * 0.78,   # 0.624 V
        'max': min(1.2 * 0.78, 1.2),  # 0.936 V (capped by supply)
        'log': False
    },

    # Note: No resistors or capacitors present in the original netlist to parameterize.
    # If you later introduce resistors/capacitors, follow the provided multiplier constraints:
    #   - Resistors: 0.5 - 2 × original
    #   - Critical caps (compensation): 0.5 - 5 × original
    #   - Other caps: 0.8 - 1.5 × original
}

# Initial parameter values (EXACT original circuit values as provided)
# IMPORTANT: These are the exact values taken from your original netlist and must not be changed.
initial_params = {
    'w_M1': 2.0e-6,    # Original width for M1 (meters)
    'w_M2': 10.0e-6,   # Original width for M2 (meters)
    'v_bias_p': 0.78,  # Original PMOS gate bias (volts)
}

# Quick assertions to ensure initial values are within the declared search ranges
# (These are helpful checks for the optimization framework; remove or disable if not desired.)
assert param_ranges_definition['w_M1']['min'] <= initial_params['w_M1'] <= param_ranges_definition['w_M1']['max']
assert param_ranges_definition['w_M2']['min'] <= initial_params['w_M2'] <= param_ranges_definition['w_M2']['max']
assert param_ranges_definition['v_bias_p']['min'] <= initial_params['v_bias_p'] <= param_ranges_definition['v_bias_p']['max']
```

Parameter descriptions (brief)
- w_M1: NMOS transistor width (meters). Sets the M1 drive current (W/L with L fixed at 90 nm). Search over 1–500× L (log scale recommended).
- w_M2: PMOS transistor width (meters). Sets the current-source (active load) strength. Search over 1–500× L (log scale recommended).
- v_bias_p: PMOS gate bias voltage (volts). Controls current through the PMOS active load. Allowed conservative variation 0.8–1.2× original (bounded by Vdd = 1.2 V). Keep within [0.624 V, 0.936 V] for safety with original = 0.78 V.

Notes and rationale
- Vdd and input voltages (Vin) are kept fixed as requested (Vdd = 1.2 V, Vin = 0.60 V). These will be externally swept during DC analysis for operating point exploration.
- Length (L) is held constant in the netlist to ensure W/L tuning only affects device behavior. The code preserves the original L = 0.09e-6 (90 nm) from your provided netlist so the initial operating point exactly matches the original circuit.
- All initial parameter values are exactly the values from your original netlist (no modification) and are inside the declared search ranges.
- No load capacitors were present in the original netlist; therefore no capacitors are included in the search. If you later add compensation or load capacitors, follow the multiplier constraints specified in your requirements.