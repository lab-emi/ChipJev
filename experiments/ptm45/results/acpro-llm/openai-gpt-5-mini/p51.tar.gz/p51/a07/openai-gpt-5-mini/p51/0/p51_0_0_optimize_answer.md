```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    """
    Create the Single-Stage High-Gain CS with Cascode and Active PMOS Load.
    This function expects a params dict with keys:
      - w_M1, w_M3, w_M2 : transistor widths in meters
      - v_biasp, v_biasn : bias voltages in volts

    Note: The model import below must remain exactly as written to match
    the execution environment.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage High-Gain CS with Cascode and Active PMOS Load')

    # Define MOSFET models (using provided parameter dictionaries)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Fixed power supply and input (not part of the optimization search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd fixed at 1.2 V (45nm tech)
    circuit.V('in', 'Vin', circuit.gnd, 0.60)   # Vin fixed at 0.60 V (swept externally)

    # Parameterized bias sources (subject to optimization; constrained in param_ranges_definition)
    circuit.V('biasp', 'VbiasP', circuit.gnd, params['v_biasp'])  # PMOS gate bias
    circuit.V('biasn', 'VbiasN', circuit.gnd, params['v_biasn'])  # NMOS cascode gate bias

    # Process length (fixed for 45 nm technology)
    L = 0.045e-6  # EXACT original L from the provided netlist (45 nm expressed as 0.045e-6)

    # Transistors: W parameterized, L kept constant
    circuit.MOSFET('M1', 'Nint', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)

    circuit.MOSFET('M3', 'Vout', 'VbiasN', 'Nint', circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L)

    circuit.MOSFET('M2', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=L)

    # No load capacitors or resistors were present in the original netlist,
    # so none are added here. Keep any external load caps fixed if used elsewhere.

    return circuit


# Optimization parameter search ranges (annotated)
# Constraints applied:
#  - Transistor width W: between 1×L and 500×L (L = 0.045e-6 m here)
#  - Bias voltages: 0.8–1.2× original value, but never exceeding 1.2 V
#  - All initial_params must exactly match the original netlist values below

L_fixed = 0.045e-6  # process length in meters (45 nm)
w_min = 1.0 * L_fixed
w_max = 500.0 * L_fixed

param_ranges_definition = {
    # Transistor widths (meters). Use log scaling for efficient exploration across decades.
    'w_M1': {'min': w_min, 'max': w_max, 'log': True},
    'w_M3': {'min': w_min, 'max': w_max, 'log': True},
    'w_M2': {'min': w_min, 'max': w_max, 'log': True},

    # Bias voltages (linear search). Ranges are 0.8x to 1.2x original but capped at 1.2 V.
    # Original v_biasp = 0.78 V -> range = [0.8*0.78, min(1.2, 1.2*0.78)] = [0.624, 0.936]
    'v_biasp': {'min': 0.8 * 0.78, 'max': min(1.2, 1.2 * 0.78), 'log': False},

    # Original v_biasn = 0.62 V -> range = [0.8*0.62, min(1.2, 1.2*0.62)] = [0.496, 0.744]
    'v_biasn': {'min': 0.8 * 0.62, 'max': min(1.2, 1.2 * 0.62), 'log': False},
}

# Initial parameter values (EXACT original circuit values from the provided netlist)
initial_params = {
    # Transistor widths (meters) - EXACT originals
    'w_M1': 2.0e-6,   # original M1 width
    'w_M3': 1.0e-6,   # original M3 width
    'w_M2': 8.0e-6,   # original M2 width

    # Bias voltages (volts) - EXACT originals
    'v_biasp': 0.78,  # original PMOS gate bias (VbiasP)
    'v_biasn': 0.62,  # original NMOS cascode gate bias (VbiasN)
}

# Verify that initial params are inside the declared ranges (for convenience/clarity)
# (Not executed here — framework may optionally assert these when starting optimization.)
assert w_min <= initial_params['w_M1'] <= w_max
assert w_min <= initial_params['w_M3'] <= w_max
assert w_min <= initial_params['w_M2'] <= w_max
assert param_ranges_definition['v_biasp']['min'] <= initial_params['v_biasp'] <= param_ranges_definition['v_biasp']['max']
assert param_ranges_definition['v_biasn']['min'] <= initial_params['v_biasn'] <= param_ranges_definition['v_biasn']['max']


# Brief descriptions of each parameter (physical meaning)
param_descriptions = {
    'w_M1':  "Width of NMOS input transistor M1 (meters). Together with fixed L determines W/L of the input device.",
    'w_M3':  "Width of NMOS cascode transistor M3 (meters). Controls cascode current handling and output resistance.",
    'w_M2':  "Width of PMOS active-load transistor M2 (meters). Controls load current and top-node impedance.",
    'v_biasp': "PMOS gate bias voltage (volts) applied to M2 gate (VbiasP). Sets PMOS operating point; keep conservative.",
    'v_biasn': "NMOS cascode gate bias voltage (volts) applied to M3 gate (VbiasN). Controls cascode bias and headroom.",
    'L_fixed': "Process channel length (meters). Fixed to 0.045e-6 (45 nm) — W is optimized, L remains constant.",
    'Vdd': "Supply voltage (volts). Fixed at 1.2 V for this process and not included in optimization.",
    'Vin': "Input DC bias (volts). Fixed at 0.60 V here; it will be externally swept for DC operating point analysis.",
}

# Notes:
# - No resistors or capacitors were present in the original netlist; therefore none are parameterized here.
# - Load capacitors (if added externally) should be kept fixed per your instructions.
# - All voltage ranges were kept conservative (0.8–1.2× original) and capped at 1.2 V to respect supply/headroom.
# - Width ranges obey the 1–500 × L constraint. Use log sampling for widths to span large ranges efficiently.
```