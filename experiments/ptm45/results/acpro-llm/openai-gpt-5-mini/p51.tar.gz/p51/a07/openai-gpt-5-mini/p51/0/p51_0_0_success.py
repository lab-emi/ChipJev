from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS with Cascode and Active PMOS Load')
# Define the MOSFET models from provided parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (DC operating points only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.60)   # Vin DC bias ~0.6 V (input node must appear)
circuit.V('biasp', 'VbiasP', circuit.gnd, 0.78)  # PMOS gate bias (Vdd - |Vth| - 0.2)
circuit.V('biasn', 'VbiasN', circuit.gnd, 0.62)  # NMOS cascode gate bias (~Vth + 0.4)
# Node names:
# - Vin: input node (appears as gate of M1)
# - Nint: internal node at M1 drain / M3 source
# - Vout: output node (drain of M3 and M2)
# Transistor geometries (45 nm tech: L = 0.045e-6 m)
L = 0.045e-6
# M1: NMOS input transistor (common-source)
# parameters: name, drain, gate, source, bulk, model, w=..., l=...
circuit.MOSFET('M1', 'Nint', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2.0e-6, l=L)
# M3: NMOS cascode transistor (between Nint and Vout)
circuit.MOSFET('M3', 'Vout', 'VbiasN', 'Nint', circuit.gnd,
               model='nmos_model', w=1.0e-6, l=L)
# M2: PMOS active load (current-source top load)
circuit.MOSFET('M2', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
               model='pmos_model', w=8.0e-6, l=L)
# End of circuit description
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
