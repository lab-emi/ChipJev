```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load,
    but with selected parameters (transistor widths and bias voltages)
    set from the `params` dictionary.

    NOTE: This function keeps Vdd and the input Vin fixed (as required).
          The import "from model import nmos_params, pmos_params" is kept
          exactly as requested and is used to instantiate device models.
    """
    # Keep the model import exactly as requested (available in runtime)
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load - Fixed Biases')

    # Device models (from provided params module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd fixed at 1.2 V (do not parameterize)

    # Input voltage (fixed, will be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.6)         # Vin fixed at 0.6 V

    # Parameterized bias voltages (subject to optimization, but constrained)
    # params keys: 'V_Vbiasp', 'V_Vbiaspc' (must be <= 1.2 and within provided ranges)
    circuit.V('vbiasp', 'Vbias_p', circuit.gnd, params['V_Vbiasp'])   # PMOS current-source gate bias
    circuit.V('vbiaspc', 'Vbias_pc', circuit.gnd, params['V_Vbiaspc'])# PMOS cascode gate bias

    # Transistors
    # Keep lengths fixed to original values (only widths are parameterized)
    # M1: NMOS common-source amplifier transistor
    # (drain, gate, source, bulk, model, w, l)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)   # original L preserved (45e-9 m)

    # M2: PMOS lower device of cascode current source
    circuit.MOSFET('M2', 'Vout', 'Vbias_p', 'nodec', 'nodec',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=0.18e-6)    # original L preserved (180e-9 m)

    # M3: PMOS cascode device (between Vdd and M2)
    circuit.MOSFET('M3', 'nodec', 'Vbias_pc', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=0.18e-6)    # original L preserved (180e-9 m)

    # No load capacitors or resistors were present in the original netlist.
    # The output node 'Vout' is explicitly created above.

    return circuit


# -----------------------
# Optimization parameter search ranges
# -----------------------
# Note:
# - All widths (W) bounds use the 1xL to 500xL rule.
# - Voltage bounds use 0.8-1.2 × original value, clipped to <= 1.2 V.
# - 'log' indicates a logarithmic sampling preference for optimizers (good for device sizes).
param_search_ranges = {
    # Transistor widths (units: meters)
    'w_M1': {   # M1: L = 0.045e-6 (45 nm) -> W range = 1×L .. 500×L
        'min': 0.045e-6,            # 1 × 45 nm
        'max': 0.045e-6 * 500.0,    # 500 × 45 nm = 22.5 µm
        'log': True
    },
    'w_M2': {   # M2: L = 0.18e-6 (180 nm) -> W range = 1×L .. 500×L
        'min': 0.18e-6,             # 1 × 180 nm
        'max': 0.18e-6 * 500.0,     # 500 × 180 nm = 90 µm
        'log': True
    },
    'w_M3': {   # M3: same L as M2
        'min': 0.18e-6,
        'max': 0.18e-6 * 500.0,
        'log': True
    },

    # Bias voltages (units: Volts)
    # Original Vbias_p = 0.5 => range 0.8×..1.2× = [0.4, 0.6] (<=1.2)
    # Original Vbias_pc = 0.6 => range 0.8×..1.2× = [0.48, 0.72] (<=1.2)
    # Use linear sampling for voltages (log would be inappropriate here).
    'V_Vbiasp': {
        'min': max(0.8 * 0.5, 0.0),   # 0.4 V
        'max': min(1.2 * 0.5, 1.2),   # 0.6 V (clipped to <= 1.2 V)
        'log': False
    },
    'V_Vbiaspc': {
        'min': max(0.8 * 0.6, 0.0),   # 0.48 V
        'max': min(1.2 * 0.6, 1.2),   # 0.72 V
        'log': False
    }
}

# -----------------------
# Initial parameter values (EXACT original circuit values)
# These values must match the original netlist exactly and are the starting point
# for optimization. They are within the ranges defined above.
# -----------------------
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 10e-6,    # Original M1 width = 10e-6 (10 µm)
    'w_M2': 8e-6,     # Original M2 width = 8e-6 (8 µm)
    'w_M3': 4e-6,     # Original M3 width = 4e-6 (4 µm)

    # Bias voltages (exact original values)
    'V_Vbiasp': 0.5,  # Original PMOS current-source gate bias
    'V_Vbiaspc': 0.6  # Original PMOS cascode gate bias
}

# -----------------------
# Parameter descriptions (brief)
# -----------------------
param_descriptions = {
    'w_M1':  "Width of the NMOS amplifier transistor M1 (sets drive current / gm). L fixed at 45e-9 m.",
    'w_M2':  "Width of the PMOS lower cascode/current-source device M2 (sets current source strength). L fixed at 180e-9 m.",
    'w_M3':  "Width of the PMOS cascode device M3 (affects cascode output resistance/headroom). L fixed at 180e-9 m.",
    'V_Vbiasp':  "DC bias applied to the gate of the PMOS current-source device (Vbias_p). Controls tail current magnitude; constrained to 0.8–1.2× original and <= 1.2 V.",
    'V_Vbiaspc': "DC bias applied to the gate of the PMOS cascode device (Vbias_pc). Controls cascode headroom; constrained to 0.8–1.2× original and <= 1.2 V."
}

# Notes:
# - Vdd remains fixed at 1.2 V and is intentionally not parameterized.
# - Vin remains fixed at 0.6 V (will be externally swept during DC analysis).
# - All initial_params values are exactly the values taken from your original netlist.
# - Width ranges obey the 1×L .. 500×L rule and include the original width inside the interval.
# - Bias voltage ranges are conservative (0.8–1.2× original) and clipped to not exceed the supply (1.2 V).
# - The MOSFET threshold (Vth ~ 0.22 V) was considered; lower bounds remain above Vth for the provided original biases.
```