from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load')
# Models from provided params
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.5)         # Vin DC bias for operating point (0.5 V)
circuit.V('vbiasp', 'Vbias_p', circuit.gnd, 0.78)  # PMOS current-source gate bias
circuit.V('vbiaspc', 'Vbias_pc', circuit.gnd, 0.95) # PMOS cascode gate bias
# Transistors
# M1: NMOS common-source amplifier transistor
# (drain, gate, source, bulk, model, w, l)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# M2: PMOS lower device of cascode current source (source tied to nodec)
circuit.MOSFET('M2', 'Vout', 'Vbias_p', 'nodec', 'nodec',
               model='pmos_model', w=10e-6, l=0.18e-6)
# M3: PMOS cascode device (between Vdd and M2)
circuit.MOSFET('M3', 'nodec', 'Vbias_pc', 'Vdd', 'Vdd',
               model='pmos_model', w=5e-6, l=0.18e-6)
# The output node (Vout) appears explicitly as requested.
# Create a simulator for operating point / further analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
