from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier with Cascoded PMOS Active Load')
# Define MOSFET models (parameters provided by external module 'model')
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)     # Vin DC bias = 0.42 V (Vth + 0.2)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78) # PMOS main load gate bias
circuit.V('biasc', 'Vbiasc', circuit.gnd, 0.88) # PMOS cascode gate bias
# Transistor dimensions (45 nm technology)
L = 0.045e-6  # 45 nm
# M1: NMOS amplifier transistor (common-source)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# M2: PMOS main current-source load (drain at Vout)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'M2_src', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
# M3: PMOS cascode transistor (between Vdd and M2 source)
circuit.MOSFET('M3', 'M2_src', 'Vbiasc', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
# Instantiate simulator (operating point / DC analysis can be run by the caller)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
