```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    """
    Create a parameterized Single-Stage CS Amplifier with Cascoded PMOS Active Load.

    NOTE: this function keeps vdd and the input Vin fixed (as required).
    The MOSFET models are imported from the provided module exactly as requested.
    """
    # Keep the import exactly as required inside the function
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier with Cascoded PMOS Active Load')

    # MOSFET models (external parameters from `model` module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and bias supplies
    # Vdd is fixed and not parameterized (1.2 V for 45nm technology)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)

    # Input voltage is fixed (will be swept during DC analysis externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)

    # Parameterized bias voltages (constrained by search ranges in param_ranges_definition)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])
    circuit.V('biasc', 'Vbiasc', circuit.gnd, params['Vbiasc'])

    # Transistor channel length (process fixed)
    L = 45e-9  # 45 nm (fixed, not part of optimization)

    # NMOS amplifier transistor (common-source) - width parameterized
    circuit.MOSFET('M1',
                   'Vout',   # drain
                   'Vin',    # gate
                   circuit.gnd,  # source
                   circuit.gnd,  # bulk
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # PMOS main current-source load (drain at Vout) - width parameterized
    circuit.MOSFET('M2',
                   'Vout',      # drain
                   'Vbias',     # gate (biased)
                   'M2_src',    # source (to cascode)
                   'Vdd',       # bulk
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)

    # PMOS cascode transistor (between Vdd and M2 source) - width parameterized
    circuit.MOSFET('M3',
                   'M2_src',    # drain
                   'Vbiasc',    # gate (cascode bias)
                   'Vdd',       # source
                   'Vdd',       # bulk
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)

    return circuit


# Optimization parameter search ranges
# All ranges follow the rules provided:
# - Width (W) in [1xL, 500xL] (here L = 45e-9 -> [45e-9, 22.5e-6])
# - Bias voltages in [0.8-1.2]×original but clipped to <= 1.2 V
# - Initial params (initial_params) are EXACTLY the original values from the user's netlist
param_ranges_definition = {
    # Transistor widths (optimize W only; L fixed at 45 nm)
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M1 original: 10e-6
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M2 original: 20e-6
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # M3 original: 20e-6

    # Bias voltages (0.8 - 1.2 × original, clipped to <= 1.2V)
    # Original Vbias = 0.78 -> range [0.624, 0.936]
    'Vbias':  {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},

    # Original Vbiasc = 0.88 -> range [0.704, 1.056]
    'Vbiasc': {'min': 0.8 * 0.88, 'max': min(1.2 * 0.88, 1.2), 'log': False},
}

# Initial parameter values (EXACT original circuit values)
# These are the starting point for optimization and are required to match the original netlist exactly.
initial_params = {
    'w_M1': 10e-6,   # Original width of M1
    'w_M2': 20e-6,   # Original width of M2
    'w_M3': 20e-6,   # Original width of M3
    'Vbias': 0.78,   # Original PMOS main load gate bias
    'Vbiasc': 0.88,  # Original PMOS cascode gate bias
}

# Parameter descriptions (brief physical meaning)
param_descriptions = {
    'w_M1':   "Width of NMOS amplifier transistor M1 (controls current drive, gm, output resistance). L fixed at 45 nm.",
    'w_M2':   "Width of PMOS main current-source load M2 (sets load current, headroom and output resistance). L fixed at 45 nm.",
    'w_M3':   "Width of PMOS cascode transistor M3 (affects cascode impedance, output resistance, and node M2_src). L fixed at 45 nm.",
    'Vbias':  "Gate bias applied to PMOS load M2 (sets DC operating point of the load). Range restricted to 0.8–1.2× original and <= 1.2 V.",
    'Vbiasc': "Gate bias applied to PMOS cascode M3 (sets cascode bias and headroom). Range restricted to 0.8–1.2× original and <= 1.2 V.",
}

# Notes:
# - Vdd (1.2 V) and Vin (0.42 V) are intentionally fixed (not in param search).
# - L (channel length) is fixed at 45e-9 m (45 nm); only W varies in optimization as requested.
# - The provided initial_params values are exactly the original values from the user's circuit.
# - All initial values lie within the defined param_ranges_definition.
# - Vth = 0.22 V was considered when keeping bias ranges conservative (bias values are well above threshold but limited to avoid exceeding supply).
```

Brief summary of how the constraints were applied:
- Transistor widths: allowed from 1×L to 500×L (45e-9 → 22.5e-6). Log scale recommended for wide dynamic range.
- Bias voltages: 0.8–1.2× original but clipped at 1.2 V (supply), resulting in Vbias ∈ [0.624, 0.936] and Vbiasc ∈ [0.704, 1.056].
- No resistors or capacitors present in the original netlist; therefore none were parameterized. Load capacitors (if present) must remain fixed per instructions.