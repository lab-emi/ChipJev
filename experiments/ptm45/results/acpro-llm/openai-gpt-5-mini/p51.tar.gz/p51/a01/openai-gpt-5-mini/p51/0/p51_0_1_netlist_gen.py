from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS with Cascoded PMOS Load - Fixed Bias')
# Define MOSFET models from provided parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias sources (operating point biasing only, no AC)
# Adjusted to ensure PMOS devices are turned on and NMOS conducts.
# For PMOS, Vsg = Vsource(=Vdd) - Vgate must exceed |Vth| (~0.22V).
circuit.V('biasp', 'Vbias', circuit.gnd, 0.30)      # Gate bias for PMOS top current source (stronger turn-on)
circuit.V('biaspc', 'Vbias_cas', circuit.gnd, 0.50) # Gate bias for PMOS cascode
circuit.V('in', 'Vin', circuit.gnd, 0.80)          # DC bias on input node to set NMOS in conduction
# Transistor devices
# M1: NMOS common-source amplifier (drain = Vout, gate = Vin, source = GND, bulk = GND)
# Use relatively large W to increase gm; minimum L for 45nm technology.
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# M2: PMOS top current-source transistor (source = Vdd, gate = Vbias, drain = Vx, bulk = Vdd)
# Make it long to increase output resistance.
circuit.MOSFET('M2', 'Vx', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.18e-6)
# M3: PMOS cascode transistor (source = Vx, gate = Vbias_cas, drain = Vout, bulk = Vdd)
# Long channel to provide cascode effect and high output resistance.
circuit.MOSFET('M3', 'Vout', 'Vbias_cas', 'Vx', 'Vdd',
               model='pmos_model', w=30e-6, l=0.18e-6)
# End with simulator creation (no further commands)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
