```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the parameterized PySpice circuit.

    Notes:
    - Vdd and input Vin are fixed (not parameterized) per requirements.
    - MOSFET lengths are kept equal to the originals (fixed). Only widths (W) are parameterized.
    - The module import "from model import nmos_params, pmos_params" is kept exactly as required.
    """
    # keep the model import exactly as requested (module available in execution environment)
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage High-Gain CS with Cascoded PMOS Load - Fixed Bias')

    # MOS models from the provided parameters
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V

    # Input voltage (fixed, not parameterized as requested)
    circuit.V('in', 'Vin', circuit.gnd, 0.80)  # Vin fixed to original value

    # Parameterized DC bias sources (subject to optimization)
    circuit.V('biasp', 'Vbias', circuit.gnd, params['Vbias_p'])       # PMOS top current-source gate
    circuit.V('biaspc', 'Vbias_cas', circuit.gnd, params['Vbias_cas'])# PMOS cascode gate

    # Transistor devices
    # M1: NMOS common-source amplifier (drain = Vout, gate = Vin, source = GND, bulk = GND)
    # Original length preserved (fixed); width parameterized
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)   # original L for M1 (0.045e-6 m)

    # M2: PMOS top current-source transistor (source = Vdd, gate = Vbias, drain = Vx, bulk = Vdd)
    circuit.MOSFET('M2', 'Vx', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=0.18e-6)    # original L for M2 (0.18e-6 m)

    # M3: PMOS cascode transistor (source = Vx, gate = Vbias_cas, drain = Vout, bulk = Vdd)
    circuit.MOSFET('M3', 'Vout', 'Vbias_cas', 'Vx', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=0.18e-6)    # original L for M3 (0.18e-6 m)

    return circuit

# -------------------------
# Optimization parameter search ranges (annotated for use with Optuna or similar)
# -------------------------
param_ranges_definition = {
    # Transistor widths (W) in meters.
    # Rule: W range = 1x L  ... 500x L  (per-device L preserved as in original netlist).
    # Log sampling recommended for widths to cover wide dynamic range efficiently.
    'w_M1': {   # M1 uses L = 0.045e-6 (45 nm)
        'min': 0.045e-6,            # 1 * L_M1 (45 nm)
        'max': 0.045e-6 * 500.0,    # 500 * L_M1 = 22.5e-6 (22.5 µm)
        'log': True
    },
    'w_M2': {   # M2 uses L = 0.18e-6 (180 nm)
        'min': 0.18e-6,             # 1 * L_M2 (180 nm)
        'max': 0.18e-6 * 500.0,     # 500 * L_M2 = 90e-6 (90 µm)
        'log': True
    },
    'w_M3': {   # M3 uses L = 0.18e-6 (180 nm)
        'min': 0.18e-6,             # 1 * L_M3 (180 nm)
        'max': 0.18e-6 * 500.0,     # 500 * L_M3 = 90e-6 (90 µm)
        'log': True
    },

    # DC bias voltages (except Vdd and input Vin which are fixed).
    # Allowed range: 0.8 - 1.2 × original value, but never exceed 1.2 V (supply).
    # These ranges are conservative to keep PMOS devices biased in intended operating region
    # (Vth ~ 0.22 V; ensure Vsg = Vdd - Vgate remains comfortably above |Vth|).
    'Vbias_p': {     # original = 0.30 V
        'min': max(0.0, 0.30 * 0.8),  # 0.24 V
        'max': min(1.2, 0.30 * 1.2),  # 0.36 V (<= 1.2)
        'log': False
    },
    'Vbias_cas': {   # original = 0.50 V
        'min': max(0.0, 0.50 * 0.8),  # 0.40 V
        'max': min(1.2, 0.50 * 1.2),  # 0.60 V (<= 1.2)
        'log': False
    }
}

# -------------------------
# Initial parameter values (EXACT original circuit values) - must match the provided netlist
# -------------------------
initial_params = {
    # Transistor widths (EXACT original values, in meters)
    'w_M1': 20e-6,   # Original M1 width from your netlist (20 µm)
    'w_M2': 40e-6,   # Original M2 width from your netlist (40 µm)
    'w_M3': 30e-6,   # Original M3 width from your netlist (30 µm)

    # DC bias voltages (EXACT original values, in volts)
    'Vbias_p': 0.30,     # Original bias for PMOS top current-source gate
    'Vbias_cas': 0.50,   # Original bias for PMOS cascode gate
}

# -------------------------
# Parameter descriptions (brief physical meaning for optimizer and human readers)
# -------------------------
parameter_descriptions = {
    'w_M1': "M1 NMOS width (m). Controls channel current and gm of the input common-source transistor. L is fixed at original value (0.045e-6 m).",
    'w_M2': "M2 PMOS width (m). Sets current-source strength and output resistance of the PMOS top device. L is fixed at original value (0.18e-6 m).",
    'w_M3': "M3 PMOS width (m). Sets cascode device strength and output resistance for the cascode stage. L is fixed at original value (0.18e-6 m).",
    'Vbias_p': "Gate bias for PMOS top current-source (V). Tunes the operating point / tail current of the PMOS load. Range = 0.8–1.2× original (clipped <=1.2 V).",
    'Vbias_cas': "Gate bias for PMOS cascode (V). Controls cascode operating point and headroom. Range = 0.8–1.2× original (clipped <=1.2 V)."
}

# Quick validation note:
# - All initial_params values are inside the ranges in param_ranges_definition:
#   * w_M1 initial: 20e-6 ∈ [0.045e-6, 22.5e-6]  -> OK
#   * w_M2 initial: 40e-6 ∈ [0.18e-6, 90e-6]     -> OK
#   * w_M3 initial: 30e-6 ∈ [0.18e-6, 90e-6]     -> OK
#   * Vbias_p initial: 0.30  ∈ [0.24, 0.36]      -> OK
#   * Vbias_cas initial: 0.50 ∈ [0.40, 0.60]     -> OK
#
# - Vdd and Vin are intentionally fixed (not included in the optimizer), as requested.
```