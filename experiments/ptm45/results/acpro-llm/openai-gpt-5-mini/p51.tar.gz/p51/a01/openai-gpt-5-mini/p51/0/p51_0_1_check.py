from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS with Cascoded PMOS Load - Fixed Bias')
# Define MOSFET models from provided parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias sources (operating point biasing only, no AC)
# Adjusted to ensure PMOS devices are turned on and NMOS conducts.
# For PMOS, Vsg = Vsource(=Vdd) - Vgate must exceed |Vth| (~0.22V).
circuit.V('biasp', 'Vbias', circuit.gnd, 0.30)      # Gate bias for PMOS top current source (stronger turn-on)
circuit.V('biaspc', 'Vbias_cas', circuit.gnd, 0.50) # Gate bias for PMOS cascode
circuit.V('in', 'Vin', circuit.gnd, "dc 0.80 ac 1n")
# Transistor devices
# M1: NMOS common-source amplifier (drain = Vout, gate = Vin, source = GND, bulk = GND)
# Use relatively large W to increase gm; minimum L for 45nm technology.
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# M2: PMOS top current-source transistor (source = Vdd, gate = Vbias, drain = Vx, bulk = Vdd)
# Make it long to increase output resistance.
circuit.MOSFET('M2', 'Vx', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.18e-6)
# M3: PMOS cascode transistor (source = Vx, gate = Vbias_cas, drain = Vout, bulk = Vdd)
# Long channel to provide cascode effect and high output resistance.
circuit.MOSFET('M3', 'Vout', 'Vbias_cas', 'Vx', 'Vdd',
               model='pmos_model', w=30e-6, l=0.18e-6)
# End with simulator creation (no further commands)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)