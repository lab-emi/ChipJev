from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 20e-6,   # Original M1 width
    'w_M2': 40e-6,   # Original M2 width
    'w_M3': 20e-6,   # Original M3 width
    # Bias voltages (exact original values)
    'Vbias_p': 0.78,   # Original PMOS load gate bias
    'Vbias_pc': 0.60,  # Original PMOS cascode gate bias
}
