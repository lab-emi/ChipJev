from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS with Cascoded PMOS Load')
# Device models (provided by the environment)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)       # Vin DC bias (~Vth + 0.2) for operating point
circuit.V('vbias_p', 'Vbias_p', circuit.gnd, 0.78)   # PMOS load gate bias (sets current)
circuit.V('vbias_pc', 'Vbias_pc', circuit.gnd, 0.60) # PMOS cascode gate bias
# Internal node between top and bottom PMOS cascode
# (no explicit voltage source; node name used in devices)
# Note: MOSFET signature: MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
# Input transistor (NMOS common-source)
# drain = Vout, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=45e-9)
# PMOS top of cascode stack (M2)
# drain = Vx, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'Vx', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=45e-9)
# PMOS cascode (bottom of cascode stack, closest to output) (M3)
# drain = Vout, gate = Vbias_pc, source = Vx, bulk = Vdd
circuit.MOSFET('M3', 'Vout', 'Vbias_pc', 'Vx', 'Vdd',
               model='pmos_model', w=20e-6, l=45e-9)
# Simulator (stop here as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
