from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load')
# Define MOSFET models (provided by external 'model' module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)        # Vin DC bias ~ Vth + 0.2 V = 0.42 V
circuit.V('btop', 'Vbias_top', circuit.gnd, 0.78)  # PMOS top gate bias ~ 0.78 V
circuit.V('bcas', 'Vbias_cas', circuit.gnd, 0.36)  # PMOS cascode gate bias ~ 0.36 V
# Node names used:
#  - Vin (input node)
#  - Vout (output node)
#  - node_x (internal node between PMOS top and PMOS cascode)
#  - Vdd (power rail)
#  - ground
# Technology dimensions (45 nm)
L_min = 45e-9  # 45 nm
# Device sizing (typical analog choices for 45nm node)
# M1: NMOS input transistor (large W for high gm)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L_min)
# M2: PMOS top current-setting device (active load)
circuit.MOSFET('M2', 'node_x', 'Vbias_top', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L_min)
# M3: PMOS cascode device (increases load resistance)
circuit.MOSFET('M3', 'Vout', 'Vbias_cas', 'node_x', 'Vdd',
               model='pmos_model', w=20e-6, l=L_min)
# Note: Bulk of each MOSFET is tied to its source as required
# Create simulator (no AC sources; operating point / DC analysis)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
