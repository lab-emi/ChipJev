from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load.
    The function accepts a params dictionary that controls transistor widths
    and the two bias voltages (Vbias_top and Vbias_cas). L is fixed to 45nm.
    """
    circuit = Circuit('Single-Stage High-Gain CS Amplifier with Cascoded PMOS Load')
    # Load transistor models from provided module (exact import required)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed supply and input (NOT parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd fixed at 1.2 V (45nm supply)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)   # Vin fixed at 0.42 V (swept externally)
    # Parameterized bias voltages (bounded to <= 1.2 V and 0.8-1.2x original)
    # Names of the sources kept as in the original netlist
    circuit.V('btop', 'Vbias_top', circuit.gnd, params['v_bias_top'])
    circuit.V('bcas', 'Vbias_cas', circuit.gnd, params['v_bias_cas'])
    # Process minimum length (fixed)
    L_min = 45e-9  # 45 nm
    # Transistors (L fixed; W set from params)
    # M1: NMOS input transistor
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)
    # M2: PMOS top current-setting device (active load)
    circuit.MOSFET('M2', 'node_x', 'Vbias_top', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_min)
    # M3: PMOS cascode device
    circuit.MOSFET('M3', 'Vout', 'Vbias_cas', 'node_x', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_min)
    return circuit
# -------------------------
# Optimization parameter search ranges (annotated)
# -------------------------
# Notes on units:
# - Widths (w_*) are in meters (SI)
# - Voltages (v_*) are in volts (SI)
#
# Rules applied:
# - W ranges generally set to 1×L_min .. max(500×L_min, original_width)
#   (this ensures the requested 1-500×L range is honored while also
#    guaranteeing the original widths are inside the search interval)
# - Bias voltages are allowed 0.8–1.2× original values, but clipped at 1.2 V
# - All voltage ranges ensure values never exceed 1.2 V
L_min = 45e-9  # used for computing width bounds in ranges below
param_ranges_definition = {
    # Transistor widths (meters). Log scale is often helpful for size sweeps.
    'w_M1': {
        'min': 1.0 * L_min,                         # 1×L
        'max': max(500.0 * L_min, 20e-6),           # 500×L or original if larger
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L_min,
        'max': max(500.0 * L_min, 40e-6),           # ensure original 40e-6 is in range
        'log': True
    },
    'w_M3': {
        'min': 1.0 * L_min,
        'max': max(500.0 * L_min, 20e-6),
        'log': True
    },
    # Bias voltages: 0.8x .. 1.2x original, clipped to <= 1.2 V
    # Keep ranges conservative relative to threshold (Vth = 0.22 V)
    'v_bias_top': {
        'min': max(0.0, 0.8 * 0.78),   # 0.624 V
        'max': min(1.2, 1.2 * 0.78),   # 0.936 V (<=1.2)
        'log': False
    },
    'v_bias_cas': {
        'min': max(0.0, 0.8 * 0.36),   # 0.288 V
        'max': min(1.2, 1.2 * 0.36),   # 0.432 V
        'log': False
    }
}
# -------------------------
# Initial parameter values (EXACT original circuit values - MUST match original code)
# -------------------------
initial_params = {
    # Exact transistor widths from the original netlist (meters)
    'w_M1': 20e-6,   # Original M1 width
    'w_M2': 40e-6,   # Original M2 width
    'w_M3': 20e-6,   # Original M3 width
    # Exact bias voltages from the original netlist (volts)
    'v_bias_top': 0.78,  # Vbias_top original
    'v_bias_cas': 0.36   # Vbias_cas original
}
# -------------------------
# Short descriptions of each parameter (physical meaning)
# -------------------------
param_descriptions = {
    'w_M1': "Width of NMOS input transistor M1. Controls gm, current capability and input device capacitance. L fixed at 45 nm.",
    'w_M2': "Width of PMOS top current-setting device M2 (active load). Controls current mirror/load current and output resistance. L fixed at 45 nm.",
    'w_M3': "Width of PMOS cascode transistor M3. Controls cascode headroom and incremental output resistance. L fixed at 45 nm.",
    'v_bias_top': "Gate bias voltage applied to M2 (Vbias_top). Sets M2 operating point and tail current; range limited to 0.8–1.2× original and <= 1.2 V.",
    'v_bias_cas': "Gate bias voltage applied to M3 cascode gate (Vbias_cas). Sets cascode bias; range limited to 0.8–1.2× original and <= 1.2 V."
}
