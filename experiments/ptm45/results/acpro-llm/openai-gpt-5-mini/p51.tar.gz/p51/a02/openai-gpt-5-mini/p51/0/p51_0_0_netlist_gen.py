from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amp with Cascoded PMOS Load')
# Define MOS models (assumed provided in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias sources (no AC)
# Use Vth = 0.22 V when picking bias values as described in the plan
circuit.V('in', 'Vin', circuit.gnd, 0.6)        # DC operating point for Vin (bias the NMOS gate)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)   # Gate bias for top PMOS (sets load current)
circuit.V('biaspc', 'Vbias_pc', circuit.gnd, 0.95) # Gate bias for PMOS cascode
# Node between the two PMOS devices
# (no explicit source for this node; it's created by the device connections)
Pnode = 'Pnode'
# Devices: circuit.MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
# M1: NMOS amplifier transistor (common-source)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# M2: PMOS cascode (lower PMOS in the stack)
# drain -> Vout, gate -> Vbias_pc, source -> Pnode, bulk -> Vdd
circuit.MOSFET('M2', 'Vout', 'Vbias_pc', Pnode, 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# M3: PMOS top device (current-source setting device)
# drain -> Pnode, gate -> Vbias_p, source -> Vdd, bulk -> Vdd
circuit.MOSFET('M3', Pnode, 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Ensure required nodes appear: Vin and Vout are present (Vout used above)
# End with the simulator creation as requested
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
