from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    """
    Create the Single-Stage CS Amp with Cascoded PMOS Load using parameter dictionary `params`.
    NOTE: this function includes the required import of device model parameter dictionaries
    exactly as requested by the optimization framework environment.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage CS Amp with Cascoded PMOS Load')
    # Attach transistor models (assumed provided by model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V for 45 nm technology
    # Input voltage source (fixed, not parameterized - will be swept externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.6)  # Vin fixed at 0.6 V (DC operating point)
    # Other DC bias sources (parameterized)
    # These are constrained to 0.8-1.2x their original values (and never > 1.2 V).
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['Vbias_p'])    # top PMOS gate bias
    circuit.V('biaspc', 'Vbias_pc', circuit.gnd, params['Vbias_pc']) # PMOS cascode gate bias
    # Node between the two PMOS devices
    Pnode = 'Pnode'
    # Fixed channel length (45 nm = 45e-9 m), only W is optimized (W/L matters)
    L = 0.045e-6  # exact length value used in original netlist (45 nm)
    # MOSFET devices (widths parameterized; lengths fixed)
    # M1: NMOS amplifier transistor (common-source)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    # M2: PMOS cascode (lower PMOS in the stack)
    # drain -> Vout, gate -> Vbias_pc, source -> Pnode, bulk -> Vdd
    circuit.MOSFET('M2', 'Vout', 'Vbias_pc', Pnode, 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)
    # M3: PMOS top device (current-source setting device)
    # drain -> Pnode, gate -> Vbias_p, source -> Vdd, bulk -> Vdd
    circuit.MOSFET('M3', Pnode, 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    return circuit
# -----------------------------------------------------------------------------
# Optimization parameter search ranges (annotated)
# -----------------------------------------------------------------------------
# Technology length used in the original netlist (kept constant):
L_fixed = 0.045e-6  # 45 nm (exact original length)
param_ranges = {
    # Transistor widths (meters)
    # Constraint: W in [1 * L, 500 * L] (i.e., 1-500× the channel length).
    # Using log scale is often useful for dimensional parameters spanning many decades.
    'w_M1': { 'min': 1.0 * L_fixed, 'max': 500.0 * L_fixed, 'scale': 'log', 'unit': 'm' },
    'w_M2': { 'min': 1.0 * L_fixed, 'max': 500.0 * L_fixed, 'scale': 'log', 'unit': 'm' },
    'w_M3': { 'min': 1.0 * L_fixed, 'max': 500.0 * L_fixed, 'scale': 'log', 'unit': 'm' },
    # Bias voltages (volts)
    # Rule: each non-Vdd, non-input voltage is allowed in 0.8-1.2× original value,
    # but must never exceed the supply (1.2 V). These ranges were clipped accordingly.
    # Note: these ranges were chosen conservatively with device Vth (~0.22 V) in mind
    # so the PMOS/NMOS remain in intended operating regions for typical bias points.
    'Vbias_p':  { 'min': 0.8 * 0.78,  'max': min(1.2, 1.2 * 0.78),  'scale': 'linear', 'unit': 'V' },
    'Vbias_pc': { 'min': 0.8 * 0.95,  'max': min(1.2, 1.2 * 0.95),  'scale': 'linear', 'unit': 'V' },
}
# Convert numeric expressions to concrete floats for clarity (these are the values used)
param_ranges['Vbias_p']['min']  = float(param_ranges['Vbias_p']['min'])   # 0.624
param_ranges['Vbias_p']['max']  = float(param_ranges['Vbias_p']['max'])   # 0.936
param_ranges['Vbias_pc']['min'] = float(param_ranges['Vbias_pc']['min'])  # 0.76
param_ranges['Vbias_pc']['max'] = float(param_ranges['Vbias_pc']['max'])  # 1.14
param_ranges['w_M1']['min'] = float(param_ranges['w_M1']['min'])          # 45e-9
param_ranges['w_M1']['max'] = float(param_ranges['w_M1']['max'])          # 22.5e-6
param_ranges['w_M2']['min'] = float(param_ranges['w_M2']['min'])
param_ranges['w_M2']['max'] = float(param_ranges['w_M2']['max'])
param_ranges['w_M3']['min'] = float(param_ranges['w_M3']['min'])
param_ranges['w_M3']['max'] = float(param_ranges['w_M3']['max'])
# -----------------------------------------------------------------------------
# Initial parameter values (EXACT original circuit values - MUST match original netlist)
# -----------------------------------------------------------------------------
initial_params = {
    # Transistor widths (exact numbers from your original code)
    'w_M1': 10e-6,   # original M1 width
    'w_M2': 20e-6,   # original M2 width
    'w_M3': 20e-6,   # original M3 width
    # Bias voltages (exact numbers from your original code)
    'Vbias_p':  0.78,  # original biasp
    'Vbias_pc': 0.95,  # original biaspc
}
# Sanity checks (these comments document that initial values lie inside the ranges)
# - w_M1 = 10e-6 is between 45e-9 and 22.5e-6
# - w_M2/w_M3 = 20e-6 are between 45e-9 and 22.5e-6
# - Vbias_p = 0.78 is within [0.624, 0.936]
# - Vbias_pc = 0.95 is within [0.76, 1.14]
# -----------------------------------------------------------------------------
# Parameter descriptions (brief physical meaning)
# -----------------------------------------------------------------------------
param_descriptions = {
    'w_M1':    'Channel width (W) of the input NMOS amplifier transistor M1 (meters). W/L controls drive strength and gm; L is fixed at 45 nm.',
    'w_M2':    'Channel width (W) of the PMOS cascode device M2 (meters). Larger W increases cascode device current capability and reduces output resistance impact.',
    'w_M3':    'Channel width (W) of the PMOS current-source/top device M3 (meters). Sets the current source strength and headroom.',
    'Vbias_p': 'Gate bias voltage applied to the top PMOS (M3) that sets the stack current (volts). Conservative range: 0.8–1.2× original but never > 1.2 V.',
    'Vbias_pc':'Gate bias voltage applied to the PMOS cascode (M2) (volts). Conservative range: 0.8–1.2× original but never > 1.2 V.',
}
# -----------------------------------------------------------------------------
# Notes:
# - vdd (1.2 V) and the input source Vin (0.6 V) are intentionally fixed (not included in search).
# - No explicit resistors or capacitors were present in the original netlist; therefore none are included here.
# - If you later add load capacitors (C_load) keep them fixed at their original values and do not include them in the parameter search.
# - All numeric initial values in `initial_params` are EXACT copies of the values in your supplied netlist.
# -----------------------------------------------------------------------------
