from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    """
    Create the Single-Stage Cascoded CS Amplifier circuit using parameterization.
    Note: The model import below must appear exactly as written (required by the environment).
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Cascoded CS Amplifier - Fixed Biases')
    # MOSFET models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V (fixed)
    # Input voltage source (fixed, not parameterized; will be swept separately)
    circuit.V('in', 'Vin', circuit.gnd, 0.8)  # Input DC bias fixed at original value
    # Parameterized DC bias sources (these are searchable parameters)
    # They must always be <= 1.2 V; ranges for these parameters are defined in param_ranges_definition
    circuit.V('bn', 'Vb_n', circuit.gnd, params['Vb_n'])    # NMOS cascode gate bias
    circuit.V('bp', 'Vb_p', circuit.gnd, params['Vb_p'])    # PMOS cascode gate bias
    circuit.V('bi', 'VbiasI', circuit.gnd, params['VbiasI'])# PMOS current-source gate bias
    # Nodes:
    # - 'Nmid' : between input NMOS drain and NMOS cascode source
    # - 'Vp'   : between PMOS current-source drain and PMOS cascode source
    # - 'Vout' : amplifier output node
    # Transistor sizing (lengths fixed; only widths parameterized)
    # L values (kept as in original netlist)
    L_M1_M4_M2 = 45e-9    # 45 nm for M1, M4, M2
    L_M3 = 180e-9         # 180 nm for M3 (explicit in original)
    # M1: Input NMOS (drain, gate, source, bulk)
    circuit.MOSFET('M1', 'Nmid', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_M1_M4_M2)
    # M4: NMOS cascode (bulk tied to its source 'Nmid') (drain, gate, source, bulk)
    circuit.MOSFET('M4', 'Vout', 'Vb_n', 'Nmid', 'Nmid',
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L_M1_M4_M2)
    # M2: PMOS cascode (bulk tied to its source 'Vp') (drain, gate, source, bulk)
    circuit.MOSFET('M2', 'Vout', 'Vb_p', 'Vp', 'Vp',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_M1_M4_M2)
    # M3: PMOS current-source (source = Vdd, bulk = Vdd) (drain, gate, source, bulk)
    circuit.MOSFET('M3', 'Vp', 'VbiasI', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_M3)
    return circuit
# ---------------------------
# Optimization parameter search ranges (annotated)
# ---------------------------
# Notes on units:
# - Widths (w_*) in meters (m)
# - Voltages (Vb_*, VbiasI) in volts (V)
#
# Constraints applied:
# - Transistor width (W) range: 1×L to 500×L (per requirement)
# - Voltages (except Vdd and Vin) vary conservatively 0.8–1.2× original but never exceed 1.2 V
# - Width ranges are offered with log sampling recommended for broad scale exploration
param_ranges_definition = {
    # Transistor widths (meters). L values used to set 1x-500x range:
    #   M1, M4, M2 use L = 45e-9
    'w_M1': {'min': 45e-9,        'max': 45e-9 * 500.0,  'log': True},   # M1: input NMOS (original 20e-6)
    'w_M4': {'min': 45e-9,        'max': 45e-9 * 500.0,  'log': True},   # M4: NMOS cascode (original 6e-6)
    'w_M2': {'min': 45e-9,        'max': 45e-9 * 500.0,  'log': True},   # M2: PMOS cascode (original 10e-6)
    # M3 uses L = 180e-9 (so its W ranges are different)
    'w_M3': {'min': 180e-9,       'max': 180e-9 * 500.0, 'log': True},   # M3: PMOS current-source (original 10e-6)
    # DC bias voltages (conservative 0.8-1.2× original, capped at 1.2 V)
    # Original values: Vb_n = 1.10 V, Vb_p = 0.20 V, VbiasI = 0.20 V
    'Vb_n':  {'min': max(0.8 * 1.10, 0.0), 'max': min(1.2 * 1.10, 1.2), 'log': False},  # NMOS cascode gate bias
    'Vb_p':  {'min': max(0.8 * 0.20, 0.0), 'max': min(1.2 * 0.20, 1.2), 'log': False},  # PMOS cascode gate bias
    'VbiasI':{'min': max(0.8 * 0.20, 0.0), 'max': min(1.2 * 0.20, 1.2), 'log': False},  # PMOS current-source gate bias
}
# For clarity, expand/evaluate the above numeric mins and maxes here explicitly:
# (This ensures the numeric ranges are unambiguous to the optimizer.)
param_ranges_definition_explicit = {
    'w_M1':   {'min': 45e-9,       'max': 22.5e-6, 'log': True},   # 1×45nm to 500×45nm
    'w_M4':   {'min': 45e-9,       'max': 22.5e-6, 'log': True},
    'w_M2':   {'min': 45e-9,       'max': 22.5e-6, 'log': True},
    'w_M3':   {'min': 180e-9,      'max': 90e-6,   'log': True},   # 1×180nm to 500×180nm
    'Vb_n':   {'min': 0.88,        'max': 1.20,     'log': False},  # 0.8×1.10 = 0.88 ; 1.2×1.10 = 1.32 -> capped at 1.2
    'Vb_p':   {'min': 0.16,        'max': 0.24,     'log': False},  # 0.8×0.20 = 0.16 ; 1.2×0.20 = 0.24
    'VbiasI': {'min': 0.16,        'max': 0.24,     'log': False},  # same as Vb_p
}
# ---------------------------
# Initial parameter values (EXACT original circuit values)
# These are the starting point for optimization and MUST match the original netlist values.
# ---------------------------
initial_params = {
    # EXACT transistor widths from the original netlist (meters)
    'w_M1': 20e-6,   # original M1 width
    'w_M4': 6e-6,    # original M4 width
    'w_M2': 10e-6,   # original M2 width
    'w_M3': 10e-6,   # original M3 width
    # EXACT DC bias voltages from the original netlist (volts)
    'Vb_n':  1.10,   # original NMOS cascode gate bias
    'Vb_p':  0.20,   # original PMOS cascode gate bias
    'VbiasI':0.20,   # original PMOS current-source gate bias
}
# Verify (human-readable) that initial values lie within param_ranges_definition_explicit:
# - w_M1: 20e-6 within [45e-9, 22.5e-6]  -> OK
# - w_M4: 6e-6   within [45e-9, 22.5e-6]  -> OK
# - w_M2: 10e-6  within [45e-9, 22.5e-6]  -> OK
# - w_M3: 10e-6  within [180e-9, 90e-6]   -> OK
# - Vb_n: 1.10   within [0.88, 1.20]      -> OK
# - Vb_p: 0.20   within [0.16, 0.24]      -> OK
# - VbiasI:0.20  within [0.16, 0.24]      -> OK
# ---------------------------
# Parameter descriptions (brief)
# ---------------------------
# w_M1   : Width (W) of input NMOS transistor M1. Controls input gm and noise; L fixed at 45 nm.
# w_M4   : Width of NMOS cascode transistor M4. Controls cascode headroom and output resistance; L fixed at 45 nm.
# w_M2   : Width of PMOS cascode transistor M2. Controls cascode behavior on the PMOS side; L fixed at 45 nm.
# w_M3   : Width of PMOS current-source transistor M3 (tail PMOS). Controls tail current and output impedance; L fixed at 180 nm.
#
# Vb_n   : DC gate bias applied to NMOS cascode (M4). Tunes cascode Vgs/Vds and headroom. Range kept conservative (0.8–1.2× original) and capped at Vdd=1.2V.
# Vb_p   : DC gate bias applied to PMOS cascode (M2). Tunes PMOS cascode operation; conservative range around original.
# VbiasI : DC gate bias for PMOS current-source (M3). Tunes tail current level; conservative range around original.
#
# Notes:
# - Vdd is fixed at 1.2 V (not parameterized).
# - Vin is fixed at the original DC bias (0.8 V) and should be swept externally during DC analysis to find operating points.
# - Only transistor widths are varied by the optimizer; lengths are fixed per original netlist (45 nm or 180 nm as specified).
# - No resistors or capacitors were present in the original netlist; hence none are parameterized. If you add resistors/caps later, follow the requested multiplier ranges.
