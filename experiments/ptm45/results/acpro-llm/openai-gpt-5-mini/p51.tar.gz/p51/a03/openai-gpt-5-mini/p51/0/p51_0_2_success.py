from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Cascoded CS Amplifier - Fixed Biases')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias sources (operate at DC operating point only)
# Adjusted bias voltages to ensure transistors are turned on and in proper regions:
circuit.V('in', 'Vin', circuit.gnd, 0.8)     # Input DC bias (stronger Vgs for M1)
circuit.V('bn', 'Vb_n', circuit.gnd, 1.10)   # NMOS cascode gate bias (close to Vdd to turn cascode on)
circuit.V('bp', 'Vb_p', circuit.gnd, 0.20)   # PMOS cascode gate bias (low to turn PMOS cascode on)
circuit.V('bi', 'VbiasI', circuit.gnd, 0.20) # PMOS current-source gate bias (low to create tail current)
# Nodes:
# - 'Nmid' : between input NMOS drain and NMOS cascode source
# - 'Vp'   : between PMOS current-source drain and PMOS cascode source
# - 'Vout' : amplifier output node
# Transistor sizing (45 nm technology)
L_min = 45e-9
# Input transistor (NMOS): main transconductor
# drain, gate, source, bulk
circuit.MOSFET('M1', 'Nmid', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L_min)
# NMOS cascode transistor (bulk tied to its source 'Nmid')
# drain, gate, source, bulk
circuit.MOSFET('M4', 'Vout', 'Vb_n', 'Nmid', 'Nmid',
               model='nmos_model', w=6e-6, l=L_min)
# PMOS cascode transistor (bulk tied to its source 'Vp')
# drain, gate, source, bulk
circuit.MOSFET('M2', 'Vout', 'Vb_p', 'Vp', 'Vp',
               model='pmos_model', w=10e-6, l=L_min)
# PMOS current-source transistor (source = Vdd, bulk = Vdd)
# drain, gate, source, bulk
circuit.MOSFET('M3', 'Vp', 'VbiasI', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=180e-9)
# Create the simulator (stop here per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
