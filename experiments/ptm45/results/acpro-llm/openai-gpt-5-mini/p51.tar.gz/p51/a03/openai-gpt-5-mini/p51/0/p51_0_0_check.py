from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Cascoded CS Amplifier')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias sources (operate at DC operating point only)
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('bn', 'Vb_n', circuit.gnd, 0.42)    # NMOS cascode gate bias
circuit.V('bp', 'Vb_p', circuit.gnd, 0.78)    # PMOS cascode gate bias (~ Vdd - Vth - 0.2)
circuit.V('bi', 'VbiasI', circuit.gnd, 0.78)  # PMOS current-source gate bias
# Nodes:
# - 'Nmid' : between input NMOS drain and NMOS cascode source
# - 'Vp'   : between PMOS current-source drain and PMOS cascode source
# - 'Vout' : amplifier output node
# Transistor sizing (45 nm technology)
L_min = 45e-9
# Input transistor (NMOS): main transconductor
circuit.MOSFET('M1', 'Nmid', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L_min)
# NMOS cascode transistor
circuit.MOSFET('M4', 'Vout', 'Vb_n', 'Nmid', circuit.gnd,
               model='nmos_model', w=6e-6, l=L_min)
# PMOS cascode transistor
circuit.MOSFET('M2', 'Vout', 'Vb_p', 'Vp', 'Vp',
               model='pmos_model', w=10e-6, l=L_min)
# PMOS current-source transistor (longer channel for higher ro)
circuit.MOSFET('M3', 'Vp', 'VbiasI', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=180e-9)
# Create the simulator (stop here per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p51/0/p51_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)