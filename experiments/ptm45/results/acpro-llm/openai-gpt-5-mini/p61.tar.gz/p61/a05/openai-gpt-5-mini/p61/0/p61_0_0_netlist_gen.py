from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
# Define transistor models using provided parameter dictionaries
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)        # Vin DC operating point = Vth + 0.20 = 0.42 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78) # PMOS bias to set current sources (1.2 - 0.22 - 0.20)
# Internal node
# n1: drain of first stage, gate of second stage
# Vout: output node
# First stage: common-source NMOS (M1) with PMOS active load (M2)
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=8e-6, l=0.045e-6)
circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Second stage: common-source NMOS (M3) with PMOS active load (M4)
circuit.MOSFET('M3', 'Vout', 'n1', circuit.gnd, circuit.gnd, model='nmos_model', w=12e-6, l=0.045e-6)
circuit.MOSFET('M4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=0.045e-6)
# Optional small load to define output DC path (keeps Vout node well-defined).
# Use a large resistor to Vdd so DC operating point is still dominated by active loads.
circuit.R('load', 'Vout', 'Vdd', 10@u_MOhm)
# End: create simulator for operating point / further analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
