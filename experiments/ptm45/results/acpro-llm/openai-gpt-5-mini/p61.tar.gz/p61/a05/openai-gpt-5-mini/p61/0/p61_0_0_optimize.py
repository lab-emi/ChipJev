from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: The model import is required by the optimization environment and
# must appear exactly as written inside create_circuit (per spec).
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
    # Attach transistor models (uses provided parameter dicts)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (45nm)
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Vin fixed for operating point sweeps
    # Parameterized bias voltage (subject to optimization, constrained <= 1.2 V)
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p'])
    # Process length (fixed for this technology)
    L = 0.045e-6  # 45 nm (kept constant; only W affects device behavior)
    # First stage: common-source NMOS (M1) with PMOS active load (M2)
    circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=L)
    # Second stage: common-source NMOS (M3) with PMOS active load (M4)
    circuit.MOSFET('M3', 'Vout', 'n1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L)
    circuit.MOSFET('M4', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)
    # Optional large load resistor to Vdd to define DC path (parameterized)
    # Value is in ohms
    circuit.R('load', 'Vout', 'Vdd', params['r_load'])
    return circuit
# ---------------------------
# Optimization parameter search ranges (annotated)
# ---------------------------
# Process length (L) used to compute W ranges: L = 45e-9 (45 nm)
L_val = 45e-9
min_W = 1 * L_val           # minimum W = 1 * L
max_W = 500 * L_val         # maximum W = 500 * L
param_ranges_definition = {
    # Transistor widths (meters). Range: 1×L .. 500×L (log scale recommended)
    # Initial values are the original widths from the provided netlist.
    'w_M1': {'min': min_W, 'max': max_W, 'log': True},  # M1 width (NMOS) original = 8e-6 m
    'w_M2': {'min': min_W, 'max': max_W, 'log': True},  # M2 width (PMOS) original = 20e-6 m
    'w_M3': {'min': min_W, 'max': max_W, 'log': True},  # M3 width (NMOS) original = 12e-6 m
    'w_M4': {'min': min_W, 'max': max_W, 'log': True},  # M4 width (PMOS) original = 25e-6 m
    # Bias voltages (volts). Per spec: 0.8-1.2× original, but never exceeding 1.2 V.
    # Original v_bias_p = 0.78 V -> allowed range 0.78*0.8 = 0.624 .. 0.78*1.2 = 0.936 (<=1.2)
    'v_bias_p': {'min': max(0.78 * 0.8, 0.0), 'max': min(0.78 * 1.2, 1.2), 'log': False},
    # Resistances (ohms). Range: 0.5-2× original.
    # Original r_load = 10 MΩ -> allowed range 5e6 .. 20e6 ohm
    'r_load': {'min': 10e6 * 0.5, 'max': 10e6 * 2.0, 'log': True},
}
# ---------------------------
# Initial parameter values (EXACT original circuit values - DO NOT MODIFY)
# These are the starting points for optimization and must exactly match the
# original netlist values present in the provided circuit code.
# ---------------------------
initial_params = {
    # Transistor widths (exact values from original code)
    'w_M1': 8e-6,    # M1 width (NMOS) original
    'w_M2': 20e-6,   # M2 width (PMOS) original
    'w_M3': 12e-6,   # M3 width (NMOS) original
    'w_M4': 25e-6,   # M4 width (PMOS) original
    # Bias voltage (exact original)
    'v_bias_p': 0.78,  # Vbias_p original
    # Load resistor (exact original)
    'r_load': 10e6,    # 10 MOhm (original value)
}
# ---------------------------
# Brief description of each parameter (physical meaning)
# ---------------------------
param_descriptions = {
    'w_M1': 'Width of first-stage NMOS (M1). Controls M1 current capability and gm. Units: meters.',
    'w_M2': 'Width of PMOS active-load device for first stage (M2). Controls current and load resistance. Units: meters.',
    'w_M3': 'Width of second-stage NMOS (M3). Controls second-stage gain and output drive. Units: meters.',
    'w_M4': 'Width of PMOS active-load device for second stage (M4). Controls current and load resistance. Units: meters.',
    'v_bias_p': 'PMOS bias voltage that sets the current source gate for PMOS loads. Constrained to remain conservative around original value and <= 1.2 V.',
    'r_load': 'Optional large resistor from Vout to Vdd to define DC path. Kept large to avoid altering AC behavior significantly. Units: ohms.',
}
# Note:
# - Vdd and Vin are intentionally NOT parameterized (kept fixed) per requirements.
# - The process length L is fixed at 45 nm in the circuit; only widths are optimized (W/L changes).
# - There were no explicit capacitors in the original netlist; any load capacitors should remain fixed
#   and are NOT included in the parameter search (per instructions).
