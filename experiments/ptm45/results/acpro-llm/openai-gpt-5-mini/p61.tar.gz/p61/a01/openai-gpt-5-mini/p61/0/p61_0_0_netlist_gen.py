from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
# Define MOSFET models from provided parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)          # Vin DC bias (Vth + 0.20) = 0.42 V
circuit.V('bias1', 'Vbias1', circuit.gnd, 0.78)    # PMOS bias for M2 (Vdd - |Vth| - 0.2)
circuit.V('bias2', 'Vbias2', circuit.gnd, 0.78)    # PMOS bias for M4 (same)
# Node names:
# N1 - inter-stage node (drain of M1 / gate of M3)
# Vout - final output node (drain of M3 / drain of M4)
# Device geometry choices (45 nm node)
L_min = 0.045e-6   # 45 nm expressed in meters
# Stage 1: Input NMOS M1 (common-source) with PMOS active load M2
# M1: drain=N1, gate=Vin, source=gnd, bulk=gnd
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L_min)
# M2: PMOS current-source load: drain=N1, gate=Vbias1, source=Vdd, bulk=Vdd
circuit.MOSFET('M2', 'N1', 'Vbias1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L_min)
# Stage 2: NMOS M3 (common-source) with PMOS active load M4
# M3: drain=Vout, gate=N1, source=gnd, bulk=gnd
circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=6e-6, l=L_min)
# M4: PMOS current-source load: drain=Vout, gate=Vbias2, source=Vdd, bulk=Vdd
circuit.MOSFET('M4', 'Vout', 'Vbias2', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=L_min)
# No explicit resistor loads or feedback networks are used to avoid static power waste
# and to prevent positive feedback paths. The input and output node names requested
# are present: 'Vin' and 'Vout'.
# Create simulator object (do not add extra code below this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
