from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
    # MOS device models (provided by environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed Vdd = 1.2 V (do not include in params)
    # Input voltage (fixed, swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # fixed Vin = 0.42 V (do not include in params)
    # Other bias voltages are parameterized (but constrained not to exceed 1.2 V)
    circuit.V('bias1', 'Vbias1', circuit.gnd, params['v_bias1'])
    circuit.V('bias2', 'Vbias2', circuit.gnd, params['v_bias2'])
    # Technology length (fixed 45 nm)
    L_min = 0.045e-6  # 45 nm (fixed, not part of optimization)
    # Stage 1: Input NMOS M1 (common-source) with PMOS active load M2
    # M1: drain=N1, gate=Vin, source=gnd, bulk=gnd
    circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L_min)
    # M2: PMOS current-source load: drain=N1, gate=Vbias1, source=Vdd, bulk=Vdd
    circuit.MOSFET('M2', 'N1', 'Vbias1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=L_min)
    # Stage 2: NMOS M3 (common-source) with PMOS active load M4
    # M3: drain=Vout, gate=N1, source=gnd, bulk=gnd
    circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L_min)
    # M4: PMOS current-source load: drain=Vout, gate=Vbias2, source=Vdd, bulk=Vdd
    circuit.MOSFET('M4', 'Vout', 'Vbias2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L_min)
    # Note: There were no explicit resistors or capacitors in the original netlist.
    # Load/compensation caps (if added externally) should be treated per instructions:
    # - Load capacitors remain fixed and are NOT part of the search.
    return circuit
