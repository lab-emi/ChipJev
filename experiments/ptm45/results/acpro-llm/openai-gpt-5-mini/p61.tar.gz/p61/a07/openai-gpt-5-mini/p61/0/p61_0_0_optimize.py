from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
# EXACT original values from the provided netlist (must be unchanged)
initial_params = {
    'w_M1': 20e-6,   # original M1 width
    'w_M2': 40e-6,   # original M2 width (note: exceeds 500×L; range was expanded to include it)
    'w_M3': 10e-6,   # original M3 width
    'w_M4': 20e-6,   # original M4 width
    'Vbias': 0.78,   # original PMOS gate bias
}
