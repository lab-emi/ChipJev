```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Two-Stage GBW/Power-Optimized Amplifier')

    # MOSFET models provided externally (model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and input supplies (fixed per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd fixed at 1.2 V (do not parameterize)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)     # Vin fixed at 0.42 V (swept externally)

    # Parameterized bias voltage (other voltages must be parameterized, within 0.8-1.2x original)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])  # original = 0.78 V

    # Fixed channel length for 45 nm process
    L = 45e-9

    # Stage 1: Common-source NMOS (M1) with PMOS active load (M2)
    circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'N1', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)

    # Stage 2: Common-source NMOS (M3) with PMOS active load (M4)
    circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M3'],
                   l=L)
    circuit.MOSFET('M4', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    return circuit
```

Optimization parameter search ranges (param_ranges_definition)
```python
# Note on W ranges:
# - Recommended W range is 1×L .. 500×L (L = 45e-9 => 45e-9 .. 22.5e-6).
# - The original w_M2 = 40e-6 is larger than 500×L (40e-6 > 22.5e-6). To satisfy the
#   requirement that initial_params remain EXACT and inside the ranges, w_M2's upper bound
#   is set to the original value (40e-6). This is an explicit accommodation of the original
#   netlist; all other transistor widths obey the 1..500×L bound.
param_ranges_definition = {
    # Transistor widths (meters). Sampling log-scale is often useful for sizes over orders of magnitude.
    'w_M1': {'min': 1 * 45e-9, 'max': 500 * 45e-9, 'log': True},         # original 20e-6 (within 1..500×L)
    'w_M2': {'min': 1 * 45e-9, 'max': max(500 * 45e-9, 40e-6), 'log': True},  # original 40e-6 (exceeds 500×L)
    'w_M3': {'min': 1 * 45e-9, 'max': 500 * 45e-9, 'log': True},         # original 10e-6
    'w_M4': {'min': 1 * 45e-9, 'max': 500 * 45e-9, 'log': True},         # original 20e-6

    # Bias voltage ranges: 0.8 - 1.2 × original, but never exceed 1.2 V (supply).
    # Original Vbias = 0.78 V -> range = [0.624, 0.936] (0.936 < 1.2 so OK).
    'Vbias': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
}
```

Initial parameter values (initial_params)
```python
# EXACT original values from the provided netlist (must be unchanged)
initial_params = {
    'w_M1': 20e-6,   # original M1 width
    'w_M2': 40e-6,   # original M2 width (note: exceeds 500×L; range was expanded to include it)
    'w_M3': 10e-6,   # original M3 width
    'w_M4': 20e-6,   # original M4 width
    'Vbias': 0.78,   # original PMOS gate bias
}
```

Brief description of each parameter and physical meaning
- w_M1 (meters): Channel width of input NMOS M1. Controls transconductance (gm), input stage gain, and device current capability. Fixed L = 45 nm; optimization adjusts W to tune gm/I and gain/bandwidth trade-offs.
- w_M2 (meters): Channel width of PMOS active-load M2 (stage 1). Sets current sourcing capability and output resistance of the active load; influences DC bias and small-signal gain. Original value (40e-6) is larger than 500×L; the search upper bound was extended to include the original value to preserve the exact initial point.
- w_M3 (meters): Channel width of second-stage NMOS M3. Affects second-stage gain, output drive and GBW.
- w_M4 (meters): Channel width of PMOS active-load M4 (stage 2). Affects stage-2 biasing and output resistance.
- Vbias (volts): DC gate bias applied to PMOS loads (M2, M4). Adjusting Vbias moves the PMOS operating points and therefore the tail currents and DC operating point of both stages. Range constrained to 0.8–1.2× original (and capped at the 1.2 V supply).

Notes and compliance with your requirements
- The function is named create_circuit as required.
- The line "from model import nmos_params, pmos_params" is included exactly as written inside create_circuit.
- Vdd remains fixed at 1.2 V and is not parameterized.
- Vin is fixed at 0.42 V and is not parameterized (it will be swept externally).
- All transistor lengths are fixed at L = 45e-9 (45 nm). Only widths (W) are parameterized.
- All other parameterization rules were followed:
  - Voltage sources (only Vbias here) use 0.8–1.2× original and do not exceed 1.2 V.
  - Transistor W ranges are nominally limited to 1–500×L; w_M2's upper bound was expanded to include the original value (40e-6) so that initial_params remains exactly the same as the original netlist.
- There were no resistors or capacitors in the original netlist; therefore none were parameterized. If you add resistors or capacitors later, apply the requested scaling rules:
  - Resistances: 0.5–2× original
  - Critical compensation caps: 0.5–5× original
  - Other caps: 0.8–1.5× original
- All initial_params entries are inside the declared param_ranges_definition.
- Vth = 0.22 V was considered when selecting bias ranges; the lower bias bound (0.624 V) leaves PMOS devices biased well in the intended region and is conservative.

If you prefer strict enforcement of the 1–500×L constraint (i.e., disallow the expanded upper bound for w_M2 = 40e-6), I can adjust the ranges accordingly — but that will make the exact original initial_params fall outside the specified search range.