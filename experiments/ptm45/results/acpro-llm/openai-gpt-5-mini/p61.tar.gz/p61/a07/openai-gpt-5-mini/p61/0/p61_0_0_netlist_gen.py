from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage GBW/Power-Optimized Amplifier')
# Define MOSFET models (assumed provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)     # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)    # Vin DC bias for operating point (Vth + 0.2)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78) # PMOS gate bias (Vdd - |Vth| - 0.2)
# Node names:
#   Vin  - input node (provided by source above)
#   N1   - inter-stage node (drain of M1, input to M3)
#   Vout - output node (drain of M3)
# Stage 1: Common-Source NMOS (M1) with PMOS current-source load (M2)
# MOSFET order: name, drain, gate, source, bulk, model, w=..., l=...
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=45e-9)   # Input transconductor (large W for gm/I)
circuit.MOSFET('M2', 'N1', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=45e-9)  # PMOS active load (stage 1)
# Stage 2: Common-Source NMOS (M3) with PMOS current-source load (M4)
circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=45e-9)  # Second-stage transconductor
circuit.MOSFET('M4', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=45e-9)  # PMOS active load (stage 2)
# End of topology; ready for operating point / AC analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
