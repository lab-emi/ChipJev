from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier')
# Models (assumed to exist in the imported model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('biasP', 'VbiasP', circuit.gnd, 0.78)  # PMOS bias = Vdd - |Vth| - 0.2 = 0.78 V
# Device geometry (45 nm technology): L = 45 nm = 0.045e-6 m
L = 0.045e-6
# Stage 1: Common-source NMOS (input) with PMOS active-load current source
# M1: drain = N1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model', w=2e-6, l=L)
# M2: PMOS active load for stage1: drain = N1, gate = VbiasP, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'N1', 'VbiasP', 'Vdd', 'Vdd',
                model='pmos_model', w=6e-6, l=L)
# Stage 2: Common-source NMOS with PMOS active-load
# M3: drain = N2, gate = N1, source = gnd, bulk = gnd
circuit.MOSFET('M3', 'N2', 'N1', circuit.gnd, circuit.gnd,
                model='nmos_model', w=3e-6, l=L)
# M4: PMOS active load for stage2: drain = N2, gate = VbiasP, source = Vdd, bulk = Vdd
circuit.MOSFET('M4', 'N2', 'VbiasP', 'Vdd', 'Vdd',
                model='pmos_model', w=8e-6, l=L)
# Stage 3 (output): Common-source NMOS with resistor load to Vdd
# M5: drain = Vout, gate = N2, source = gnd, bulk = gnd
circuit.MOSFET('M5', 'Vout', 'N2', circuit.gnd, circuit.gnd,
                model='nmos_model', w=8e-6, l=L)
# Output resistor R1 from Vout to Vdd (loads the final stage, sets DC level)
circuit.R('1', 'Vout', 'Vdd', 50@u_kΩ)
# End of circuit description; a simulator can be instantiated as requested
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)