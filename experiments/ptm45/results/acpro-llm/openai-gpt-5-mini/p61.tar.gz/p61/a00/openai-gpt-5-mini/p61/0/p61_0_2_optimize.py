from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact originals)
    'w_M1': 4e-6,    # original M1 width
    'w_M2': 12e-6,   # original M2 width
    'w_M3': 6e-6,    # original M3 width
    'w_M4': 12e-6,   # original M4 width
    'w_M5': 12e-6,   # original M5 width
    # Bias voltage (exact original)
    'V_biasP': 0.78,  # original biasP value
    # Resistor (exact original, unit-aware)
    'r_R1': 5 @ u_kΩ,  # original R('1', 'Vout', 'Vdd', 5@u_kΩ)
}
