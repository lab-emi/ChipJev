from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
# MOSFET models (from provided model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)     # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)    # Vin DC bias for operating point (Vth + Vov ~ 0.42 V)
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)    # PMOS gate bias for active load (~0.78 V)
# Devices (MOSFET ordering: name, drain, gate, source, bulk, model, w=, l=)
# Stage 1: Input common-source (M1) with PMOS active current-source load (M2)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model', w=3e-6, l=0.045e-6)
circuit.MOSFET('M2', 'N1', 'Vbp', 'Vdd', 'Vdd',
                model='pmos_model', w=10e-6, l=0.045e-6)
# Stage 2: Common-source amplifier (M3) with resistive load R1
circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
                model='nmos_model', w=6e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 20@u_kΩ)
# End of netlist; ready for simulator
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
