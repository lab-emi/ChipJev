from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Two-Stage GBW/Power Optimized Amplifier circuit.
    The function expects a params dictionary with keys:
      - w_M1, w_M2, w_M3 : transistor widths in meters
      - v_bp              : PMOS bias voltage in volts
      - r_R1              : load resistor value in kOhm (float, kΩ)
    L (channel length) is kept fixed to the original design value.
    Vdd and Vin remain fixed as required.
    """
    # Fixed process length (original netlist value)
    L = 0.045e-6  # 45 nm (exact original numeric value)
    circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
    # MOSFET models (from provided model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and bias sources
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)     # Vdd = 1.2 V (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)    # Vin DC bias (fixed, swept externally)
    # PMOS gate bias (parameterized; constrained in ranges so never exceeds 1.2V)
    circuit.V('bp', 'Vbp', circuit.gnd, params['v_bp'])
    # Devices (MOSFET ordering: name, drain, gate, source, bulk, model, w=, l=)
    circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'N1', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=L)
    circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L)
    # Load resistor - parameter given in kΩ to keep human-readable scaling
    # Convert to NGSpice-readable string with "k" suffix
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_R1']}k")
    # No explicit capacitors in the original netlist; if present they would be handled as fixed values
    return circuit
# Optimization parameter search ranges (annotated)
# NOTES:
# - L is fixed at 0.045e-6 (45 nm). W ranges are 1xL .. 500xL as required.
# - All voltages (except Vdd and Vin which are fixed) are constrained to 0.8..1.2× original,
#   but never exceeding 1.2 V (supply). The original Vbp=0.78 V => range [0.624, 0.936] V.
# - Resistor ranges follow 0.5..2× the original (original R1 = 20 kΩ => [10, 40] kΩ).
param_ranges_definition = {
    # Transistor widths (meters): 1×L .. 500×L (log-space sampling recommended)
    'w_M1': {
        'min': 0.045e-6,               # L (1×L)
        'max': 0.045e-6 * 500.0,       # 500×L = 22.5e-6
        'log': True
    },
    'w_M2': {
        'min': 0.045e-6,
        'max': 0.045e-6 * 500.0,
        'log': True
    },
    'w_M3': {
        'min': 0.045e-6,
        'max': 0.045e-6 * 500.0,
        'log': True
    },
    # Bias voltages (V): 0.8..1.2× original, but capped at <= 1.2 V (linear sampling)
    'v_bp': {
        'min': max(0.78 * 0.8, 0.0),   # 0.624 V
        'max': min(0.78 * 1.2, 1.2),   # 0.936 V (does not exceed 1.2V)
        'log': False
    },
    # Resistive loads: 0.5..2× original (units in kΩ for convenience)
    'r_R1': {
        'min': 20.0 * 0.5,             # 10 kΩ
        'max': 20.0 * 2.0,             # 40 kΩ
        'log': True
    },
    # (No capacitors present in the original netlist to parameterize.
    #  If compensation caps existed they'd be 0.5..5× original, but there are none.)
}
# Initial parameter values (EXACT original circuit values; MUST match the original netlist)
initial_params = {
    # Transistor widths (exact original values in meters)
    'w_M1': 3e-6,    # Original M1 width
    'w_M2': 10e-6,   # Original M2 width
    'w_M3': 6e-6,    # Original M3 width
    # Bias voltage (exact original)
    'v_bp': 0.78,    # Original PMOS gate bias
    # Load resistor (exact original, given in kΩ to match how it's used in create_circuit)
    'r_R1': 20.0     # Original R1 = 20 kΩ
}
# Short descriptions of each parameter (physical meaning)
param_descriptions = {
    'w_M1': 'M1 transistor gate width (meters). Sets M1 current drive and gm; L fixed at 45nm.',
    'w_M2': 'M2 (PMOS active load) gate width (meters). Controls load current/impedance; L fixed.',
    'w_M3': 'M3 transistor gate width (meters). Second-stage driver width; L fixed at 45nm.',
    'v_bp': 'PMOS gate bias voltage (volts) that sets the active-load current/source point. '
            'Constrained to 0.8–1.2× original but ≤ 1.2V to keep device in intended region.',
    'r_R1': 'Resistive load R1 (kΩ). Determines second-stage load; given in kΩ when constructing the circuit.'
}
