from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier - Fixed')
# Define MOSFET models (from provided model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.80)     # Vin DC bias = 0.80 V (raised to help bias N2)
circuit.V('bp', 'Vbiasp', circuit.gnd, 0.83)  # PMOS gate bias ~ Vdd - (Vth + margin)
# Technology sizing (45 nm)
L = 45e-9  # 45 nm
# Stage 1: Common-source NMOS (M1) with PMOS active load (M2)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)         # M1: input NMOS
circuit.MOSFET('M2', 'N1', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)       # M2: PMOS active load
# Stage 2: Common-source NMOS (M4) with PMOS active load (M5)
circuit.MOSFET('M4', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)        # M4: second-stage NMOS
circuit.MOSFET('M5', 'N2', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=30e-6, l=L)       # M5: PMOS active load
# Stage 3: Source-follower buffer (M6) to drive Vout
# Drain tied to Vdd, gate driven by N2, source is Vout (bulk connected to source)
circuit.MOSFET('M6', 'Vdd', 'N2', 'Vout', 'Vout',
               model='nmos_model', w=20e-6, l=L)        # M6: source follower
# Pull-down resistor at Vout to establish proper DC operating point (ensures Vout < N2 at DC)
# High value to minimize DC power consumption while preventing Vout from floating to Vdd.
circuit.R('pull', 'Vout', circuit.gnd, 1@u_MOhm)
# End: create simulator (no extra code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
