from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier - Fixed')
# Define MOSFET models (from provided model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.80 ac 1n")
circuit.V('bp', 'Vbiasp', circuit.gnd, 0.83)  # PMOS gate bias ~ Vdd - (Vth + margin)
# Technology sizing (45 nm)
L = 45e-9  # 45 nm
# Stage 1: Common-source NMOS (M1) with PMOS active load (M2)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)         # M1: input NMOS
circuit.MOSFET('M2', 'N1', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)       # M2: PMOS active load
# Stage 2: Common-source NMOS (M4) with PMOS active load (M5)
circuit.MOSFET('M4', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)        # M4: second-stage NMOS
circuit.MOSFET('M5', 'N2', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=30e-6, l=L)       # M5: PMOS active load
# Stage 3: Source-follower buffer (M6) to drive Vout
# Drain tied to Vdd, gate driven by N2, source is Vout (bulk connected to source)
circuit.MOSFET('M6', 'Vdd', 'N2', 'Vout', 'Vout',
               model='nmos_model', w=20e-6, l=L)        # M6: source follower
# Pull-down resistor at Vout to establish proper DC operating point (ensures Vout < N2 at DC)
# High value to minimize DC power consumption while preventing Vout from floating to Vdd.
circuit.R('pull', 'Vout', circuit.gnd, 1@u_MOhm)
# End: create simulator (no extra code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)