from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier')
# Define MOSFET models (external model parameters provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Bias source for the PMOS active load (use Vth = 0.22 V per instructions)
# Vbias = Vdd - (Vth + 0.2) = 1.2 - (0.22 + 0.2) = 0.78 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)
# Input DC bias (operating point). No AC source per instructions.
# Choose Vin to bias the input NMOS gate so it operates in conduction (e.g., ~0.6 V)
circuit.V('in', 'Vin', circuit.gnd, 0.6)
# Node naming:
# int1: drain of first stage (stage1 output, stage2 input)
# Vout_pre: drain of second stage (internal node driving buffer)
# Vout: final external output (source follower output)
# Transistor dimensions (45 nm technology: L = 0.045e-6 m)
L_min = 0.045e-6
# Stage 1: common-source NMOS (M1) with PMOS active current-source load (M2)
# M1: drain=int1, gate=Vin, source=ground, bulk=ground
circuit.MOSFET('M1', 'int1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=L_min)
# M2: PMOS current source: drain=int1, gate=Vbias, source=Vdd, bulk=Vdd
circuit.MOSFET('M2', 'int1', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=L_min)
# Stage 2: common-source NMOS (M3) with resistor load R1
# M3: drain=Vout_pre, gate=int1, source=ground, bulk=ground
circuit.MOSFET('M3', 'Vout_pre', 'int1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=L_min)
# R1: load resistor from Vout_pre to Vdd (sets small DC current to limit power)
circuit.R('1', 'Vout_pre', 'Vdd', 50@u_kΩ)
# Stage 3: source-follower buffer (M4) to drive external output and isolate Vout_pre
# M4: drain=Vdd, gate=Vout_pre, source=Vout, bulk tied to source (per instruction)
circuit.MOSFET('M4', 'Vdd', 'Vout_pre', 'Vout', 'Vout',
               model='nmos_model', w=8e-6, l=L_min)
# Ensure input and output node names appear in the circuit
# (Vin and Vout already present because of the sources and device connections)
# Create simulator (no further code after this)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
