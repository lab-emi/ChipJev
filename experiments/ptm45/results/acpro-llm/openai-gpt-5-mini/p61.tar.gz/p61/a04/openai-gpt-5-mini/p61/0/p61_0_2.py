from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier - Fixed OP')
# Define MOSFET models (external model parameters provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Bias source for the PMOS active load (use Vth = 0.22 V per instructions)
# Vbias = Vdd - (Vth + 0.2) = 1.2 - (0.22 + 0.2) = 0.78 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)
# Input DC bias (operating point). Increased to ensure sufficient drive for the stages.
circuit.V('in', 'Vin', circuit.gnd, 0.8)
# Node naming:
# int1: drain of first stage (stage1 output, stage2 input)
# Vout_pre: drain of second stage (internal node driving buffer)
# Vout: final external output (source follower output)
# Transistor dimensions (45 nm technology: L = 0.045e-6 m)
L_min = 0.045e-6
# Stage 1: common-source NMOS (M1) with PMOS active current-source load (M2)
circuit.MOSFET('M1', 'int1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=L_min)
circuit.MOSFET('M2', 'int1', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=L_min)
# Stage 2: common-source NMOS (M3) with resistor load R1
circuit.MOSFET('M3', 'Vout_pre', 'int1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=L_min)
# Reduce R1 to provide a stronger pull-up so Vout_pre is sufficiently high to turn M4 on
circuit.R('1', 'Vout_pre', 'Vdd', 10@u_kΩ)
# Stage 3: source-follower buffer (M4) to drive external output and isolate Vout_pre
# Bulk tied to source (Vout) per instruction
circuit.MOSFET('M4', 'Vdd', 'Vout_pre', 'Vout', 'Vout',
               model='nmos_model', w=8e-6, l=L_min)
# Weak pulldown on Vout to establish a defined starting source potential,
# but not so strong as to prevent M4 from turning on once the gate is high.
circuit.R('2', 'Vout', circuit.gnd, 100@u_kΩ)
# Create simulator (no further code after this)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
