from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier')
# MOS models (from provided model parameters)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)         # Vin bias = Vth + 0.2 = 0.42 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)     # PMOS bias ≈ Vdd - |Vth| - 0.2 = 0.78 V
# Stage 1: Common-Source NMOS (M1) with PMOS active load (M2)
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Vmid', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=0.045e-6)   # Input transconductor
circuit.MOSFET('M2', 'Vmid', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=0.045e-6)  # Active current-source load
# Stage 2: Common-Source NMOS (M3) driving Vout, with resistive pull-up R1
circuit.MOSFET('M3', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
               model='nmos_model', w=6e-6, l=0.045e-6)   # Second stage amplifier
circuit.R('1', 'Vout', 'Vdd', 10@u_kΩ)               # Load resistor on output
# Simulator setup
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
