from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    # Keep this import exactly as requested; the model dicts are provided externally.
    from model import nmos_params, pmos_params
    circuit = Circuit('Multi-Stage GBW/Power Optimized Amplifier')
    # MOS models (from provided model parameters)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd fixed at 1.2 V (not in search)
    # Input voltage (fixed, to be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)         # Vin fixed at 0.42 V (not in search)
    # Bias supply (parameterized; range enforced outside to be within 0.8-1.2× original and <=1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['V_bias'])
    # Fixed device channel length (45 nm process)
    L_fixed = 0.045e-6  # 45 nm in meters (kept constant; only W is optimized)
    # Stage 1: Common-Source NMOS (M1) with PMOS active load (M2)
    # Note: Use the same naming/ordering as the original netlist
    circuit.MOSFET('M1', 'Vmid', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)
    circuit.MOSFET('M2', 'Vmid', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_fixed)
    # Stage 2: Common-Source NMOS (M3) driving Vout, with resistive pull-up R1
    circuit.MOSFET('M3', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M3'],
                   l=L_fixed)
    # Load resistor - parameterized (value given in kΩ in params)
    # Convert to kΩ string accepted by PySpice/NgSpice (e.g. "10k")
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_R1']}k")
    # No load capacitors or compensation capacitors present in the original netlist.
    # If you add caps later, follow the stated rules: C_load must remain fixed unless explicitly allowed.
    return circuit
# Optimization parameter search ranges (annotated)
# All ranges chosen according to the requirements in the prompt:
# - Width W: 1×L to 500×L (L = 45 nm = 0.045e-6 m)
# - Voltage sources (except Vdd and Vin) : 0.8-1.2× original, capped at 1.2 V
# - Resistors: 0.5-2× original
# Use 'log': True where a wide dynamic range is sensible (transistor widths and resistor).
param_search_space = {
    # Transistor widths (meters). L_fixed = 0.045e-6 m -> W range = [45e-9, 22.5e-6]
    'w_M1': {'min': 0.045e-6, 'max': 0.045e-6 * 500, 'log': True},  # M1 original: 4e-6
    'w_M2': {'min': 0.045e-6, 'max': 0.045e-6 * 500, 'log': True},  # M2 original: 8e-6
    'w_M3': {'min': 0.045e-6, 'max': 0.045e-6 * 500, 'log': True},  # M3 original: 6e-6
    # Bias voltage Vbias: 0.8 - 1.2 × original (0.78 V) but never exceed 1.2 V
    # 0.8*0.78 = 0.624 V, 1.2*0.78 = 0.936 V (both <= 1.2 V)
    'V_bias': {'min': 0.624, 'max': 0.936, 'log': False},
    # Load resistor R1 (in kΩ): 0.5 - 2 × original (10 kΩ -> 5 - 20 kΩ)
    'r_R1': {'min': 5.0, 'max': 20.0, 'log': True},  # units: kΩ
}
# Initial parameter values (EXACT original circuit values, MUST NOT BE MODIFIED)
initial_params = {
    # Transistor widths (meters) - exact values from original netlist
    'w_M1': 4e-6,   # M1 original width
    'w_M2': 8e-6,   # M2 original width
    'w_M3': 6e-6,   # M3 original width
    # Bias voltage - exact original value
    'V_bias': 0.78,  # Vbias original
    # Resistor (kΩ) - exact original value
    'r_R1': 10.0,    # R1 original value in kΩ
}
