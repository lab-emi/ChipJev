from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
# Define MOSFET models (parameters provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias sources (no AC signals per requirements)
# Vin DC bias placed at Vth + 0.2 = 0.22 + 0.2 = 0.42 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)
# PMOS gate bias for active load: Vdd - |Vth| - 0.2 = 1.2 - 0.22 - 0.2 = 0.78 V
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)
# Devices (45 nm technology: L = 0.045e-6)
L_min = 0.045e-6
# First stage: Common-source NMOS M1 with PMOS active load M2
# M1: drain = node1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'node1', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model', w=12e-6, l=L_min)
# M2: PMOS active load: drain = node1, gate = Vbp, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'node1', 'Vbp', 'Vdd', 'Vdd',
                model='pmos_model', w=24e-6, l=L_min)
# Second stage: Common-source NMOS M3 with resistor load R1
# M3: drain = Vout, gate = node1, source = gnd, bulk = gnd
circuit.MOSFET('M3', 'Vout', 'node1', circuit.gnd, circuit.gnd,
                model='nmos_model', w=16e-6, l=L_min)
# Resistive load from Vdd to Vout (sets DC output and gives wideband loading)
circuit.R('1', 'Vdd', 'Vout', 2@u_kOhm)
# End of topology; user can run DC/operating point or transient analyses outside this snippet
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p61/0/p61_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
