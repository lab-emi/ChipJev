from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
# Fixed process length for 45 nm technology
L_PROCESS = 0.045e-6  # 45 nm
def create_circuit(params):
    """
    Create the parameterized Two-Stage GBW/Power Optimized Amplifier circuit.
    params: dictionary containing:
      - w_M1, w_M2, w_M3 : transistor widths in meters
      - v_bp              : PMOS gate bias for active load (V)
      - r_R1              : Resistive load value in kOhm (kΩ)
    Note: vdd and Vin are fixed (not parameterized) per requirements.
    """
    circuit = Circuit('Two-Stage GBW/Power Optimized Amplifier')
    # Keep these two import lines as required by execution environment
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V
    # Input voltage (fixed, not parameterized). Will be swept externally.
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Vin fixed at 0.42 V
    # PMOS gate bias for active load - parameterized (but constrained within allowed range)
    circuit.V('bp', 'Vbp', circuit.gnd, params['v_bp'])
    # MOSFET devices (L fixed to process minimum; only W is parameterized)
    # First stage: Common-source NMOS M1 with PMOS active load M2
    circuit.MOSFET('M1', 'node1', 'Vin', circuit.gnd, circuit.gnd,
                    model='nmos_model', w=params['w_M1'], l=L_PROCESS)
    circuit.MOSFET('M2', 'node1', 'Vbp', 'Vdd', 'Vdd',
                    model='pmos_model', w=params['w_M2'], l=L_PROCESS)
    # Second stage: Common-source NMOS M3 with resistor load R1
    circuit.MOSFET('M3', 'Vout', 'node1', circuit.gnd, circuit.gnd,
                    model='nmos_model', w=params['w_M3'], l=L_PROCESS)
    # Resistive load from Vdd to Vout (parameterized, in kΩ)
    # Note: ngspice/PySpice accepts strings like "2k" for resistances.
    circuit.R('1', 'Vdd', 'Vout', f"{params['r_R1']}k")
    return circuit
# -----------------------------
# Optimization parameter search ranges (annotated)
# -----------------------------
# L_PROCESS is 45 nm (0.045e-6 m)
# Width rules: nominal requirement is 1 - 500 × L. To ensure the original
# initial widths (provided by the user) remain inside the ranges, the max is
# set to max(500 * L, original_width). This guarantees the "initial_params"
# (below) are inside the search ranges while still respecting the 1-500×L goal
# where possible.
param_ranges = {
    # Transistor widths (meters)
    # Allowed range: [1 * L_PROCESS, max(500 * L_PROCESS, original_width)]
    'w_M1': {
        'min': 1.0 * L_PROCESS,                         # 1 × L
        'max': max(500.0 * L_PROCESS, 12e-6),          # 500 × L or at least original
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L_PROCESS,
        # Note: original w_M2 = 24e-6 slightly exceeds 500 * L (22.5e-6),
        # so we enlarge the max to include the original initial value.
        'max': max(500.0 * L_PROCESS, 24e-6),
        'log': True
    },
    'w_M3': {
        'min': 1.0 * L_PROCESS,
        'max': max(500.0 * L_PROCESS, 16e-6),
        'log': True
    },
    # PMOS gate bias for active load Vbp (Volts)
    # Per requirement: within 0.8 - 1.2 × original, but never above 1.2 V
    # original v_bp = 0.78 V -> allowed range: [0.8*0.78, min(1.2*0.78, 1.2)]
    # which evaluates to ≈ [0.624, 0.936]. Use linear sampling.
    'v_bp': {
        'min': 0.8 * 0.78,   # 0.624 V
        'max': min(1.2 * 0.78, 1.2),  # 0.936 V (keeps below Vdd)
        'log': False
    },
    # Resistive load R1 (in kilo-Ohms as used in create_circuit)
    # Original is 2 kΩ -> allowed: 0.5 - 2 × original = [1, 4] kΩ
    'r_R1': {
        'min': 0.5 * 2.0,    # 1.0 kΩ
        'max': 2.0 * 2.0,    # 4.0 kΩ
        'log': True
    },
    # Note: There are no compensation or other capacitors defined in the original
    # netlist that need parameterization. Load capacitors (if any) are required
    # to remain fixed per the instructions.
}
# -----------------------------
# Initial parameter values (EXACT original circuit values)
# These values must be preserved exactly as given in the original netlist.
# -----------------------------
initial_params = {
    # Transistor widths (meters) - EXACT original values
    'w_M1': 12e-6,
    'w_M2': 24e-6,
    'w_M3': 16e-6,
    # PMOS gate bias (V) - EXACT original
    'v_bp': 0.78,
    # Resistive load R1 in kΩ - EXACT original
    'r_R1': 2.0,
}
# -----------------------------
# Brief description of each parameter (physical meaning)
# -----------------------------
param_descriptions = {
    'w_M1': "Width of NMOS M1 (first-stage input transistor). W affects gm, current, and device parasitics. L is fixed at 45 nm.",
    'w_M2': "Width of PMOS M2 (active-load device for first stage). Controls load current and output resistance of first stage. L is fixed at 45 nm.",
    'w_M3': "Width of NMOS M3 (second-stage transistor). Affects gain and bandwidth of the second stage. L is fixed at 45 nm.",
    'v_bp': "PMOS active-load gate bias (Vbp). Sets the operating point of the PMOS load, therefore affecting DC output node and available headroom.",
    'r_R1': "Resistive load from Vdd to Vout (in kΩ). Sets DC output bias point and load on the second stage; alters gain/bandwidth and power dissipation.",
}
# sanity check: ensure initial values lie inside the specified ranges (optional)
# This check can be used by the optimization harness before starting.
def _initials_within_ranges():
    for k, v in initial_params.items():
        if k not in param_ranges:
            continue
        r = param_ranges[k]
        if not (r['min'] <= v <= r['max']):
            raise ValueError(f"Initial parameter {k}={v} outside of declared range {r['min']}..{r['max']}")
# run check now (will raise if there's any mismatch)
_initials_within_ranges()
