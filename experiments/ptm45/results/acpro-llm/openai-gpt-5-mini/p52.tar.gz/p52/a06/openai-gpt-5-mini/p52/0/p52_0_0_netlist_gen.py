from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp - Active Mirror Load')
# Define MOSFET models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input DC bias sources (for operating point analysis)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Vinp DC bias ~ common-mode
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Vinn DC bias ~ common-mode
# Tail bias for the NMOS current sink (use Vth = 0.22 V -> Vtail = 0.42 V)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)
# Internal nodes
# Vs: common-source node of the differential pair
# DrainR: drain of the right input transistor and gate of the PMOS mirror
# Vout: output node (drain of left input transistor and PMOS mirror output)
# Differential NMOS input pair
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=10e-6, l=0.045e-6)   # left input transistor
circuit.MOSFET('M2', 'DrainR', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=10e-6, l=0.045e-6)  # right input transistor
# Tail current sink (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# PMOS current mirror load (no cross-coupling)
# M3: diode-connected reference on the right branch (drain = gate = DrainR)
circuit.MOSFET('M3', 'DrainR', 'DrainR', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.12e-6)
# M4: mirror device that loads the left branch (Vout)
circuit.MOSFET('M4', 'Vout', 'DrainR', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.12e-6)
# Create simulator (for operating-point / DC analysis)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
