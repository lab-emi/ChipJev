```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # The external device model import must appear exactly as below (per framework requirement)
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp - Active Mirror Load')

    # Define MOSFET models (provided by external model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V (fixed)

    # Input DC bias sources (fixed, not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # Vinp DC bias ~ common-mode (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)  # Vinn DC bias ~ common-mode (fixed)

    # Tail bias (parameterized)
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])  # Vtail parameter (constrained <= 1.2 V)

    # MOSFETs (lengths kept fixed; only widths are parameterized)
    # NOTE: lengths are the same as in the original netlist and are not included in params
    # NMOS length = 45 nm -> 0.045e-6
    # PMOS length = 120 nm -> 0.12e-6

    # Differential NMOS input pair
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)   # left input transistor

    circuit.MOSFET('M2', 'DrainR', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=0.045e-6)   # right input transistor

    # Tail current sink (NMOS)
    circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=0.045e-6)

    # PMOS current mirror load (diode-connected M3 on right, mirror M4 on left)
    circuit.MOSFET('M3', 'DrainR', 'DrainR', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=0.12e-6)   # diode-connected PMOS reference

    circuit.MOSFET('M4', 'Vout', 'DrainR', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=0.12e-6)   # PMOS mirror device that loads left branch

    return circuit


# Optimization parameter search ranges
# All ranges chosen to satisfy the constraints:
# - W: 1 - 500 × L (L fixed per device)
# - Voltages (except vdd and inputs) within 0.8-1.2× original value and <= 1.2 V
# Note: 'log' indicates that a log-uniform sampling may be preferred for scale parameters like widths.
param_ranges_definition = {
    # Transistor widths (meters). Lengths are fixed in create_circuit().
    # NMOS (L = 45e-9 m): W in [1*L, 500*L] => [45e-9, 22.5e-6]
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},
    'w_Mtail': {'min': 45e-9, 'max': 22.5e-6, 'log': True},

    # PMOS (L = 120e-9 m): W in [1*L, 500*L] => [120e-9, 60e-6]
    'w_M3': {'min': 120e-9, 'max': 60e-6, 'log': True},
    'w_M4': {'min': 120e-9, 'max': 60e-6, 'log': True},

    # Tail bias voltage: original = 0.42 V.
    # Allowed range = 0.8 - 1.2 × original, clipped to <= 1.2 V.
    # 0.8*0.42 = 0.336, 1.2*0.42 = 0.504 -> both <= 1.2 V, so range is [0.336, 0.504]
    'v_tail': {'min': 0.336, 'max': 0.504, 'log': False},
}

# Initial parameter values (EXACT original circuit values; MUST match the original netlist exactly)
initial_params = {
    'w_M1': 10e-6,    # Original width for M1 (10 µm)
    'w_M2': 10e-6,    # Original width for M2 (10 µm)
    'w_Mtail': 2e-6,  # Original width for Mtail (2 µm)
    'w_M3': 20e-6,    # Original width for M3 (20 µm)
    'w_M4': 20e-6,    # Original width for M4 (20 µm)
    'v_tail': 0.42,   # Original tail voltage (0.42 V)
}
```

Parameter descriptions (brief):
- w_M1, w_M2 (m): Widths of the differential NMOS input transistors. Affect transconductance (gm), device current, input-referred noise, and matching.
- w_Mtail (m): Width of the NMOS tail current sink. Controls tail current capability and source degeneration via finite resistance; influences common-source node bias (Vs).
- w_M3, w_M4 (m): Widths of the PMOS mirror devices (diode reference and mirror). Affect mirror current, output resistance of the load, and common-mode swing.
- v_tail (V): Tail bias voltage applied to the gate of the NMOS tail device (Mtail). Tunes tail current (with fixed W/L) and bias point of the differential pair. Range chosen conservatively (0.8–1.2× original) and kept <= 1.2 V.

Notes and rationale:
- L values remain fixed to the original process values (NMOS 45 nm, PMOS 120 nm) because only W/L ratio matters for sizing in this optimization.
- Vdd and Vinp/Vinn remain fixed as requested (Vdd = 1.2 V; Vinp/Vinn = 0.6 V).
- The v_tail search range was computed as 0.8–1.2×0.42 and clipped to be <= 1.2 V; the resulting [0.336, 0.504] V is conservative and remains well above Vth = 0.22 V to keep Mtail in expected operating region.
- There were no resistors or capacitors in the provided netlist to parameterize; any load/comp capacitors should remain fixed per your instruction (none present here).
- All initial parameter values are inside the specified ranges.
```