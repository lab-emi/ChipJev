from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the model import is required by the framework and also appears inside create_circuit
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized single-stage differential op-amp circuit.
    Required: this function must include the exact import line for model parameters
    (per the framework requirements).
    """
    # Keep the model import exactly as requested inside the function as well
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential Opamp (NMOS pair, PMOS mirror load)')
    # MOSFET models (assumed provided in model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC biases
    # Vdd MUST be fixed at 1.2V (not part of optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
    # Input DC nodes are fixed (will be swept externally)
    circuit.V('in_p', 'Vinp', circuit.gnd, 0.62)
    circuit.V('in_n', 'Vinn', circuit.gnd, 0.58)
    # Tail bias (parameterized; constrained externally to 0.8-1.2x original and <= 1.2V)
    circuit.V('bias_tail', 'Vbias', circuit.gnd, params['v_bias_tail'])
    # Device geometry (length fixed for 45 nm process)
    L = 0.045e-6  # 45 nm (fixed, not part of optimization)
    # NMOS input transistors (W parameterized, L fixed)
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS current mirror load (M3 diode-connected on D1, M4 mirrors to Vout)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)  # diode-connected
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)  # mirror output
    # Tail current sink (NMOS)
    circuit.MOSFET('M7', 'Iss', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M7'],
                   l=L)
    # Note: No resistors or capacitors were present in the original netlist.
    # If you need to add a (fixed) load capacitor in future, keep it fixed and out of the search.
    return circuit
# ============================================================
# Optimization parameter search ranges (annotated)
# ============================================================
# Process length (fixed): L = 45e-9 (45 nm)
L_fixed = 0.045e-6
# Allowed W range: 1xL .. 500xL (per requirements)
W_min = L_fixed * 1.0
W_max = L_fixed * 500.0
param_ranges_definition = {
    # Transistor widths (only W is optimized; L is fixed at 45 nm)
    # Use log sampling recommended for wide range of device widths
    'w_M1': {'min': W_min, 'max': W_max, 'log': True},  # NMOS input transistor (original 10e-6)
    'w_M2': {'min': W_min, 'max': W_max, 'log': True},  # NMOS input transistor (original 10e-6)
    'w_M3': {'min': W_min, 'max': W_max, 'log': True},  # PMOS mirror diode (original 20e-6)
    'w_M4': {'min': W_min, 'max': W_max, 'log': True},  # PMOS mirror output (original 20e-6)
    'w_M7': {'min': W_min, 'max': W_max, 'log': True},  # Tail NMOS (original 5e-6)
    # Voltage source(s) (except Vdd and input voltages which are fixed)
    # v_bias_tail allowed to vary conservatively 0.8-1.2× original, but never > 1.2V
    # Original = 0.5 V -> range = [0.5*0.8, min(0.5*1.2, 1.2)] = [0.4, 0.6]
    'v_bias_tail': {'min': max(0.0, 0.5 * 0.8), 'max': min(1.2, 0.5 * 1.2), 'log': False},
}
# ============================================================
# Initial parameter values (EXACT original values from the provided netlist)
# IMPORTANT: these must exactly match the original circuit code values
# ============================================================
initial_params = {
    # Transistor widths -- EXACT original values
    'w_M1': 10e-6,  # original M1 width
    'w_M2': 10e-6,  # original M2 width
    'w_M3': 20e-6,  # original M3 width (PMOS diode)
    'w_M4': 20e-6,  # original M4 width (PMOS mirror)
    'w_M7': 5e-6,   # original M7 tail NMOS width
    # Bias voltage (EXACT original)
    'v_bias_tail': 0.5,  # original tail bias voltage
}
# Sanity check (you may remove these assertions when integrating into your framework)
# They ensure initial values are within the declared ranges.
for key, val in initial_params.items():
    rng = param_ranges_definition.get(key)
    if rng is not None:
        assert rng['min'] <= val <= rng['max'], f"Initial parameter {key}={val} outside search range {rng}"
# ============================================================
# Parameter descriptions (brief physical meaning)
# ============================================================
param_descriptions = {
    'w_M1': "Width of NMOS M1 (input transistor on non-inverting side). Affects gm, current, output swing.",
    'w_M2': "Width of NMOS M2 (input transistor on inverting side). Affects gm, current, output swing.",
    'w_M3': "Width of PMOS M3 (diode-connected device in the current mirror load). Sets mirror reference current and output resistance.",
    'w_M4': "Width of PMOS M4 (mirrored device delivering load current to the output). Affects mirror accuracy and load drive.",
    'w_M7': "Width of NMOS M7 (tail current sink transistor). Controls tail current for the differential pair.",
    'v_bias_tail': "Tail bias voltage (Vbias) that drives the gate of the tail NMOS current sink. Kept conservative (0.4-0.6 V) to maintain correct operating point (Vth ~ 0.22 V).",
}
# The dictionaries exported by this module:
# - create_circuit(params): function to build the circuit with given params
# - param_ranges_definition: parameter search ranges for optimizer
# - initial_params: exact original values from the user's netlist
# - param_descriptions: brief meaning of each parameter
