from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Opamp (NMOS pair, PMOS mirror load)')
# MOSFET models (assumed provided in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('bias_tail', 'Vbias', circuit.gnd, 0.5) # Tail bias for current sink (NMOS)
# DC input nodes (DC operating point values only, no AC)
circuit.V('in_p', 'Vinp', circuit.gnd, 0.62)      # Vinp (DC)
circuit.V('in_n', 'Vinn', circuit.gnd, 0.58)      # Vinn (DC)
# Internal nodes
# Iss = common source node of M1/M2 (tail node)
# D1 = drain of M1 (diode-connected mirror transistor tied here)
# Vout = output node (drain of M2 and mirror output)
# Device geometry (45 nm node)
L = 0.045e-6  # 45 nm
# NMOS input transistors
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=L)
# PMOS current mirror load: M3 diode-connected on node D1, M4 mirrors to Vout
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L)  # mirror output
# Tail current sink (NMOS)
circuit.MOSFET('M7', 'Iss', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=L)
# Make sure required nodes appear in the netlist:
# - Vinp and Vinn (inputs)
# - Vout (output)
# Run a DC operating point analysis (user requested: no extra commands after simulator creation)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
