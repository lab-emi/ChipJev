```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

# Fixed process length (45 nm)
L = 0.045e-6  # 45 nm in meters

def create_circuit(params):
    """
    Create the Single-Stage Differential Amplifier with PMOS Active Load,
    parameterized for optimization. Uses params dict for transistor widths
    and the tail voltage. Vdd, Vinp and Vinn are kept fixed (not parameterized).
    """
    circuit = Circuit('Single-Stage Differential Amplifier with PMOS Active Load')

    # MOSFET models (provided externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and DC bias sources
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd fixed at 1.2 V (not parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp fixed at 0.6 V (swept externally)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn fixed at 0.6 V (swept externally)

    # Tail bias - parameterized (must remain <= 1.2 V)
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])

    # Differential pair (NMOS) - lengths are fixed, widths parameterized
    circuit.MOSFET('M1', 'D1', 'Vinp', 'SS', 'SS',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'SS', 'SS',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # PMOS active load (current mirror)
    # M3: diode-connected PMOS (drain tied to gate at D1)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # M4: mirror PMOS (gate tied to D1)
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # Tail current source (NMOS)
    circuit.MOSFET('M5', 'SS', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)

    return circuit
```

Parameter search ranges (param_ranges_definition):
```python
# Process length used (fixed)
L_fixed = 0.045e-6   # 45 nm

# Width search bounds follow rule: 1×L to 500×L
w_min = L_fixed
w_max = 500.0 * L_fixed  # 22.5e-6

# Tail voltage original = 0.6 V -> allowed 0.8-1.2× original but never > 1.2 V
v_tail_min = max(0.8 * 0.6, 0.0)  # 0.48 V
v_tail_max = min(1.2 * 0.6, 1.2)  # 0.72 V

param_ranges_definition = {
    # Transistor widths (in meters). Sampling can be log-uniform or uniform;
    # log sampling often helps explore many decades of W.
    'w_M1': {'min': w_min, 'max': w_max, 'log': True},
    'w_M2': {'min': w_min, 'max': w_max, 'log': True},
    'w_M3': {'min': w_min, 'max': w_max, 'log': True},
    'w_M4': {'min': w_min, 'max': w_max, 'log': True},
    'w_M5': {'min': w_min, 'max': w_max, 'log': True},

    # Tail bias voltage (in volts) - linear sampling recommended
    'v_tail': {'min': v_tail_min, 'max': v_tail_max, 'log': False},
}
```

Initial parameters (EXACT original values from your circuit code; these must be kept exactly as provided):
```python
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 10e-6,   # M1 original width
    'w_M2': 10e-6,   # M2 original width
    'w_M3': 20e-6,   # M3 original width
    'w_M4': 20e-6,   # M4 original width
    'w_M5': 2e-6,    # M5 original width

    # Tail bias (exact original value)
    'v_tail': 0.6,   # Tail bias original value
}
```

Short descriptions of each parameter (physical meaning):
- w_M1 (m): Width of NMOS M1 (left input transistor). Affects its current drive, gm, output resistance, and input pair tail-share behavior.
- w_M2 (m): Width of NMOS M2 (right input transistor). Similar role as M1 for the other side of the differential pair.
- w_M3 (m): Width of diode-connected PMOS M3 (sets mirror bias current reference). Affects mirror reference current and headroom.
- w_M4 (m): Width of PMOS mirror device M4 (active load mirror device). Affects mirrored current, output resistance, and load behavior.
- w_M5 (m): Width of NMOS tail device M5 (tail current source transistor). Controls tail current and degeneration of the input pair (affecting gm and bias).
- v_tail (V): Tail bias node DC level (Vtail). This bias sets the gate of M5 and therefore primarily controls tail current magnitude (together with device sizes). Range kept conservative (0.48–0.72 V) and always <= 1.2 V.

Notes and compliance with your constraints:
- The function is named create_circuit as required and imports "from model import nmos_params, pmos_params" exactly.
- Vdd and the input voltages Vinp/Vinn are fixed at their original values and not included in the search.
- L is fixed at 45 nm (0.045e-6 m) and only W is parameterized.
- Width ranges are set to 1–500×L (45e-9 to 22.5e-6 m) as requested.
- Tail voltage range is 0.8–1.2× original but capped to <= 1.2 V (0.48–0.72 V here).
- initial_params contains exactly the original values from your provided netlist.
- No load capacitors were present in your original netlist; if you later add any compensation or load capacitors, follow the constraints you specified (critical comp capacitors: 0.5–5×, others 0.8–1.5×). Existing nodes and device connectivity are preserved exactly.

If you want, I can:
- Provide an alternate parameterization using W/L ratios explicitly (e.g., param = W/L) or
- Export these ranges in an Optuna-friendly sampler example (suggested samplers for 'log' vs 'linear'),
- Or add assertions to verify initial_params are inside param_ranges_definition.