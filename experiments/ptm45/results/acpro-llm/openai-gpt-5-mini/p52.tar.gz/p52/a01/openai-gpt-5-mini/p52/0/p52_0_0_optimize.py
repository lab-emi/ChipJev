from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 10e-6,   # M1 original width
    'w_M2': 10e-6,   # M2 original width
    'w_M3': 20e-6,   # M3 original width
    'w_M4': 20e-6,   # M4 original width
    'w_M5': 2e-6,    # M5 original width
    # Tail bias (exact original value)
    'v_tail': 0.6,   # Tail bias original value
}
