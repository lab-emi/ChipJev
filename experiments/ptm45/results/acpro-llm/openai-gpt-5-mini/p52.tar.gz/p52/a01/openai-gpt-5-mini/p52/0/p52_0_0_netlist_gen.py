from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Amplifier with PMOS Active Load')
# MOSFET models (provided externally via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)    # Vinp DC operating point (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)    # Vinn DC operating point (common-mode)
circuit.V('tail', 'Vtail', circuit.gnd, 0.6)  # Tail bias (sets tail current; > Vth = 0.22 V)
# Nodes:
# D1 : drain of M1 and diode-connected PMOS M3 gate/drain
# Vout: output node (drain of M2 and drain of PMOS mirror M4)
# SS : common source node of input pair, drain of tail M5
# Differential pair (NMOS)
circuit.MOSFET('M1', 'D1', 'Vinp', 'SS', 'SS', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'SS', 'SS', model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS active load (current mirror)
# M3: diode-connected PMOS (drain tied to gate at D1)
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M4: mirror PMOS (gate tied to D1)
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('M5', 'SS', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# End with simulator instantiation (no extra commands after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
