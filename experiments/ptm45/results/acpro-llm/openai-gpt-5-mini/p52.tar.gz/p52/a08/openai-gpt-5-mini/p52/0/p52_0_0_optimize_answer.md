```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp (High Gain, No Positive Feedback)')

    # Device models (expected to be provided by model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)             # Vdd = 1.2 V (fixed)

    # Input voltages (fixed, swept externally during analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)           # Vinp (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)           # Vinn (fixed)

    # Tail bias - parameterized (constrained to be <= 1.2V in search ranges)
    circuit.V('bt', 'Vb_tail', circuit.gnd, params['Vb_tail'])  # Tail bias source

    # Node: Iss is the source node of the input pair and drain of tail device

    # Fixed channel lengths (process constants) - not part of optimization
    L_n = 0.045e-6  # NMOS channel length = 45 nm (fixed)
    L_p = 0.12e-6   # PMOS channel length = 120 nm (fixed) as in original netlist

    # Input differential pair (NMOS) - widths parameterized
    circuit.MOSFET('M1', 'Dn1', 'Vinp', 'Iss', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_n)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_n)

    # Tail current source (NMOS) - width parameterized
    circuit.MOSFET('Mtail', 'Iss', 'Vb_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L_n)

    # PMOS current mirror load (M3 diode-connected on left branch, M4 mirrored device to right branch)
    circuit.MOSFET('M3', 'Dn1', 'Dn1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_p)  # diode-connected PMOS
    circuit.MOSFET('M4', 'Vout', 'Dn1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_p)  # mirror output PMOS

    return circuit


# -----------------------------
# Optimization parameter search ranges
# -----------------------------
# Notes / units:
# - Widths (w_*) are in meters.
# - Lengths are fixed (L_n = 45e-9, L_p = 120e-9).
# - Vb_tail is in volts and constrained to 0.8-1.2× original but never > 1.2 V.
#
# Transistor width constraint: W_min = 1 * L, W_max = 500 * L (per requirement).
# Use log sampling for widths because ranges span many decades.

param_ranges = {
    # NMOS widths (L_n = 45 nm): valid range = [45e-9, 500 * 45e-9 = 22.5e-6]
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # Input NMOS left
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # Input NMOS right
    'w_Mtail': {'min': 45e-9, 'max': 22.5e-6, 'log': True},# Tail NMOS

    # PMOS widths (L_p = 120 nm): valid range = [120e-9, 500 * 120e-9 = 60e-6]
    'w_M3': {'min': 120e-9, 'max': 60e-6, 'log': True},    # PMOS diode-connected
    'w_M4': {'min': 120e-9, 'max': 60e-6, 'log': True},    # PMOS mirror device

    # Tail bias source - 0.8 - 1.2 × original (original = 0.42 V), but never exceed 1.2 V.
    # 0.8*0.42 = 0.336 V, 1.2*0.42 = 0.504 V -> upper stays below 1.2 V
    'Vb_tail': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
}

# -----------------------------
# Initial parameter values (EXACT original circuit values)
# These MUST match the original netlist values exactly (per requirement).
# -----------------------------
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 4e-6,     # original M1 width
    'w_M2': 4e-6,     # original M2 width
    'w_Mtail': 2e-6,  # original Mtail width
    'w_M3': 12e-6,    # original M3 width (PMOS diode)
    'w_M4': 12e-6,    # original M4 width (PMOS mirror)

    # Bias voltages (exact original values)
    'Vb_tail': 0.42,  # original tail bias
}

# -----------------------------
# Brief descriptions of each parameter (physical meaning)
# -----------------------------
param_descriptions = {
    'w_M1': "Width of NMOS M1 (left input transistor). With fixed L_n = 45 nm this sets W/L and thus transconductance/drive.",
    'w_M2': "Width of NMOS M2 (right input transistor). With fixed L_n = 45 nm this sets W/L for the other input branch.",
    'w_Mtail': "Width of NMOS tail transistor (current source). Controls tail current / headroom with L_n = 45 nm fixed.",
    'w_M3': "Width of PMOS M3 (diode-connected load transistor). With fixed L_p = 120 nm this sets the PMOS branch current and output resistance.",
    'w_M4': "Width of PMOS M4 (mirror output transistor). Mirrors M3; width controls matching and output swing.",
    'Vb_tail': "Tail bias voltage applied to the gate of the tail NMOS (Mtail). Controls tail current and operating point. Range kept conservative around original (0.42 V) and always <= 1.2 V.",
}

# -----------------------------
# Notes / Constraints adhered to:
# - create_circuit function name preserved (required).
# - "from model import nmos_params, pmos_params" kept exactly inside create_circuit.
# - vdd (1.2 V) and input voltages (Vinp/Vinn = 0.6 V) remain fixed (not parameterized).
# - Only transistor widths (W) are parameterized; lengths (L_n, L_p) are fixed to process values.
# - Transistor width ranges follow 1×L to 500×L rule.
# - Vb_tail range is 0.8–1.2× original but capped at 1.2 V.
# - initial_params contains exactly the original numeric values from the provided netlist.
# - There were no explicit resistors or capacitors in the original netlist to parameterize.
# -----------------------------
```