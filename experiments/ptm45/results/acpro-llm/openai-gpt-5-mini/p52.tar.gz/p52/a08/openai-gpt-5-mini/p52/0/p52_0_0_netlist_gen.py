from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (High Gain, No Positive Feedback)')
# Models (assumed provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)             # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)           # Vinp DC common-mode bias ~0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)           # Vinn DC common-mode bias ~0.6 V
circuit.V('bt', 'Vb_tail', circuit.gnd, 0.42)        # Tail bias = Vth + 0.2 (0.22 + 0.2 = 0.42 V)
# Node: Iss is source node of input pair and drain of tail device
# Input differential pair (NMOS)
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Dn1', 'Vinp', 'Iss', circuit.gnd, model='nmos_model', w=4e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', circuit.gnd, model='nmos_model', w=4e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vb_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# PMOS current mirror load (M3 diode-connected on left branch, M4 mirrored device to right branch)
circuit.MOSFET('M3', 'Dn1', 'Dn1', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.12e-6)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'Dn1', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.12e-6)  # mirror output
# Simulator (operating point / DC)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
