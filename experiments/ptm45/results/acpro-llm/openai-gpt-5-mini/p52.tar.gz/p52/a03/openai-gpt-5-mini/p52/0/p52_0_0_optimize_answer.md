```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # Import transistor model parameter dictionaries from the provided module
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage High-Gain OpAmp')

    # MOS models (provided externally)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V

    # Input and bias DC sources (operating point/bias only; inputs fixed & swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.5)   # Input+ fixed (will be swept externally)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.5)   # Input- fixed (will be swept externally)

    # Tail bias - parameterized (within 0.8-1.2× original but <= 1.2V)
    circuit.V('tailb', 'Vtailb', circuit.gnd, params['v_tailb'])

    # Device sizing
    # Note: lengths are kept constant (fixed) here. Only widths are parameterized.
    # Using the original device lengths from your netlist as fixed L values.
    # (Keeping original L per device ensures the initial widths from your netlist
    # remain within the 1-500×L constraints.)
    #
    # M1: NMOS input (+)
    circuit.MOSFET('M1', 'Dp', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.09e-6)  # fixed length (originally 0.09e-6)
    # M2: NMOS input (-), output taken at its drain
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=0.09e-6)  # fixed length (originally 0.09e-6)
    # M3: PMOS diode-connected mirror transistor (sense leg)
    circuit.MOSFET('M3', 'Dp', 'Dp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=0.18e-6)  # fixed length (originally 0.18e-6)
    # M4: PMOS mirror transistor (active load at output)
    circuit.MOSFET('M4', 'Vout', 'Dp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=0.18e-6)  # fixed length (originally 0.18e-6)
    # M5: NMOS tail current source
    circuit.MOSFET('M5', 'S', 'Vtailb', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=0.18e-6)  # fixed length (originally 0.18e-6)

    # No load capacitors in this netlist. If you add C_load later, keep it fixed
    # as requested (do not include it in the optimization parameters).

    return circuit


# ----------------------------
# Parameter search range definition
# ----------------------------
# For each transistor, W range obeys 1 - 500 × L (L taken as the fixed per-device length
# used in create_circuit above). Log-sampling is often appropriate for transistor widths.
#
# For the tail bias voltage: 0.8 - 1.2× original, clipped so it never exceeds 1.2 V.
# (Original Vtailb = 0.6 V -> range = [0.48, 0.72] V)
#
# All initial parameter values below are EXACTLY the original values from your provided netlist.

param_ranges_definition = {
    # Transistor widths (meters). min = 1 * L_device, max = 500 * L_device.
    'w_M1': {                         # M1 original: w=12e-6, l=0.09e-6
        'min': 1 * 0.09e-6,           # 0.09e-6
        'max': 500 * 0.09e-6,         # 45e-6
        'log': True
    },
    'w_M2': {                         # M2 original: w=12e-6, l=0.09e-6
        'min': 1 * 0.09e-6,
        'max': 500 * 0.09e-6,
        'log': True
    },
    'w_M3': {                         # M3 original: w=24e-6, l=0.18e-6
        'min': 1 * 0.18e-6,
        'max': 500 * 0.18e-6,         # 90e-6
        'log': True
    },
    'w_M4': {                         # M4 original: w=24e-6, l=0.18e-6
        'min': 1 * 0.18e-6,
        'max': 500 * 0.18e-6,
        'log': True
    },
    'w_M5': {                         # M5 original: w=4e-6, l=0.18e-6
        'min': 1 * 0.18e-6,
        'max': 500 * 0.18e-6,
        'log': True
    },

    # Voltage sources (excluding vdd and Vinp/Vinn which are fixed). Use 0.8-1.2× original,
    # clipped to <= 1.2 V as required. (Vtailb original = 0.6 V)
    'v_tailb': {
        'min': max(0.0, 0.6 * 0.8),   # 0.48 V
        'max': min(1.2, 0.6 * 1.2),   # 0.72 V
        'log': False
    }
}

# ----------------------------
# Initial parameter values (EXACT original circuit values)
# These values MUST match the original netlist exactly (unchanged).
# ----------------------------
initial_params = {
    # Transistor widths (meters) - EXACT original widths from your netlist
    'w_M1': 12e-6,   # M1 original width
    'w_M2': 12e-6,   # M2 original width
    'w_M3': 24e-6,   # M3 original width
    'w_M4': 24e-6,   # M4 original width
    'w_M5': 4e-6,    # M5 original width

    # Tail bias voltage - EXACT original
    'v_tailb': 0.6,  # original tail bias voltage
}

# ----------------------------
# Parameter descriptions (brief physical meaning)
# ----------------------------
# w_M1, w_M2: Width of the input NMOS pair transistors (affects gm, input pair current and input-referred noise)
# w_M3, w_M4: Width of the PMOS mirror/load transistors (affects output load resistance, ro of mirror)
# w_M5: Width of the tail NMOS current-source transistor (affects tail current and headroom)
# v_tailb: Tail bias voltage applied to the gate of the tail NMOS (sets the tail/source current bias)
#
# Notes / Constraints summary:
# - Vdd is fixed at 1.2 V (not parameterized).
# - Vinp and Vinn (input DC sources) are fixed at 0.5 V (will be swept externally).
# - All voltage parameters constrained to be <= 1.2 V.
# - Width ranges obey 1×L to 500×L per device (L is the fixed per-device length used in create_circuit),
#   ensuring physically reasonable W/L ratios and that the provided initial values lie within the ranges.
# - No load capacitors present in the original netlist; if added later, they should remain fixed
#   (not included in the parameter search) unless you explicitly decide otherwise.
```

Notes:
- I kept each transistor's fixed length equal to the original length from your netlist (M1/M2: 0.09e-6, M3/M4/M5: 0.18e-6). This ensures the initial widths you supplied remain inside the 1-500×L constraints and satisfies the requirement to keep L constant per-device (only W is varied).
- The required import line "from model import nmos_params, pmos_params" is present exactly as requested inside the create_circuit function.
- All initial_params values are exactly the original values you provided and are within the defined search ranges.