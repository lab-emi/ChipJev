from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain OpAmp')
# MOS models (provided by external module 'model')
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input and bias DC sources (operating point/bias only; no AC)
# Set input common-mode to ~0.5 V (can be adjusted in simulations)
circuit.V('inp', 'Vinp', circuit.gnd, 0.5)
circuit.V('inn', 'Vinn', circuit.gnd, 0.5)
# Tail bias to set tail current (nominal)
circuit.V('tailb', 'Vtailb', circuit.gnd, 0.6)
# Device sizing (all dimensions in meters)
# Note: minimal feature ~45 nm (0.045e-6). Use longer L for PMOS loads to increase ro.
# M1: NMOS input (+)
# drain, gate, source, bulk
circuit.MOSFET('M1', 'Dp', 'Vinp', 'S', 'S',
               model='nmos_model',
               w=12e-6, l=0.09e-6)
# M2: NMOS input (-), output taken at its drain
circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', 'S',
               model='nmos_model',
               w=12e-6, l=0.09e-6)
# M3: PMOS diode-connected mirror transistor (sense leg)
circuit.MOSFET('M3', 'Dp', 'Dp', 'Vdd', 'Vdd',
               model='pmos_model',
               w=24e-6, l=0.18e-6)
# M4: PMOS mirror transistor (active load at output)
circuit.MOSFET('M4', 'Vout', 'Dp', 'Vdd', 'Vdd',
               model='pmos_model',
               w=24e-6, l=0.18e-6)
# M5: NMOS tail current source
circuit.MOSFET('M5', 'S', 'Vtailb', circuit.gnd, circuit.gnd,
               model='nmos_model',
               w=4e-6, l=0.18e-6)
# Simulator (OP point / DC analysis will use the DC biasing above)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
