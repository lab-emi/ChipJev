from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp - High Gain (Corrected)')
# Define MOSFET models from external model module
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('vbn', 'Vbiasn', circuit.gnd, 0.42)       # NMOS tail bias ~ Vth + 0.2 = 0.42 V
# Input DC common-mode biases (for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)          # Vinp DC = 0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)          # Vinn DC = 0.6 V
# Node names:
# D1: drain of left input transistor and diode-connected PMOS gate/drain
# Tail: source node of the input pair (drain of tail transistor)
# First (and only) stage: NMOS differential pair (M1, M2) with PMOS current mirror load (M3 diode, M4 mirror)
# Tail current source: M7
# M1 - left input NMOS (bulk tied to its source 'Tail')
circuit.MOSFET('M1', 'D1', 'Vinp', 'Tail', 'Tail',
               model='nmos_model', w=20e-6, l=45e-9)
# M2 - right input NMOS (output side) (bulk tied to its source 'Tail')
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Tail', 'Tail',
               model='nmos_model', w=20e-6, l=45e-9)
# M3 - diode-connected PMOS (reference side of mirror), bulk tied to Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=180e-9)
# M4 - PMOS mirror transistor (loads the Vout node), bulk tied to Vdd
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=180e-9)
# M7 - NMOS tail current source (bulk tied to its source = ground)
circuit.MOSFET('M7', 'Tail', 'Vbiasn', circuit.gnd, circuit.gnd,
               model='nmos_model', w=3e-6, l=120e-9)
# Create simulator (no further simulation commands per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
