from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain Diff Amp - Fixed OP')
# MOSFET models (provided by the local model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Inputs (DC bias for operating point)
# Set inputs near Vth + margin to allow the differential pair to conduct
# Vth = 0.22 V, choose inputs = 0.40 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.40)
circuit.V('inn', 'Vinn', circuit.gnd, 0.40)
# Tail bias
# Use a strong bias (Vdd) on the tail gate so the tail transistor supplies current
circuit.V('biasn', 'Vbiasn', circuit.gnd, 1.2)
# Node names used:
#  - Drainp : drain of left input transistor and diode PMOS gate/drain
#  - Ssrc   : common source node of the differential pair (connected to tail transistor)
#  - Vout   : single-ended output (drain of right input transistor)
# Differential pair (NMOS)
# M1: left input transistor
circuit.MOSFET('M1', 'Drainp', 'Vinp', 'Ssrc', 'Ssrc',
               model='nmos_model', w=20e-6, l=0.18e-6)
# M2: right input transistor (output side)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Ssrc', 'Ssrc',
               model='nmos_model', w=20e-6, l=0.18e-6)
# Tail current source (NMOS) - stronger sizing to ensure reasonable tail current
circuit.MOSFET('Mtail', 'Ssrc', 'Vbiasn', circuit.gnd, circuit.gnd,
               model='nmos_model', w=15e-6, l=0.18e-6)
# PMOS active mirror loads
# M3: diode-connected PMOS on left half (drain tied to gate)
circuit.MOSFET('M3', 'Drainp', 'Drainp', 'Vdd', 'Vdd',
               model='pmos_model', w=60e-6, l=0.18e-6)
# M4: mirror PMOS on right half (gate tied to Drainp)
circuit.MOSFET('M4', 'Vout', 'Drainp', 'Vdd', 'Vdd',
               model='pmos_model', w=60e-6, l=0.18e-6)
# Simulator creation (end of provided runnable code)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
