```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import is required exactly as written inside create_circuit per instructions
# (it will also be present inside the function)
# from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the parameterized PySpice circuit.
    The model import line required by the framework is included exactly as requested.
    params: dictionary with keys:
        'w_M1', 'w_M2', 'w_Mtail', 'w_M3', 'w_M4'  -> transistor widths in meters
        'v_biasn'                                  -> tail gate bias voltage in volts
    """
    from model import nmos_params, pmos_params  # required exact import

    circuit = Circuit('Single-Stage High-Gain Diff Amp - Fixed OP')

    # MOSFET models (provided by the local model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (not part of optimization)

    # Inputs (fixed DC bias for operating point sweep outside optimization)
    # Vth = 0.22 V; keep inputs fixed to allow DC sweeps externally
    circuit.V('inp', 'Vinp', circuit.gnd, 0.40)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.40)

    # Tail bias - parameterized (but constrained to <= 1.2 V in ranges)
    circuit.V('biasn', 'Vbiasn', circuit.gnd, params['v_biasn'])

    # Node names:
    #  - Drainp : drain of left input transistor and diode PMOS gate/drain
    #  - Ssrc   : common source node of the differential pair (connected to tail transistor)
    #  - Vout   : single-ended output (drain of right input transistor)

    # Process / geometry convention:
    # Keep channel length fixed (L = original 0.18e-6 m). Only widths are varied.
    L_FIXED = 0.18e-6

    # Differential pair (NMOS)
    # M1: left input transistor
    circuit.MOSFET('M1', 'Drainp', 'Vinp', 'Ssrc', 'Ssrc',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_FIXED)

    # M2: right input transistor (output side)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Ssrc', 'Ssrc',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_FIXED)

    # Tail current source (NMOS) - stronger sizing to ensure reasonable tail current
    circuit.MOSFET('Mtail', 'Ssrc', 'Vbiasn', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L_FIXED)

    # PMOS active mirror loads
    # M3: diode-connected PMOS on left half (drain tied to gate)
    circuit.MOSFET('M3', 'Drainp', 'Drainp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_FIXED)

    # M4: mirror PMOS on right half (gate tied to Drainp)
    circuit.MOSFET('M4', 'Vout', 'Drainp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_FIXED)

    # No load capacitors present in original circuit; if added externally, keep fixed per instructions.

    return circuit


# ===========================
# Optimization parameter search ranges
# ===========================
# The channel length used in original circuit is L = 0.18e-6 m, so 1×L .. 500×L corresponds to:
L_FIXED = 0.18e-6
W_MIN = 1.0 * L_FIXED            # 0.18e-6 m
W_MAX = 500.0 * L_FIXED          # 90e-6 m

# For v_biasn: original value = 1.2 V. Allowed range = 0.8-1.2×original but never exceeding 1.2 V.
# So min = 0.8 * 1.2 = 0.96 V, max = 1.2 V
param_ranges_definition = {
    # Transistor widths (meters). Search in log-space is recommended because widths span orders of magnitude.
    'w_M1':   {'min': W_MIN, 'max': W_MAX, 'log': True},  # M1 left input NMOS
    'w_M2':   {'min': W_MIN, 'max': W_MAX, 'log': True},  # M2 right input NMOS (output side)
    'w_Mtail':{'min': W_MIN, 'max': W_MAX, 'log': True},  # Mtail tail NMOS
    'w_M3':   {'min': W_MIN, 'max': W_MAX, 'log': True},  # M3 diode-connected PMOS (W in meters)
    'w_M4':   {'min': W_MIN, 'max': W_MAX, 'log': True},  # M4 mirror PMOS

    # Tail bias voltage (volts). Conservative linear search; must be <= 1.2 V (supply).
    'v_biasn': {'min': max(0.8 * 1.2, 0.0), 'max': 1.2, 'log': False},
}

# ===========================
# Initial parameter values (EXACT original values from the provided circuit)
# These are the unmodified, original values and must lie within the ranges above.
# ===========================
initial_params = {
    # EXACT widths from original code (in meters)
    'w_M1':    20e-6,   # original M1 width
    'w_M2':    20e-6,   # original M2 width
    'w_Mtail': 15e-6,   # original Mtail width
    'w_M3':    60e-6,   # original M3 width (PMOS diode)
    'w_M4':    60e-6,   # original M4 width (PMOS mirror)

    # EXACT voltage from original code
    'v_biasn': 1.2,     # original tail gate bias (note: at upper bound of allowed range)
}

# ===========================
# Short descriptions of each parameter (physical meaning)
# ===========================
# w_M1    : Width of left input NMOS transistor (Drainp, Vinp). Controls gm, current, output resistance of left half.
# w_M2    : Width of right input NMOS transistor (Vout, Vinn). Controls gm, current, output resistance of right half.
# w_Mtail : Width of tail NMOS transistor (Ssrc node). Controls tail current capability and common-source degeneration.
# w_M3    : Width of diode-connected PMOS (left load). Sets mirror reference current and load resistance.
# w_M4    : Width of mirror PMOS (right load). Sets mirrored load current and output load resistance.
# v_biasn : Tail gate bias voltage applied to Mtail gate. Tunes tail current; must remain <= Vdd (1.2 V).
#
# Notes:
# - Channel length (L) is fixed at the original 0.18e-6 m for all transistors (only W is optimized).
# - Input voltages (Vinp, Vinn) and Vdd are fixed as requested (not part of the optimization).
# - There were no explicit resistors or capacitors in the original netlist; therefore none are parameterized.
# - All ranges ensure the initial_params values lie inside the search ranges.
```