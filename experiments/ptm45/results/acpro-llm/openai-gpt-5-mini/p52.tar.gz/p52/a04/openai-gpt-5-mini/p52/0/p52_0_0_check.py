from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage OpAmp - High Gain')
# MOSFET models (provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Supply
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('vb_n', 'Vbias_tail', circuit.gnd, 0.42)   # Tail NMOS gate bias
circuit.V('vb_p', 'Vbias_pcas', circuit.gnd, 0.78)   # PMOS cascode gate bias
# Typical 45 nm channel length
L = 0.045e-6
# Transistor sizing (meters)
W_M1_M2 = 20e-6    # input NMOS pair
W_Mtail = 2e-6     # tail current source NMOS
W_Pmir = 40e-6     # PMOS mirror transistors
W_Pcas = 10e-6     # PMOS cascodes
# Node names:
# node_left : left differential drain (also diode-connected mirror node)
# node_pc_left, node_pc_right : intermediate nodes between Vdd and mirror devices (cascode drains)
# node_s : common source node of input pair (drain of tail)
# Vout : specified output node
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'node_left', 'Vinp', 'node_s', circuit.gnd,
               model='nmos_model', w=W_M1_M2, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'node_s', circuit.gnd,
               model='nmos_model', w=W_M1_M2, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mt', 'node_s', 'Vbias_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=W_Mtail, l=L)
# PMOS cascodes (source to Vdd, bulk to Vdd)
circuit.MOSFET('PcL', 'node_pc_left', 'Vbias_pcas', 'Vdd', 'Vdd',
               model='pmos_model', w=W_Pcas, l=L)
circuit.MOSFET('PcR', 'node_pc_right', 'Vbias_pcas', 'Vdd', 'Vdd',
               model='pmos_model', w=W_Pcas, l=L)
# PMOS mirror: left diode-connected device and right mirror device
# Left diode: gate tied to its drain (node_left); source tied to node_pc_left
circuit.MOSFET('M3', 'node_left', 'node_left', 'node_pc_left', 'Vdd',
               model='pmos_model', w=W_Pmir, l=L)
# Mirror leg: gate tied to node_left, source tied to node_pc_right, drain is Vout
circuit.MOSFET('M4', 'Vout', 'node_left', 'node_pc_right', 'Vdd',
               model='pmos_model', w=W_Pmir, l=L)
# Simulator (end of netlist)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)