from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage OpAmp - High Gain')
# MOSFET models (provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Supply
circuit.V('inp', 'Vinp', circuit.gnd, 0.42)      # Input positive DC bias (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.42)      # Input negative DC bias (common-mode)
circuit.V('vb_n', 'Vbias_tail', circuit.gnd, 0.42)   # Tail NMOS gate bias
circuit.V('vb_p', 'Vbias_pcas', circuit.gnd, 0.78)   # PMOS cascode gate bias
# Typical 45 nm channel length
L = 0.045e-6
# Transistor sizing (meters)
W_M1_M2 = 20e-6    # input NMOS pair
W_Mtail = 2e-6     # tail current source NMOS
W_Pmir = 40e-6     # PMOS mirror transistors
W_Pcas = 10e-6     # PMOS cascodes
# Node names:
# node_left : left differential drain (also diode-connected mirror node)
# node_pc_left, node_pc_right : intermediate nodes between Vdd and mirror devices (cascode drains)
# node_s : common source node of input pair (drain of tail)
# Vout : specified output node
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'node_left', 'Vinp', 'node_s', circuit.gnd,
               model='nmos_model', w=W_M1_M2, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'node_s', circuit.gnd,
               model='nmos_model', w=W_M1_M2, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mt', 'node_s', 'Vbias_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=W_Mtail, l=L)
# PMOS cascodes (source to Vdd, bulk to Vdd)
circuit.MOSFET('PcL', 'node_pc_left', 'Vbias_pcas', 'Vdd', 'Vdd',
               model='pmos_model', w=W_Pcas, l=L)
circuit.MOSFET('PcR', 'node_pc_right', 'Vbias_pcas', 'Vdd', 'Vdd',
               model='pmos_model', w=W_Pcas, l=L)
# PMOS mirror: left diode-connected device and right mirror device
# Left diode: gate tied to its drain (node_left); source tied to node_pc_left
circuit.MOSFET('M3', 'node_left', 'node_left', 'node_pc_left', 'Vdd',
               model='pmos_model', w=W_Pmir, l=L)
# Mirror leg: gate tied to node_left, source tied to node_pc_right, drain is Vout
circuit.MOSFET('M4', 'Vout', 'node_left', 'node_pc_right', 'Vdd',
               model='pmos_model', w=W_Pmir, l=L)
# Simulator (end of netlist)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
