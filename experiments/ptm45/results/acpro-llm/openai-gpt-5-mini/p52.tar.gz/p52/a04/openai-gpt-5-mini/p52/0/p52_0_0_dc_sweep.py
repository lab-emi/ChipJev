from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage OpAmp - High Gain')
# MOSFET models (provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Supply
circuit.V('dc', 'Vinn', 'Vinp', 0.0)
circuit.V('inn', 'Vinn', circuit.gnd, 0.42)      # Input negative DC bias (common-mode)
circuit.V('vb_n', 'Vbias_tail', circuit.gnd, 0.42)   # Tail NMOS gate bias
circuit.V('vb_p', 'Vbias_pcas', circuit.gnd, 0.78)   # PMOS cascode gate bias
# Typical 45 nm channel length
L = 0.045e-6
# Transistor sizing (meters)
W_M1_M2 = 20e-6    # input NMOS pair
W_Mtail = 2e-6     # tail current source NMOS
W_Pmir = 40e-6     # PMOS mirror transistors
W_Pcas = 10e-6     # PMOS cascodes
# Node names:
# node_left : left differential drain (also diode-connected mirror node)
# node_pc_left, node_pc_right : intermediate nodes between Vdd and mirror devices (cascode drains)
# node_s : common source node of input pair (drain of tail)
# Vout : specified output node
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'node_left', 'Vinp', 'node_s', circuit.gnd,
               model='nmos_model', w=W_M1_M2, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'node_s', circuit.gnd,
               model='nmos_model', w=W_M1_M2, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mt', 'node_s', 'Vbias_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=W_Mtail, l=L)
# PMOS cascodes (source to Vdd, bulk to Vdd)
circuit.MOSFET('PcL', 'node_pc_left', 'Vbias_pcas', 'Vdd', 'Vdd',
               model='pmos_model', w=W_Pcas, l=L)
circuit.MOSFET('PcR', 'node_pc_right', 'Vbias_pcas', 'Vdd', 'Vdd',
               model='pmos_model', w=W_Pcas, l=L)
# PMOS mirror: left diode-connected device and right mirror device
# Left diode: gate tied to its drain (node_left); source tied to node_pc_left
circuit.MOSFET('M3', 'node_left', 'node_left', 'node_pc_left', 'Vdd',
               model='pmos_model', w=W_Pmir, l=L)
# Mirror leg: gate tied to node_left, source tied to node_pc_right, drain is Vout
circuit.MOSFET('M4', 'Vout', 'node_left', 'node_pc_right', 'Vdd',
               model='pmos_model', w=W_Pmir, l=L)
# Simulator (end of netlist)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

import numpy as np

# Get the VDD value from the circuit
try:
    dc_value = circuit.element('Vdd').dc_value
    if type(dc_value) == str:
        v_dd_value = float(dc_value.split()[0])
    else:
        v_dd_value = float(dc_value)
except:
    # Try alternative name formats
    try:
        dc_value = circuit.element('VDD').dc_value
        if type(dc_value) == str:
            v_dd_value = float(dc_value.split()[0])
        else:
            v_dd_value = float(dc_value)
    except:
        # Default to 1.2V if VDD cannot be found
        v_dd_value = 1.2

# Define reasonable voltage range for differential amplifier biasing
# Avoid regions too close to rails where transistors might not be in saturation
min_voltage = 0.2
max_voltage = v_dd_value - 0.2  # Avoid saturation region

# Target output voltage is typically VDD/2 for many amplifier circuits
target_vout = v_dd_value / 2

# Save the data to file in two lines
fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_dc.txt", "w")


for element in circuit.elements:
    if element.name == "Vinn":
        vin_pin_name = element.pins[0].node
# Three-level scanning strategy
# Level 1: Coarse scan across reasonable operating range
coarse_step = (max_voltage - min_voltage) / 20  # Adaptive step size
analysis_coarse = simulator.dc(Vinn=slice(min_voltage, max_voltage, coarse_step))
out_voltage_coarse = np.array(analysis_coarse.Vout)
in_voltage_coarse = np.array(getattr(analysis_coarse, vin_pin_name))

# Find the approximate best point
best_vin_coarse = v_dd_value / 2  # Initial guess
min_diff_coarse = float('inf')
for i, vout in enumerate(out_voltage_coarse):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_coarse:
        min_diff_coarse = diff
        best_vin_coarse = float(in_voltage_coarse[i])

# Level 2: Medium resolution scan around best point from coarse scan
mid_range = (max_voltage - min_voltage) / 4  # 25% of the range
mid_step = (max_voltage - min_voltage) / 200  # Higher resolution
mid_min = max(min_voltage, best_vin_coarse - mid_range/2)
mid_max = min(max_voltage, best_vin_coarse + mid_range/2)

# get vin pin name



analysis_mid = simulator.dc(Vinn=slice(mid_min, mid_max, mid_step))
out_voltage_mid = np.array(analysis_mid.Vout)
in_voltage_mid = np.array(getattr(analysis_mid, vin_pin_name))

# Find the best point in medium resolution scan
best_vin_mid = best_vin_coarse
min_diff_mid = float('inf')
for i, vout in enumerate(out_voltage_mid):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_mid:
        min_diff_mid = diff
        best_vin_mid = float(in_voltage_mid[i])

# Level 3: Ultra-high resolution scan around best point from medium scan
fine_range = (max_voltage - min_voltage) / 40  # ~2.5% of the range
fine_step = (max_voltage - min_voltage) / 2000  # Ultra-fine resolution
fine_min = max(min_voltage, best_vin_mid - fine_range/2)
fine_max = min(max_voltage, best_vin_mid + fine_range/2)

analysis_fine = simulator.dc(Vinn=slice(fine_min, fine_max, fine_step))
out_voltage = np.array(analysis_fine.Vout)
in_voltage = np.array(getattr(analysis_fine, vin_pin_name))

# Print information about the search
print(f"VDD = {v_dd_value:.3f}V, Target Vout = {target_vout:.3f}V")
print(f"Search range: {min_voltage:.3f}V to {max_voltage:.3f}V")
print(f"Coarse scan result: Best Vin ≈ {best_vin_coarse:.6f}V")
print(f"Medium scan result: Best Vin ≈ {best_vin_mid:.6f}V")

# Find best point in fine scan
best_vin_fine = best_vin_mid
best_vout_fine = target_vout
min_diff_fine = float('inf')
for i, vout in enumerate(out_voltage):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_fine:
        min_diff_fine = diff
        best_vin_fine = float(in_voltage[i])
        best_vout_fine = float(vout)

print(f"Fine scan result: Best Vin = {best_vin_fine:.6f}V (Vout ≈ {best_vout_fine:.6f}V)")

# Combine all results for comprehensive data output
all_out_voltage = np.concatenate((out_voltage_coarse, out_voltage_mid, out_voltage))
all_in_voltage = np.concatenate((in_voltage_coarse, in_voltage_mid, in_voltage))

for item in all_in_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
for item in all_out_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
fopen.close()