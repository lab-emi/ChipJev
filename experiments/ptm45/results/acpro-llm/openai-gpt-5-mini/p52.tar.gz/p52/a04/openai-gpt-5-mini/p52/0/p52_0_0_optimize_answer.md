```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import MUST appear inside create_circuit per your requirement:
# from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the Single-Stage OpAmp - High Gain circuit whose variable
    quantities are passed via the params dict.

    IMPORTANT: This function includes the required exact import statement
    for the device model parameter dictionaries.
    """
    from model import nmos_params, pmos_params  # MUST be present exactly as written

    circuit = Circuit('Single-Stage OpAmp - High Gain (parameterized)')

    # MOSFET models (provided externally)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and DC bias supplies
    # vdd is fixed (do not include in parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Supply fixed at 1.2 V

    # Input voltages (fixed, will be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.42)      # Input positive DC bias (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.42)      # Input negative DC bias (fixed)

    # Parameterized bias sources (these are included in the optimization)
    # Note: values in params are in Volts and guaranteed <= 1.2 V by the search ranges.
    circuit.V('vb_n', 'Vbias_tail', circuit.gnd, params['Vbias_tail'])   # Tail NMOS gate bias
    circuit.V('vb_p', 'Vbias_pcas', circuit.gnd, params['Vbias_pcas'])   # PMOS cascode gate bias

    # Fixed channel length (per your requirement: keep L constant)
    L = 0.045e-6   # Exact original L value (45 nm expressed as 0.045e-6)

    # MOSFET sizing (W taken from params, L fixed)
    # All widths are in meters
    circuit.MOSFET('M1', 'node_left', 'Vinp', 'node_s', circuit.gnd,
                   model='nmos_model', w=params['W_M1_M2'], l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'node_s', circuit.gnd,
                   model='nmos_model', w=params['W_M1_M2'], l=L)

    # Tail current source (NMOS)
    circuit.MOSFET('Mt', 'node_s', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['W_Mtail'], l=L)

    # PMOS cascodes (source to Vdd, bulk to Vdd)
    circuit.MOSFET('PcL', 'node_pc_left', 'Vbias_pcas', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['W_Pcas'], l=L)
    circuit.MOSFET('PcR', 'node_pc_right', 'Vbias_pcas', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['W_Pcas'], l=L)

    # PMOS mirror: left diode-connected device and right mirror device
    # Left diode: gate tied to its drain (node_left); source tied to node_pc_left
    circuit.MOSFET('M3', 'node_left', 'node_left', 'node_pc_left', 'Vdd',
                   model='pmos_model', w=params['W_Pmir'], l=L)

    # Mirror leg: gate tied to node_left, source tied to node_pc_right, drain is Vout
    circuit.MOSFET('M4', 'Vout', 'node_left', 'node_pc_right', 'Vdd',
                   model='pmos_model', w=params['W_Pmir'], l=L)

    # No explicit load capacitors/resistors were present in the original netlist.
    # If you later add C_load or R_load, follow the instruction to keep C_load fixed.

    return circuit


# -----------------------------------------------------------------------------
# Optimization parameter search ranges (for Optuna or similar tools)
# -----------------------------------------------------------------------------
# Notes on range choices:
# - Widths: nominal rule is 1×L .. 500×L. To guarantee that the original
#   provided width values are inside the search ranges (per your IMPORTANT requirement),
#   the upper bound is set to max(500*L, original_width). This ensures the initial
#   parameter is inside the allowed range while still respecting the 1-500× guideline
#   where possible.
# - Voltages: 0.8 - 1.2 × original value but capped at 1.2 V (supply).
# - All numeric values are in SI units (meters for W/L, volts for V).
# - Use 'log': True for width searches because they often span decades.

L_fixed = 0.045e-6  # fixed L value used in create_circuit (45 nm)
Vth = 0.22          # MOSFET threshold voltage to consider when selecting bias ranges

param_ranges_definition = {
    # Transistor widths (meters)
    'W_M1_M2': {
        'min': L_fixed * 1.0,                         # 1 × L
        'max': max(500.0 * L_fixed, 20e-6),           # 500×L or original if larger
        'log': True,
        'unit': 'm',
        'note': 'Input NMOS pair width'
    },
    'W_Mtail': {
        'min': L_fixed * 1.0,
        'max': max(500.0 * L_fixed, 2e-6),
        'log': True,
        'unit': 'm',
        'note': 'Tail NMOS current source width'
    },
    'W_Pmir': {
        'min': L_fixed * 1.0,
        # Original W_Pmir = 40e-6 exceeds 500*L (22.5e-6). To satisfy the
        # requirement that initial_params exactly equal the original value,
        # include the original value in the range by taking the max:
        'max': max(500.0 * L_fixed, 40e-6),
        'log': True,
        'unit': 'm',
        'note': 'PMOS mirror transistors width (left diode and right mirror)'
    },
    'W_Pcas': {
        'min': L_fixed * 1.0,
        'max': max(500.0 * L_fixed, 10e-6),
        'log': True,
        'unit': 'm',
        'note': 'PMOS cascode device width'
    },

    # DC bias voltages (Volts) - parameterized but constrained to 0.8-1.2× original
    'Vbias_tail': {
        'min': max(0.8 * 0.42, 0.0),   # 0.8× original (0.42 V) = 0.336 V
        'max': min(1.2 * 0.42, 1.2),   # 1.2× original but capped at 1.2 V = 0.504 V
        'log': False,
        'unit': 'V',
        'note': 'Tail NMOS gate bias. Keep above threshold (Vth ~= 0.22 V) for safe operation.'
    },
    'Vbias_pcas': {
        'min': max(0.8 * 0.78, 0.0),   # 0.8× original = 0.624 V
        'max': min(1.2 * 0.78, 1.2),   # 1.2× original = 0.936 V
        'log': False,
        'unit': 'V',
        'note': 'PMOS cascode gate bias. Capped at Vdd=1.2 V.'
    },
}

# -----------------------------------------------------------------------------
# Initial parameter values (EXACT original circuit values) - MUST be preserved
# -----------------------------------------------------------------------------
# These values are exactly the ones from your original netlist (unchanged).
initial_params = {
    # Transistor widths (meters) - EXACT original values
    'W_M1_M2': 20e-6,   # input NMOS pair
    'W_Mtail': 2e-6,    # tail current source NMOS
    'W_Pmir': 40e-6,    # PMOS mirror transistors (left diode + mirror) - original value
    'W_Pcas': 10e-6,    # PMOS cascodes

    # Bias voltages (Volts) - EXACT original values
    'Vbias_tail': 0.42,   # Tail NMOS gate bias (vb_n)
    'Vbias_pcas': 0.78,   # PMOS cascode gate bias (vb_p)
}

# -----------------------------------------------------------------------------
# Brief description of each parameter (physical meaning)
# -----------------------------------------------------------------------------
parameter_descriptions = {
    'W_M1_M2': 'Width of the input NMOS differential pair (meters). L fixed at 45 nm.',
    'W_Mtail': 'Width of the tail NMOS current source device (meters).',
    'W_Pmir': 'Width of the PMOS mirror devices (left diode-connected and right mirror) (meters).',
    'W_Pcas': 'Width of the PMOS cascode transistors (meters).',
    'Vbias_tail': 'Gate bias voltage for the tail NMOS (Volts). Controls tail current and common-source node potential.',
    'Vbias_pcas': 'Gate bias voltage for the PMOS cascode transistors (Volts). Controls cascode bias and headroom.',
}

# -----------------------------------------------------------------------------
# Sanity checks (ensures initial values lie inside defined ranges)
# -----------------------------------------------------------------------------
# These checks are only informative and can be removed in production.
for k, v in initial_params.items():
    if k in param_ranges_definition:
        r = param_ranges_definition[k]
        if not (r['min'] <= v <= r['max']):
            raise ValueError(f"Initial parameter '{k}' = {v} is outside defined range [{r['min']}, {r['max']}]. "
                             "Per the specification, initial_params must lie inside their search ranges.")

# End of module
```

Notes / rationale:
- create_circuit includes the precise import line "from model import nmos_params, pmos_params" as required.
- L is kept constant at the original exact value (0.045e-6). Only widths (W_...) are parameterized because W/L ratio is what matters.
- The width ranges follow the "1–500×L" rule. Where an original width (W_Pmir = 40e-6) exceeded 500×L (22.5e-6), the upper bound was extended to include the original value to satisfy the IMPORTANT requirement that initial_params contain the exact original values and lie within the search range.
- Voltages other than vdd and the input biases Vinp/Vinn are parameterized conservatively over 0.8–1.2× the original values and always capped at 1.2 V.
- initial_params contains EXACT original numeric values from your netlist (unchanged).
- No load capacitors or resistors were present in the original netlist; thus none are included or parameterized. If you later add compensation or load capacitors, follow your stated constraints (comp caps 0.5–5×, other caps 0.8–1.5×).