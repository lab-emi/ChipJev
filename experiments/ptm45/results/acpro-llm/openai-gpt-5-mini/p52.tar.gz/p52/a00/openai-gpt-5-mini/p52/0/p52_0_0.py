from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (Max Gain, no positive feedback)')
# Device models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC input/bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                   # Vdd = 1.2 V
circuit.V('vinp', 'Vinp', circuit.gnd, 0.6)                # DC input (common-mode)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.6)                # DC input (common-mode)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42)   # Tail bias (Vth + 0.2) = 0.42 V
# Nodes:
# D1 = output node (Vout)
# D2 = reference drain for mirror
# S  = common source node of input pair (connected to tail drain)
# NMOS differential pair
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S', model='nmos_model', w=12e-6, l=0.09e-6)
circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S', model='nmos_model', w=12e-6, l=0.09e-6)
# NMOS tail current source
circuit.MOSFET('Mtail', 'S', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=0.18e-6)
# PMOS active mirror load (Mp_ref is diode-connected, Mp_out mirrors it)
circuit.MOSFET('Mp_ref', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.18e-6)  # diode-connected PMOS on right node
circuit.MOSFET('Mp_out', 'D1', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.18e-6)  # mirror transistor to left node (output)
# Make the output node name explicit
# (D1 is the drain of M1 and Mp_out; expose it as Vout)
circuit.Node('Vout')  # ensures the node name exists in netlist (PySpice will use D1 as node; the explicit node is not strictly required)
# Note: No AC sources used. Inputs Vinp and Vinn are DC for operating point analysis.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
