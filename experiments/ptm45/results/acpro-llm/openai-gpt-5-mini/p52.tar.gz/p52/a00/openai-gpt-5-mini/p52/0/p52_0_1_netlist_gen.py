from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (Corrected)')
# Define the MOSFET models (unchanged)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC input/bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                   # Vdd = 1.2 V
circuit.V('vinp', 'Vinp', circuit.gnd, 0.6)                # DC input (common-mode)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.6)                # DC input (common-mode)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42)   # Tail bias (Vth + 0.2) = 0.42 V
# Nodes used:
# - 'Vout' is the explicit output node (previously implicitly 'D1', and 'circuit.Node' was incorrectly called)
# - 'Vmid' is the other drain node used as mirror reference (previous 'D2')
# - 'S' is the common source node of the input pair (tail drain)
# NMOS differential pair
# Modification: use explicit node name 'Vout' for left drain so the output node appears as requested.
# Also ensure bulk tied to source (bulk = 'S'), per rules.
# MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S', model='nmos_model', w=12e-6, l=45e-9)  # left input transistor
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'S', 'S', model='nmos_model', w=12e-6, l=45e-9)  # right input transistor (mirror reference drain = Vmid)
# NMOS tail current source
# Modification: bulk tied to source (ground) and L chosen longer than minimum to increase output resistance of tail.
circuit.MOSFET('Mtail', 'S', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=90e-9)
# PMOS active mirror load (diode-connected reference and mirror output)
# Modification: diode-connect the reference by tying gate to drain (node 'Vmid').
# PMOS bulks tied to Vdd (their sources).
circuit.MOSFET('Mp_ref', 'Vmid', 'Vmid', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=90e-9)  # diode-connected PMOS on right node
circuit.MOSFET('Mp_out', 'Vout', 'Vmid', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=90e-9)   # mirrored PMOS to left node (output)
# Notes about modifications:
# - Removed the incorrect call circuit.Node('Vout') (this was causing AttributeError).
# - Replaced implicit 'D1' with explicit 'Vout' so the output node name matches the requirement.
# - Ensured all bulks are tied to sources (NMOS bulks -> S or gnd, PMOS bulks -> Vdd).
# - Adjusted channel lengths to be consistent with 45 nm tech (L = 45e-9) for input devices; used slightly longer L for tail and loads (90e-9) to raise output resistance.
# - No AC sources used; all inputs are DC for operating point.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
