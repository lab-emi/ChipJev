from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact values from your provided netlist)
    'w_M1': 12e-6,     # left input transistor original width
    'w_M2': 12e-6,     # right input transistor original width
    'w_Mtail': 4e-6,   # tail transistor original width
    'w_Mp_ref': 12e-6, # diode-connected PMOS original width
    'w_Mp_out': 12e-6, # mirrored PMOS original width
    # Tail bias (exact original)
    'Vbias_tail': 0.42
}
