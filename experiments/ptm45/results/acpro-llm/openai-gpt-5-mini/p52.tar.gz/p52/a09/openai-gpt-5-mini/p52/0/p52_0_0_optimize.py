from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import is required to be present exactly as written INSIDE create_circuit
# per the user's requirements.
def create_circuit(params):
    from model import nmos_params, pmos_params  # required exact import statement
    circuit = Circuit('Single-Stage High-Gain Differential Op-Amp')
    # MOS models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and input sources (fixed as requested)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Supply (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)             # DC common-mode input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)             # DC common-mode input (fixed)
    # Parameterized bias voltage sources (these are parameterized but capped at <= 1.2 V)
    circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, params['Vbias_tail'])  # Tail NMOS gate bias
    circuit.V('bias_p', 'Vbias_p', circuit.gnd, params['Vbias_p'])          # PMOS cascode gate bias
    # Keep process length fixed (as requested)
    L = 0.045e-6  # 45 nm process length (kept constant)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'S', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)
    # Differential pair (NMOS)
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS cascode above diode-connected mirror transistor (left branch)
    circuit.MOSFET('Mc3', 'Pc3_d', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_Mc3'],
                   l=L)
    # Diode-connected PMOS that sets mirror reference (connected to D2)
    circuit.MOSFET('M3', 'D2', 'D2', 'Pc3_d', 'Pc3_d',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # PMOS cascode above mirror transistor (right/output branch)
    circuit.MOSFET('Mc4', 'Pout_s', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_Mc4'],
                   l=L)
    # Mirror PMOS (gate tied to diode node D2), supplies current to Vout
    circuit.MOSFET('M4', 'Vout', 'D2', 'Pout_s', 'Pout_s',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    return circuit
# Physical constants / considerations
L_fixed = 0.045e-6   # 45 nm (fixed device length)
Vth = 0.22           # MOSFET threshold voltage (given)
# Original (exact) values from provided circuit (these must be preserved as initial values)
initial_params = {
    # Transistor widths (exact original values)
    'w_Mtail': 5e-6,
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_Mc3': 20e-6,
    'w_M3': 40e-6,
    'w_Mc4': 20e-6,
    'w_M4': 40e-6,
    # Voltage biases (exact original values)
    'Vbias_tail': 0.42,
    'Vbias_p': 0.78,
}
# Parameter search ranges for optimization frameworks (e.g., Optuna)
# Notes:
# - W ranges are nominally 1xL .. 500xL. If an original width exceeds 500xL,
#   the upper bound has been extended to include the original value so that the
#   initial_params are inside the search range (this preserves the user's requirement).
# - Voltage ranges are 0.8..1.2× original, but clipped to <= 1.2 V (supply).
# - All voltage lower bounds are checked to be above Vth where sensible (keeps device biased).
#
# Each entry uses physical SI units (meters for widths, volts for voltages).
param_ranges_definition = {}
# Helper to compute width bounds while ensuring initial value is inside range
def _w_bounds(original_w):
    min_w = max(L_fixed, 1.0 * L_fixed)       # 1×L
    max_w_by_ratio = 500.0 * L_fixed          # 500×L
    # Ensure original fits in range: extend upper bound if original > 500xL
    max_w = max(max_w_by_ratio, original_w)
    return min_w, max_w
# Width parameters (log scale recommended; widths span orders of magnitude)
for key in ['w_Mtail', 'w_M1', 'w_M2', 'w_Mc3', 'w_M3', 'w_Mc4', 'w_M4']:
    ow = initial_params[key]
    wmin, wmax = _w_bounds(ow)
    param_ranges_definition[key] = {
        'min': wmin,
        'max': wmax,
        'log': True,
        'units': 'm',
        'note': f'Width of {key} (search 1×L .. 500×L nominal; extended to include original if larger).'
    }
# Voltage bias parameters: 0.8×..1.2× original but never exceeding 1.2 V.
def _v_bounds(original_v):
    vmin = max(0.8 * original_v, Vth)  # conservative lower bound, not below threshold
    vmax = min(1.2 * original_v, 1.2)  # cap at supply voltage
    # Ensure vmin <= vmax (should hold given original values and Vth constraints)
    if vmin > vmax:
        # fallback: set to a small window around the original but respecting caps
        vmin = max(original_v * 0.95, Vth)
        vmax = min(original_v * 1.05, 1.2)
    return vmin, vmax
for key in ['Vbias_tail', 'Vbias_p']:
    ov = initial_params[key]
    vmin, vmax = _v_bounds(ov)
    param_ranges_definition[key] = {
        'min': vmin,
        'max': vmax,
        'log': False,
        'units': 'V',
        'note': f'Bias voltage {key}: 0.8–1.2× original, clipped to <=1.2V and >=Vth where sensible.'
    }
# A short human-readable description of each parameter (physical meaning)
param_descriptions = {
    'w_Mtail': "Tail NMOS transistor width (sets tail current capability).",
    'w_M1': "Left input NMOS transistor width (differential pair).",
    'w_M2': "Right input NMOS transistor width (differential pair).",
    'w_Mc3': "PMOS cascode device width in the mirror (left branch).",
    'w_M3': "Diode-connected PMOS mirror reference transistor width (left diode device).",
    'w_Mc4': "PMOS cascode device width in the mirror (right/output branch).",
    'w_M4': "PMOS mirror output transistor width (supplies current to Vout).",
    'Vbias_tail': "Gate bias voltage for the tail NMOS (sets tail current operating point).",
    'Vbias_p': "Gate bias voltage for PMOS cascode devices (sets cascode operating point).",
}
# Example summary (for logging/inspection by the optimization framework)
# - L is fixed to 0.045e-6 (45 nm) as required.
# - Vdd, Vinp, Vinn are fixed (not part of search).
# - No load capacitors were present in the original netlist; if present they must remain fixed.
#
# Ensure initial_params exactly equal the original values and are within the ranges defined above.
# (The code above was written to guarantee that by extending width upper bounds when needed.)
