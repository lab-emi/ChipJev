from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain Differential Op-Amp')
# MOS models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Supply
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)             # DC common-mode input (no AC)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)             # DC common-mode input (no AC)
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42) # Tail NMOS gate bias (Vth + 0.2)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)      # PMOS cascode gate bias
# Node names used:
# Vout  - output node
# D2    - mirror/diode node (drain of right input transistor)
# S     - tail node (sources of M1/M2, drain of Mtail)
# Pc3_d - drain of Mc3 (source of diode PMOS M3)
# Pout_s- drain of Mc4 (source of mirror PMOS M4)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'S', 'Vbias_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# Differential pair (NMOS)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S',
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S',
               model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS cascode above diode-connected mirror transistor (left branch)
circuit.MOSFET('Mc3', 'Pc3_d', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Diode-connected PMOS that sets mirror reference (connected to D2)
circuit.MOSFET('M3', 'D2', 'D2', 'Pc3_d', 'Pc3_d',
               model='pmos_model', w=40e-6, l=0.045e-6)
# PMOS cascode above mirror transistor (right/output branch)
circuit.MOSFET('Mc4', 'Pout_s', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Mirror PMOS (gate tied to diode node D2), supplies current to Vout
circuit.MOSFET('M4', 'Vout', 'D2', 'Pout_s', 'Pout_s',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Create the simulator (operating-point / DC)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
