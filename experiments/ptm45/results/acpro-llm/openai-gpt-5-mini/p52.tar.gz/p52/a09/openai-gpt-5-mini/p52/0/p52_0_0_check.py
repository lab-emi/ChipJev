from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-Gain Differential Op-Amp')
# MOS models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Supply
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42) # Tail NMOS gate bias (Vth + 0.2)
circuit.V('bias_p', 'Vbias_p', circuit.gnd, 0.78)      # PMOS cascode gate bias
# Node names used:
# Vout  - output node
# D2    - mirror/diode node (drain of right input transistor)
# S     - tail node (sources of M1/M2, drain of Mtail)
# Pc3_d - drain of Mc3 (source of diode PMOS M3)
# Pout_s- drain of Mc4 (source of mirror PMOS M4)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'S', 'Vbias_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# Differential pair (NMOS)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S',
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S',
               model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS cascode above diode-connected mirror transistor (left branch)
circuit.MOSFET('Mc3', 'Pc3_d', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Diode-connected PMOS that sets mirror reference (connected to D2)
circuit.MOSFET('M3', 'D2', 'D2', 'Pc3_d', 'Pc3_d',
               model='pmos_model', w=40e-6, l=0.045e-6)
# PMOS cascode above mirror transistor (right/output branch)
circuit.MOSFET('Mc4', 'Pout_s', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Mirror PMOS (gate tied to diode node D2), supplies current to Vout
circuit.MOSFET('M4', 'Vout', 'D2', 'Pout_s', 'Pout_s',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Create the simulator (operating-point / DC)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p52/0/p52_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)