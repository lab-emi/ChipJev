from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    # Import device model parameter dictionaries (must be available in execution environment)
    from model import nmos_params, pmos_params
    circuit = Circuit('Two-Stage Cascoded Amplifier (Max Gain, No Positive Feedback)')
    # Attach MOSFET models (unchanged)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed - not part of optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Supply (fixed 1.2V)
    # Input voltage (fixed - to be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.5)         # DC input bias (fixed)
    # Parameterized bias voltages (subject to optimization/search)
    # NOTE: values are taken from params dict (ranges defined separately).
    circuit.V('bp1', 'Vbias_p1', circuit.gnd, params['v_bp1'])   # PMOS load bias stage 1
    circuit.V('bp2', 'Vbias_p2', circuit.gnd, params['v_bp2'])   # PMOS load bias stage 2
    circuit.V('bn1', 'Vb_n1', circuit.gnd, params['v_bn1'])      # NMOS cascode bias stage 1
    circuit.V('bn2', 'Vb_n2', circuit.gnd, params['v_bn2'])      # NMOS cascode bias stage 2
    # Process length (fixed for 45 nm technology)
    L = 45e-9
    # Stage 1: input cascoded CS
    # M1: input NMOS - drain N1, gate Vin, source gnd, bulk gnd
    circuit.M('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
              model='nmos_model',
              w=params['w_M1'],
              l=L)
    # M3: NMOS cascode above M1 - drain N2, gate Vb_n1, source N1, bulk tied to source N1
    circuit.M('M3', 'N2', 'Vb_n1', 'N1', 'N1',
              model='nmos_model',
              w=params['w_M3'],
              l=L)
    # M2: PMOS current-source load for stage1 - drain N2, gate Vbias_p1, source Vdd, bulk Vdd
    circuit.M('M2', 'N2', 'Vbias_p1', 'Vdd', 'Vdd',
              model='pmos_model',
              w=params['w_M2'],
              l=L)
    # Stage 2: cascoded CS
    # M4: stage-2 input NMOS - drain N3, gate N2 (stage1 output), source gnd, bulk gnd
    circuit.M('M4', 'N3', 'N2', circuit.gnd, circuit.gnd,
              model='nmos_model',
              w=params['w_M4'],
              l=L)
    # M5: NMOS cascode above M4 - drain Vout, gate Vb_n2, source N3, bulk tied to source N3
    circuit.M('M5', 'Vout', 'Vb_n2', 'N3', 'N3',
              model='nmos_model',
              w=params['w_M5'],
              l=L)
    # M6: PMOS current-source load for stage2 - drain Vout, gate Vbias_p2, source Vdd, bulk Vdd
    circuit.M('M6', 'Vout', 'Vbias_p2', 'Vdd', 'Vdd',
              model='pmos_model',
              w=params['w_M6'],
              l=L)
    # Vout node is the amplifier output
    return circuit
# ---------------------------
# Optimization parameter search ranges
# ---------------------------
# Technology length (fixed): L = 45e-9 (45 nm)
L_fixed = 45e-9
W_min = L_fixed * 1.0           # 1×L
W_max = L_fixed * 500.0         # 500×L (22.5e-6)
# Bias voltages: 0.8-1.2× original value, but never exceed 1.2V (supply).
# Original values: bp1=0.78, bp2=0.78, bn1=0.60, bn2=0.60
param_ranges_definition = {
    # Transistor widths (meters). Use log scaling for efficient search across decades.
    'w_M1': {'min': W_min, 'max': W_max, 'log': True},   # Was 4e-6
    'w_M3': {'min': W_min, 'max': W_max, 'log': True},   # Was 2e-6
    'w_M2': {'min': W_min, 'max': W_max, 'log': True},   # Was 8e-6 (PMOS)
    'w_M4': {'min': W_min, 'max': W_max, 'log': True},   # Was 8e-6
    'w_M5': {'min': W_min, 'max': W_max, 'log': True},   # Was 3e-6
    'w_M6': {'min': W_min, 'max': W_max, 'log': True},   # Was 16e-6 (PMOS)
    # Bias voltages (linear search). Boundaries are 0.8-1.2× original but clipped to <= 1.2V.
    # The lower limits are conservative (0.8× original). Keep in mind device Vth ~ 0.22V.
    'v_bp1': {'min': max(0.0, 0.8 * 0.78), 'max': min(1.2, 1.2 * 0.78), 'log': False},  # PMOS load bias stage 1
    'v_bp2': {'min': max(0.0, 0.8 * 0.78), 'max': min(1.2, 1.2 * 0.78), 'log': False},  # PMOS load bias stage 2
    'v_bn1': {'min': max(0.0, 0.8 * 0.60), 'max': min(1.2, 1.2 * 0.60), 'log': False},  # NMOS cascode bias stage 1
    'v_bn2': {'min': max(0.0, 0.8 * 0.60), 'max': min(1.2, 1.2 * 0.60), 'log': False},  # NMOS cascode bias stage 2
}
# ---------------------------
# Initial parameter values (EXACT original circuit values - MUST match the original netlist)
# ---------------------------
initial_params = {
    # Transistor widths (exact values from your original code)
    'w_M1': 4e-6,    # M1: input NMOS (original)
    'w_M3': 2e-6,    # M3: NMOS cascode above M1 (original)
    'w_M2': 8e-6,    # M2: PMOS load for stage1 (original)
    'w_M4': 8e-6,    # M4: stage-2 input NMOS (original)
    'w_M5': 3e-6,    # M5: NMOS cascode above M4 (original)
    'w_M6': 16e-6,   # M6: PMOS load for stage2 (original)
    # Bias voltages (exact values from your original code)
    'v_bp1': 0.78,   # Vbias_p1 original
    'v_bp2': 0.78,   # Vbias_p2 original
    'v_bn1': 0.60,   # Vb_n1 original
    'v_bn2': 0.60,   # Vb_n2 original
}
# ---------------------------
# Brief description of parameter meanings (physical interpretation)
# ---------------------------
# w_M1, w_M3, w_M2, w_M4, w_M5, w_M6:
#   Gate widths (W) of the corresponding MOSFETs in meters. L is fixed at 45 nm.
#   Changing W adjusts device current capability and gm, affecting gain, bandwidth, headroom, and output swing.
#
# v_bp1, v_bp2:
#   PMOS gate bias voltages for the stage-1 and stage-2 PMOS current-source loads.
#   These set the operating point/current of the PMOS loads and therefore the tail currents and output headroom.
#   Range constrained to 0.8-1.2× original values and clipped to not exceed Vdd=1.2V.
#
# v_bn1, v_bn2:
#   NMOS cascode gate bias voltages for the stage-1 and stage-2 cascode devices.
#   These set the cascode headroom and impact output resistance (and hence gain). Ranges are conservative 0.8-1.2× original.
#
# Notes:
#  - Vdd (1.2V) and the input DC bias (Vin = 0.5V) are intentionally fixed per requirements.
#  - Length L is held constant at 45 nm (process-limited). Only widths are included in optimization.
#  - No load or compensation capacitors or resistors were present in the original netlist; thus none are parameterized.
#  - All initial_params values are identical to the original circuit values and lie within the specified search ranges.
