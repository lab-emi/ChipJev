from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Cascoded Amplifier (Max Gain, No Positive Feedback)')
# MOSFET models (provided externally via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias sources (DC biases only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Supply
circuit.V('in', 'Vin', circuit.gnd, 0.5)         # DC input bias (operating point)
circuit.V('bp1', 'Vbias_p1', circuit.gnd, 0.78)  # PMOS load bias stage 1
circuit.V('bp2', 'Vbias_p2', circuit.gnd, 0.78)  # PMOS load bias stage 2
circuit.V('bn1', 'Vb_n1', circuit.gnd, 0.60)     # NMOS cascode bias stage 1
circuit.V('bn2', 'Vb_n2', circuit.gnd, 0.60)     # NMOS cascode bias stage 2
# Device geometric parameters
L = 0.045e-6  # 45 nm
# Stage 1: input cascoded CS
# M1: input NMOS - drain N1, gate Vin, source gnd, bulk gnd
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=L)
# M3: NMOS cascode above M1 - drain N2, gate Vb_n1, source N1, bulk tied to source N1
circuit.MOSFET('M3', 'N2', 'Vb_n1', 'N1', 'N1',
               model='nmos_model', w=2e-6, l=L)
# M2: PMOS current-source load for stage1 - drain N2, gate Vbias_p1, source Vdd, bulk Vdd
circuit.MOSFET('M2', 'N2', 'Vbias_p1', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=L)
# Stage 2: cascoded CS
# M4: stage-2 input NMOS - drain N3, gate N2 (stage1 output), source gnd, bulk gnd
circuit.MOSFET('M4', 'N3', 'N2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# M5: NMOS cascode above M4 - drain Vout, gate Vb_n2, source N3, bulk tied to source N3
circuit.MOSFET('M5', 'Vout', 'Vb_n2', 'N3', 'N3',
               model='nmos_model', w=3e-6, l=L)
# M6: PMOS current-source load for stage2 - drain Vout, gate Vbias_p2, source Vdd, bulk Vdd
circuit.MOSFET('M6', 'Vout', 'Vbias_p2', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=L)
# The node Vout is the output node as requested
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
