```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Three-Stage Cascoded CS Amplifier - Corrected OP Biasing v2')

    # MOSFET models (external model dictionaries)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V (fixed)

    # Input DC bias (fixed, not parameterized; swept externally during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.60)      # Vin DC = 0.60 V (fixed)

    # Parameterized bias source (originally 0.40 V)
    circuit.V('bpp', 'Vbp', circuit.gnd, params['Vbp'])

    # Process length (fixed for 45 nm technology)
    L = 45e-9

    # ---------- Stage 1 ----------
    # NMOS input device: M1
    circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # PMOS cascode active load for stage 1 (M2 top, M3 bottom)
    circuit.MOSFET('M2', 'P1', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)
    circuit.MOSFET('M3', 'N1', 'Vbp', 'P1', 'P1',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)

    # A moderate-value pull-up to Vdd (parameterized)
    # Original used 1@u_MΩ -> we expose this in MΩ units
    circuit.R('b1', 'N1', 'Vdd', params['r_b1'] * u_MΩ)

    # ---------- Stage 2 ----------
    # NMOS second stage: M4
    circuit.MOSFET('M4', 'N2', 'N1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L)

    # PMOS cascode active load for stage 2 (M5 top, M6 bottom)
    circuit.MOSFET('M5', 'Q1', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M5'],
                   l=L)
    circuit.MOSFET('M6', 'N2', 'Vbp', 'Q1', 'Q1',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L)

    # Moderate pull-up on node N2 to avoid floating node if necessary
    circuit.R('b2', 'N2', 'Vdd', params['r_b2'] * u_MΩ)

    # ---------- Stage 3 (Output) ----------
    # NMOS output stage: M7
    circuit.MOSFET('M7', 'Vout', 'N2', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M7'],
                   l=L)

    # PMOS cascode active load for stage 3 (M8 top, M9 bottom)
    circuit.MOSFET('M8', 'S1', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M8'],
                   l=L)
    circuit.MOSFET('M9', 'Vout', 'Vbp', 'S1', 'S1',
                   model='pmos_model',
                   w=params['w_M9'],
                   l=L)

    # Very weak pull-up on Vout to avoid a completely floating node in degenerate DC cases
    # Original used 100@u_MΩ -> parameterized in MΩ units
    circuit.R('bout', 'Vout', 'Vdd', params['r_bout'] * u_MΩ)

    return circuit


# -------------------------------
# Optimization parameter search ranges
# All widths in meters (m). Length is fixed at 45e-9 m.
# Resistances are expressed in MΩ units to match the original netlist style (1@u_MΩ, 100@u_MΩ).
# Voltage Vbp in volts (V).
#
# Constraints applied:
# - W in [L, 500*L] (i.e., 1 - 500 × L); log sampling recommended for widths.
# - Resistances in [0.5 - 2.0] × original (MΩ).
# - Voltages (except Vdd and Vin) in [0.8 - 1.2] × original, clipped to ≤ 1.2 V.
# -------------------------------
param_ranges_definition = {
    # Transistor widths (meters). 1×L .. 500×L
    'w_M1': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M1 original 8e-6
    'w_M2': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M2 original 40e-6
    'w_M3': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M3 original 40e-6
    'w_M4': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M4 original 10e-6
    'w_M5': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M5 original 40e-6
    'w_M6': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M6 original 40e-6
    'w_M7': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M7 original 12e-6
    'w_M8': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M8 original 40e-6
    'w_M9': {'min': 45e-9, 'max': 45e-9 * 500.0, 'log': True},   # M9 original 40e-6

    # Resistances (expressed in MΩ units). Ranges = 0.5 - 2.0 × original
    # b1 and b2 original = 1 MΩ
    'r_b1': {'min': 0.5, 'max': 2.0, 'log': True},    # MΩ
    'r_b2': {'min': 0.5, 'max': 2.0, 'log': True},    # MΩ
    # bout original = 100 MΩ
    'r_bout': {'min': 50.0, 'max': 200.0, 'log': True},  # MΩ

    # Bias voltage Vbp (volts). Range = 0.8 - 1.2 × original, clipped to ≤ 1.2 V
    # Original Vbp = 0.40 V -> 0.32 .. 0.48 V (within supply and > Vth considerations)
    'Vbp': {'min': 0.32, 'max': 0.48, 'log': False},
}

# -------------------------------
# Initial parameter values (EXACT original circuit values)
# These are the exact numeric values used in the provided circuit listing.
# NOTE: Resistances are expressed in MΩ units so they can be multiplied by u_MΩ
# when instantiating in PySpice (e.g., params['r_b1'] * u_MΩ).
# -------------------------------
initial_params = {
    # Transistor widths (m) - exact original values
    'w_M1': 8e-6,    # M1 original width
    'w_M2': 40e-6,   # M2 original width
    'w_M3': 40e-6,   # M3 original width
    'w_M4': 10e-6,   # M4 original width
    'w_M5': 40e-6,   # M5 original width
    'w_M6': 40e-6,   # M6 original width
    'w_M7': 12e-6,   # M7 original width
    'w_M8': 40e-6,   # M8 original width
    'w_M9': 40e-6,   # M9 original width

    # Resistances in MΩ (exact original values)
    'r_b1': 1.0,     # original 1@u_MΩ
    'r_b2': 1.0,     # original 1@u_MΩ
    'r_bout': 100.0, # original 100@u_MΩ

    # Bias voltage (exact original value)
    'Vbp': 0.40,     # original Vbp = 0.40 V
}

# -------------------------------
# Parameter descriptions (brief)
# -------------------------------
param_descriptions = {
    # Transistor widths
    'w_M1': "Width of NMOS input transistor M1 (m). Controls input device current and gm.",
    'w_M2': "Width of PMOS cascode device M2 (m). Controls cascode/top-device current handling.",
    'w_M3': "Width of PMOS cascode device M3 (m). Controls cascode/bottom-device load.",
    'w_M4': "Width of NMOS second-stage transistor M4 (m). Affects gain and stage drive.",
    'w_M5': "Width of PMOS cascode device M5 (m) for stage 2.",
    'w_M6': "Width of PMOS cascode device M6 (m) for stage 2.",
    'w_M7': "Width of NMOS output transistor M7 (m). Affects output drive and output node impedance.",
    'w_M8': "Width of PMOS cascode device M8 (m) for stage 3.",
    'w_M9': "Width of PMOS cascode device M9 (m) for stage 3.",

    # Resistances
    'r_b1': "Pull-up resistor on node N1 in MΩ (used to prevent floating when DC solution is marginal).",
    'r_b2': "Pull-up resistor on node N2 in MΩ (used to prevent floating when DC solution is marginal).",
    'r_bout': "Very weak pull-up resistor on Vout in MΩ (prevents fully floating output in degenerate DC cases).",

    # Bias voltage
    'Vbp': "PMOS gate bias voltage (V). Controls PMOS cascode conduction. Must be <= Vdd (1.2 V).",
}

# Quick sanity check comment:
# - All initial_params are exactly the original values provided in the netlist.
# - All initial values are inside the ranges defined in param_ranges_definition.
```

Notes:
- Length L is held fixed at 45e-9 m; W parameters are the only transistor geometry variables in the optimizer (W/L variation).
- vdd and Vin are intentionally fixed (not included in params); the optimizer must not change them. Vin is expected to be swept externally during DC analysis.
- Resistances are expressed in MΩ to match the original netlist units (1@u_MΩ, 100@u_MΩ). During circuit creation they are converted back to Ohm via multiplication by u_MΩ (PySpice Unit).
- The Vbp range (0.32–0.48 V) is a conservative 0.8–1.2× window around the original 0.40 V while respecting the 1.2 V supply and considering transistor threshold (Vth ≈ 0.22 V).