from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded CS Amplifier - Max Gain')
# Define the MOSFET models using provided parameter dictionaries
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Supply and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
# Input DC bias for operating point (no AC)
circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC = Vth + 0.20 = 0.42 V
# PMOS gate/cascode bias (single convenient bias chosen)
circuit.V('bpp', 'Vbp', circuit.gnd, 0.78)     # Vbp = 1.2 - (Vth + 0.20) = 0.78 V
# Device sizing (45 nm technology)
L = 45e-9
# Stage 1
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)        # Input NMOS
# PMOS cascode active load for stage 1: top M2, bottom M3
circuit.MOSFET('M2', 'P1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)      # PMOS top (source tied to Vdd)
circuit.MOSFET('M3', 'N1', 'Vbp', 'P1', 'P1',
               model='pmos_model', w=20e-6, l=L)      # PMOS bottom (cascode)
# Stage 2
circuit.MOSFET('M4', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)       # 2nd stage NMOS
# PMOS cascode active load for stage 2
circuit.MOSFET('M5', 'Q1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
circuit.MOSFET('M6', 'N2', 'Vbp', 'Q1', 'Q1',
               model='pmos_model', w=20e-6, l=L)
# Stage 3 (output stage)
circuit.MOSFET('M7', 'Vout', 'N2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)       # Output NMOS
# PMOS cascode active load for stage 3
circuit.MOSFET('M8', 'S1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
circuit.MOSFET('M9', 'Vout', 'Vbp', 'S1', 'S1',
               model='pmos_model', w=20e-6, l=L)
# End: create simulator (no AC sources, operating-point analysis scenario)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
