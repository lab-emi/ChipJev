from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded CS Amplifier - Corrected OP Biasing')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC = Vth + 0.20 = 0.42 V
# Use a PMOS gate/cascode bias that ensures PMOS devices are on (conservative)
circuit.V('bpp', 'Vbp', circuit.gnd, 0.78)     # Vbp = 1.2 - (Vth + 0.20) = 0.78 V
# Device sizing (45 nm technology)
L = 45e-9
# ---------- Stage 1 ----------
# NMOS input device: M1
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# PMOS cascode active load for stage 1 (M2 top, M3 bottom)
circuit.MOSFET('M2', 'P1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
circuit.MOSFET('M3', 'N1', 'Vbp', 'P1', 'P1',
               model='pmos_model', w=20e-6, l=L)
# Weak pull-up on node N1 to define a DC operating point and avoid floating node
# This helps ensure the next-stage gate (M4) has a reasonable DC bias so M4 can conduct.
circuit.R('b1', 'N1', 'Vdd', 10@u_MΩ)
# ---------- Stage 2 ----------
# NMOS second stage: M4
circuit.MOSFET('M4', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# PMOS cascode active load for stage 2 (M5 top, M6 bottom)
circuit.MOSFET('M5', 'Q1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
circuit.MOSFET('M6', 'N2', 'Vbp', 'Q1', 'Q1',
               model='pmos_model', w=20e-6, l=L)
# Weak pull-up on node N2 to define DC operating point (prevents floating and enables M7 bias)
circuit.R('b2', 'N2', 'Vdd', 10@u_MΩ)
# ---------- Stage 3 (Output) ----------
# NMOS output stage: M7
circuit.MOSFET('M7', 'Vout', 'N2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)
# PMOS cascode active load for stage 3 (M8 top, M9 bottom)
circuit.MOSFET('M8', 'S1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
circuit.MOSFET('M9', 'Vout', 'Vbp', 'S1', 'S1',
               model='pmos_model', w=20e-6, l=L)
# Optional weak pull-up on Vout to avoid a floating node in pathological cases (very large value)
circuit.R('bout', 'Vout', 'Vdd', 100@u_MΩ)
# End: create simulator (operating-point)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
