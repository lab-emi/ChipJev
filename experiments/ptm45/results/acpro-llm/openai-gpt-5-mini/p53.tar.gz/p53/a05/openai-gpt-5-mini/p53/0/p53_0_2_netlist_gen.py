from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded CS Amplifier - Corrected OP Biasing v2')
# Define MOSFET models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
# Raise the input DC bias to ensure NMOS stages conduct reliably
circuit.V('in', 'Vin', circuit.gnd, 0.60)      # Vin DC = 0.60 V (higher than Vth + margin)
# Lower the PMOS gate bias (more negative relative to source) so PMOS stacks can supply current
circuit.V('bpp', 'Vbp', circuit.gnd, 0.40)     # Vbp = 0.40 V -> Vsg ~ 0.8 V (stronger PMOS conduction)
# Device sizing (45 nm technology)
L = 45e-9
# ---------- Stage 1 ----------
# NMOS input device: M1
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# PMOS cascode active load for stage 1 (M2 top, M3 bottom)
circuit.MOSFET('M2', 'P1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M3', 'N1', 'Vbp', 'P1', 'P1',
               model='pmos_model', w=40e-6, l=L)
# A moderate-value pull-up to Vdd to prevent pathological floating but not dominate currents
# This helps when operating point solutions are marginal; value chosen large enough to be non-invasive.
circuit.R('b1', 'N1', 'Vdd', 1@u_MΩ)
# ---------- Stage 2 ----------
# NMOS second stage: M4
circuit.MOSFET('M4', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# PMOS cascode active load for stage 2 (M5 top, M6 bottom)
circuit.MOSFET('M5', 'Q1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M6', 'N2', 'Vbp', 'Q1', 'Q1',
               model='pmos_model', w=40e-6, l=L)
# Moderate pull-up on node N2 to avoid floating node if necessary
circuit.R('b2', 'N2', 'Vdd', 1@u_MΩ)
# ---------- Stage 3 (Output) ----------
# NMOS output stage: M7
circuit.MOSFET('M7', 'Vout', 'N2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)
# PMOS cascode active load for stage 3 (M8 top, M9 bottom)
circuit.MOSFET('M8', 'S1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M9', 'Vout', 'Vbp', 'S1', 'S1',
               model='pmos_model', w=40e-6, l=L)
# Very weak pull-up on Vout to avoid a completely floating node in degenerate DC cases
circuit.R('bout', 'Vout', 'Vdd', 100@u_MΩ)
# End: create simulator (operating-point)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
