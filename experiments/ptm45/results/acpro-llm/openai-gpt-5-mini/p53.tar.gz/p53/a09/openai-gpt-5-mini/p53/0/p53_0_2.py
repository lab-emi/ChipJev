from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage High-Gain Amplifier (Corrected Bias for M1)')
# Device models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias sources (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Vdd = 1.2 V
# Set Vin high enough to ensure M1 is ON: VGS(M1) > Vth (Vth = 0.22 V).
# Choose Vin = 0.60 V to give M1 a comfortable overdrive.
circuit.V('in', 'Vin', circuit.gnd, 0.60)              # Vin DC operating bias
# PMOS gate biases (set to provide active current load and cascoding)
# Using Vbias ~ Vdd - |Vth| - 0.2 = 0.78 V (as previously used)
circuit.V('pb', 'Vbias_p', circuit.gnd, 0.78)         # PMOS gate bias
circuit.V('pbc', 'Vbias_pcas', circuit.gnd, 0.78)     # PMOS cascode gate bias
# Geometry defaults (45 nm technology)
Lmin = 0.045e-6  # 45 nm
# ---------- Stage 1: NMOS input common-source (M1) with cascoded PMOS active load (MP1+MP2) ----------
# M1: drain = D1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'D1', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model',
                w=20e-6, l=Lmin)
# PMOS load stack for stage1:
# MP1 (top): source = Vdd, drain = Pnode1, gate = Vbias_p, bulk = Vdd
circuit.MOSFET('MP1', 'Pnode1', 'Vbias_p', 'Vdd', 'Vdd',
                model='pmos_model',
                w=30e-6, l=Lmin)
# MP2 (cascode bottom): source = Pnode1, drain = D1, gate = Vbias_pcas, bulk = Vdd
circuit.MOSFET('MP2', 'D1', 'Vbias_pcas', 'Pnode1', 'Vdd',
                model='pmos_model',
                w=30e-6, l=Lmin)
# ---------- Stage 2: NMOS common-source (M4) with cascoded PMOS active load (MP5+MP6) ----------
# M4: drain = Vout, gate = D1 (stage1 output), source = gnd, bulk = gnd
circuit.MOSFET('M4', 'Vout', 'D1', circuit.gnd, circuit.gnd,
                model='nmos_model',
                w=40e-6, l=Lmin)
# PMOS load stack for stage2:
# MP5 (top): source = Vdd, drain = Pnode2, gate = Vbias_p, bulk = Vdd
circuit.MOSFET('MP5', 'Pnode2', 'Vbias_p', 'Vdd', 'Vdd',
                model='pmos_model',
                w=60e-6, l=Lmin)
# MP6 (cascode bottom): source = Pnode2, drain = Vout, gate = Vbias_pcas, bulk = Vdd
circuit.MOSFET('MP6', 'Vout', 'Vbias_pcas', 'Pnode2', 'Vdd',
                model='pmos_model',
                w=60e-6, l=Lmin)
# End: create simulator for DC operating point / further analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
