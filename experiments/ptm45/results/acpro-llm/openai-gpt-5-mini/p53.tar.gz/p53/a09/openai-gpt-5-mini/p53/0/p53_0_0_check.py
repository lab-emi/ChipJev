from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage High-Gain Amplifier (Cascoded PMOS Loads)')
# Device models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias sources (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('pb', 'Vbias_p', circuit.gnd, 0.78)         # PMOS gate bias ~ Vdd - |Vth| - 0.2
circuit.V('pbc', 'Vbias_pcas', circuit.gnd, 0.78)     # PMOS cascode gate bias (same nominal)
# Geometry defaults (45 nm technology)
Lmin = 0.045e-6  # 45 nm
# ---------- Stage 1: NMOS input common-source (M1) with cascoded PMOS active load (MP1+MP2) ----------
# M1: drain = D1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'D1', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model',
                w=20e-6, l=Lmin)
# PMOS load stack for stage1:
# MP1 (top): source = Vdd, drain = Pnode1, gate = Vbias_p, bulk = Vdd
circuit.MOSFET('MP1', 'Pnode1', 'Vbias_p', 'Vdd', 'Vdd',
                model='pmos_model',
                w=30e-6, l=Lmin)
# MP2 (cascode bottom): source = Pnode1, drain = D1, gate = Vbias_pcas, bulk = Vdd
circuit.MOSFET('MP2', 'D1', 'Vbias_pcas', 'Pnode1', 'Vdd',
                model='pmos_model',
                w=30e-6, l=Lmin)
# ---------- Stage 2: NMOS common-source (M4) with cascoded PMOS active load (MP5+MP6) ----------
# M4: drain = Vout, gate = D1 (stage1 output), source = gnd, bulk = gnd
circuit.MOSFET('M4', 'Vout', 'D1', circuit.gnd, circuit.gnd,
                model='nmos_model',
                w=40e-6, l=Lmin)
# PMOS load stack for stage2:
# MP5 (top): source = Vdd, drain = Pnode2, gate = Vbias_p, bulk = Vdd
circuit.MOSFET('MP5', 'Pnode2', 'Vbias_p', 'Vdd', 'Vdd',
                model='pmos_model',
                w=60e-6, l=Lmin)
# MP6 (cascode bottom): source = Pnode2, drain = Vout, gate = Vbias_pcas, bulk = Vdd
circuit.MOSFET('MP6', 'Vout', 'Vbias_pcas', 'Pnode2', 'Vdd',
                model='pmos_model',
                w=60e-6, l=Lmin)
# End: create simulator for DC operating point / further analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)