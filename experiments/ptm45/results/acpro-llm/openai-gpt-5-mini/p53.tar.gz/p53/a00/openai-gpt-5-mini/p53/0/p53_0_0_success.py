from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Cascoded High-Gain Amplifier')
# Define MOSFET models (assumed provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)         # Vin DC bias (input node)
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.78)    # PMOS load gate bias (Vdd - Vth - 0.2)
circuit.V('bc', 'Vbias_cn', circuit.gnd, 0.60)   # NMOS cascode gate bias
# Stage-1: NMOS M1 (input) with cascode M3 and PMOS load M2
# Nodes: nb1 (drain of M1 / source of M3), n1 (drain of M3 and drain of M2) 
circuit.MOSFET('M1', 'nb1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M3', 'n1', 'Vbias_cn', 'nb1', 'nb1',
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Stage-2: NMOS M4 (input) with cascode M6 and PMOS load M5
# Nodes: nb2 (drain of M4 / source of M6), n2 (drain of M6 and drain of M5) -> Vout
circuit.MOSFET('M4', 'nb2', 'n1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M6', 'Vout', 'Vbias_cn', 'nb2', 'nb2',
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M5', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# End of topology definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
