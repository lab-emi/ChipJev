```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the Two-Stage Cascoded High-Gain Amplifier with parameterized
    transistor widths and bias voltages.

    Notes:
    - Keeps Vdd and input Vin fixed as required.
    - Transistor lengths are fixed to the original value (45 nm expressed as 0.045e-6).
    - The function expects params to contain the W (width) values for each MOSFET
      and the bias voltages Vbias_p and Vbias_cn.
    """
    circuit = Circuit('Two-Stage Cascoded High-Gain Amplifier')

    # Keep the exact import line requested (models provided externally)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd fixed at 1.2 V

    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)         # Vin fixed at 0.42 V

    # Parameterized bias voltages (subject to optimization but constrained)
    # These are the only non-Vdd, non-input voltage sources to be parameterized.
    circuit.V('bp', 'Vbias_p', circuit.gnd, params['Vbias_p'])    # PMOS load gate bias
    circuit.V('bc', 'Vbias_cn', circuit.gnd, params['Vbias_cn'])  # NMOS cascode gate bias

    # Fixed channel length as in original netlist (45 nm)
    L_fixed = 0.045e-6  # exact original length expression preserved

    # Stage-1: NMOS M1 (input) with cascode M3 and PMOS load M2
    circuit.MOSFET('M1', 'nb1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)
    circuit.MOSFET('M3', 'n1', 'Vbias_cn', 'nb1', 'nb1',
                   model='nmos_model',
                   w=params['w_M3'],
                   l=L_fixed)
    circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_fixed)

    # Stage-2: NMOS M4 (input) with cascode M6 and PMOS load M5
    circuit.MOSFET('M4', 'nb2', 'n1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L_fixed)
    circuit.MOSFET('M6', 'Vout', 'Vbias_cn', 'nb2', 'nb2',
                   model='nmos_model',
                   w=params['w_M6'],
                   l=L_fixed)
    circuit.MOSFET('M5', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M5'],
                   l=L_fixed)

    # No explicit load capacitors present in the original netlist to fix here.
    # If a downstream fixed load C is required, add it as a fixed value (not parameterized).

    return circuit

# ========================================================================
# Parameter search ranges for optimization (suitable for Optuna or similar)
# ========================================================================
# Constraints applied:
# - Transistor width W: between 1×L and 500×L (L = 45 nm => range [45e-9, 22.5e-6])
# - Bias voltages (except Vdd and Vin): 0.8–1.2× original, but never exceeding 1.2 V
# - All initial parameter values below are EXACT original values from the provided netlist
# ========================================================================

param_ranges_definition = {
    # Transistor widths (meters). Use log scale search since device sizing often spans orders of magnitude.
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6

    # Bias voltages (volts). 0.8-1.2× original values, but caps never exceed 1.2 V.
    # Original Vbias_p = 0.78 V => range = [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    # Original Vbias_cn = 0.60 V => range = [0.48, 0.72]
    'Vbias_p': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
    'Vbias_cn': {'min': 0.8 * 0.60, 'max': min(1.2 * 0.60, 1.2), 'log': False},
}

# ========================================================================
# Initial parameters (EXACT original values from your circuit code)
# IMPORTANT: These values are unchanged from your original netlist and
# must be preserved as the starting point for optimization.
# ========================================================================
initial_params = {
    # Transistor widths (exact originals)
    'w_M1': 20e-6,   # original width for M1
    'w_M3': 10e-6,   # original width for M3
    'w_M2': 20e-6,   # original width for M2
    'w_M4': 20e-6,   # original width for M4
    'w_M6': 10e-6,   # original width for M6
    'w_M5': 20e-6,   # original width for M5

    # Bias voltages (exact originals)
    'Vbias_p': 0.78,  # original Vbias_p
    'Vbias_cn': 0.60, # original Vbias_cn
}

# ========================================================================
# Parameter descriptions (brief physical meaning)
# ========================================================================
# w_M1  : Width (W) of input NMOS M1. Larger W increases current drive and reduces Vov.
# w_M3  : Width of NMOS cascode M3 in stage 1. Affects cascode headroom and output resistance.
# w_M2  : Width of PMOS load M2 (stage 1). Affects load current and output resistance.
# w_M4  : Width of input NMOS M4 (stage 2). Similar role to M1 for second stage.
# w_M6  : Width of NMOS cascode M6 in stage 2. Affects second-stage cascode performance.
# w_M5  : Width of PMOS load M5 (stage 2). Affects second-stage load current and output resistance.
# Vbias_p: PMOS gate bias used for the load devices. Controls PMOS operating point; must be compatible with Vdd and Vth.
# Vbias_cn: NMOS cascode gate bias. Sets cascode device Vgs/Vds and cascode headroom.

# ========================================================================
# Notes and tips:
# - The fixed transistor length used in this implementation is L = 0.045e-6 (45 nm),
#   exactly as in your original netlist.
# - All voltage parameter ranges ensure values never exceed Vdd = 1.2 V.
# - The ranges above are conservative (biases constrained to 0.8–1.2× originals),
#   mindful of Vth = 0.22 V to keep devices in intended operating regions.
# - There were no explicit resistors or capacitors in your original netlist;
#   hence none are parameterized here. If you add passive components later,
#   follow the multiplier rules you gave (resistors 0.5–2×, comp caps 0.5–5×, etc.).
# ========================================================================
```