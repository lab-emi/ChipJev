from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded Amplifier - High Gain')
# Define device models (45 nm nominal)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)    # PMOS current source gate bias
circuit.V('biasn', 'Vbias_nc', circuit.gnd, 0.6)    # NMOS cascode gate bias
# Stage 1
# M1: input NMOS (common-source)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=0.045e-6)
# MC1: NMOS cascode for M1 (source = N1, drain = N1_top)
circuit.MOSFET('MC1', 'N1_top', 'Vbias_nc', 'N1', 'N1',
               model='nmos_model', w=1e-6, l=0.09e-6)
# MP1: PMOS current-source load for stage1
circuit.MOSFET('MP1', 'N1_top', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=5e-6, l=0.09e-6)
# Stage 2
# M2: NMOS common-source, gate driven by stage1 output (N1_top)
circuit.MOSFET('M2', 'N2', 'N1_top', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=0.045e-6)
# MC2: cascode for M2
circuit.MOSFET('MC2', 'N2_top', 'Vbias_nc', 'N2', 'N2',
               model='nmos_model', w=1e-6, l=0.09e-6)
# MP2: PMOS current-source load for stage2
circuit.MOSFET('MP2', 'N2_top', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=5e-6, l=0.09e-6)
# Stage 3
# M3: NMOS common-source, gate driven by stage2 output (N2_top)
circuit.MOSFET('M3', 'N3', 'N2_top', circuit.gnd, circuit.gnd,
               model='nmos_model', w=3e-6, l=0.045e-6)
# MC3: cascode for M3; top node is the final output Vout
circuit.MOSFET('MC3', 'Vout', 'Vbias_nc', 'N3', 'N3',
               model='nmos_model', w=1e-6, l=0.09e-6)
# MP3: PMOS current-source load for stage3 (defines Vout DC)
circuit.MOSFET('MP3', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=6e-6, l=0.09e-6)
# End: instantiate simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)