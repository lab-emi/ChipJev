# Corrected PySpice netlist for the three-stage cascoded amplifier
# Modifications are explained inline as comments prefixed with "MOD:".
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded Amplifier - Corrected')
# Define device models (45 nm nominal)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
# MOD: Ensure DC bias nodes exist and are set so NMOS/PMOS operate in saturation.
#      Values chosen relative to Vth = 0.22 V (as given). These produce non-zero bias currents.
circuit.V('in', 'Vin', circuit.gnd, 0.60)           # Vin DC bias = 0.60 V (input bias)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.40)    # PMOS gate bias -> Vsg = Vdd - Vbias_p = 0.8 V
circuit.V('biasn', 'Vbias_nc', circuit.gnd, 0.90)   # NMOS cascode gate bias
# Geometry constants (meters)
L_min = 45e-9
L_long = 90e-9
# MOD: Use the correct PySpice MOSFET call signature:
#      circuit.MOSFET(name, drain, gate, source, bulk, model='model_name', w=..., l=...)
#      Previously the model string was passed positionally causing a "Number of args mismatch".
# MOD: Ensure each MOSFET's bulk node is connected to its source node (per instruction).
# Stage 1
# M1: input NMOS (common-source)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=3e-6, l=L_min)
# MC1: NMOS cascode for M1 (source = N1, drain = N1_top), bulk tied to source N1
circuit.MOSFET('MC1', 'N1_top', 'Vbias_nc', 'N1', 'N1',
               model='nmos_model', w=1e-6, l=L_long)
# MP1: PMOS active current-source load for stage1 (source and bulk tied to Vdd)
circuit.MOSFET('MP1', 'N1_top', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=6e-6, l=L_long)
# Stage 2
# M2: NMOS common-source, gate driven by stage1 output (N1_top)
circuit.MOSFET('M2', 'N2', 'N1_top', circuit.gnd, circuit.gnd,
               model='nmos_model', w=3e-6, l=L_min)
# MC2: cascode for M2, bulk tied to source N2
circuit.MOSFET('MC2', 'N2_top', 'Vbias_nc', 'N2', 'N2',
               model='nmos_model', w=1e-6, l=L_long)
# MP2: PMOS active current-source load for stage2 (source and bulk tied to Vdd)
circuit.MOSFET('MP2', 'N2_top', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=6e-6, l=L_long)
# Stage 3
# M3: NMOS common-source, gate driven by stage2 output (N2_top)
circuit.MOSFET('M3', 'N3', 'N2_top', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=L_min)
# MC3: cascode for M3; top node is the final output Vout. bulk tied to source N3
circuit.MOSFET('MC3', 'Vout', 'Vbias_nc', 'N3', 'N3',
               model='nmos_model', w=1e-6, l=L_long)
# MP3: PMOS active current-source load for stage3 (source and bulk tied to Vdd)
circuit.MOSFET('MP3', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=7e-6, l=L_long)
# MOD: All MOSFET bulks are tied to their sources in the devices above.
# MOD: All MOSFET model parameters are passed via model='...' keyword (fixes previous arg mismatch).
# Instantiate simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
