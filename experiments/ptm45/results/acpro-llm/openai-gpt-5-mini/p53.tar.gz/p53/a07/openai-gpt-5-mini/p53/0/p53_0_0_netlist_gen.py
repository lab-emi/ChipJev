from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded Amplifier - High Gain')
# Define device models (45 nm nominal)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias = Vth + 0.2 = 0.42 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)    # PMOS current source gate bias
circuit.V('biasn', 'Vbias_nc', circuit.gnd, 0.6)    # NMOS cascode gate bias
# Stage 1
# M1: input NMOS (common-source)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=0.045e-6)
# MC1: NMOS cascode for M1 (source = N1, drain = N1_top)
circuit.MOSFET('MC1', 'N1_top', 'Vbias_nc', 'N1', 'N1',
               model='nmos_model', w=1e-6, l=0.09e-6)
# MP1: PMOS current-source load for stage1
circuit.MOSFET('MP1', 'N1_top', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=5e-6, l=0.09e-6)
# Stage 2
# M2: NMOS common-source, gate driven by stage1 output (N1_top)
circuit.MOSFET('M2', 'N2', 'N1_top', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=0.045e-6)
# MC2: cascode for M2
circuit.MOSFET('MC2', 'N2_top', 'Vbias_nc', 'N2', 'N2',
               model='nmos_model', w=1e-6, l=0.09e-6)
# MP2: PMOS current-source load for stage2
circuit.MOSFET('MP2', 'N2_top', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=5e-6, l=0.09e-6)
# Stage 3
# M3: NMOS common-source, gate driven by stage2 output (N2_top)
circuit.MOSFET('M3', 'N3', 'N2_top', circuit.gnd, circuit.gnd,
               model='nmos_model', w=3e-6, l=0.045e-6)
# MC3: cascode for M3; top node is the final output Vout
circuit.MOSFET('MC3', 'Vout', 'Vbias_nc', 'N3', 'N3',
               model='nmos_model', w=1e-6, l=0.09e-6)
# MP3: PMOS current-source load for stage3 (defines Vout DC)
circuit.MOSFET('MP3', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=6e-6, l=0.09e-6)
# End: instantiate simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
