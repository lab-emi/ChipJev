from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import must appear exactly as written inside create_circuit per requirements:
# from model import nmos_params, pmos_params
L = 45e-9  # Process length (45 nm) - kept constant, W will be parameterized
def create_circuit(params):
    """
    Create the two-stage cascoded high-gain amplifier using parameter dictionary `params`.
    This function imports device model parameter dictionaries from model.py (exact import required).
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Two-Stage Cascoded High-Gain Amplifier')
    # MOSFET models (assumed provided by model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V (fixed)
    # Input voltage (fixed - swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin = 0.42 V (fixed, as in original)
    # Other voltage bias sources (parameterized, but constrained not to exceed 1.2V)
    circuit.V('bn', 'Vbn', circuit.gnd, params['V_bn'])   # NMOS cascode gate bias
    circuit.V('bp', 'Vbp', circuit.gnd, params['V_bp'])   # PMOS gate bias
    # Stage 1
    # M1: NMOS input transistor (drain = Vx1, gate = Vin, source = gnd, bulk = gnd)
    circuit.MOSFET('M1', 'Vx1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    # MC1: NMOS cascode for M1 (drain = Vtop1, gate = Vbn, source = Vx1, bulk = Vx1)
    circuit.MOSFET('MC1', 'Vtop1', 'Vbn', 'Vx1', 'Vx1',
                   model='nmos_model',
                   w=params['w_MC1'],
                   l=L)
    # M2: PMOS active load for stage 1 (drain = Vtop1, gate = Vbp, source = Vdd, bulk = Vdd)
    circuit.MOSFET('M2', 'Vtop1', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)
    # Stage 2
    # M4: NMOS input transistor of stage 2 (drain = Vx2, gate = Vtop1, source = gnd, bulk = gnd)
    circuit.MOSFET('M4', 'Vx2', 'Vtop1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L)
    # MC2: NMOS cascode for M4 (drain = Vout, gate = Vbn, source = Vx2, bulk = Vx2)
    circuit.MOSFET('MC2', 'Vout', 'Vbn', 'Vx2', 'Vx2',
                   model='nmos_model',
                   w=params['w_MC2'],
                   l=L)
    # M5: PMOS active load for stage 2 (drain = Vout, gate = Vbp, source = Vdd, bulk = Vdd)
    circuit.MOSFET('M5', 'Vout', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M5'],
                   l=L)
    return circuit
# -------------------------
# Parameter search ranges
# -------------------------
# Constraints applied:
# - Transistor widths (W) range: 1×L .. 500×L  => [45e-9, 22.5e-6]
# - All other voltages (except Vdd and Vin) range: 0.8..1.2 × original, but capped at 1.2 V
# - Initial parameter values (initial_params) must match exactly the original netlist values
param_ranges_definition = {
    # Transistor widths (meters). Use log scale for wide dynamic ranges.
    'w_M1':  {'min': 1 * L,        'max': 500 * L,     'log': True},  # original 10e-6
    'w_MC1': {'min': 1 * L,        'max': 500 * L,     'log': True},  # original 4e-6
    'w_M2':  {'min': 1 * L,        'max': 500 * L,     'log': True},  # original 20e-6 (PMOS)
    'w_M4':  {'min': 1 * L,        'max': 500 * L,     'log': True},  # original 8e-6
    'w_MC2': {'min': 1 * L,        'max': 500 * L,     'log': True},  # original 3e-6
    'w_M5':  {'min': 1 * L,        'max': 500 * L,     'log': True},  # original 20e-6 (PMOS)
    # Bias voltages: 0.8-1.2× original but never exceed 1.2 V (linear scale)
    # Original V_bn = 0.42 V => range [0.8*0.42, 1.2*0.42] = [0.336, 0.504]
    'V_bn':  {'min': 0.8 * 0.42,   'max': min(1.2 * 0.42, 1.2), 'log': False},
    # Original V_bp = 0.78 V => range [0.8*0.78, 1.2*0.78] = [0.624, 0.936]
    'V_bp':  {'min': 0.8 * 0.78,   'max': min(1.2 * 0.78, 1.2), 'log': False},
}
# -------------------------
# Initial parameter values
# (MUST match EXACT original circuit values)
# -------------------------
initial_params = {
    # Transistor widths (meters) - EXACT original values from the provided netlist
    'w_M1':  10e-6,
    'w_MC1': 4e-6,
    'w_M2':  20e-6,
    'w_M4':  8e-6,
    'w_MC2': 3e-6,
    'w_M5':  20e-6,
    # Voltage biases - EXACT original values
    'V_bn':  0.42,
    'V_bp':  0.78,
}
# -------------------------
# Human-readable descriptions for each parameter
# -------------------------
param_descriptions = {
    'w_M1':  "Width of input NMOS transistor M1 (affects gm, current, and input device sizing). L fixed at 45nm.",
    'w_MC1': "Width of NMOS cascode transistor MC1 (affects output resistance of stage 1/cascode performance).",
    'w_M2':  "Width of PMOS active load M2 (affects load current, output resistance of stage 1).",
    'w_M4':  "Width of NMOS input transistor of stage 2 (affects stage 2 gain and bandwidth).",
    'w_MC2': "Width of NMOS cascode transistor MC2 (affects output resistance of stage 2/cascode performance).",
    'w_M5':  "Width of PMOS active load M5 (affects load current, output resistance of stage 2).",
    'V_bn':  "NMOS cascode gate bias (Vbn). Controls cascode transistor Vgs; range chosen conservative around original 0.42V.",
    'V_bp':  "PMOS gate bias (Vbp). Controls PMOS load Vgs; range chosen conservative around original 0.78V.",
}
# Note:
# - Vdd is fixed at 1.2 V and is intentionally NOT part of the parameter search.
# - Vin is fixed at 0.42 V per original netlist and should be swept externally if different operating points are needed.
# - No explicit load capacitors or resistors were present in the original netlist, so none are parameterized here.
# - All initial_params have been verified to lie within their corresponding ranges defined in param_ranges_definition.
