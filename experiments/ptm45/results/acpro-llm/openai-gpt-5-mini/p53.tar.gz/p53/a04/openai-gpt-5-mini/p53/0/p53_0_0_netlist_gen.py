from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Cascoded High-Gain Amplifier')
# MOSFET models (assumed provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC operating point (bias) = 0.42 V
circuit.V('bn', 'Vbn', circuit.gnd, 0.42)      # NMOS cascode gate bias = Vth + 0.2 = 0.42 V
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)      # PMOS gate bias = Vdd - |Vth| - 0.2 = 0.78 V
# Geometry constants (45 nm technology)
L = 0.045e-6  # 45 nm
# Stage 1
# M1: NMOS input transistor (drain = Vx1, gate = Vin, source = gnd, bulk = gnd)
circuit.MOSFET('M1', 'Vx1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# MC1: NMOS cascode for M1 (drain = Vtop1, gate = Vbn, source = Vx1, bulk = Vx1)
circuit.MOSFET('MC1', 'Vtop1', 'Vbn', 'Vx1', 'Vx1',
               model='nmos_model', w=4e-6, l=L)
# M2: PMOS active load for stage 1 (drain = Vtop1, gate = Vbp, source = Vdd, bulk = Vdd)
circuit.MOSFET('M2', 'Vtop1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
# Stage 2
# M4: NMOS input transistor of stage 2 (drain = Vx2, gate = Vtop1, source = gnd, bulk = gnd)
circuit.MOSFET('M4', 'Vx2', 'Vtop1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# MC2: NMOS cascode for M4 (drain = Vout, gate = Vbn, source = Vx2, bulk = Vx2)
circuit.MOSFET('MC2', 'Vout', 'Vbn', 'Vx2', 'Vx2',
               model='nmos_model', w=3e-6, l=L)
# M5: PMOS active load for stage 2 (drain = Vout, gate = Vbp, source = Vdd, bulk = Vdd)
circuit.MOSFET('M5', 'Vout', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
# Create the simulator (do not append other commands after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
