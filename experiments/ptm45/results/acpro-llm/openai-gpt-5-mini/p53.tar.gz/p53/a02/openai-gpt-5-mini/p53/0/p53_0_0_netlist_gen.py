from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded-Load Amplifier (Max Gain)')
# Models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)             # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)            # Vin DC bias = Vth + 0.2 = 0.42 V
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.70)        # PMOS top load gate bias (~1.2 - 0.5)
circuit.V('bpc', 'Vbias_pcas', circuit.gnd, 0.95)    # PMOS cascode gate bias
# Device sizing (45 nm tech -> L = 45e-9 m = 0.045e-6 m)
L = 0.045e-6
# Stage 1 (input)
# M1: NMOS input device
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L)
# M2 (PMOS top current source), M4 (PMOS cascode)
circuit.MOSFET('M2', 'X1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M4', 'N1', 'Vbias_pcas', 'X1', 'X1',
               model='pmos_model', w=10e-6, l=L)
# Stage 2 (middle)
# M3: NMOS middle device (gate driven by N1)
circuit.MOSFET('M3', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=15e-6, l=L)
# M6 (PMOS top load), M7 (PMOS cascode)
circuit.MOSFET('M6', 'X2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M7', 'N2', 'Vbias_pcas', 'X2', 'X2',
               model='pmos_model', w=10e-6, l=L)
# Stage 3 (output)
# M5: NMOS output gain device (drain is Vout)
circuit.MOSFET('M5', 'Vout', 'N2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=30e-6, l=L)
# M8 (PMOS top load), M9 (PMOS cascode)
circuit.MOSFET('M8', 'X3', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M9', 'Vout', 'Vbias_pcas', 'X3', 'X3',
               model='pmos_model', w=10e-6, l=L)
# End: create simulator (user may run operating point or small-signal analyses)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
