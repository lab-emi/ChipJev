from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded-Load Amplifier (Fixed DC Bias)')
# Models (provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)             # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.28)            # Vin DC bias reduced to 0.28 V (still > Vth = 0.22 V)
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.70)        # PMOS top load gate bias
circuit.V('bpc', 'Vbias_pcas', circuit.gnd, 0.95)    # PMOS cascode gate bias
# Device sizing (45 nm technology)
L = 0.045e-6
# Stage 1 (input)
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=L)       # reduced width to make M1 weaker
circuit.MOSFET('M2', 'X1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)     # PMOS top current source
circuit.MOSFET('M4', 'N1', 'Vbias_pcas', 'X1', 'X1',
               model='pmos_model', w=10e-6, l=L)     # PMOS cascode
# Stage 2 (middle)
circuit.MOSFET('M3', 'N2', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=L)       # reduced width to keep N2 biased high
circuit.MOSFET('M6', 'X2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M7', 'N2', 'Vbias_pcas', 'X2', 'X2',
               model='pmos_model', w=10e-6, l=L)
# Stage 3 (output)
circuit.MOSFET('M5', 'Vout', 'N2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)      # moderate width for output device
circuit.MOSFET('M8', 'X3', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L)
circuit.MOSFET('M9', 'Vout', 'Vbias_pcas', 'X3', 'X3',
               model='pmos_model', w=10e-6, l=L)
# Create simulator for operating point / small-signal runs
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
