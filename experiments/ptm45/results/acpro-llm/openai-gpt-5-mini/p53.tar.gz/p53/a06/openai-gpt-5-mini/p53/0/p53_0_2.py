from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier - OP Fix')
# Models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC) - adjusted to ensure Node1 (M2 gate) is sufficiently high
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.20)        # Vin DC bias lowered (M1 off or barely on) so Node1 is pulled high
circuit.V('vb_p', 'Vbias_p', circuit.gnd, 0.85)  # PMOS current-source gate bias (moderate current)
circuit.V('vb_pc', 'Vbias_pc', circuit.gnd, 0.95) # PMOS cascode gate bias
# Device dimensions (45 nm node)
L = 0.045e-6  # 45 nm channel length
# Stage 1 (input stage) - NMOS common-source with cascoded PMOS active load
# M1: NMOS input transistor (made small so it won't strongly pull Node1 down)
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=1.0e-6, l=L)
# Mp1_top: PMOS current source (top device)
circuit.MOSFET('Mp1_top', 'cas_p1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=12e-6, l=L)
# Mp1_cas: PMOS cascode (between top current source and Node1)
circuit.MOSFET('Mp1_cas', 'Node1', 'Vbias_pc', 'cas_p1', 'cas_p1',
               model='pmos_model', w=8e-6, l=L)
# Stage 2 (gain stage) - NMOS common-source with cascoded PMOS active load
# M2: NMOS second-stage transistor (gate driven by Node1). With Node1 pulled high, M2 Vgs > Vth.
circuit.MOSFET('M2', 'Vout', 'Node1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=L)
# Mp2_top: PMOS current source for stage 2
circuit.MOSFET('Mp2_top', 'cas_p2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=14e-6, l=L)
# Mp2_cas: PMOS cascode for stage 2
circuit.MOSFET('Mp2_cas', 'Vout', 'Vbias_pc', 'cas_p2', 'cas_p2',
               model='pmos_model', w=10e-6, l=L)
# Create simulator (no analyses included per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
