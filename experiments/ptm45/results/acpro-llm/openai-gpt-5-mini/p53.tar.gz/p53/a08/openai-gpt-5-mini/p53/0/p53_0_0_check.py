from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded CS Amplifier (Max Gain)')
# MOSFET models (provided by external module 'model')
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (operating-point DC biases only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)   # PMOS current device gate bias
circuit.V('biaspc', 'Vbias_pc', circuit.gnd, 0.58) # PMOS cascode gate bias
# Stage 1 (input)
# M1: NMOS common-source (drain = n1, gate = Vin, source = gnd, bulk = gnd)
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# M2a: PMOS current device (top), drain = pcas1, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M2a', 'pcas1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M2c: PMOS cascode (lower), drain = n1, gate = Vbias_pc, source = pcas1, bulk tied to its source (pcas1)
circuit.MOSFET('M2c', 'n1', 'Vbias_pc', 'pcas1', 'pcas1', model='pmos_model', w=8e-6, l=0.045e-6)
# Stage 2 (middle)
# M3: NMOS common-source (drain = n2, gate = n1, source = gnd, bulk = gnd)
circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd, model='nmos_model', w=3e-6, l=0.045e-6)
# M4a: PMOS current device (top), drain = pcas2, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M4a', 'pcas2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M4c: PMOS cascode (lower), drain = n2, gate = Vbias_pc, source = pcas2, bulk = pcas2
circuit.MOSFET('M4c', 'n2', 'Vbias_pc', 'pcas2', 'pcas2', model='pmos_model', w=8e-6, l=0.045e-6)
# Stage 3 (output)
# M5: NMOS common-source (drain = Vout, gate = n2, source = gnd, bulk = gnd)
circuit.MOSFET('M5', 'Vout', 'n2', circuit.gnd, circuit.gnd, model='nmos_model', w=6e-6, l=0.045e-6)
# M6a: PMOS current device (top), drain = pcas3, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M6a', 'pcas3', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.045e-6)
# M6c: PMOS cascode (lower), drain = Vout, gate = Vbias_pc, source = pcas3, bulk = pcas3
circuit.MOSFET('M6c', 'Vout', 'Vbias_pc', 'pcas3', 'pcas3', model='pmos_model', w=10e-6, l=0.045e-6)
# Simulator (stop here, as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)