from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Three-Stage Cascoded CS Amplifier (Max Gain)')
# MOSFET models (provided by external module 'model')
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (operating-point DC biases only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC bias = Vth + 0.2 = 0.42 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)   # PMOS current device gate bias
circuit.V('biaspc', 'Vbias_pc', circuit.gnd, 0.58) # PMOS cascode gate bias
# Stage 1 (input)
# M1: NMOS common-source (drain = n1, gate = Vin, source = gnd, bulk = gnd)
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# M2a: PMOS current device (top), drain = pcas1, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M2a', 'pcas1', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M2c: PMOS cascode (lower), drain = n1, gate = Vbias_pc, source = pcas1, bulk tied to its source (pcas1)
circuit.MOSFET('M2c', 'n1', 'Vbias_pc', 'pcas1', 'pcas1', model='pmos_model', w=8e-6, l=0.045e-6)
# Stage 2 (middle)
# M3: NMOS common-source (drain = n2, gate = n1, source = gnd, bulk = gnd)
circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd, model='nmos_model', w=3e-6, l=0.045e-6)
# M4a: PMOS current device (top), drain = pcas2, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M4a', 'pcas2', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# M4c: PMOS cascode (lower), drain = n2, gate = Vbias_pc, source = pcas2, bulk = pcas2
circuit.MOSFET('M4c', 'n2', 'Vbias_pc', 'pcas2', 'pcas2', model='pmos_model', w=8e-6, l=0.045e-6)
# Stage 3 (output)
# M5: NMOS common-source (drain = Vout, gate = n2, source = gnd, bulk = gnd)
circuit.MOSFET('M5', 'Vout', 'n2', circuit.gnd, circuit.gnd, model='nmos_model', w=6e-6, l=0.045e-6)
# M6a: PMOS current device (top), drain = pcas3, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M6a', 'pcas3', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=0.045e-6)
# M6c: PMOS cascode (lower), drain = Vout, gate = Vbias_pc, source = pcas3, bulk = pcas3
circuit.MOSFET('M6c', 'Vout', 'Vbias_pc', 'pcas3', 'pcas3', model='pmos_model', w=10e-6, l=0.045e-6)
# Simulator (stop here, as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
