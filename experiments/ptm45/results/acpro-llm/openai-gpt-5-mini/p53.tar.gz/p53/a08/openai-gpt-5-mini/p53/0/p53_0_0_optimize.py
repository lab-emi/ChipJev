from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
# IMPORTANT: These initial parameter values are EXACTLY the original values from your netlist.
initial_params = {
    # Transistor widths (exact originals)
    'w_M1' :  2e-6,
    'w_M2a': 10e-6,
    'w_M2c':  8e-6,
    'w_M3' :  3e-6,
    'w_M4a': 10e-6,
    'w_M4c':  8e-6,
    'w_M5' :  6e-6,
    'w_M6a': 12e-6,
    'w_M6c': 10e-6,
    # Bias voltages (exact originals)
    'Vbias_p' : 0.78,
    'Vbias_pc': 0.58,
}
