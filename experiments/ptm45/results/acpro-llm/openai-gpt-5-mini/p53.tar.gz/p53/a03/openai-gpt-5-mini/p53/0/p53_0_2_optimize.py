from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    """
    Create the cascoded two-stage amplifier with parameterized widths and bias voltages.
    NOTE: This function imports the process model parameters from the provided module
    as required by the execution environment.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier - Parameterized')
    # MOSFET models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V (fixed)
    # Input voltage source (fixed, not parameterized per requirements)
    circuit.V('in', 'Vin', circuit.gnd, 0.60)       # Vin DC bias (fixed)
    # Parameterized bias voltages (within 0.8-1.2x original, capped at 1.2 V)
    circuit.V('bp', 'Vbp', circuit.gnd, params['v_bp'])   # PMOS gate bias (parameter)
    circuit.V('bn', 'Vbn', circuit.gnd, params['v_bn'])   # NMOS cascode gate bias (parameter)
    # Process length (fixed for optimization). Per requirement we keep L constant (45 nm).
    L_fixed = 45e-9
    # Stage 1: input cascode common-source
    # M1: input NMOS (drain Node1, gate Vin, source GND, bulk GND)
    circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)
    # M2: cascode NMOS for M1 (drain Node2, gate Vbn, source Node1, bulk GND)
    circuit.MOSFET('M2', 'Node2', 'Vbn', 'Node1', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_fixed)
    # M3: PMOS current-source load for stage1 (drain Node2, gate Vbp, source Vdd, bulk Vdd)
    circuit.MOSFET('M3', 'Node2', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_fixed)
    # Stage 2: cascoded common-source (driven by Node2)
    # M4: second-stage NMOS (drain Node3, gate Node2, source GND, bulk GND)
    circuit.MOSFET('M4', 'Node3', 'Node2', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L_fixed)
    # M5: cascode NMOS for M4 (drain Vout, gate Vbn, source Node3, bulk GND)
    circuit.MOSFET('M5', 'Vout', 'Vbn', 'Node3', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L_fixed)
    # M6: PMOS current-source load for stage2 (drain Vout, gate Vbp, source Vdd, bulk Vdd)
    circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L_fixed)
    # End of topology; operating point simulator will be created by caller when needed
    return circuit
# ============================================================
# Optimization parameter search ranges (for Optuna or similar)
# ============================================================
# Fixed process length used to derive W ranges:
L_fixed = 45e-9  # 45 nm process length (fixed)
W_min = 1.0 * L_fixed
W_max = 500.0 * L_fixed
param_ranges_definition = {
    # Transistor widths (optimize W only; L is fixed to 45 nm)
    # Use log scale for widths to allow exploration across orders of magnitude
    'w_M1': {'min': W_min, 'max': W_max, 'log': True},  # M1 input NMOS (original 2e-6)
    'w_M2': {'min': W_min, 'max': W_max, 'log': True},  # M2 NMOS cascode (original 1e-6)
    'w_M3': {'min': W_min, 'max': W_max, 'log': True},  # M3 PMOS load (original 20e-6)
    'w_M4': {'min': W_min, 'max': W_max, 'log': True},  # M4 second-stage NMOS (original 4e-6)
    'w_M5': {'min': W_min, 'max': W_max, 'log': True},  # M5 NMOS cascode (original 1e-6)
    'w_M6': {'min': W_min, 'max': W_max, 'log': True},  # M6 PMOS load (original 20e-6)
    # Bias voltages (conservative 0.8-1.2× original, capped at 1.2 V supply)
    # Linear sampling is recommended for voltages
    'v_bp': {'min': max(0.0, 0.8 * 0.40), 'max': min(1.2, 1.2 * 0.40), 'log': False},  # original 0.40 V
    'v_bn': {'min': max(0.0, 0.8 * 1.00), 'max': min(1.2, 1.2 * 1.00), 'log': False},  # original 1.00 V
}
# ============================================================
# Initial parameter values (EXACT original values from the provided netlist)
# ============================================================
# IMPORTANT: These are the exact original values from your circuit code and MUST NOT be changed.
initial_params = {
    # Transistor widths (exact original values)
    'w_M1': 2e-6,    # Original: M1 w=2e-6
    'w_M2': 1e-6,    # Original: M2 w=1e-6
    'w_M3': 20e-6,   # Original: M3 w=20e-6
    'w_M4': 4e-6,    # Original: M4 w=4e-6
    'w_M5': 1e-6,    # Original: M5 w=1e-6
    'w_M6': 20e-6,   # Original: M6 w=20e-6
    # Bias voltages (exact original values)
    'v_bp': 0.40,    # Original: Vbp = 0.40 V
    'v_bn': 1.00,    # Original: Vbn = 1.00 V
}
# ============================================================
# Parameter descriptions (brief physical meaning)
# ============================================================
param_descriptions = {
    # Widths (W) — physical channel width of MOSFETs; L is fixed at 45 nm in the layout/model.
    # Increasing W increases current drive and transconductance (gm) but also increases parasitics
    # and area. These parameters control the W/L ratio (since L is fixed).
    'w_M1': "Width of input NMOS M1 (controls input device drive and gm).",
    'w_M2': "Width of NMOS cascode M2 (affects cascode headroom and output resistance of stage1).",
    'w_M3': "Width of PMOS load M3 (current-source load for stage1; increases pull-up strength).",
    'w_M4': "Width of second-stage NMOS M4 (controls stage2 drive and gm).",
    'w_M5': "Width of NMOS cascode M5 (affects cascode headroom and output resistance of stage2).",
    'w_M6': "Width of PMOS load M6 (current-source load for stage2).",
    # Bias voltages
    'v_bp': "PMOS gate bias used for current-source loads (Vbp). Controls PMOS Vsg and load current.",
    'v_bn': "NMOS cascode gate bias used for cascode transistors (Vbn). Controls cascode conduction and headroom.",
}
# Sanity check note (not executed): initial_params values are within the ranges specified:
# - All widths lie within [1*L_fixed, 500*L_fixed] where L_fixed = 45e-9 (i.e. [45e-9, 22.5e-6]).
# - v_bp in [0.8*0.40, 1.2*0.40] = [0.32, 0.48] V
# - v_bn in [0.8*1.00, 1.2*1.00] = [0.80, 1.20] V (capped at 1.2 V supply)
