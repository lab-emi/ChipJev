from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier - Corrected')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
# Note: node name 'Vdd' is the positive node of the Vdd source; use that same name when
# tying PMOS sources/bulks to the supply node.
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
# Input DC bias for Vin (operating point)
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
# Bias nodes for PMOS loads and NMOS cascodes
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)       # PMOS gate bias for current sources
circuit.V('bn', 'Vbn', circuit.gnd, 0.60)       # NMOS cascode gate bias
# --- Stage 1: input cascode common-source ---
# M1: input NMOS (drain Node1, gate Vin, source GND, bulk GND)
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model',
               w=2e-6, l=0.12e-6)
# Modification 1 (FIX):
# M2 cascode NMOS: the ORIGINAL netlist tied bulk to Node1 (M2 bulk = Node1).
# That creates a floating body when Node1 can float; many models expect a fixed substrate.
# Fix: tie bulk to global NMOS substrate (ground) to avoid floating-substrate issues.
# M2: cascode NMOS for M1 (drain Node2, gate Vbn, source Node1, bulk -> circuit.gnd)
circuit.MOSFET('M2', 'Node2', 'Vbn', 'Node1', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M3: PMOS current-source load for stage1 (drain Node2, gate Vbp, source Vdd, bulk Vdd)
# Note: PMOS bulk tied to Vdd (global PMOS substrate) — this prevents floating PMOS body.
circuit.MOSFET('M3', 'Node2', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=12e-6, l=0.12e-6)
# --- Stage 2: cascoded common-source (driven by Node2) ---
# M4: second-stage NMOS (drain Node3, gate Node2, source GND, bulk GND)
circuit.MOSFET('M4', 'Node3', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model',
               w=4e-6, l=0.12e-6)
# Modification 2 (FIX):
# M5 cascode NMOS: the ORIGINAL netlist tied bulk to Node3 (M5 bulk = Node3).
# Fix: tie bulk to global NMOS substrate (ground) to avoid floating-substrate issues.
# M5: cascode NMOS for M4 (drain Vout, gate Vbn, source Node3, bulk -> circuit.gnd)
circuit.MOSFET('M5', 'Vout', 'Vbn', 'Node3', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M6: PMOS current-source load for stage2 (drain Vout, gate Vbp, source Vdd, bulk Vdd)
# PMOS bulk tied to Vdd (global PMOS substrate)
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=12e-6, l=0.12e-6)
# Notes on modifications:
# - Major fix: NMOS bulks for cascodes (M2, M5) changed from their sources (internal nodes)
#   to circuit.gnd (global NMOS substrate). This removes floating-substrate nodes that
#   can cause SPICE to fail to converge, especially with foundry process models.
# - PMOS bulks remain tied to the Vdd node (global PMOS substrate).
# - All MOSFET terminal orders are (drain, gate, source, bulk) as required by PySpice.
# - All node and supply names (Vin, Vbp, Vbn, Vdd, Vout) are present as requested.
# Create the simulator for DC operating point analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)