from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)       # Vin DC bias ~ Vth + 0.2 V (Vth = 0.22)
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)       # PMOS gate bias for current sources
circuit.V('bn', 'Vbn', circuit.gnd, 0.60)       # NMOS cascode gate bias
# Stage 1: input cascode common-source
# M1: input NMOS (drain Node1, gate Vin, source GND, bulk GND)
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model',
               w=2e-6, l=0.12e-6)
# M2: cascode NMOS for M1 (drain Node2, gate Vbn, source Node1, bulk Node1)
circuit.MOSFET('M2', 'Node2', 'Vbn', 'Node1', 'Node1', model='nmos_model',
               w=1e-6, l=0.12e-6)
# M3: PMOS current-source load for stage1 (drain Node2, gate Vbp, source Vdd, bulk Vdd)
circuit.MOSFET('M3', 'Node2', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=12e-6, l=0.12e-6)
# Stage 2: cascoded common-source (driven by Node2)
# M4: second-stage NMOS (drain Node3, gate Node2, source GND, bulk GND)
circuit.MOSFET('M4', 'Node3', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model',
               w=4e-6, l=0.12e-6)
# M5: cascode NMOS for M4 (drain Vout, gate Vbn, source Node3, bulk Node3)
circuit.MOSFET('M5', 'Vout', 'Vbn', 'Node3', 'Node3', model='nmos_model',
               w=1e-6, l=0.12e-6)
# M6: PMOS current-source load for stage2 (drain Vout, gate Vbp, source Vdd, bulk Vdd)
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=12e-6, l=0.12e-6)
# End of topology; create simulator for DC operating point analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
