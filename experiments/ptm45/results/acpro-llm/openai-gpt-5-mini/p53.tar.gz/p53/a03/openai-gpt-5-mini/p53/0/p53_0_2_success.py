from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier - Operating Point Fixed')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
# -------------------------
# DC bias / input settings
# -------------------------
# Modification A: raise Vin DC bias from 0.42 V -> 0.60 V so M1 and M4 have larger Vgs and conduct.
# Rationale: earlier Vin (~0.42 V) gave small gm and in combination with other biases left the stack off.
circuit.V('in', 'Vin', circuit.gnd, 0.60)       # Vin DC bias
# Modification B: lower PMOS gate bias (Vbp) from 0.78 V -> 0.40 V to increase PMOS current.
# Rationale: Vbp previously produced only weak PMOS current (Vsg ~0.42 V). Lowering Vbp raises Vsg,
# increasing PMOS current to establish a DC path.
circuit.V('bp', 'Vbp', circuit.gnd, 0.40)       # PMOS gate bias for current sources (stronger pull-up)
# Modification C: raise NMOS cascode gate bias (Vbn) from 0.60 V -> 1.00 V to ensure cascodes are ON.
# Rationale: cascode gates previously made the cascode transistors block current; raising Vbn
# ensures Vgs(cascode) is sufficiently positive to allow current flow while still providing cascode action.
circuit.V('bn', 'Vbn', circuit.gnd, 1.00)       # NMOS cascode gate bias
# -------------------------
# Devices and connections
# -------------------------
# Stage 1: input cascode common-source
# M1: input NMOS (drain Node1, gate Vin, source GND, bulk GND)
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model',
               w=2e-6, l=0.12e-6)
# M2: cascode NMOS for M1
# Modification D: keep NMOS bulk tied to global substrate (ground) to avoid floating-body issues.
# Terminal order: drain, gate, source, bulk
circuit.MOSFET('M2', 'Node2', 'Vbn', 'Node1', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M3: PMOS current-source load for stage1
# Modification E: increase PMOS width to ensure adequate current (12e-6 -> 20e-6).
# PMOS bulk tied to Vdd (global PMOS substrate)
circuit.MOSFET('M3', 'Node2', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=20e-6, l=0.12e-6)
# Stage 2: cascoded common-source (driven by Node2)
# M4: second-stage NMOS (drain Node3, gate Node2, source GND, bulk GND)
circuit.MOSFET('M4', 'Node3', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model',
               w=4e-6, l=0.12e-6)
# M5: cascode NMOS for M4
# Modification F: keep NMOS bulk tied to global substrate (ground) to avoid floating-body issues.
circuit.MOSFET('M5', 'Vout', 'Vbn', 'Node3', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M6: PMOS current-source load for stage2
# PMOS bulk tied to Vdd
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=20e-6, l=0.12e-6)
# End of topology; create simulator for DC operating point analysis
# Note: No AC sources are used; we only want the operating point to be valid (nonzero ID).
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
