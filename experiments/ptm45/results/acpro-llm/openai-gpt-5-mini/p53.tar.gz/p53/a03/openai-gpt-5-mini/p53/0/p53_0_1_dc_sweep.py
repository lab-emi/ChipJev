from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier - Corrected')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
# Note: node name 'Vdd' is the positive node of the Vdd source; use that same name when
# tying PMOS sources/bulks to the supply node.
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
# Input DC bias for Vin (operating point)
circuit.V('in', 'Vin', circuit.gnd, 0.42)       # Vin DC bias ~ Vth + 0.2 V (Vth = 0.22)
# Bias nodes for PMOS loads and NMOS cascodes
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)       # PMOS gate bias for current sources
circuit.V('bn', 'Vbn', circuit.gnd, 0.60)       # NMOS cascode gate bias
# --- Stage 1: input cascode common-source ---
# M1: input NMOS (drain Node1, gate Vin, source GND, bulk GND)
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model',
               w=2e-6, l=0.12e-6)
# Modification 1 (FIX):
# M2 cascode NMOS: the ORIGINAL netlist tied bulk to Node1 (M2 bulk = Node1).
# That creates a floating body when Node1 can float; many models expect a fixed substrate.
# Fix: tie bulk to global NMOS substrate (ground) to avoid floating-substrate issues.
# M2: cascode NMOS for M1 (drain Node2, gate Vbn, source Node1, bulk -> circuit.gnd)
circuit.MOSFET('M2', 'Node2', 'Vbn', 'Node1', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M3: PMOS current-source load for stage1 (drain Node2, gate Vbp, source Vdd, bulk Vdd)
# Note: PMOS bulk tied to Vdd (global PMOS substrate) — this prevents floating PMOS body.
circuit.MOSFET('M3', 'Node2', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=12e-6, l=0.12e-6)
# --- Stage 2: cascoded common-source (driven by Node2) ---
# M4: second-stage NMOS (drain Node3, gate Node2, source GND, bulk GND)
circuit.MOSFET('M4', 'Node3', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model',
               w=4e-6, l=0.12e-6)
# Modification 2 (FIX):
# M5 cascode NMOS: the ORIGINAL netlist tied bulk to Node3 (M5 bulk = Node3).
# Fix: tie bulk to global NMOS substrate (ground) to avoid floating-substrate issues.
# M5: cascode NMOS for M4 (drain Vout, gate Vbn, source Node3, bulk -> circuit.gnd)
circuit.MOSFET('M5', 'Vout', 'Vbn', 'Node3', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M6: PMOS current-source load for stage2 (drain Vout, gate Vbp, source Vdd, bulk Vdd)
# PMOS bulk tied to Vdd (global PMOS substrate)
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=12e-6, l=0.12e-6)
# Notes on modifications:
# - Major fix: NMOS bulks for cascodes (M2, M5) changed from their sources (internal nodes)
#   to circuit.gnd (global NMOS substrate). This removes floating-substrate nodes that
#   can cause SPICE to fail to converge, especially with foundry process models.
# - PMOS bulks remain tied to the Vdd node (global PMOS substrate).
# - All MOSFET terminal orders are (drain, gate, source, bulk) as required by PySpice.
# - All node and supply names (Vin, Vbp, Vbn, Vdd, Vout) are present as requested.
# Create the simulator for DC operating point analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
import numpy as np

# Get the VDD value from the circuit
try:
    dc_value = circuit.element('Vdd').dc_value
    if type(dc_value) == str:
        v_dd_value = float(dc_value.split()[0])
    else:
        v_dd_value = float(dc_value)
except:
    # Try alternative name formats
    try:
        dc_value = circuit.element('VDD').dc_value
        if type(dc_value) == str:
            v_dd_value = float(dc_value.split()[0])
        else:
            v_dd_value = float(dc_value)
    except:
        # Default to 1.2V if VDD cannot be found
        v_dd_value = 1.2

# Define reasonable voltage range for differential amplifier biasing
# Avoid regions too close to rails where transistors might not be in saturation
min_voltage = 0.2
max_voltage = v_dd_value - 0.2  # Avoid saturation region

# Target output voltage is typically VDD/2 for many amplifier circuits
target_vout = v_dd_value / 2

# Save the data to file in two lines
fopen = open("openai-gpt-5-mini/p53/0/p53_0_1_dc.txt", "w")


for element in circuit.elements:
    if element.name == "Vin":
        vin_pin_name = element.pins[0].node
# Three-level scanning strategy
# Level 1: Coarse scan across reasonable operating range
coarse_step = (max_voltage - min_voltage) / 20  # Adaptive step size
analysis_coarse = simulator.dc(Vin=slice(min_voltage, max_voltage, coarse_step))
out_voltage_coarse = np.array(analysis_coarse.Vout)
in_voltage_coarse = np.array(getattr(analysis_coarse, vin_pin_name))

# Find the approximate best point
best_vin_coarse = v_dd_value / 2  # Initial guess
min_diff_coarse = float('inf')
for i, vout in enumerate(out_voltage_coarse):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_coarse:
        min_diff_coarse = diff
        best_vin_coarse = float(in_voltage_coarse[i])

# Level 2: Medium resolution scan around best point from coarse scan
mid_range = (max_voltage - min_voltage) / 4  # 25% of the range
mid_step = (max_voltage - min_voltage) / 200  # Higher resolution
mid_min = max(min_voltage, best_vin_coarse - mid_range/2)
mid_max = min(max_voltage, best_vin_coarse + mid_range/2)

# get vin pin name



analysis_mid = simulator.dc(Vin=slice(mid_min, mid_max, mid_step))
out_voltage_mid = np.array(analysis_mid.Vout)
in_voltage_mid = np.array(getattr(analysis_mid, vin_pin_name))

# Find the best point in medium resolution scan
best_vin_mid = best_vin_coarse
min_diff_mid = float('inf')
for i, vout in enumerate(out_voltage_mid):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_mid:
        min_diff_mid = diff
        best_vin_mid = float(in_voltage_mid[i])

# Level 3: Ultra-high resolution scan around best point from medium scan
fine_range = (max_voltage - min_voltage) / 40  # ~2.5% of the range
fine_step = (max_voltage - min_voltage) / 2000  # Ultra-fine resolution
fine_min = max(min_voltage, best_vin_mid - fine_range/2)
fine_max = min(max_voltage, best_vin_mid + fine_range/2)

analysis_fine = simulator.dc(Vin=slice(fine_min, fine_max, fine_step))
out_voltage = np.array(analysis_fine.Vout)
in_voltage = np.array(getattr(analysis_fine, vin_pin_name))

# Print information about the search
print(f"VDD = {v_dd_value:.3f}V, Target Vout = {target_vout:.3f}V")
print(f"Search range: {min_voltage:.3f}V to {max_voltage:.3f}V")
print(f"Coarse scan result: Best Vin ≈ {best_vin_coarse:.6f}V")
print(f"Medium scan result: Best Vin ≈ {best_vin_mid:.6f}V")

# Find best point in fine scan
best_vin_fine = best_vin_mid
best_vout_fine = target_vout
min_diff_fine = float('inf')
for i, vout in enumerate(out_voltage):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_fine:
        min_diff_fine = diff
        best_vin_fine = float(in_voltage[i])
        best_vout_fine = float(vout)

print(f"Fine scan result: Best Vin = {best_vin_fine:.6f}V (Vout ≈ {best_vout_fine:.6f}V)")

# Combine all results for comprehensive data output
all_out_voltage = np.concatenate((out_voltage_coarse, out_voltage_mid, out_voltage))
all_in_voltage = np.concatenate((in_voltage_coarse, in_voltage_mid, in_voltage))

for item in all_in_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
for item in all_out_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
fopen.close()