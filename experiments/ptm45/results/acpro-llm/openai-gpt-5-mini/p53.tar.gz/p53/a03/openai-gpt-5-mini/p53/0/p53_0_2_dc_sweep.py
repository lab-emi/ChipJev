from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage High-Gain Amplifier - Operating Point Fixed')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
# -------------------------
# DC bias / input settings
# -------------------------
# Modification A: raise Vin DC bias from 0.42 V -> 0.60 V so M1 and M4 have larger Vgs and conduct.
# Rationale: earlier Vin (~0.42 V) gave small gm and in combination with other biases left the stack off.
circuit.V('in', 'Vin', circuit.gnd, 0.60)       # Vin DC bias
# Modification B: lower PMOS gate bias (Vbp) from 0.78 V -> 0.40 V to increase PMOS current.
# Rationale: Vbp previously produced only weak PMOS current (Vsg ~0.42 V). Lowering Vbp raises Vsg,
# increasing PMOS current to establish a DC path.
circuit.V('bp', 'Vbp', circuit.gnd, 0.40)       # PMOS gate bias for current sources (stronger pull-up)
# Modification C: raise NMOS cascode gate bias (Vbn) from 0.60 V -> 1.00 V to ensure cascodes are ON.
# Rationale: cascode gates previously made the cascode transistors block current; raising Vbn
# ensures Vgs(cascode) is sufficiently positive to allow current flow while still providing cascode action.
circuit.V('bn', 'Vbn', circuit.gnd, 1.00)       # NMOS cascode gate bias
# -------------------------
# Devices and connections
# -------------------------
# Stage 1: input cascode common-source
# M1: input NMOS (drain Node1, gate Vin, source GND, bulk GND)
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd, model='nmos_model',
               w=2e-6, l=0.12e-6)
# M2: cascode NMOS for M1
# Modification D: keep NMOS bulk tied to global substrate (ground) to avoid floating-body issues.
# Terminal order: drain, gate, source, bulk
circuit.MOSFET('M2', 'Node2', 'Vbn', 'Node1', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M3: PMOS current-source load for stage1
# Modification E: increase PMOS width to ensure adequate current (12e-6 -> 20e-6).
# PMOS bulk tied to Vdd (global PMOS substrate)
circuit.MOSFET('M3', 'Node2', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=20e-6, l=0.12e-6)
# Stage 2: cascoded common-source (driven by Node2)
# M4: second-stage NMOS (drain Node3, gate Node2, source GND, bulk GND)
circuit.MOSFET('M4', 'Node3', 'Node2', circuit.gnd, circuit.gnd, model='nmos_model',
               w=4e-6, l=0.12e-6)
# M5: cascode NMOS for M4
# Modification F: keep NMOS bulk tied to global substrate (ground) to avoid floating-body issues.
circuit.MOSFET('M5', 'Vout', 'Vbn', 'Node3', circuit.gnd, model='nmos_model',
               w=1e-6, l=0.12e-6)
# M6: PMOS current-source load for stage2
# PMOS bulk tied to Vdd
circuit.MOSFET('M6', 'Vout', 'Vbp', 'Vdd', 'Vdd', model='pmos_model',
               w=20e-6, l=0.12e-6)
# End of topology; create simulator for DC operating point analysis
# Note: No AC sources are used; we only want the operating point to be valid (nonzero ID).
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
import numpy as np

# Get the VDD value from the circuit
try:
    dc_value = circuit.element('Vdd').dc_value
    if type(dc_value) == str:
        v_dd_value = float(dc_value.split()[0])
    else:
        v_dd_value = float(dc_value)
except:
    # Try alternative name formats
    try:
        dc_value = circuit.element('VDD').dc_value
        if type(dc_value) == str:
            v_dd_value = float(dc_value.split()[0])
        else:
            v_dd_value = float(dc_value)
    except:
        # Default to 1.2V if VDD cannot be found
        v_dd_value = 1.2

# Define reasonable voltage range for differential amplifier biasing
# Avoid regions too close to rails where transistors might not be in saturation
min_voltage = 0.2
max_voltage = v_dd_value - 0.2  # Avoid saturation region

# Target output voltage is typically VDD/2 for many amplifier circuits
target_vout = v_dd_value / 2

# Save the data to file in two lines
fopen = open("openai-gpt-5-mini/p53/0/p53_0_2_dc.txt", "w")


for element in circuit.elements:
    if element.name == "Vin":
        vin_pin_name = element.pins[0].node
# Three-level scanning strategy
# Level 1: Coarse scan across reasonable operating range
coarse_step = (max_voltage - min_voltage) / 20  # Adaptive step size
analysis_coarse = simulator.dc(Vin=slice(min_voltage, max_voltage, coarse_step))
out_voltage_coarse = np.array(analysis_coarse.Vout)
in_voltage_coarse = np.array(getattr(analysis_coarse, vin_pin_name))

# Find the approximate best point
best_vin_coarse = v_dd_value / 2  # Initial guess
min_diff_coarse = float('inf')
for i, vout in enumerate(out_voltage_coarse):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_coarse:
        min_diff_coarse = diff
        best_vin_coarse = float(in_voltage_coarse[i])

# Level 2: Medium resolution scan around best point from coarse scan
mid_range = (max_voltage - min_voltage) / 4  # 25% of the range
mid_step = (max_voltage - min_voltage) / 200  # Higher resolution
mid_min = max(min_voltage, best_vin_coarse - mid_range/2)
mid_max = min(max_voltage, best_vin_coarse + mid_range/2)

# get vin pin name



analysis_mid = simulator.dc(Vin=slice(mid_min, mid_max, mid_step))
out_voltage_mid = np.array(analysis_mid.Vout)
in_voltage_mid = np.array(getattr(analysis_mid, vin_pin_name))

# Find the best point in medium resolution scan
best_vin_mid = best_vin_coarse
min_diff_mid = float('inf')
for i, vout in enumerate(out_voltage_mid):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_mid:
        min_diff_mid = diff
        best_vin_mid = float(in_voltage_mid[i])

# Level 3: Ultra-high resolution scan around best point from medium scan
fine_range = (max_voltage - min_voltage) / 40  # ~2.5% of the range
fine_step = (max_voltage - min_voltage) / 2000  # Ultra-fine resolution
fine_min = max(min_voltage, best_vin_mid - fine_range/2)
fine_max = min(max_voltage, best_vin_mid + fine_range/2)

analysis_fine = simulator.dc(Vin=slice(fine_min, fine_max, fine_step))
out_voltage = np.array(analysis_fine.Vout)
in_voltage = np.array(getattr(analysis_fine, vin_pin_name))

# Print information about the search
print(f"VDD = {v_dd_value:.3f}V, Target Vout = {target_vout:.3f}V")
print(f"Search range: {min_voltage:.3f}V to {max_voltage:.3f}V")
print(f"Coarse scan result: Best Vin ≈ {best_vin_coarse:.6f}V")
print(f"Medium scan result: Best Vin ≈ {best_vin_mid:.6f}V")

# Find best point in fine scan
best_vin_fine = best_vin_mid
best_vout_fine = target_vout
min_diff_fine = float('inf')
for i, vout in enumerate(out_voltage):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_fine:
        min_diff_fine = diff
        best_vin_fine = float(in_voltage[i])
        best_vout_fine = float(vout)

print(f"Fine scan result: Best Vin = {best_vin_fine:.6f}V (Vout ≈ {best_vout_fine:.6f}V)")

# Combine all results for comprehensive data output
all_out_voltage = np.concatenate((out_voltage_coarse, out_voltage_mid, out_voltage))
all_in_voltage = np.concatenate((in_voltage_coarse, in_voltage_mid, in_voltage))

for item in all_in_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
for item in all_out_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
fopen.close()