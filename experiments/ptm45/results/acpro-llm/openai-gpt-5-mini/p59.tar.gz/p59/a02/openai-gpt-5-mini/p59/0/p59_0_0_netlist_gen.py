from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - High GBW/Power FoM')
# MOS models coming from provided model module
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
# Vin is the required input node; provide a DC bias for operating point only (no AC)
circuit.V('in', 'Vin', circuit.gnd, 0.32)       # Vin DC bias = Vth + Vov_n ≈ 0.22 + 0.10 = 0.32 V
# Vbias biases the PMOS current-source gate (sets current through the stage)
circuit.V('bias', 'Vbias', circuit.gnd, 0.86)   # Vbias ≈ Vdd - (|Vth| + Vov_p) = 0.86 V
# Device geometry (45 nm tech)
L = 45e-9     # 45 nm
# M1: NMOS common-source amplifier transistor
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=L)
# M2: PMOS active current-source load (gate = Vbias)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=4e-6, l=L)
# End with simulator creation (no extra code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
