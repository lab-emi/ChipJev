```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # Keep the model import exactly as requested (this module is available in the execution env)
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier - High GBW/Power FoM')

    # MOS models coming from provided model module
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, NOT parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V (fixed)

    # Input voltage source (fixed, NOT parameterized). Will be swept externally.
    circuit.V('in', 'Vin', circuit.gnd, 0.32)       # Vin DC bias = 0.32 V (fixed)

    # Bias voltage (parameterized). Must remain <= Vdd (1.2 V).
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])

    # Device geometry (L fixed for 45 nm technology; only W is parameterized)
    L = 45e-9     # 45 nm (fixed)
    # M1: NMOS common-source amplifier transistor
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    # M2: PMOS active current-source load (gate = Vbias)
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=L)

    return circuit


# Optimization parameter search ranges
# Notes on constraints applied:
# - Transistor width (W) range: 1x to 500x the process length L (L = 45 nm => W in [45e-9, 22.5e-6])
# - All non-Vdd and non-input voltages use 0.8-1.2× original value, clipped to <=1.2 V
# - Vbias original = 0.86 V --> range 0.8*0.86 .. 1.2*0.86 => [0.688 .. 1.032] V (<= 1.2 V)
# - We considered Vth = 0.22 V when selecting conservative bias range (lower bound is still well above Vth)
param_ranges_definition = {
    # Transistor dimensions (W only; L fixed to 45e-9)
    'w_M1': {                       # M1 original W = 2e-6
        'min': 45e-9,               # 1 * L
        'max': 45e-9 * 500,         # 500 * L = 22.5e-6
        'log': True                 # use logarithmic sampling for wide dynamic range
    },
    'w_M2': {                       # M2 original W = 4e-6
        'min': 45e-9,
        'max': 45e-9 * 500,
        'log': True
    },

    # Voltage parameters (non-Vdd, non-input). Conservative linear sampling.
    'Vbias': {                      # original Vbias = 0.86 V
        'min': 0.8 * 0.86,          # 0.8x original = 0.688 V
        'max': min(1.2 * 0.86, 1.2),# 1.2x original = 1.032 V, must be <= 1.2 V
        'log': False
    }
}

# Initial parameter values (EXACT original circuit values) -- MUST match original code exactly
initial_params = {
    'w_M1': 2e-6,   # original M1 width from provided netlist
    'w_M2': 4e-6,   # original M2 width from provided netlist
    'Vbias': 0.86   # original bias voltage from provided netlist
}

# Brief description of each parameter (physical meaning)
parameter_descriptions = {
    'w_M1': 'Width of NMOS M1 (common-source amplifying transistor). L is fixed to 45 nm; W controls current and gm.',
    'w_M2': 'Width of PMOS M2 (active current-source load). L is fixed to 45 nm; W controls current sourcing and output resistance.',
    'Vbias': 'DC gate bias applied to PMOS M2. Sets tail/load current; must stay below Vdd and chosen to maintain correct operating point (consider Vth ≈ 0.22 V).'
}
```

Notes:
- Vdd and Vin remain fixed as requested (not included in parameter search).
- The fixed process length L = 45e-9 m is intentionally not included in the search (W/L ratio tuning is achieved by varying W only).
- All initial parameter values are inside the declared ranges.
- If you add resistors or capacitors later, follow the provided multiplier rules (resistors 0.5–2×, critical caps 0.5–5×, other caps 0.8–1.5×).