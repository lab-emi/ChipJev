from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - High GBW/Power')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias sources (DC operating point biases only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.6)      # Vin DC bias (input node)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78) # Bias for PMOS load gate (sets current)
# Transistors
# M1: NMOS common-source amplifier
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=45e-9)
# M2: PMOS active current-source load
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=45e-9)
# Simulator (user may run .operating_point() or AC analyses as needed)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
