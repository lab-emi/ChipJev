```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    """
    Create the parameterized Single-Stage CS Amplifier circuit.

    NOTE: This function contains the required import for model parameters
    exactly as requested (the module will be present in the execution env).
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier - High GBW/Power')

    # MOSFET models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd fixed at 1.2 V (45nm technology)

    # Input voltage source (fixed, not parameterized; will be swept externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.6)      # Vin fixed DC bias (0.6 V)

    # Bias voltage for PMOS load gate - parameterized (kept conservative)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])  # param: Vbias (V)

    # Transistors
    # Length is fixed for the process (45 nm). Only widths are parameterized.
    L_channel = 45e-9

    # M1: NMOS common-source amplifier
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_channel)

    # M2: PMOS active current-source load
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_channel)

    # NOTE: No load capacitor in the original circuit; if present it must remain fixed.
    return circuit


# ---------------------------------------------------------------------
# Optimization parameter search ranges (for Optuna or similar)
# ---------------------------------------------------------------------
# Constraints applied:
# - Transistor width W: between 1×L and 500×L (L = 45e-9 m)
# - All extra voltage sources (except Vdd and Vin) : 0.8–1.2× original value,
#   but never exceed 1.2 V (supply). Original Vbias = 0.78 V → allowed range computed accordingly.
# - Only W is optimized for MOSFETs; L is fixed at 45e-9.
#
# NOTE: 'log' flags are provided where useful for wide dynamic ranges.
L_channel = 45e-9
param_ranges_definition = {
    # Transistor widths (meters). Range = [1×L, 500×L] = [45e-9, 22.5e-6]
    'w_M1': {
        'min': 1.0 * L_channel,        # 45e-9 m
        'max': 500.0 * L_channel,      # 22.5e-6 m
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L_channel,        # 45e-9 m
        'max': 500.0 * L_channel,      # 22.5e-6 m
        'log': True
    },

    # Bias voltage for PMOS gate (Vbias).
    # Original = 0.78 V. Allowed = 0.8–1.2×orig = [0.624, 0.936], but also <= 1.2 V.
    # This range keeps the device biased well above Vth (Vth = 0.22 V) with margin.
    'Vbias': {
        'min': max(0.8 * 0.78, 0.22 + 0.05),   # 0.624 (keeps some margin above Vth)
        'max': min(1.2 * 0.78, 1.2),          # 0.936
        'log': False
    },
}

# ---------------------------------------------------------------------
# Initial parameter values (EXACT original circuit values — unmodified)
# These are the starting point for the optimizer and MUST match original netlist.
# ---------------------------------------------------------------------
initial_params = {
    'w_M1': 10e-6,    # Original width for M1 (10 µm)
    'w_M2': 20e-6,    # Original width for M2 (20 µm)
    'Vbias': 0.78     # Original bias voltage for PMOS gate (0.78 V)
}

# ---------------------------------------------------------------------
# Brief description of each parameter (physical meaning)
# ---------------------------------------------------------------------
param_descriptions = {
    'w_M1': "M1 (NMOS) channel width in meters. Controls drive current and gm of the input transistor. "
            "Length (L) fixed at 45e-9 m; optimization adjusts W to change W/L ratio.",
    'w_M2': "M2 (PMOS current-source load) channel width in meters. Controls load current and output impedance. "
            "Length (L) fixed at 45e-9 m; optimization adjusts W to change W/L ratio.",
    'Vbias': "Gate bias voltage for the PMOS active load (V). Sets the DC operating point / tail current. "
             "Range chosen as 0.8–1.2× original value while not exceeding supply (1.2 V). "
             "Range also respects device threshold (Vth = 0.22 V) to keep devices in intended region."
}
```

Notes / Highlights:
- create_circuit contains the exact import statement "from model import nmos_params, pmos_params" as requested.
- Vdd and Vin are kept fixed (not part of the search). Vbias is parameterized but constrained conservatively (0.624–0.936 V).
- Channel length is fixed at 45e-9 m; widths vary between 1×L and 500×L (45e-9 – 22.5e-6 m). Initial width values (10 µm and 20 µm) are inside those ranges.
- There were no resistors or capacitors in the original netlist; thus none are included in the parameter search. If you add compensation or load capacitors later, follow the stated multiplier constraints (comp caps: 0.5–5×, other caps: 0.8–1.5×).