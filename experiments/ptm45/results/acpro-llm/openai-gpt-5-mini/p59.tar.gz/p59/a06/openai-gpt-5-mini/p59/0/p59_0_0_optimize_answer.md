```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

# Fixed process length (45 nm) used in the circuit and for range computation
L = 45e-9  # 45 nm

def create_circuit(params):
    """
    Create the Single-Stage CS Amplifier circuit using parameter dictionary `params`.
    Note: the model import below must appear exactly as written for the execution environment.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier - GBW/Power Optimized')

    # MOSFET models (provided by the environment via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V (fixed)

    # Input voltage source (fixed, not parameterized - will be swept externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.6)    # Vin DC operating point (fixed)

    # Parameterized bias voltage (must remain <= 1.2 V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # PMOS gate bias

    # Transistor lengths are fixed by process
    L_fixed = 45e-9

    # NMOS input transistor M1 (drain -> Vout, gate -> Vin, source/bulk -> gnd)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)

    # PMOS active load M2 (drain -> Vout, gate -> Vbias, source/bulk -> Vdd)
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_fixed)

    # No explicit load capacitors/resistors were present in the original circuit;
    # if needed, keep them fixed (per requirements) and do not include in the optimization.

    return circuit


# Optimization parameter search ranges
# All ranges chosen to satisfy the constraints:
# - transistor width: 1×L .. 500×L
# - voltages (except Vdd and Vin): 0.8..1.2 × original, but never > 1.2V
param_ranges_definition = {
    # Transistor widths (only W is optimized; L is fixed at 45 nm)
    # Range: 1 - 500 × L (i.e., 45e-9 .. 22.5e-6)
    'w_M1': {
        'min': 1.0 * L,             # 1 × L = 45e-9
        'max': 500.0 * L,           # 500 × L = 22.5e-6
        'log': True                 # log-scale sweeping is usually preferred for geometry
    },
    'w_M2': {
        'min': 1.0 * L,
        'max': 500.0 * L,
        'log': True
    },

    # Bias voltage for PMOS gate (original = 0.83 V). Constrained to 0.8-1.2×original,
    # and also capped by supply (<= 1.2 V). 0.8*0.83 = 0.664, 1.2*0.83 = 0.996
    'v_bias': {
        'min': 0.8 * 0.83,         # = 0.664 V
        'max': min(1.2, 1.2 * 0.83),  # = min(1.2, 0.996) => 0.996 V
        'log': False
    }
}

# Initial parameter values (EXACT original circuit values from your code; do NOT modify)
initial_params = {
    'w_M1': 8e-6,    # Original NMOS width (M1) from your circuit
    'w_M2': 16e-6,   # Original PMOS width (M2) from your circuit
    'v_bias': 0.83   # Original bias voltage (Vbias) from your circuit
}

# Brief descriptions of each parameter (physical meaning)
parameter_descriptions = {
    'w_M1': "NMOS input transistor width (M1). With L fixed at 45 nm, this sets W/L for the NMOS and controls drain current, gm, and parasitics.",
    'w_M2': "PMOS active-load transistor width (M2). With L fixed at 45 nm, this sets W/L for the PMOS current-source load, affecting bias current and output resistance.",
    'v_bias': "PMOS gate bias voltage applied to the active-load (Vbias). Controls the operating point (current) of the PMOS load; ranges chosen conservatively relative to Vth (~0.22 V) and supply."
}
```

Notes:
- Vdd (1.2 V) and Vin (0.6 V) are intentionally fixed and not included in the optimization per your requirements.
- No load capacitors or resistors existed in the original netlist; therefore none were added or parameterized. If you later include compensation or load components, follow the requested multiplier ranges (e.g., compensation caps 0.5–5×, other caps 0.8–1.5×, resistors 0.5–2×).
- All initial parameter values are within their respective search ranges.