from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - GBW/Power Optimized')
# MOSFET models (provided by the environment via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (operating-point only, no AC)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.6 ac 1n")
# Vth = 0.22 V used to pick Vbias: Vbias = Vdd - |Vth| - Vov_p (Vov_p ~ 0.15 V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.83)  # PMOS gate bias to set current-source load
# Transistor dimensions and technology
L = 45e-9        # 45 nm
W_n = 8e-6       # NMOS width (M1)
W_p = 16e-6      # PMOS width (M2)
# Single-stage common-source NMOS amplifier with PMOS active load
# M1: NMOS input transistor (drain -> Vout, gate -> Vin, source/bulk -> gnd)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model', w=W_n, l=L)
# M2: PMOS active current-source load (drain -> Vout, gate -> Vbias, source/bulk -> Vdd)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                model='pmos_model', w=W_p, l=L)
# End: ready for operating-point or other DC analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)