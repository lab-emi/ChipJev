from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - GBW/Power Optimized')
# MOSFET models (provided by the environment via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (operating-point only, no AC)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.6)    # Vin DC operating point (input node)
# Vth = 0.22 V used to pick Vbias: Vbias = Vdd - |Vth| - Vov_p (Vov_p ~ 0.15 V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.83)  # PMOS gate bias to set current-source load
# Transistor dimensions and technology
L = 45e-9        # 45 nm
W_n = 8e-6       # NMOS width (M1)
W_p = 16e-6      # PMOS width (M2)
# Single-stage common-source NMOS amplifier with PMOS active load
# M1: NMOS input transistor (drain -> Vout, gate -> Vin, source/bulk -> gnd)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model', w=W_n, l=L)
# M2: PMOS active current-source load (drain -> Vout, gate -> Vbias, source/bulk -> Vdd)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                model='pmos_model', w=W_p, l=L)
# End: ready for operating-point or other DC analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
