from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - High FoM')
# Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and input DC bias (operating-point bias)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
# Use Vth = 0.22 V and set Vin DC = Vth + 0.25 V = 0.47 V for small overdrive bias
circuit.V('in', 'Vin', circuit.gnd, 0.47)           # Vin DC bias (operating point)
# Internal bias network: diode-connected PMOS M2 and resistor Rb set reference current
# Node names: Vbias (internal)
# M2: diode-connected PMOS from Vdd to Vbias (drain and gate tied to Vbias)
# M3: PMOS mirror from Vdd to Vout, gate tied to Vbias
#
# Device ordering for MOSFET: (name, drain, gate, source, bulk, model, w=..., l=...)
L_min = 45e-9  # 45 nm channel length
# Input transistor: common-source NMOS
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=6e-6, l=L_min)
# Diode-connected PMOS (reference device)
circuit.MOSFET('2', 'Vbias', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=3e-6, l=L_min)
# PMOS mirror device (active load)
circuit.MOSFET('3', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=3e-6, l=L_min)
# Reference resistor from Vbias to ground to set the diode current (small µA-range current)
circuit.R('b', 'Vbias', circuit.gnd, 100@u_kΩ)
# Ensure input and output node names appear in the circuit netlist
# (Vin is defined as a DC source, Vout is node at the drains of M1 and M3)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
