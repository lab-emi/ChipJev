```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    """
    Create the Single-Stage CS Amplifier circuit using parameter dictionary `params`.

    Important:
    - Keeps Vdd and Vin fixed (not parameterized).
    - Uses the imported device model parameter dictionaries from `model`.
      The import below must be present exactly as written for the execution environment.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier - High FoM (fixed bias)')

    # Models (use model parameter dictionaries supplied by the environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply and input DC bias (fixed; not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V (fixed)
    circuit.V('in', 'Vin', circuit.gnd, 0.47)           # Vin DC bias (fixed) - Vth(0.22V)+0.25V

    # Channel length (fixed for this process)
    L_min = 45e-9  # 45 nm

    # Transistors (widths parameterized; length fixed)
    # Input transistor: common-source NMOS (M1)
    circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)

    # Diode-connected PMOS (reference device) - gate tied to drain (Vbias) (M2)
    circuit.MOSFET('2', 'Vbias', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_min)

    # PMOS mirror device (active load) - gate tied to Vbias, drain to Vout (M3)
    circuit.MOSFET('3', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_min)

    # Reference resistor from Vbias to ground (parameterized)
    # Use kΩ notation for readability in netlist
    # params['r_b'] is expected in ohms (Ω); convert to kΩ string for PySpice
    circuit.R('b', 'Vbias', circuit.gnd, f"{params['r_b'] / 1e3}k")

    # Notes:
    # - Vin and Vdd are intentionally fixed: they will be swept externally during DC analyses.
    # - L is fixed (45 nm); optimization varies W only (i.e. W/L via W).
    return circuit


# Optimization parameter search ranges (for Optuna or similar)
# The ranges are chosen according to the rules:
# - W in [1×L, 500×L]  => [45e-9, 22.5e-6]
# - Resistors in [0.5×, 2×] original
# - All initial parameter values (initial_params) are exactly the original values
param_ranges_definition = {
    # Transistor widths (meters). Sample log-uniform to cover many decades efficiently.
    'w_M1': {
        'min': 45e-9,            # 1 × L (45 nm)
        'max': 22.5e-6,          # 500 × L
        'log': True
    },
    'w_M2': {
        'min': 45e-9,
        'max': 22.5e-6,
        'log': True
    },
    'w_M3': {
        'min': 45e-9,
        'max': 22.5e-6,
        'log': True
    },

    # Reference resistor Rb (ohms). Original is 10kΩ -> allow 0.5× to 2× (5kΩ to 20kΩ).
    # Use log sampling to allow both small and large values to be explored.
    'r_b': {
        'min': 5e3,   # 0.5 × 10kΩ
        'max': 20e3,  # 2.0 × 10kΩ
        'log': True
    }
}

# Initial parameters - EXACT originals from the provided netlist (do not modify).
# Units:
# - Widths in meters (W)
# - Resistances in ohms (Ω)
initial_params = {
    'w_M1': 6e-6,    # Original width for M1 (6 µm)
    'w_M2': 3e-6,    # Original width for M2 (3 µm)
    'w_M3': 3e-6,    # Original width for M3 (3 µm)
    'r_b' : 10e3     # Original reference resistor value (10 kΩ)
}


# Brief description of each parameter (physical meaning)
param_descriptions = {
    'w_M1': 'Width of input NMOS M1 (controls input device current, gm, output resistance). L fixed at 45 nm.',
    'w_M2': 'Width of diode-connected PMOS M2 (sets reference diode current; gate tied to drain -> Vbias generation). L fixed at 45 nm.',
    'w_M3': 'Width of PMOS mirror M3 (active load) (affects load current and output resistance). L fixed at 45 nm.',
    'r_b' : 'Reference resistor between Vbias and ground; sets diode/reference current for M2 and therefore bias point for the PMOS mirror.'
}
```

Notes and checks:
- Vdd (1.2 V) and Vin (0.47 V) remain fixed and are not included in the search space (as requested).
- All transistor lengths are fixed at 45 nm; only widths are tunable (so W/L changes come from W).
- All initial parameter values are exactly the same numeric values as in your original netlist and are inside the provided search ranges.
- No load capacitor was present in the original netlist; if you add any load/compensation capacitors later, follow the requested multiplier rules and keep load caps fixed if required.