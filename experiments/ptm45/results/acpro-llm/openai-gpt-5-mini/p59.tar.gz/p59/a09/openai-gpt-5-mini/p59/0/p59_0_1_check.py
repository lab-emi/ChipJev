from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - High FoM (fixed bias)')
# Models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and input DC bias (operating-point bias)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
# Use Vth = 0.22 V and set Vin DC = Vth + 0.25 V = 0.47 V for small overdrive bias
circuit.V('in', 'Vin', circuit.gnd, "dc 0.47 ac 1n")
# Channel length (45 nm technology)
L_min = 45e-9  # 45 nm
# Input transistor: common-source NMOS
circuit.MOSFET('1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=6e-6, l=L_min)
# Diode-connected PMOS (reference device) - gate tied to drain (Vbias)
circuit.MOSFET('2', 'Vbias', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=3e-6, l=L_min)
# PMOS mirror device (active load) - gate tied to Vbias, drains to Vout
circuit.MOSFET('3', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=3e-6, l=L_min)
# Reference resistor from Vbias to ground to set diode current.
# Reduced from 100k to 10k to ensure a non-zero reference current (M2 conducts).
circuit.R('b', 'Vbias', circuit.gnd, 10@u_kΩ)
# Ensure input and output node names appear in the circuit netlist
# (Vin is defined as a DC source, Vout is node at the drains of M1 and M3)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)