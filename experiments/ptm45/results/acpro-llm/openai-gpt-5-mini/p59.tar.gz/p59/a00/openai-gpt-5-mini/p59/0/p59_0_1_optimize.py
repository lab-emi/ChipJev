from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the PySpice circuit with parameterized transistor widths and bias voltage.
    Required: the module "model" must provide nmos_params and pmos_params as imported above.
    """
    circuit = Circuit('Single-Stage GBW/Power Optimized Amplifier - Corrected')
    # device models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)   # Vdd fixed at 1.2 V (do not parameterize)
    # Input voltage source (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Vin DC bias fixed at 0.42 V (kept fixed for DC sweeps)
    # Parameterized bias voltage (allowed to vary within conservative range)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])  # Vbias parameterized
    # Single-stage amplifier transistors
    # Note: length (L) is fixed for 45 nm process
    L_45nm = 45e-9
    # M1: NMOS common-source amplifier transistor
    # drain, gate, source, bulk, model, w, l
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_45nm)
    # M2: PMOS active load transistor
    # drain, gate, source, bulk, model, w, l
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_45nm)
    # Load capacitor (fixed as per requirements) - do NOT include in optimization search
    circuit.C('load', 'Vout', circuit.gnd, 1e-15)  # Cload = 1 fF (fixed)
    return circuit
# Optimization parameter search ranges (for use by Optuna or similar)
# All voltage sources except Vdd and Vin are allowed to vary within 0.8-1.2× original,
# but never exceed 1.2 V. W ranges are given with L fixed at 45 nm.
#
# IMPORTANT: initial_params below contains EXACTLY the original values from the provided netlist.
# Process/fixed length used for bounds
L = 45e-9          # 45 nm (fixed process length)
param_ranges_definition = {
    # Transistor widths (W). Sampling `log` is often reasonable for geometry tuning.
    # Constraint: 1-500×L is recommended. To ensure the original (provided) initial value
    # is inside the search range, the upper bound is set to max(500*L, original_value).
    # If the original value already exceeds 500*L, we keep the original as the upper bound
    # so the optimizer can start at the exact original point.
    'w_M1': {
        'min': 1.0 * L,                         # 1 × L = 45e-9 [m]
        'max': max(500.0 * L, 60e-6),           # max(500×L, original) -> ensures initial included
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L,                         # 1 × L
        'max': max(500.0 * L, 20e-6),           # 500×L = 22.5e-6, original 20e-6 < 22.5e-6
        'log': True
    },
    # Bias voltage range: 0.8 - 1.2 × original, but never exceed 1.2 V supply.
    # Original Vbias = 0.78 V -> allowed range = [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    'Vbias': {
        'min': 0.8 * 0.78,
        'max': min(1.2 * 0.78, 1.2),
        'log': False
    },
    # Note: C_load is intentionally omitted from parameter search per instructions.
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    'w_M1': 60e-6,    # Original M1 width value from provided netlist (60 µm)
    'w_M2': 20e-6,    # Original M2 width value (20 µm)
    'Vbias': 0.78,    # Original bias voltage (0.78 V)
    # C_load not included (fixed at 1e-15 F in circuit)
}
# Brief description of each parameter (physical meaning)
param_descriptions = {
    'w_M1': "Width of the NMOS amplifier transistor M1 (meters). With L fixed to 45 nm, W/L sets M1's drive current.",
    'w_M2': "Width of the PMOS active-load transistor M2 (meters). With L fixed to 45 nm, W/L sets load current and headroom.",
    'Vbias': "Gate bias voltage applied to PMOS active load (volts). Controls PMOS operating point; chosen conservatively "
             "around original 0.78 V to keep devices in intended region given Vth ≈ 0.22 V.",
}
# Example of how the ranges look numerically (helpful validation)
# Note: all initial parameter values are guaranteed to be inside the ranges above.
if __name__ == "__main__":
    import pprint
    print("Parameter ranges:")
    pprint.pprint(param_ranges_definition)
    print("\nInitial parameters (exact original values):")
    pprint.pprint(initial_params)
    print("\nParameter descriptions:")
    pprint.pprint(param_descriptions)
