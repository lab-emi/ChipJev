from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage GBW/Power Optimized Amplifier - Corrected')
# Models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias = Vth + 0.2 = 0.22 + 0.2
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)       # Vbias = Vdd - |Vth| - 0.2 = 1.2 - 0.22 - 0.2
# Single-stage amplifier
# M1: NMOS common-source amplifier transistor
# drain, gate, source, bulk, model, w, l
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=60e-6, l=0.045e-6)
# M2: PMOS active current-source load
# drain, gate, source, bulk, model, w, l
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Modification 1 (fix): Replace undefined unit '1@u_fF' with an explicit numeric value in farads.
# Rationale: PySpice does not define u_fF. Use a numeric literal for a femtofarad (1e-15 F).
# This avoids NameError and is understood by PySpice.
circuit.C('load', 'Vout', circuit.gnd, 1e-15)  # Cload = 1 fF
# Note: Input node 'Vin' and output node 'Vout' are present as requested.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
