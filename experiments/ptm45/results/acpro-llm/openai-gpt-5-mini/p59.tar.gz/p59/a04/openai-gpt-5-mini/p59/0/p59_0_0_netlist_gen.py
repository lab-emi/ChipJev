from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - FoM Optimized')
# Define device models (parameters provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC bias for input (operating point) and PMOS gate bias (to set current, uses Vth=0.22V in selection)
circuit.V('in', 'Vin', circuit.gnd, 0.50)    # Vin DC bias (~Vth + moderate overdrive)
circuit.V('bias', 'Vbias', circuit.gnd, 0.88)  # Vbias chosen via Vth = 0.22 V (1.2 - 0.22 - 0.1 ≈ 0.88 V)
# Transistor sizing (45 nm technology)
L_min = 45e-9  # 45 nm channel length
# M1: NMOS input transistor (common-source)
# drain, gate, source, bulk
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=L_min)
# M2: PMOS active current-source load
# drain, gate, source, bulk
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=8e-6, l=L_min)
# Ready for simulation
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
