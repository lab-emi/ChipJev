```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

# Fixed technology length (kept constant for W/L optimization)
L_MIN = 45e-9  # 45 nm

def create_circuit(params):
    """
    Create the parameterized single-stage common-source amplifier circuit.

    Required: the module 'model' must expose nmos_params and pmos_params (imported above).
    The optimization framework will call this function with a params dict.
    """
    circuit = Circuit('Single-Stage CS Amplifier - FoM Optimized')

    # Device models (provided externally)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2V for 45nm technology

    # Input voltage (fixed - to be swept during DC operating point search externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.50)  # Vin fixed at 0.50 V (operating point)

    # Gate bias for PMOS (parameterized)
    # Note: params['v_bias'] is constrained to <= 1.2 V by the search ranges below.
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])

    # M1: NMOS input transistor (common-source)
    # drain, gate, source, bulk
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_MIN)

    # M2: PMOS active current-source load
    # drain, gate, source, bulk
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_MIN)

    return circuit


# ---------------------------
# Optimization parameter search ranges (annotated)
# ---------------------------

# For convenience, compute W bounds using the 1-500×L rule:
W_min = L_MIN * 1         # 1 × L
W_max = L_MIN * 500       # 500 × L

# Vbias original = 0.88 V. Allowed 0.8–1.2× original BUT must not exceed 1.2 V.
v_bias_min = max(0.8 * 0.88, 0.0)           # = 0.704 V
v_bias_max = min(1.2 * 0.88, 1.2)           # = 1.056 V (<= 1.2 V)

param_ranges_definition = {
    # Transistor widths (meters)
    # Use log scaling for device widths to allow exploration from very small to wide devices efficiently.
    'w_M1': {
        'min': W_min,            # 1 × L = 45e-9 m
        'max': W_max,            # 500 × L = 22.5e-6 m
        'log': True
    },
    'w_M2': {
        'min': W_min,
        'max': W_max,
        'log': True
    },

    # Bias voltage for PMOS gate (Vbias) - keep conservative shift around original 0.88 V
    # Linear sampling is recommended for voltages.
    'v_bias': {
        'min': v_bias_min,       # 0.8 × 0.88 = 0.704 V
        'max': v_bias_max,       # 1.2 × 0.88 = 1.056 V (capped at <=1.2 V)
        'log': False
    }
}

# ---------------------------
# Initial parameter values (EXACT original values from the provided circuit)
# These are the starting point for optimization and MUST match the original netlist.
# ---------------------------
initial_params = {
    'w_M1': 4e-6,   # Original width of M1 from the provided code (4 µm)
    'w_M2': 8e-6,   # Original width of M2 from the provided code (8 µm)
    'v_bias': 0.88  # Original Vbias from the provided code (0.88 V)
}

# ---------------------------
# Brief descriptions of each parameter (physical meaning)
# ---------------------------
param_descriptions = {
    'w_M1': "NMOS input transistor M1 channel width (meters). L fixed at 45 nm. "
            "Changing w_M1 adjusts the device current, gm, input capacitance and output impedance.",
    'w_M2': "PMOS load transistor M2 channel width (meters). L fixed at 45 nm. "
            "Changing w_M2 alters the load current, output resistance and DC operating point.",
    'v_bias': "DC gate bias applied to PMOS load (voltage, V). Determines M2 conduction (current source level) "
              "and helps set the amplifier operating point. Range is conservative (0.704–1.056 V) and capped at 1.2 V."
}
```