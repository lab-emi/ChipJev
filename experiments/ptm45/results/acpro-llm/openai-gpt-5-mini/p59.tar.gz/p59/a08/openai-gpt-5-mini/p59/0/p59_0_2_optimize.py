from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
# Parameter ranges definition
# Note: units are SI (W in meters, R in ohms, V in volts)
param_ranges_definition = {
    # Transistor widths (W). Constraints: 1–500 × device L (L kept fixed per-device as in original netlist).
    # M1 original L = 45e-9 -> W range = [45e-9, 22.5e-6]
    'w_M1': { 'min': 1 * 45e-9,    'max': 500 * 45e-9,    'log': True },
    # M2 original L = 180e-9 -> W range = [180e-9, 90e-6]
    'w_M2': { 'min': 1 * 180e-9,   'max': 500 * 180e-9,   'log': True },
    # Bias voltage for PMOS gate (Vbias).
    # Rule: 0.8–1.2 × original, but never exceed 1.2 V.
    # Original Vbias = 0.20 V -> range = [0.16, 0.24] V
    # (This keeps PMOS Vsg = Vdd - Vbias comfortably > Vth=0.22 V for typical biases;
    # Vbias upper = 0.24 still keeps Vsg = 0.96 V > 0.22 V)
    'v_bias': { 'min': 0.8 * 0.20,  'max': min(1.2 * 0.20, 1.2), 'log': False },
    # Bleed resistor: 0.5–2 × original
    # Original Rbleed = 1e9 ohm -> range = [0.5e9, 2e9] ohm
    'r_bleed': { 'min': 0.5e9,      'max': 2e9,             'log': True },
}
# Initial parameter values (EXACT original circuit values; these must not be modified)
initial_params = {
    'w_M1': 12e-6,     # Original M1 width (12 µm)
    'w_M2': 24e-6,     # Original M2 width (24 µm)
    'v_bias': 0.20,    # Original bias voltage (0.20 V)
    'r_bleed': 1e9,    # Original bleed resistor (1 GΩ)
}
