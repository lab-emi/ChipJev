from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier - Fixed Operating Point')
# MOSFET models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
# Adjusted DC bias voltages to ensure devices operate in conduction region
# Vin is set high enough so NMOS has Vgs > Vth; Vbias is set low enough so PMOS has Vsg > |Vth|
circuit.V('in', 'Vin', circuit.gnd, 0.60)     # Vin DC bias (0.60 V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.20) # Vbias for PMOS gate (0.20 V)
# Single-stage amplifier:
# M1: NMOS common-source input transistor
#   drain -> Vout, gate -> Vin, source & bulk -> gnd
# M2: PMOS active current-source load
#   drain -> Vout, gate -> Vbias, source & bulk -> Vdd
# Sizes selected for 45nm technology (W in meters, L in meters)
# M1: minimum length for speed, moderate width for reasonable gm at low-medium current
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=45e-9)
# M2: PMOS active load: wider and longer channel for higher r_o (higher gain) while providing load current
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=180e-9)
# A very large bleed resistor to ground to help define the DC operating point robustly
# This is very large so it minimally affects AC performance but prevents a floating node in pathological cases.
circuit.R('bleed', 'Vout', circuit.gnd, 1@u_Gu)  # 1 GΩ
# End of netlist; create simulator (do not add further code)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
