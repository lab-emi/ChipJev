from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
# Create circuit
circuit = Circuit('Single-Stage CS Amplifier - Corrected')
# Load external MOS models (provided by the environment)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
# ------------------------
# Modification 1 (bias): Provide DC biases that ensure devices conduct
# - NMOS needs Vgs > Vth (~0.22 V). Set Vin = 0.60 V -> Vgs_M1 = 0.60 V (ON).
# - PMOS needs Vsg > |Vth|. Set Vbias = 0.20 V -> Vsg_M2 = Vdd - Vbias = 1.0 V (ON).
# These bias choices prevent both devices from being off simultaneously.
# ------------------------
circuit.V('in', 'Vin', circuit.gnd, "dc 0.60 ac 1n")
circuit.V('bias', 'Vbias', circuit.gnd, 0.20) # Vbias for PMOS gate (ensures M2 ON)
# ------------------------
# Single-stage amplifier topology
# M1: NMOS common-source (input)
#   drain -> Vout, gate -> Vin, source & bulk -> gnd
# M2: PMOS active load
#   drain -> Vout, gate -> Vbias, source & bulk -> Vdd
# ------------------------
# Modification 2 (sizing): Use 45nm-technology-appropriate sizes.
# - M1: minimum L for speed, moderate W to get gm at low current.
# - M2: wider and longer L to increase output resistance (improve gain at low I).
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=45e-9)   # M1: NMOS input
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=24e-6, l=180e-9)  # M2: PMOS active load
# Modification 3 (prevent floating node): Add a very large bleed resistor to define DC node.
# Reason: If there are pathological model edge-cases where both transistors are nearly off,
# the bleed resistor prevents an undefined floating Vout during operating-point solve.
# Use a numeric value instead of a unit constant that caused the NameError before.
circuit.R('bleed', 'Vout', circuit.gnd, 1e9)   # 1 GΩ bleed resistor (very large)
# End of netlist; create simulator (do not add further code)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)