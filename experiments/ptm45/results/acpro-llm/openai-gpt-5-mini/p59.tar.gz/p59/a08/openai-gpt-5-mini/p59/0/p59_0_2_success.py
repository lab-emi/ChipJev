from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
# Create circuit
circuit = Circuit('Single-Stage CS Amplifier - Corrected')
# Load external MOS models (provided by the environment)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
# ------------------------
# Modification 1 (bias): Provide DC biases that ensure devices conduct
# - NMOS needs Vgs > Vth (~0.22 V). Set Vin = 0.60 V -> Vgs_M1 = 0.60 V (ON).
# - PMOS needs Vsg > |Vth|. Set Vbias = 0.20 V -> Vsg_M2 = Vdd - Vbias = 1.0 V (ON).
# These bias choices prevent both devices from being off simultaneously.
# ------------------------
circuit.V('in', 'Vin', circuit.gnd, 0.60)     # Vin DC bias (ensures M1 ON)
circuit.V('bias', 'Vbias', circuit.gnd, 0.20) # Vbias for PMOS gate (ensures M2 ON)
# ------------------------
# Single-stage amplifier topology
# M1: NMOS common-source (input)
#   drain -> Vout, gate -> Vin, source & bulk -> gnd
# M2: PMOS active load
#   drain -> Vout, gate -> Vbias, source & bulk -> Vdd
# ------------------------
# Modification 2 (sizing): Use 45nm-technology-appropriate sizes.
# - M1: minimum L for speed, moderate W to get gm at low current.
# - M2: wider and longer L to increase output resistance (improve gain at low I).
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=45e-9)   # M1: NMOS input
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=24e-6, l=180e-9)  # M2: PMOS active load
# Modification 3 (prevent floating node): Add a very large bleed resistor to define DC node.
# Reason: If there are pathological model edge-cases where both transistors are nearly off,
# the bleed resistor prevents an undefined floating Vout during operating-point solve.
# Use a numeric value instead of a unit constant that caused the NameError before.
circuit.R('bleed', 'Vout', circuit.gnd, 1e9)   # 1 GΩ bleed resistor (very large)
# End of netlist; create simulator (do not add further code)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
