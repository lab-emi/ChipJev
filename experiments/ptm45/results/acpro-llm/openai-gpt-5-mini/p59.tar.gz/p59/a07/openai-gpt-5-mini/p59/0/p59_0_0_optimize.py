from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: the model import required by the framework will be inside create_circuit
# (kept there exactly as requested).
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage GBW/Power Optimized Amplifier')
    # MOSFET models (from provided model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V (fixed)
    # Input voltage source (fixed, not parameterized; swept externally during analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias fixed at 0.42 V
    # Bias voltage (parameterized, constrained per requirements)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # parameterized bias source
    # Transistor channel length (fixed for 45nm process)
    L_fixed = 0.045e-6  # 45 nm (fixed, do NOT include in optimization)
    # NMOS amplifier (M1): drain = Vout, gate = Vin, source = gnd, bulk = gnd
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)
    # PMOS current-source load (M2): drain = Vout, gate = Vbias, source = Vdd, bulk = Vdd
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_fixed)
    # No explicit load capacitor in the original netlist (C_load omitted to maximize GBW).
    # If a load capacitance existed, per instructions it should remain fixed and not be part of the search.
    return circuit
# ===== Optimization parameter search ranges =====
# Notes:
# - L_fixed = 45 nm (0.045e-6 m) is constant and not included in the search.
# - Transistor width ranges nominally follow 1xL .. 500xL, but must also include the original
#   width values as required. M2 original width (40e-6 m) exceeds 500*L (22.5e-6 m),
#   so the upper bound for w_M2 is extended to include the original value (see comment below).
#
L = 0.045e-6
param_ranges_definition = {
    # Transistor widths (meters)
    # w range: 1xL .. 500xL (log-uniform), but ensure initial/original widths are inside the range.
    'w_M1': {
        'min': 1.0 * L,                  # 1 * L = 45e-9 m
        'max': 500.0 * L,                # 500 * L = 22.5e-6 m
        'log': True
    },
    # M2 original width is 40e-6 which is larger than 500*L (22.5e-6). To satisfy the requirement that
    # initial_params == original values AND be inside the search range, we extend the upper bound to the
    # original value. This preserves the 1..500*L rule where possible but ensures the initial point is valid.
    'w_M2': {
        'min': 1.0 * L,
        'max': max(500.0 * L, 40e-6),    # = 40e-6 m to include original value (otherwise original would be outside)
        'log': True
    },
    # Voltage sources (except Vdd and Vin which are fixed)
    # Rule: within 0.8 - 1.2 × original, but never exceed 1.2 V (supply).
    # Original v_bias = 0.78 V -> allowed range [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    'v_bias': {
        'min': 0.8 * 0.78,               # conservative lower bound (0.624 V)
        'max': min(1.2 * 0.78, 1.2),     # conservative upper bound but <= 1.2 V (0.936 V)
        'log': False
    }
    # No resistors or capacitors were present in the original netlist.
    # If added later, follow the stated multiplier constraints in the prompt.
}
# ===== Initial parameter values (EXACT original circuit values) =====
# These must be exactly the values present in the original netlist and must be within the ranges above.
initial_params = {
    'w_M1': 20e-6,   # Original NMOS width = 20 µm (exact)
    'w_M2': 40e-6,   # Original PMOS width = 40 µm (exact) -- note: exceeds 500*L, upper bound extended to include this
    'v_bias': 0.78   # Original bias voltage = 0.78 V (exact)
}
# ===== Brief descriptions of parameters (physical meaning) =====
# w_M1  : NMOS device M1 channel width (m). Changing this alters current drive, transconductance, parasitics.
# w_M2  : PMOS device M2 channel width (m). Acts as active load current source; affects tail/load current and output resistance.
# v_bias: DC bias voltage applied to the PMOS gate (Vbias). Adjusts the operating point of the PMOS current source and the amplifier DC operating point.
#
# Notes / rationale:
# - L is fixed at 45 nm (0.045e-6 m) because W/L ratio is the actual design degree of freedom in the optimizer.
# - Vin (0.42 V) and Vdd (1.2 V) are intentionally fixed; Vin is swept during DC analyses and Vdd is the supply rail.
# - v_bias search is conservative and clamped to ≤ 1.2 V. The v_bias range was chosen with the 0.8–1.2× rule while ensuring it does not exceed supply.
# - Transistor width ranges are log-uniform to cover many decades effectively during optimization; widths are specified in meters.
# - M2's original width (40 µm) exceeds 500×L (22.5 µm). To satisfy the requirement that initial_params exactly match the original netlist
#   and that initial values lie within the search ranges, w_M2's upper bound is extended to include 40 µm.
#   If you prefer to strictly enforce the 1–500×L rule, set w_M2['max'] = 500.0 * L and adjust initial_params accordingly.
