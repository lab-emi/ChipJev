from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Optimized for GBW/Power')
# MOS models (from external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Supplies and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)     # Vdd = 1.2 V
# Set DC operating point for input node so that Vgs(M1) = Vth + Vov = 0.22 + 0.10 = 0.32 V
circuit.V('in', 'Vin', circuit.gnd, 0.32)    # Vin DC bias (operating point)
# PMOS gate bias to set current source Vsg ≈ |Vth| + Vov_load = 0.22 + 0.10 => Vbias ≈ 1.2 - 0.32 = 0.88 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.88)  # PMOS gate bias
# Transistor sizing (45 nm technology)
# M1: NMOS common-source amplifier
# name, drain, gate, source, bulk, model, w, l
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=0.045e-6)
# M2: PMOS active current-source load
# source and bulk tied to Vdd
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=0.045e-6)
# Note: Vout node appears as the drain node of M1 and M2
# Create simulator (no AC sources used; operating point / DC analysis expected)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
