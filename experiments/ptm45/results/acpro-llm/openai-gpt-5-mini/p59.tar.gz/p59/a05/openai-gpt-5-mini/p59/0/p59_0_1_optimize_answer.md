```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Parameterized circuit creation for optimization frameworks.
    Required name: create_circuit(params)
    - Keeps vdd and input voltages fixed (not parameterized).
    - Uses fixed device length (45 nm) and parameterizes widths only.
    - Imports MOS models from the provided `model` module.
    """
    circuit = Circuit('Single-Stage FoM-Optimized Amplifier - Parametrized')

    # Keep the provided MOS models import exactly as requested
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V (fixed)

    # Input voltages (fixed, will be swept during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.60)   # Vin DC bias (fixed)
    # Note: No other input (Vinp/Vinn) in the original netlist; they remain fixed if added.

    # Other DC bias sources (parameterized)
    # Vbias is parameterized per requirements (within 0.8-1.2x original, capped <= 1.2V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])

    # Fixed process length (keep L constant at 45 nm for optimization; only W varies)
    L_FIXED = 45e-9  # 45 nm (process length used for W/L)

    # NMOS input transistor (M1)
    # Original mapping: M1: drain -> Vout, gate -> Vin, source -> gnd, bulk -> gnd
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_FIXED)

    # PMOS active load (M2)
    # Original mapping: M2: drain -> Vout, gate -> Vbias, source -> Vdd, bulk -> Vdd
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_FIXED)

    # No load capacitors or resistors in the original netlist to parameterize.
    # If adding compensation or load components later, follow constraints in the param ranges.

    return circuit


# ---------------------------------------------------------------------
# Optimization parameter search ranges (annotated)
# All units shown in SI units (meters for widths, volts for voltages).
# Rationale:
# - Transistor widths: 1 - 500 × L_FIXED (L_FIXED = 45e-9 -> [45e-9, 22.5e-6])
# - Voltages (other than vdd and input Vin): 0.8 - 1.2 × original, capped at <= 1.2 V
# ---------------------------------------------------------------------
param_ranges_definition = {
    # Transistor widths (only W is optimized; L is fixed at 45 nm)
    'w_M1': {
        'min': 45e-9,         # 1 × L (45 nm)
        'max': 22.5e-6,       # 500 × L
        'scale': 'log',       # log scale sampling recommended for wide dynamic range
        'unit': 'm',
        'note': 'NMOS input transistor width (M1)'
    },
    'w_M2': {
        'min': 45e-9,         # 1 × L
        'max': 22.5e-6,       # 500 × L
        'scale': 'log',
        'unit': 'm',
        'note': 'PMOS active-load transistor width (M2)'
    },

    # DC bias voltages (other than Vdd and Vin which are fixed)
    # Original Vbias = 0.30 V -> 0.8*0.30 = 0.24 V to 1.2*0.30 = 0.36 V
    # Also ensure values never exceed 1.2 V (satisfied here)
    'v_bias': {
        'min': 0.24,          # 0.8 * original (V)
        'max': 0.36,          # 1.2 * original (V)
        'scale': 'linear',
        'unit': 'V',
        'note': 'PMOS gate bias (Vbias). Keep conservative to maintain PMOS Vsg; Vth=0.22V considered.'
    },
}

# ---------------------------------------------------------------------
# Initial parameter values (EXACT original circuit values from the provided netlist)
# IMPORTANT: These exact values are preserved as the starting point for optimization.
# Units: widths in meters, voltages in volts
# ---------------------------------------------------------------------
initial_params = {
    'w_M1': 5.0e-6,    # Original width for M1 (5.0e-6 m)
    'w_M2': 10.0e-6,   # Original width for M2 (10.0e-6 m)
    'v_bias': 0.30,    # Original Vbias (0.30 V)
}

# ---------------------------------------------------------------------
# Brief parameter descriptions (physical meaning)
# ---------------------------------------------------------------------
param_descriptions = {
    'w_M1': 'NMOS input transistor gate width (meters). Controls drive strength and gm. L is fixed at 45 nm.',
    'w_M2': 'PMOS active-load transistor gate width (meters). Controls current supplied by active load. L is fixed at 45 nm.',
    'v_bias': 'DC bias applied to PMOS gate (Vbias) in volts. Tunes the PMOS source-gate voltage (Vsg) and operating current.'
}
```

Notes / reasoning highlights:
- create_circuit uses the exact import line "from model import nmos_params, pmos_params" as requested.
- vdd and Vin are fixed (not included in param search) so they can be swept externally during DC analysis.
- L is fixed at 45 nm per instruction; only W is parameterized. Width ranges follow 1–500×L (45e-9 → 22.5e-6 m).
- Vbias range is 0.8–1.2× original and kept ≤ 1.2 V. The lower bound (0.24 V) remains above Vth=0.22 V (conservative margin).
- initial_params contains the EXACT values from your original netlist and they are inside the declared ranges.