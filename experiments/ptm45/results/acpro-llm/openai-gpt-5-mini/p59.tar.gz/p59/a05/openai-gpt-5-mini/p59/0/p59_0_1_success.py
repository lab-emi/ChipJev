from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage FoM-Optimized Amplifier - Corrected')
# Define MOS models from provided model parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (operating-point biasing only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V
# Adjusted DC bias values to ensure a valid operating point (non-zero Id)
# Vin is increased to ensure M1 is well above threshold.
# Vbias is lowered to increase PMOS Vsg so the active load provides current.
circuit.V('in', 'Vin', circuit.gnd, 0.60)   # Vin DC bias (gate of M1)
circuit.V('bias', 'Vbias', circuit.gnd, 0.30)  # PMOS gate bias (sets current through M2)
# Single-stage common-source amplifier
# M1: input NMOS (drain -> Vout, gate -> Vin, source -> gnd, bulk -> gnd)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5.0e-6, l=0.045e-6)
# M2: PMOS active current-source load (drain -> Vout, gate -> Vbias, source -> Vdd, bulk -> Vdd)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=10.0e-6, l=0.18e-6)
# Create a simulator object for operating-point / small-signal work
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
