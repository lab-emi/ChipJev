from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage FoM-Optimized Amplifier')
# Define MOS models from provided model parameters
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (operating-point biasing only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)               # Vin DC bias ~ Vth + 0.2 (0.22 + 0.2)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)           # PMOS gate bias ~ Vdd - |Vth| - 0.2
# Single-stage common-source amplifier
# M1: input NMOS (drain -> Vout, gate -> Vin, source -> gnd, bulk -> gnd)
# Use a relatively wide device for good gm at low current, min length for speed
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2.0e-6, l=0.045e-6)
# M2: PMOS active current-source load (drain -> Vout, gate -> Vbias, source -> Vdd, bulk -> Vdd)
# Use longer L for higher output resistance (improves gain without extra current)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=6.0e-6, l=0.18e-6)
# The output node is Vout (connected to drain of M1 and M2)
# No explicit load or feedback is added to keep the pole frequency high and avoid positive feedback.
# Create a simulator object for operating-point / small-signal work
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p59/0/p59_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
