```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: per requirement, the model import must appear exactly as written inside the circuit creation function

def create_circuit(params):
    """
    Create the Single-Stage Differential Opamp (GBW-optimized) circuit.
    This function expects a params dict containing:
      - w_M1, w_M2, w_Mtail, w_M3, w_M4 : transistor widths (meters)
      - v_bias : tail gate bias (volts)
    The transistor models are imported from the provided `model` module (nmos_params, pmos_params).
    Vdd, Vinp and Vinn are kept fixed (not parameterized) as required.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential Opamp (GBW-optimized)')

    # MOSFET models (provided externally via the imported module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V (fixed)

    # Input voltages (fixed - will be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.60)   # Vinp = 0.60 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.58)   # Vinn = 0.58 V (fixed)

    # Tail bias (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # parameterized tail gate bias

    # Node names:
    # Vs  = common source node of input pair (drain of tail)
    # D1  = left drain node and diode-connected PMOS gate
    # Vout = output node (right drain)

    # Fixed process length (45 nm). Length is held constant for optimization.
    L = 0.045e-6  # 0.045 µm = 45 nm

    # First stage: NMOS differential pair
    # MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model', w=params['w_M1'], l=L)   # left input
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model', w=params['w_M2'], l=L)  # right input (output drain)

    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Vs', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L)

    # PMOS active load: M3 diode-connected, M4 mirror
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)   # diode-connected PMOS on left
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)  # mirror PMOS on right (output load)

    # No explicit load capacitor or resistor added here (GBW-optimized as requested)

    return circuit


# Optimization parameter search ranges (for Optuna or similar)
# Note: L is 45e-9 (0.045e-6). Recommended W range is 1-500 × L => [L, 500*L] .
# To ensure the initial (original) values are included in their ranges (requirement),
# the upper bound is set to max(500*L, original_width) so that the original widths
# are inside the ranges even if they exceed the 500×L recommendation.
#
# All voltage sources (except Vdd and the input Vinp/Vinn which are fixed) use 0.8-1.2×
# their original values but are capped at 1.2 V (supply). For Vbias the original is 0.80 V,
# so the allowed range is [0.8*0.8, min(1.2, 1.2*0.8)] => [0.64, 0.96] V.
#
# All initial parameter values below are EXACTLY the original values from the provided netlist.

L = 0.045e-6  # process length (45 nm)
recommended_w_min = L
recommended_w_max = 500 * L  # 22.5e-6 (recommended upper bound)

param_ranges_definition = {
    # Transistor widths (meters). Log scale is helpful over wide dynamic ranges.
    'w_M1': {
        'min': recommended_w_min,
        'max': max(recommended_w_max, 20e-6),  # include original if it exceeds recommended max
        'log': True
    },
    'w_M2': {
        'min': recommended_w_min,
        'max': max(recommended_w_max, 20e-6),
        'log': True
    },
    'w_Mtail': {
        'min': recommended_w_min,
        'max': max(recommended_w_max, 4e-6),
        'log': True
    },
    'w_M3': {
        'min': recommended_w_min,
        # Original is 60e-6 which exceeds 500×L (22.5e-6). To satisfy the requirement that initial
        # parameters must be in-range, we expand the upper bound to include the original value.
        # Note: original > 500*L; this is flagged in the parameter description below.
        'max': max(recommended_w_max, 60e-6),
        'log': True
    },
    'w_M4': {
        'min': recommended_w_min,
        # Same note as for M3
        'max': max(recommended_w_max, 60e-6),
        'log': True
    },

    # Tail bias voltage (volts). Must be within 0.8-1.2× original and ≤ 1.2 V.
    # Original v_bias = 0.80 V -> range [0.8*0.80, min(1.2,1.2*0.80)] = [0.64, 0.96] V
    'v_bias': {
        'min': max(0.8 * 0.80, 0.22 + 0.05),   # also ensure safely above threshold (Vth=0.22 V + margin)
        'max': min(1.2, 1.2 * 0.80),
        'log': False
    }
}

# Initial parameter values (EXACT original circuit values; must match the provided netlist)
initial_params = {
    'w_M1': 20e-6,     # original width for M1 (meters)
    'w_M2': 20e-6,     # original width for M2 (meters)
    'w_Mtail': 4e-6,   # original width for Mtail (meters)
    'w_M3': 60e-6,     # original width for M3 (meters)  <-- note: exceeds 500*L
    'w_M4': 60e-6,     # original width for M4 (meters)  <-- note: exceeds 500*L
    'v_bias': 0.80     # original tail gate bias (volts)
}

# Parameter descriptions (brief physical meaning)
param_descriptions = {
    'w_M1': 'Width of NMOS M1 (left input transistor). Sets transconductance and input pair tail current division.',
    'w_M2': 'Width of NMOS M2 (right input / output transistor). Sets transconductance and output drive.',
    'w_Mtail': 'Width of NMOS tail device (Mtail). Controls tail current magnitude and output impedance of source node Vs.',
    'w_M3': 'Width of PMOS diode-connected device (left side). Sets mirror bias point and load resistance seen by the differential pair. NOTE: original width (60e-6 m) exceeds 500×L; upper range expanded to include original value.',
    'w_M4': 'Width of PMOS mirror device (right side, output load). Sets output load current and output resistance. NOTE: original width (60e-6 m) exceeds 500×L; upper range expanded to include original value.',
    'v_bias': 'Tail gate bias (Vbias) that sets the tail current. Parameterized within 0.8–1.2× original (capped by 1.2 V). Keep conservative to maintain device in intended operating region.'
}

# Sanity checks to ensure initial values lie within the defined ranges.
# (Optional helper, not required by the framework; retained for clarity)
def _check_initials_in_range():
    for k, v in initial_params.items():
        if k not in param_ranges_definition:
            continue
        rng = param_ranges_definition[k]
        if not (rng['min'] <= v <= rng['max']):
            raise ValueError(f"Initial parameter {k}={v} is outside defined range [{rng['min']}, {rng['max']}]")

# Run the sanity check now (will raise if there is a mismatch)
_check_initials_in_range()
```

Notes / rationale summary:
- The function create_circuit(params) is provided exactly as required and imports nmos_params and pmos_params from model inside the function (as requested).
- Vdd and input voltages (Vinp, Vinn) remain fixed (not parameterized); Vbias is parameterized with a conservative 0.8–1.2× range and capped at 1.2 V. The v_bias range also respects a safety margin above Vth (0.22 V).
- Channel lengths (L) are kept constant at 45 nm (0.045e-6 m) — only widths are exposed to optimization, since behavior depends on W/L.
- Transistor width ranges are based on the 1–500×L rule; however, M3 and M4 original widths (60e-6 m) exceed 500×L (22.5e-6 m). To satisfy the strict requirement that initial parameters equal the original values, their upper bounds were expanded to include the original values (this is noted in the descriptions).
- There are no resistors or capacitors in the provided netlist; load capacitors are not present and therefore not parameterized (per instruction).