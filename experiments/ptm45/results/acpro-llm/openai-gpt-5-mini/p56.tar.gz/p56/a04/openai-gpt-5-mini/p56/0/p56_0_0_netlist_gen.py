from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Opamp (GBW-optimized)')
# MOSFET models (provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC input/bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.60)   # Vinp DC bias ~ 0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.58)   # Vinn DC bias ~ 0.58 V (small offset)
circuit.V('bias', 'Vbias', circuit.gnd, 0.80) # Tail gate bias ~ 0.8 V
# Node names:
# Vs  = common source node of input pair (drain of tail)
# D1  = left drain node and diode-connected PMOS gate
# Vout = output node (right drain)
# First stage: NMOS differential pair
# MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=0.045e-6)   # left input
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=0.045e-6)  # right input (output drain)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=0.045e-6)
# PMOS active load: M3 diode-connected, M4 mirror
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=0.045e-6)   # diode-connected PMOS on left
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=0.045e-6)  # mirror PMOS on right (output load)
# No explicit load capacitor or resistor is added to maximize GBW at the node Vout.
# The input and output node names required by the problem are present: Vinp, Vinn, Vout.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
