from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (Max GBW, no positive feedback)')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (only DC operating points)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp DC bias (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn DC bias (common-mode)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)  # Tail bias (Vth + 0.2 ~ 0.42 V)
# Node names:
# Dref  - drain of left input transistor and gate of diode PMOS (mirror reference)
# Vs    - common-source node (drain of tail transistor)
# Vout  - output node (drain of right input transistor)
# Transistor dimensions (45 nm technology)
L = 0.045e-6        # 45 nm channel length (in meters)
W_in = 20e-6        # input NMOS width (20 um)
W_pmos = 40e-6      # PMOS mirror widths (40 um)
W_tail = 5e-6       # tail NMOS width (5 um)
# Input NMOS differential pair
circuit.MOSFET('M1', 'Dref', 'Vinp', 'Vs', circuit.gnd,
               model='nmos_model', w=W_in, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Vs', circuit.gnd,
               model='nmos_model', w=W_in, l=L)
# PMOS active mirror load
# M3: diode-connected PMOS on the left (drain tied to gate) to set mirror bias
circuit.MOSFET('M3', 'Dref', 'Dref', 'Vdd', 'Vdd',
               model='pmos_model', w=W_pmos, l=L)
# M4: mirror device feeding the output node
circuit.MOSFET('M4', 'Vout', 'Dref', 'Vdd', 'Vdd',
               model='pmos_model', w=W_pmos, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=W_tail, l=L)
# Create a simulator (stop here, per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
