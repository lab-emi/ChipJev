from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# The model import is required inside the create_circuit function exactly as requested.
def create_circuit(params):
    """
    Create the single-stage differential op-amp circuit with parameterized widths and tail bias.
    Required: this function must contain the line:
        from model import nmos_params, pmos_params
    (kept exactly as requested)
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (Max GBW, no positive feedback)')
    # MOSFET models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply and DC bias sources
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd fixed at 1.2 V (NOT parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)      # Vinp fixed (swept externally during analyses)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)      # Vinn fixed (swept externally during analyses)
    # Tail bias (parameterized, but constrained conservatively)
    circuit.V('tail', 'Vtail', circuit.gnd, params['Vtail'])
    # Geometry: length fixed for 45 nm technology (keep L constant)
    L = 0.045e-6  # 45 nm in meters (fixed)
    # Transistors (widths parameterized, lengths fixed)
    # Input NMOS differential pair
    circuit.MOSFET('M1', 'Dref', 'Vinp', 'Vs', circuit.gnd,
                   model='nmos_model', w=params['W_in'], l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Vs', circuit.gnd,
                   model='nmos_model', w=params['W_in'], l=L)
    # PMOS active mirror load
    # M3: diode-connected PMOS on the left (drain tied to gate) to set mirror bias
    circuit.MOSFET('M3', 'Dref', 'Dref', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['W_pmos'], l=L)
    # M4: mirror device feeding the output node
    circuit.MOSFET('M4', 'Vout', 'Dref', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['W_pmos'], l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['W_tail'], l=L)
    return circuit
# ------------------------------
# Optimization parameter search ranges (annotated)
# ------------------------------
# Notes on rules applied:
# - L (=45 nm) is kept constant; widths (W) are parameterized.
# - Default guideline: W in [1×L, 500×L]. If the original (initial) value exceeds 500×L,
#   the upper bound is relaxed to include the original value so that initial_params
#   remain exactly as provided.
# - Vtail range is 0.8–1.2× original Vtail, but never > 1.2 V (supply). Also ensured the
#   lower bound stays above threshold considerations (original here already well above Vth).
# - All initial_params are EXACT copies of the original values provided by the user.
# Fixed technology length (for reference)
L_val = 0.045e-6           # 45 nm
# Compute recommended 1-500× limits
min_W = 1 * L_val
max_W_guideline = 500 * L_val  # 22.5e-6
# Original widths from the provided netlist (these exact values must be the initial params)
# W_in_original  = 20e-6
# W_pmos_original = 40e-6  <-- note: this exceeds 500×L (40e-6 > 22.5e-6)
# W_tail_original = 5e-6
# To satisfy "initial_params must be inside ranges", relax upper bound for W_pmos
# if it exceeds the 500×L guideline:
max_W_pmos = max(max_W_guideline, 40e-6)  # ensure the original 40e-6 is included
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling recommended for size optimization.
    'W_in': {
        'min': min_W,            # 1 × L = 45e-9 m
        'max': max_W_guideline,  # 500 × L = 22.5e-6 m
        'log': True,
        'unit': 'm',
        'note': 'Input NMOS width. W/L controls current and speed; L fixed at 45 nm.'
    },
    'W_pmos': {
        'min': min_W,
        'max': max_W_pmos,       # relaxed to include the original 40e-6 if necessary
        'log': True,
        'unit': 'm',
        'note': ('PMOS mirror width. Relaxed upper bound so initial value (40e-6 m) '
                 'is inside the search range; guideline was 1-500×L (22.5e-6 m).')
    },
    'W_tail': {
        'min': min_W,
        'max': max_W_guideline,
        'log': True,
        'unit': 'm',
        'note': 'Tail NMOS width controlling tail current source compliance.'
    },
    # Tail bias voltage (V). Range 0.8–1.2× original, clipped to <= 1.2 V (supply).
    'Vtail': {
        'min': max(0.8 * 0.42, 0.0),  # 0.336 V (original*0.8). Keep >= 0 V.
        'max': min(1.2 * 0.42, 1.2),  # 0.504 V (original*1.2) and <= 1.2 V supply
        'log': False,
        'unit': 'V',
        'note': ('Tail bias (gate of tail NMOS). Conservative 0.8–1.2× original '
                 'range; original = 0.42 V. Consider Vth=0.22 V when tuning.')
    }
}
# ------------------------------
# Initial parameter values (EXACT original circuit values; MUST NOT BE MODIFIED)
# ------------------------------
initial_params = {
    'W_in': 20e-6,    # original input NMOS width (20 um)
    'W_pmos': 40e-6,  # original PMOS mirror width (40 um) - note: exceeds 500×L guideline
    'W_tail': 5e-6,   # original tail NMOS width (5 um)
    'Vtail': 0.42     # original tail bias (V)
}
# ------------------------------
# Short descriptions of physical meaning of each parameter
# ------------------------------
parameter_descriptions = {
    'W_in': 'Width of the input NMOS devices (M1, M2). Controls input pair transconductance and current.',
    'W_pmos': 'Width of the PMOS mirror load devices (M3, M4). Controls mirror bias current and output load.',
    'W_tail': 'Width of the tail NMOS (Mtail). Controls tail current compliance and bias.',
    'Vtail': 'DC gate bias for the tail NMOS current source. Sets tail current operating point (conservative range).'
}
