from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (maximize GBW)')
# Define MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input nodes (DC common-mode voltages; no AC excitations per instructions)
circuit.V('inp', 'Vinp', circuit.gnd, 0.8)   # Vinp common-mode (DC)
circuit.V('inn', 'Vinn', circuit.gnd, 0.8)   # Vinn common-mode (DC)
# Tail bias (use Vth guidance: Vth = 0.22 V => Vbtail = Vth + 0.4 = 0.62 V)
circuit.V('bt', 'Vbtail', circuit.gnd, 0.62)
# Node names:
# Ntail  - common source node of input NMOS pair (tail drain)
# Nd1    - drain/diode node of left branch (also PMOS mirror gate)
# Vout   - drain of right NMOS / output node
# Technology sizing (45 nm)
Lmin = 45e-9
# Input NMOS differential pair
# M(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Nd1', 'Vinp', 'Ntail', 'Ntail', model='nmos_model', w=20e-6, l=Lmin)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Ntail', 'Ntail', model='nmos_model', w=20e-6, l=Lmin)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Ntail', 'Vbtail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=Lmin)
# PMOS active load: M3 diode-connected (left), M4 mirrors to right (output)
circuit.MOSFET('M3', 'Nd1', 'Nd1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=Lmin)  # diode-connected PMOS
circuit.MOSFET('M4', 'Vout', 'Nd1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=Lmin)  # mirror PMOS
# End of circuit definition — create a simulator object for further analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
