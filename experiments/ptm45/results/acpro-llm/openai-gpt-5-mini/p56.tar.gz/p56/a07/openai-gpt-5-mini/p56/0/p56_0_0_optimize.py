from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp circuit using parameter dictionary `params`.
    The import line below is required to be exactly as provided in the environment.
    """
    # Keep the model import exactly as requested (module available in environment)
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (maximize GBW)')
    # MOSFET models (external definitions)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (45nm process)
    # Input nodes (fixed common-mode voltages; will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.8)   # Vinp fixed at 0.8 V
    circuit.V('inn', 'Vinn', circuit.gnd, 0.8)   # Vinn fixed at 0.8 V
    # Tail bias: parameterized but clamped to not exceed 1.2 V
    vbtail = params.get('Vbtail', 0.62)
    # Safety clamp: ensure vbtail never exceeds Vdd (1.2V)
    if vbtail > 1.2:
        vbtail = 1.2
    circuit.V('bt', 'Vbtail', circuit.gnd, vbtail)
    # Technology length (fixed)
    Lmin = 45e-9
    # Transistor sizes (Widths parameterized, lengths fixed)
    # Using the same node names and topology as the original netlist
    circuit.MOSFET('M1', 'Nd1', 'Vinp', 'Ntail', 'Ntail',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=Lmin)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Ntail', 'Ntail',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=Lmin)
    circuit.MOSFET('Mtail', 'Ntail', 'Vbtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=Lmin)
    # PMOS active load: diode-connected M3 and mirror M4
    circuit.MOSFET('M3', 'Nd1', 'Nd1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=Lmin)
    circuit.MOSFET('M4', 'Vout', 'Nd1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=Lmin)
    return circuit
# -------------------------------
# Parameter search ranges
# -------------------------------
# Note on widths: requirement stated widths should be in 1-500× L.
# All transistor initial values from the original netlist are preserved in initial_params.
# Two PMOS widths (40e-6) exceed 500×L (22.5e-6). To satisfy both the 1-500×L guideline and the
# requirement that initial_params must be inside the search ranges, the upper bound is set to:
#   max(500*Lmin, original_width)
# This guarantees the original widths are within the search domain while keeping the 500×L guideline
# as a preferred default when possible.
Lmin = 45e-9
w_min = Lmin
w_max_500L = 500 * Lmin  # 22.5e-6
param_ranges_definition = {
    # Transistor widths (W). Log scaling is recommended for optimization over wide dynamic range.
    'w_M1': {
        'min': w_min,
        'max': max(w_max_500L, 20e-6),  # ensure original 20e-6 is included
        'log': True
    },
    'w_M2': {
        'min': w_min,
        'max': max(w_max_500L, 20e-6),  # ensure original 20e-6 is included
        'log': True
    },
    'w_Mtail': {
        'min': w_min,
        'max': max(w_max_500L, 4e-6),   # ensure original 4e-6 is included
        'log': True
    },
    'w_M3': {
        'min': w_min,
        'max': max(w_max_500L, 40e-6),  # original is 40e-6 > 500*L; allow up to original
        'log': True
    },
    'w_M4': {
        'min': w_min,
        'max': max(w_max_500L, 40e-6),  # original is 40e-6 > 500*L; allow up to original
        'log': True
    },
    # Tail bias voltage: 0.8 - 1.2 × original, but never > 1.2 V (Vdd)
    # Original Vbtail = 0.62 V => range = [0.8*0.62, min(1.2*0.62, 1.2)] = [0.496, 0.744]
    'Vbtail': {
        'min': 0.8 * 0.62,
        'max': min(1.2 * 0.62, 1.2),
        'log': False
    }
}
# -------------------------------
# Initial parameters (EXACT originals)
# -------------------------------
# These values are the EXACT values from the provided netlist and must remain unchanged.
initial_params = {
    'w_M1': 20e-6,    # original width for M1
    'w_M2': 20e-6,    # original width for M2
    'w_Mtail': 4e-6,  # original width for Mtail
    'w_M3': 40e-6,    # original width for M3 (diode-connected PMOS)
    'w_M4': 40e-6,    # original width for M4 (mirror PMOS)
    'Vbtail': 0.62    # original tail bias voltage (V)
}
# -------------------------------
# Parameter descriptions
# -------------------------------
param_descriptions = {
    'w_M1': "Width of input NMOS M1 (left diff pair). Length fixed at 45 nm. Affects input device transconductance and GBW.",
    'w_M2': "Width of input NMOS M2 (right diff pair / output side). Length fixed at 45 nm. Affects input device transconductance and output drive.",
    'w_Mtail': "Width of tail NMOS current source (Mtail). Length fixed at 45 nm. Affects tail current and common-source impedance.",
    'w_M3': "Width of diode-connected PMOS (active load left). Length fixed at 45 nm. Affects mirror bias point and load resistance.",
    'w_M4': "Width of mirror PMOS (active load right / output). Length fixed at 45 nm. Affects mirror output resistance and load on output node.",
    'Vbtail': "Voltage of tail bias source (Vbtail). Sets gate of tail NMOS current source; range selected conservatively around original 0.62 V (Vth guidance considered)."
}
# Notes:
# - Vdd and the input common-mode sources (Vinp, Vinn) are intentionally fixed (not parameterized)
#   per requirements and should be swept externally during DC analysis if required.
# - No resistors or capacitors were present in the original netlist, so none are parameterized.
# - The load capacitor note: there were no explicit load capacitors in the provided netlist. If you later
#   add compensation or load capacitors, follow the specified range rules (comp: 0.5-5×, other caps: 0.8-1.5×).
# - All initial parameter values above are exactly those from the original code and are included
#   within the ranges defined in param_ranges_definition.
