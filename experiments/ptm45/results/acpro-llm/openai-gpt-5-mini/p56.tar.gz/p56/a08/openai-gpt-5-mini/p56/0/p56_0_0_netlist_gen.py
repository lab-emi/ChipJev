from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (Max GBW, No Positive Feedback)')
# Define MOSFET models (provided by external model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC input/bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)    # Vinp common-mode = 0.6 V (DC)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)    # Vinn common-mode = 0.6 V (DC)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42) # Tail bias = Vth + 0.20 = 0.42 V
# Node names:
# - Dleft: drain of M1 and diode-connected PMOS M3
# - Vout: output node (drain of M2 and mirror PMOS M4)
# - Tail: common source node for M1/M2 and drain of tail transistor M5
# Transistor sizing (45 nm technology)
L_min = 0.045e-6
# M1: NMOS input (left)
circuit.MOSFET('M1', 'Dleft', 'Vinp', 'Tail', 'Tail', model='nmos_model',
               w=20e-6, l=L_min)
# M2: NMOS input (right) -> output node at its drain
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Tail', 'Tail', model='nmos_model',
               w=20e-6, l=L_min)
# M3: PMOS diode-connected active load (reference)
circuit.MOSFET('M3', 'Dleft', 'Dleft', 'Vdd', 'Vdd', model='pmos_model',
               w=40e-6, l=L_min)
# M4: PMOS mirror load (drives the output node)
circuit.MOSFET('M4', 'Vout', 'Dleft', 'Vdd', 'Vdd', model='pmos_model',
               w=40e-6, l=L_min)
# M5: NMOS tail current source
circuit.MOSFET('M5', 'Tail', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model',
               w=10e-6, l=L_min)
# End of netlist; create simulator for operating-point / further analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
