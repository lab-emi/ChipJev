```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp (parameterized).

    Required: this function must import nmos_params and pmos_params exactly as:
        from model import nmos_params, pmos_params
    (kept above at module level per requirement)
    """
    # Keep the process length fixed (45 nm)
    L_min = 0.045e-6  # 45 nm (fixed, not parameterized)

    # Retrieve parameters (use defaults if not provided)
    w_M1 = params['w_M1']
    w_M2 = params['w_M2']
    w_M3 = params['w_M3']
    w_M4 = params['w_M4']
    w_M5 = params['w_M5']

    # Other parameterized sources
    v_tail = params['v_tail']  # tail bias (parameterized; Vin/Vdd kept fixed)

    circuit = Circuit('Single-Stage Differential OpAmp (Max GBW, No Positive Feedback)')

    # MOSFET models (provided by external model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply and DC input/bias sources
    # vdd and input voltages are fixed (per requirement)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn = 0.6 V (fixed)

    # Tail bias is parameterized (but constrained within 0.8-1.2× original and <=1.2V)
    circuit.V('tail', 'Vtail', circuit.gnd, v_tail) # Tail bias (parameterized)

    # Transistor instances - lengths fixed to L_min, widths parameterized
    # M1: NMOS input (left)
    circuit.MOSFET('M1', 'Dleft', 'Vinp', 'Tail', 'Tail',
                   model='nmos_model', w=w_M1, l=L_min)

    # M2: NMOS input (right) -> output node at its drain
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Tail', 'Tail',
                   model='nmos_model', w=w_M2, l=L_min)

    # M3: PMOS diode-connected active load (reference)
    circuit.MOSFET('M3', 'Dleft', 'Dleft', 'Vdd', 'Vdd',
                   model='pmos_model', w=w_M3, l=L_min)

    # M4: PMOS mirror load (drives the output node)
    circuit.MOSFET('M4', 'Vout', 'Dleft', 'Vdd', 'Vdd',
                   model='pmos_model', w=w_M4, l=L_min)

    # M5: NMOS tail current source
    circuit.MOSFET('M5', 'Tail', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=w_M5, l=L_min)

    # Note: The original netlist did not include explicit resistors or capacitors
    # (load capacitors are not present). If you add caps/resistors later, follow
    # the search-range rules described in the parameter ranges dictionary below.

    return circuit
```

Parameter search ranges (annotated for use with Optuna or similar):
- Notes on range calculation:
  - Process length (L) is fixed at 45e-9 m (45 nm).
  - Standard requested constraint: W ∈ [1×L, 500×L]. However, the original netlist contains some transistor widths larger than 500×L (M3/M4 = 40e-6 m while 500×L = 22.5e-6 m). To satisfy both the user's constraint and the strict requirement that initial_params must equal the original values and be inside the ranges, I expand the upper bound for any transistor whose original width exceeds 500×L to include the original. This is noted per-parameter below.
  - All voltage sources (except Vdd, Vinp, Vinn) follow 0.8–1.2× original values and are clipped to ≤ 1.2 V.
  - Sampling: transistor widths use log-scale sampling (recommended). v_tail uses linear sampling.

```python
# Parameter range definition (for optimizer)
L_fixed = 0.045e-6  # 45 nm

param_ranges_definition = {
    # Transistor widths (meters). Sampling log-scale recommended for sizes.
    # Base allowed range is [1*L, 500*L]; if original > 500*L we expand to include original.
    'w_M1': {
        'min': 1.0 * L_fixed,                        # 1×L = 45e-9 m
        'max': max(500.0 * L_fixed, 20e-6),          # 500×L = 22.5e-6 m; original = 20e-6 -> max = 22.5e-6
        'scale': 'log'
    },
    'w_M2': {
        'min': 1.0 * L_fixed,
        'max': max(500.0 * L_fixed, 20e-6),          # original = 20e-6
        'scale': 'log'
    },
    'w_M3': {
        'min': 1.0 * L_fixed,
        'max': max(500.0 * L_fixed, 40e-6),          # original = 40e-6 ; 500×L = 22.5e-6 < original -> max expanded to include original
        'scale': 'log'
    },
    'w_M4': {
        'min': 1.0 * L_fixed,
        'max': max(500.0 * L_fixed, 40e-6),          # same as M3
        'scale': 'log'
    },
    'w_M5': {
        'min': 1.0 * L_fixed,
        'max': max(500.0 * L_fixed, 10e-6),          # original = 10e-6
        'scale': 'log'
    },

    # Tail bias (voltage) - follow 0.8-1.2× original, clipped to <=1.2 V, linear sampling recommended.
    # Original v_tail = 0.42 V -> allowed: [0.42*0.8=0.336, 0.42*1.2=0.504] (both <= 1.2)
    'v_tail': {
        'min': 0.42 * 0.8,   # 0.336 V
        'max': min(0.42 * 1.2, 1.2),  # 0.504 V (<=1.2)
        'scale': 'linear'
    }
}
```

Initial parameters (EXACT original values from your circuit; these must be preserved):
- Important: these values are exactly as provided in your original netlist and are guaranteed to be inside the ranges defined above (ranges were expanded where necessary to include them).

```python
initial_params = {
    # Transistor widths (exact originals)
    'w_M1': 20e-6,   # original width of M1 (meters)
    'w_M2': 20e-6,   # original width of M2 (meters)
    'w_M3': 40e-6,   # original width of M3 (meters)
    'w_M4': 40e-6,   # original width of M4 (meters)
    'w_M5': 10e-6,   # original width of M5 (meters)

    # Tail bias (exact original)
    'v_tail': 0.42,  # original tail voltage (V)
}
```

Brief description of each parameter (physical meaning):
- w_M1 (m): Gate width of NMOS input transistor M1. Controls its drive strength, gm and current; longer widths increase current and reduce output impedance.
- w_M2 (m): Gate width of NMOS input transistor M2 (right side). Symmetric to M1 for differential pair.
- w_M3 (m): Gate width of PMOS diode-connected load (M3). Sets the reference branch current and output resistance of the left branch; larger width increases PMOS current capability.
- w_M4 (m): Gate width of PMOS mirror transistor (M4). Sets mirror drive capability to the output node; modifies gain/load behavior.
- w_M5 (m): Gate width of NMOS tail transistor (M5). Controls tail current magnitude and headroom; affects common-mode range and gm of the differential pair.
- v_tail (V): DC voltage applied to the gate of the tail NMOS (M5). Controls the tail current (together with device sizes) and operating point. Range kept conservative (0.8–1.2× original) and clipped to <= 1.2 V. Considered against Vth=0.22 V to ensure the tail device remains biased reasonably above threshold in this range.

Additional notes and rationale:
- Vdd (1.2 V) and input common-mode sources Vinp and Vinn (0.6 V) are fixed and intentionally excluded from the optimization parameter set, per your requirements.
- No explicit resistors or capacitors were present in the original netlist. If you add them:
  - Resistors: search range should be 0.5–2× original value.
  - Critical compensation capacitors: 0.5–5× original.
  - Other capacitors: 0.8–1.5× original.
  - Load capacitors must remain fixed (not included in the search).
- Transistor lengths are fixed (45 nm) because W/L ratio is what affects performance; only widths are parameterized.
- Width sampling uses logarithmic scale to efficiently explore several decades in device size; voltages use linear sampling.
- Where the original widths exceeded the 500×L rule (M3/M4), the upper bound was expanded to include the original values so the initial_params are inside the search ranges as required. If you prefer strictly enforcing 500×L, change the initial M3/M4 widths in your starting netlist to <= 22.5e-6 m (not done here to preserve the exact original initial_params).

If you want, I can also produce a small helper that converts these parameter values to the unit strings (e.g., '40u' or '10u') should your framework require unit-suffixed strings for the PySpice call.