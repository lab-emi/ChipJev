from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact originals)
    'w_M1': 20e-6,   # original width of M1 (meters)
    'w_M2': 20e-6,   # original width of M2 (meters)
    'w_M3': 40e-6,   # original width of M3 (meters)
    'w_M4': 40e-6,   # original width of M4 (meters)
    'w_M5': 10e-6,   # original width of M5 (meters)
    # Tail bias (exact original)
    'v_tail': 0.42,  # original tail voltage (V)
}
