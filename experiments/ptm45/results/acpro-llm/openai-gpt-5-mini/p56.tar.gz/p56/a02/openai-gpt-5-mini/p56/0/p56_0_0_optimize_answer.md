```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
 
def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp - GBW Optimized')

    # Attach transistor models provided externally (exact import line required)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)   # Vdd fixed at 1.2 V (do not include in optimization)

    # Input DC common-mode bias (fixed; will be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)

    # Tail bias (parameterized, but constrained to <= 1.2 V)
    circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, params['V_bias_tail'])

    # Node names (kept identical to original netlist)
    tail = 'tail_node'
    dr = 'node_dR'
    vout = 'Vout'

    # Fixed channel length (45 nm technology)
    Lmin = 0.045e-6  # 45 nm (fixed)

    # Transistors: only widths (W) are parameterized. Lengths are fixed at Lmin.
    # Note: Using the circuit.MOSFET method as in the original netlist.
    circuit.MOSFET('M1', vout, 'Vinp', tail, tail,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=Lmin)

    circuit.MOSFET('M2', dr, 'Vinn', tail, tail,
                   model='nmos_model',
                   w=params['w_M2'],
                   l=Lmin)

    circuit.MOSFET('Mtail', tail, 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=Lmin)

    # PMOS current mirror loads (diode-connected M4 drives gate of M3)
    circuit.MOSFET('M4', dr, dr, 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=Lmin)

    circuit.MOSFET('M3', vout, dr, 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=Lmin)

    return circuit


# ========================================================================
# Optimization parameter search ranges (for Optuna or similar frameworks)
# ========================================================================
# Notes on range choices:
# - Channel length L is fixed at 45 nm; we only optimize widths (W).
# - Requested constraint: W within 1 - 500 × L. For a 45 nm L, that nominally
#   gives W_min = 45e-9, W_max = 22.5e-6 (22.5 µm).
# - The ORIGINAL circuit uses some transistor widths larger than 22.5 µm
#   (e.g., 40e-6 and 80e-6). To satisfy the requirement that initial_params
#   contain EXACT original values and are inside the search ranges, the
#   search ranges for those devices are extended to include the original
#   widths. This is annotated per-device below.
# - V_bias_tail is constrained to 0.8 - 1.2 × original (0.42 V), clipped to <= 1.2 V.
# ========================================================================

param_ranges_definition = {
    # Transistor widths (meters)
    # For L = 45e-9 m: 1×L = 45e-9, 500×L = 22.5e-6
    # M1 and M2 original widths are 40e-6 (40 µm) which exceed 500×L.
    # To preserve the original starting point, the upper bound is extended
    # to include the original value. Ideally device widths would be within
    # 1-500×L; this is noted here as an exception.
    'w_M1': {'min': 45e-9, 'max': max(22.5e-6, 40e-6), 'log': True},
    'w_M2': {'min': 45e-9, 'max': max(22.5e-6, 40e-6), 'log': True},

    # Mtail original width 2e-6 is within 1-500×L (<= 22.5e-6)
    'w_Mtail': {'min': 45e-9, 'max': 22.5e-6, 'log': True},

    # M3 and M4 original widths are 80e-6 (80 µm) which also exceed 500×L.
    # Extend upper bounds to include original values to avoid excluding the
    # required initial parameters.
    'w_M3': {'min': 45e-9, 'max': max(22.5e-6, 80e-6), 'log': True},
    'w_M4': {'min': 45e-9, 'max': max(22.5e-6, 80e-6), 'log': True},

    # Tail bias voltage (V). Constraint: 0.8 - 1.2 × original, clipped to <= 1.2 V
    # Original = 0.42 V -> range = [0.336, 0.504] V
    'V_bias_tail': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
}

# ========================================================================
# Initial parameter values (EXACT original circuit values, unmodified)
# ========================================================================
initial_params = {
    # Transistor widths (exact as in original netlist)
    'w_M1': 40e-6,    # M1 original width (m)
    'w_M2': 40e-6,    # M2 original width (m)
    'w_Mtail': 2e-6,  # Mtail original width (m)
    'w_M3': 80e-6,    # M3 original width (m)
    'w_M4': 80e-6,    # M4 original width (m)

    # Tail bias (exact original)
    'V_bias_tail': 0.42,  # V
}
```

Parameter descriptions (brief)
- w_M1 (m): Width of input NMOS transistor M1 (drain at Vout). Affects input gm of left branch and output node loading.
- w_M2 (m): Width of input NMOS transistor M2 (drain at node_dR). Symmetric counterpart to M1.
- w_Mtail (m): Width of tail NMOS current source. Controls tail current capability and DC tail compliance.
- w_M3 (m): Width of PMOS mirror transistor (left load). Affects load current and output impedance at Vout.
- w_M4 (m): Width of diode-connected PMOS (right branch) that drives the mirror gate. Affects mirror bias point and matching.
- V_bias_tail (V): Tail bias voltage that sets Mtail gate. Range chosen conservatively around original (0.42 V) within 0.8–1.2× original and clipped to remain ≤ 1.2 V. Keep in mind Vth = 0.22 V when interpreting bias range.

Notes / rationale
- L is fixed at 45 nm (Lmin = 0.045e-6) because only W/L ratio matters; optimization only varies widths as requested.
- Vdd and input voltages (Vinp/Vinn) are intentionally fixed and omitted from optimization as required.
- No explicit resistors or capacitors were present in the original netlist; therefore none are parameterized. If you later add resistors or capacitors, follow the stated multipliers for their ranges (resistors 0.5–2×, critical caps 0.5–5×, others 0.8–1.5×).
- A small deviation from the 1–500×L guideline was required to preserve the original transistor widths as exact initial parameter values. These exceptions are annotated in the parameter ranges above; if strict enforcement of 500×L is desired, change the initial_params to lie within that bound (which would modify the exact original starting point).