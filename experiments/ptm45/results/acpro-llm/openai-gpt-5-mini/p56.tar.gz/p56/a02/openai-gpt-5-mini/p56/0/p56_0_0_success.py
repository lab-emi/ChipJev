from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp - GBW Optimized')
# Technology / supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)   # Vdd = 1.2 V
# Input DC common-mode bias (operating-point only, no AC)
# Chosen common-mode ~0.6 V to give headroom for NMOS inputs and PMOS loads
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Tail bias using Vth = 0.22 V per instruction: Vbias_tail = Vth + 0.2 = 0.42 V
circuit.V('bias_tail', 'Vbias_tail', circuit.gnd, 0.42)
# Define MOSFET models (provided by external module model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Node names
tail = 'tail_node'
dr = 'node_dR'
vout = 'Vout'
# Device sizing (45 nm node: L = 0.045e-6)
Lmin = 0.045e-6
# Input NMOS differential pair (wide to maximize gm -> increase GBW)
# M1: left input (drain -> Vout)
circuit.MOSFET('M1', vout, 'Vinp', tail, tail, model='nmos_model', w=40e-6, l=Lmin)
# M2: right input (drain -> node_dR)
circuit.MOSFET('M2', dr, 'Vinn', tail, tail, model='nmos_model', w=40e-6, l=Lmin)
# Tail NMOS current source (biased by Vbias_tail)
circuit.MOSFET('Mtail', tail, 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=Lmin)
# PMOS current mirror load (no cross-coupling -> no positive feedback)
# M4: diode-connected PMOS on right branch (drives mirror gate)
circuit.MOSFET('M4', dr, dr, 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=Lmin)
# M3: PMOS mirror transistor (left load) whose gate is driven by M4
circuit.MOSFET('M3', vout, dr, 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=Lmin)
# The output node Vout is the drain node shared by M1 and M3
# Input and output node names (Vinp, Vinn, Vout) explicitly used above.
# Prepare simulator (end of netlist; no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
