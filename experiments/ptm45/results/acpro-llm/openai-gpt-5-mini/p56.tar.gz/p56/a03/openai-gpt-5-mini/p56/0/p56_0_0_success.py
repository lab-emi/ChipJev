from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp - GBW Optimized')
# Device models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and DC inputs
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Input common-mode ~ 0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Input common-mode ~ 0.6 V
circuit.V('bias', 'Vbias_tail', circuit.gnd, 0.72)  # Tail bias ~ Vth + 0.5 (Vth=0.22V)
# Node names:
# D1  - drain of left input transistor and diode-connected PMOS
# Iss - common source node of input pair (connected to tail current source)
# Vout - single-ended output
# Transistor sizing (45 nm node)
L = 0.045e-6
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', circuit.gnd, model='nmos_model', w=20e-6, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# Tail current source (NMOS)
circuit.MOSFET('M5', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=L)
# PMOS current mirror load (active load): M3 diode-connected on left, M4 mirrors to right (Vout)
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L)  # mirror transistor
# Create simulator (stop here as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
