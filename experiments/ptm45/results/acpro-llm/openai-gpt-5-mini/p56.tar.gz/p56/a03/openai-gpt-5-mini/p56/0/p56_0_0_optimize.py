from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: The model import line requested in the spec must appear exactly as written
# and will be placed inside the create_circuit function (as required).
# The rest of this file exposes:
#  - create_circuit(params)  -- builds the parameterized PySpice circuit
#  - param_ranges_definition -- dictionary of search ranges (for optimizer)
#  - initial_params           -- dictionary containing the exact original values
def create_circuit(params):
    from model import nmos_params, pmos_params  # required to be present exactly like this
    circuit = Circuit('Single-Stage Differential OpAmp - GBW Optimized')
    # Device models (from provided external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supplies and DC inputs
    # Vdd fixed per requirements (do NOT include in parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V (fixed)
    # Input voltages are fixed (will be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Input common-mode ~ 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Input common-mode ~ 0.6 V (fixed)
    # Tail bias (parameterized). Must always be <= 1.2V; search range enforced externally in param_ranges_definition.
    circuit.V('bias', 'Vbias_tail', circuit.gnd, params['v_bias_tail'])  # originally 0.72 V
    # Technology: keep channel length fixed (only W is optimized)
    L = 0.045e-6  # 45 nm (fixed)
    # Input differential pair (NMOS) - parameterized widths
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', circuit.gnd,
                   model='nmos_model', w=params['w_M2'], l=L)
    # Tail current source (NMOS) - parameterized width
    circuit.MOSFET('M5', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=L)
    # PMOS current mirror load (active load): M3 diode-connected on left, M4 mirrors to right (Vout)
    # Note: these widths were originally large (40e-6). They remain parameterized here.
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)  # diode-connected
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)  # mirror transistor
    # No explicit resistors or capacitors were present in the original netlist.
    # If you add passive elements later, follow the problem constraints for parameterization.
    return circuit
# Optimization parameter search ranges
# All transistor widths are constrained to be between 1×L and 500×L where possible.
# However, the original circuit used M3/M4 widths (40e-6) which exceed 500×L (22.5e-6).
# To satisfy the requirement "initial_params must be inside ranges" we extend those specific ranges
# to include the original values while indicating the guideline (1-500×L).
#
# Units: widths in meters (consistent with PySpice float use), voltages in volts.
L = 0.045e-6
param_ranges_definition = {
    # Transistor widths (W). Search space is wide -> use log sampling in optimizer.
    # Standard guideline: min = 1 * L, max = 500 * L.
    # For M3/M4 the original W = 40e-6 > 500*L (22.5e-6) so we extend the max to include the original.
    'w_M1': {
        'min': 1.0 * L,                         # 1×L = 45e-9
        'max': 500.0 * L,                       # 500×L = 22.5e-6
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L,
        'max': 500.0 * L,
        'log': True
    },
    'w_M5': {
        'min': 1.0 * L,
        'max': 500.0 * L,
        'log': True
    },
    # M3 and M4: original widths are larger than 500*L; extend max to include the original value
    'w_M3': {
        'min': 1.0 * L,
        'max': max(500.0 * L, 40e-6),           # use max of guideline and original to ensure inclusion
        'log': True
    },
    'w_M4': {
        'min': 1.0 * L,
        'max': max(500.0 * L, 40e-6),
        'log': True
    },
    # Tail bias voltage parameter: 0.8-1.2× original but never exceed 1.2V.
    # original = 0.72 V -> allowed range = [0.8*0.72, 1.2*0.72] = [0.576, 0.864] V
    # Keep linear sampling (not log).
    'v_bias_tail': {
        'min': round(0.8 * 0.72, 12),  # 0.576 V
        'max': min(round(1.2 * 0.72, 12), 1.2),  # 0.864 V (capped at 1.2V)
        'log': False
    }
}
# Initial parameter values (EXACT original circuit values; unchanged)
initial_params = {
    # Transistor widths (exact values from original netlist)
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M5': 5e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    # Tail bias (exact original)
    'v_bias_tail': 0.72
}
# --- Brief description of each parameter (physical meaning) ---
# w_M1   : Width (W) of NMOS input transistor M1 (left side of differential pair). Controls gm, Rds(on), current.
# w_M2   : Width (W) of NMOS input transistor M2 (right side of differential pair). Controls gm, Rds(on), current.
# w_M5   : Width (W) of NMOS tail transistor M5 (current source). Sets tail current magnitude and headroom.
# w_M3   : Width (W) of PMOS diode-connected device M3 (active load / reference leg). Affects load current and output resistance.
# w_M4   : Width (W) of PMOS mirror device M4 (active load mirrored to output). Affects mirror accuracy and load current.
# v_bias_tail : Tail bias voltage applied to the gate of M5. Controls tail current and common-mode operating point.
#
# Notes / important constraints enforced:
# - Channel length L is fixed at 45 nm (0.045e-6 m). Only widths are optimized (W/L ratio changes).
# - All widths are constrained with a lower bound = 1×L and guideline upper bound = 500×L.
#   For M3/M4 the original device widths exceed 500×L; to preserve the exact original initial values,
#   the upper bound for w_M3/w_M4 has been extended to include the original 40e-6 value.
# - v_bias_tail search region is conservative: 0.8–1.2× original, capped at 1.2 V (the supply).
# - Vdd, Vinp and Vinn are fixed and NOT included in the parameter search (per requirements).
# - No resistors or capacitors were present in the provided netlist. If added later,
#   follow the required multiplier ranges for resistors and capacitors described in the problem statement.
