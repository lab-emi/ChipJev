from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (EXACT original values)
    'w_M1': 20e-6,   # M1 original width in meters
    'w_M2': 20e-6,   # M2 original width
    'w_M3': 20e-6,   # M3 original width (PMOS diode)
    'w_M4': 40e-6,   # M4 original width (PMOS mirror)  <-- exactly preserved
    'w_M5': 2e-6,    # M5 original width (tail NMOS)
    # Voltages (EXACT original values)
    'v_bias': 0.42,  # tail bias (original)
}
