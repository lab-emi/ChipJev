from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (GBW-optimized)')
# MOSFET models (provided via imported parameters)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # supply
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # DC common-mode on + input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # DC common-mode on - input
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # tail bias (Vth + 0.2)
# Node names used:
# - Vinp, Vinn : external inputs
# - Vout       : single-ended output
# - Vs         : common source of input pair (tail node)
# - D2         : drain of M2 and gate of the PMOS mirror (diode node)
# Transistor sizing (45 nm technology)
L_min = 45e-9
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=L_min)
circuit.MOSFET('M2', 'D2',   'Vinn', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=L_min)
# PMOS current mirror load: M3 diode-connected on D2, M4 mirror to Vout
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L_min)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L_min)  # mirror transistor
# NMOS tail current source
circuit.MOSFET('M5', 'Vs', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=L_min)
# Create simulator (do not add any statements after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
