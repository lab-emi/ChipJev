```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp (parameterized)')

    # MOSFET models (provided by the external model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed Vdd for 45nm technology

    # Input nodes - fixed (will be swept during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)

    # Tail gate bias - parameterized (kept <= 1.2V)
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])

    # Fixed device lengths (process values)
    L_min = 45e-9      # 45 nm (used for input pair in original netlist)
    L_long = 180e-9    # 180 nm (used for long-channel devices in original netlist)

    # NMOS input pair (M1: left -> Vout, M2: right -> diode/mirror node)
    # Bulk tied to source as in original
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_min)

    # Tail current source (NMOS) - bulk tied to ground (source is ground in original)
    circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L_long)

    # PMOS current mirror load (M3 diode-connected at D2, M4 mirror to Vout)
    # Bulk connected to Vdd (same as source)
    circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_long)
    circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_long)

    # Note: no load capacitors or resistors present in original netlist;
    # if you add them, follow the stated parameterization rules.

    return circuit
```

Optimization parameter search ranges (annotated)
```python
# Parameter ranges (to be used by Optuna or similar)
# Units: widths in meters, voltages in volts.
param_ranges_definition = {
    # Transistor widths (W). Rule-of-thumb: 1-500× the channel length.
    # To ensure the original values (required) are inside the ranges, the upper
    # bound is set to max(500 * L, original_width).
    # Log sampling is recommended for widths (wide dynamic range).
    'w_M1': {
        'min': 1 * 45e-9,                         # 1 × L_min
        'max': max(500 * 45e-9, 60e-6),           # 500×L_min or original(60e-6) whichever is larger
        'log': True
    },
    'w_M2': {
        'min': 1 * 45e-9,
        'max': max(500 * 45e-9, 60e-6),
        'log': True
    },
    'w_Mtail': {
        'min': 1 * 180e-9,                        # 1 × L_long
        'max': 500 * 180e-9,                      # 500 × L_long (original 5e-6 is inside this range)
        'log': True
    },
    'w_M3': {
        'min': 1 * 180e-9,
        'max': 500 * 180e-9,                      # original 20e-6 is inside this range
        'log': True
    },
    'w_M4': {
        'min': 1 * 180e-9,
        'max': 500 * 180e-9,
        'log': True
    },

    # Tail bias voltage (Vtail). Must remain conservative: 0.8–1.2× original, capped at 1.2V.
    # Original Vtail = 1.0 V -> range [0.8, 1.2]
    'v_tail': {
        'min': max(0.0, 0.8 * 1.0),   # lower bound (kept above 0); original >> Vth
        'max': min(1.2 * 1.0, 1.2),   # upper bound never exceed Vdd (1.2V)
        'log': False
    }
}
```

Initial parameter values (EXACT values from the original netlist)
```python
initial_params = {
    # EXACT original widths from your provided circuit (do NOT modify these values)
    'w_M1': 60e-6,
    'w_M2': 60e-6,
    'w_Mtail': 5e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,

    # EXACT original tail bias
    'v_tail': 1.0
}
```

Brief description of each parameter (physical meaning)
- w_M1 (m): Width of left NMOS input transistor (M1). Controls input transistor drive current and W/L.
- w_M2 (m): Width of right NMOS input transistor (M2). Controls mirror/diode node transistor strength.
- w_Mtail (m): Width of tail NMOS current source (Mtail). Sets tail current capability and headroom.
- w_M3 (m): Width of diode-connected PMOS in current mirror (M3). Sets mirror reference current and matching.
- w_M4 (m): Width of PMOS mirror transistor (M4) feeding Vout. Controls load current and output swing.
- v_tail (V): Tail gate bias voltage (Vtail) that sets the tail NMOS operating point and thus approximate tail current.

Notes and important clarifications
- vdd (1.2 V) and the input voltages (Vinp, Vinn at 0.6 V) are intentionally fixed and not included in the search (they will be swept during DC analysis).
- The function create_circuit contains "from model import nmos_params, pmos_params" exactly as requested; the model module must be available at execution time.
- All initial parameter values in initial_params are exactly the values from your original code and are inside the parameter ranges defined above. For M1/M2 the original width (60 µm) exceeds 500×L_min (22.5 µm). To satisfy your strict requirement that initial_params remain unchanged while still honoring the 1–500×L guidance, the upper bound for w_M1 and w_M2 was extended to include the original value (i.e., max(500×L_min, original_width)). This preserves the original starting point while keeping the 1–500×L rule as a guideline for sampling below that original width.
- There were no resistors or capacitors in the original netlist; hence no R/C parameters were added. If you add resistors or capacitors later, follow the stated multiplier ranges (resistors 0.5–2×, critical comps 0.5–5×, others 0.8–1.5×).
- The provided ranges use meters for widths and volts for voltages. Use log sampling for transistor widths in the optimizer (recommended) because widths span several decades; use linear sampling for voltages.

If you want, I can also produce an Optuna-compatible sampler example that uses these ranges (including suggested transforms for log-space sampling) or convert widths into more human-friendly units (µm) in the ranges.