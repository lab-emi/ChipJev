from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # EXACT original widths from your provided circuit (do NOT modify these values)
    'w_M1': 60e-6,
    'w_M2': 60e-6,
    'w_Mtail': 5e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    # EXACT original tail bias
    'v_tail': 1.0
}
