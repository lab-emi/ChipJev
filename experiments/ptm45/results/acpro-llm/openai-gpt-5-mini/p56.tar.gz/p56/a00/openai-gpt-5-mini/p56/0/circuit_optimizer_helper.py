"""Reconstructed AnalogCoder-Pro optimizer helper (see chipjev_topo_v3.acpro)."""
import sys

from chipjev_topo_v3.acpro import helper_main

sys.exit(helper_main(sys.argv[1:]))
