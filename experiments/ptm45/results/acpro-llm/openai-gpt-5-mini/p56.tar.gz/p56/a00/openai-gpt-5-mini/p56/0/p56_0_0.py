from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (high GBW)')
# MOSFET models (provided by the external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# DC bias / input nodes (operating point DC values only)
# Common-mode inputs set to mid-rail (0.6 V). No AC sources.
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Tail bias (set using Vth = 0.22 V -> Vtail ~ Vth + 0.2 = 0.42 V)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)
# Internal nodes: Vs = common source, D2 = mirror/diode node, Vout output
# NMOS input pair (M1: left -> output, M2: right -> mirror/diode node)
# Format: circuit.MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
# Bulk connected to source for each device.
# Device geometric parameters (meters)
L_min = 45e-9      # 45 nm
L_long = 180e-9    # longer channel to increase ro where desired
# M1: left input transistor
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=30e-6, l=L_min)
# M2: right input transistor
circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=30e-6, l=L_min)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=L_long)
# PMOS current mirror load (M3 diode-connected at D2, M4 mirror to Vout)
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_long)  # diode-connected PMOS
circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_long)  # mirror PMOS
# End of topology. Ready for simulator instantiation.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
