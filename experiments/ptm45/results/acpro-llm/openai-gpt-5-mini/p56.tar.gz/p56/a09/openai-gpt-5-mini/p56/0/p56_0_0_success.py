from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (GBW-optimized)')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias sources (DC operating point only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp DC common-mode = 0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn DC common-mode = 0.6 V
# Use Vth = 0.22 V per instruction; set tail bias = Vth + 0.2 = 0.42 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # Tail gate bias for current sink
# Node names:
# S  = common source node of differential pair (tail node)
# D1 = drain of M1 (also diode node for PMOS mirror gate)
# Vout = single-ended output (drain of M2)
# Transistor dimensions (45 nm technology)
L_min = 45e-9  # 45 nm
# Input differential pair (NMOS)
# M1: drain = D1, gate = Vinp, source = S, bulk = S
circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S', model='nmos_model', w=20e-6, l=L_min)
# M2: drain = Vout, gate = Vinn, source = S, bulk = S
circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', 'S', model='nmos_model', w=20e-6, l=L_min)
# PMOS current mirror load
# M3: diode-connected PMOS between Vdd and D1 (drain=gate=D1) - reference branch
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_min)
# M4: mirror PMOS between Vdd and Vout (gate tied to D1)
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_min)
# Tail current sink (NMOS): drain = S (common source), gate = Vbias, source = gnd, bulk = gnd
circuit.MOSFET('M5', 'S', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=L_min)
# The required input and output node names appear in the circuit: Vinp, Vinn, Vout, Vbias, Vdd
# End of topology definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
