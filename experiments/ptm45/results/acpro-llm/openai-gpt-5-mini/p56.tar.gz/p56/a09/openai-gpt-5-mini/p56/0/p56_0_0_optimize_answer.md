```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp (GBW-optimized) circuit.
    The function imports transistor model parameter dictionaries from 'model'
    (this import line must remain exactly as written per framework requirements).
    All transistor lengths are fixed to 45e-9 (45 nm). Only widths and the tail
    bias source are parameterized.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp (GBW-optimized)')

    # MOSFET models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and DC bias sources
    # vdd and input sources remain fixed (not part of the optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Vinp DC common-mode = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Vinn DC common-mode = 0.6 V (fixed)

    # Tail bias is parameterized (subject to conservative range)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Tail gate bias for current sink

    # Process length (fixed)
    L_min = 45e-9  # 45 nm (fixed for this technology)

    # Input differential pair (NMOS)
    # M1: drain = D1, gate = Vinp, source = S, bulk = S
    circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)

    # M2: drain = Vout, gate = Vinn, source = S, bulk = S
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_min)

    # PMOS current mirror load
    # M3: diode-connected PMOS between Vdd and D1 (drain=gate=D1) - reference branch
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_min)

    # M4: mirror PMOS between Vdd and Vout (gate tied to D1)
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_min)

    # Tail current sink (NMOS): drain = S (common source), gate = Vbias, source = gnd, bulk = gnd
    circuit.MOSFET('M5', 'S', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L_min)

    return circuit


# Optimization parameter search ranges
# - Transistor widths: 1xL .. 500xL (i.e., 45e-9 .. 22.5e-6)
# - Tail bias Vbias: 0.8 .. 1.2 × original (clamped to <= 1.2 V)
# Note: All ranges chosen to satisfy the constraints in the problem statement.
param_ranges = {
    # Transistor widths (meters). Use log sampling for wide dynamic range.
    'w_M1': {'min': 45e-9,    'max': 22.5e-6,  'log': True},  # originally 20e-6
    'w_M2': {'min': 45e-9,    'max': 22.5e-6,  'log': True},  # originally 20e-6
    'w_M3': {'min': 45e-9,    'max': 22.5e-6,  'log': True},  # originally 10e-6
    'w_M4': {'min': 45e-9,    'max': 22.5e-6,  'log': True},  # originally 10e-6
    'w_M5': {'min': 45e-9,    'max': 22.5e-6,  'log': True},  # originally 5e-6

    # Tail bias voltage (V). Constrained to 0.8 - 1.2× original value,
    # but must never exceed the supply (1.2 V). Original Vbias = 0.42 V.
    # 0.8 * 0.42 = 0.336 V, 1.2 * 0.42 = 0.504 V -> both <= 1.2 V.
    'v_bias': {'min': 0.8 * 0.42, 'max': 1.2 * 0.42, 'log': False},
}

# Initial parameter values (EXACT original circuit values)
# These values must match the original netlist exactly and must lie within the ranges above.
initial_params = {
    'w_M1': 20e-6,   # Original width for M1 (20 µm)
    'w_M2': 20e-6,   # Original width for M2 (20 µm)
    'w_M3': 10e-6,   # Original width for M3 (10 µm)
    'w_M4': 10e-6,   # Original width for M4 (10 µm)
    'w_M5': 5e-6,    # Original width for M5 (5 µm)
    'v_bias': 0.42,  # Original tail bias voltage (0.42 V)
}

# Short descriptions of each parameter (physical meaning)
param_descriptions = {
    'w_M1': "Width of NMOS M1 (left transistor of input differential pair). Controls gm, current and capacitances.",
    'w_M2': "Width of NMOS M2 (right transistor of input differential pair). Controls gm, current and capacitances.",
    'w_M3': "Width of PMOS M3 (diode-connected leg of the PMOS current mirror). Sets mirror reference current and headroom.",
    'w_M4': "Width of PMOS M4 (mirror output leg). Sets load current and output resistance.",
    'w_M5': "Width of NMOS M5 (tail current sink). Controls tail current and common-source node operating point.",
    'v_bias': "Tail bias gate voltage (Vbias) that sets current sink gate potential; affects tail current and bias point. "
              "Range chosen conservatively relative to Vth = 0.22 V and supply = 1.2 V.",
}

# Notes:
# - vdd, Vinp and Vinn remain fixed as required (1.2 V and 0.6 V respectively).
# - L is fixed to 45e-9 (45 nm); only widths are optimized (W/L ratio changes via W).
# - There were no resistors or explicit capacitors in the original netlist to parameterize.
# - If you later add resistors or capacitors, follow the requested multipliers:
#   resistors: 0.5-2× original, critical compensation caps: 0.5-5× original,
#   other caps: 0.8-1.5× original. Load caps must remain fixed if present.
```

Brief verification:
- All initial_params match the original netlist exactly.
- All initial parameters lie within the provided search ranges.
- Vbias range respects 0.8-1.2× rule and does not exceed Vdd = 1.2 V.