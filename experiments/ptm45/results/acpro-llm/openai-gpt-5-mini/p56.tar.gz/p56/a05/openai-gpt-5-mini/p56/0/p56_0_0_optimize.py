from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: model import must appear exactly as requested inside the create_circuit function
def create_circuit(params):
    """
    Create the parameterized Single-Stage Differential Opamp (GBW-optimized).
    Required in-scope module (per instructions):
      from model import nmos_params, pmos_params
    params : dict
        Expected keys:
          - 'w_M1', 'w_M2', 'w_M3', 'w_M4', 'w_Mtail' : transistor widths in meters
          - 'Vbiasn', 'Vbiasp' : bias voltages in Volts
    """
    # The import line below is required exactly as written by the framework instructions.
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential Opamp (GBW-optimized)')
    # MOSFET models (provided by model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed 1.2 V supply for 45 nm tech
    # Bias sources (parameterized: within conservative ±20%, capped at <= 1.2 V)
    circuit.V('biasn', 'Vbiasn', circuit.gnd, params['Vbiasn'])  # tail NMOS gate bias
    circuit.V('biasp', 'Vbiasp', circuit.gnd, params['Vbiasp'])  # PMOS gate bias
    # Input voltages (fixed, swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Geometry: keep length fixed for the process (45 nm)
    l_min = 0.045e-6  # fixed channel length (m) -- do NOT parameterize
    # Input pair NMOS (M1 - left, M2 - right). Bulk connected to source node "S".
    circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=l_min)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=l_min)
    # PMOS active loads (gates tied to fixed bias Vbiasp). Bulks tied to Vdd.
    circuit.MOSFET('M3', 'D1', 'Vbiasp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=l_min)
    circuit.MOSFET('M4', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=l_min)
    # Tail current source (NMOS). Bulk tied to ground (source).
    circuit.MOSFET('Mtail', 'S', 'Vbiasn', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=l_min)
    # No load capacitors/resistors present in the original netlist;
    # if later added, keep load caps fixed per instructions.
    return circuit
# ---------------------------------------------------------------------
# Optimization parameter search ranges (annotated).
# All initial_params are EXACT copies of the original values from the provided netlist.
# ---------------------------------------------------------------------
# Fixed process length (for reference)
_l_min = 0.045e-6  # 45 nm (m)
# Original widths from the user's netlist (kept exactly)
_initial_w_M1 = 20e-6
_initial_w_M2 = 20e-6
_initial_w_M3 = 40e-6
_initial_w_M4 = 40e-6
_initial_w_Mtail = 60e-6
# For each transistor: enforce a practical lower bound of 1×L and nominal "recommended" upper
# bound of 500×L. However, to satisfy the requirement that initial parameters remain inside
# the search ranges, the computed max is the larger of (500×L) and the original value.
# (This keeps the documented 1-500× recommendation but guarantees the original geometry is reachable.)
_width_min = _l_min * 1.0
_width_max_base = _l_min * 500.0  # recommended upper bound
param_ranges_definition = {
    # Transistor widths (meters). Search in log-domain recommended for geometry sweeping.
    'w_M1': {'min': _width_min, 'max': max(_width_max_base, _initial_w_M1), 'log': True},
    'w_M2': {'min': _width_min, 'max': max(_width_max_base, _initial_w_M2), 'log': True},
    'w_M3': {'min': _width_min, 'max': max(_width_max_base, _initial_w_M3), 'log': True},
    'w_M4': {'min': _width_min, 'max': max(_width_max_base, _initial_w_M4), 'log': True},
    'w_Mtail': {'min': _width_min, 'max': max(_width_max_base, _initial_w_Mtail), 'log': True},
    # Bias voltages: 0.8 - 1.2 × original, but never exceed 1.2 V supply.
    # Note: these ranges are conservative relative to Vth = 0.22 V to keep devices in intended regions.
    'Vbiasn': {'min': max(0.0, 0.8 * 0.42), 'max': min(1.2, 1.2 * 0.42), 'log': False},  # orig 0.42 V
    'Vbiasp': {'min': max(0.0, 0.8 * 0.78), 'max': min(1.2, 1.2 * 0.78), 'log': False},  # orig 0.78 V
}
# Initial parameters (EXACT original values from the provided circuit code).
initial_params = {
    # Transistor widths (meters) - EXACT original values
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_Mtail': 60e-6,
    # Bias voltages (Volts) - EXACT original values
    'Vbiasn': 0.42,
    'Vbiasp': 0.78,
}
# Sanity check note (not executed here): all initial_params must satisfy param_ranges_definition.
# The ranges above were constructed to guarantee that (upper bounds are at least the initial values).
# ---------------------------------------------------------------------
# Brief description of each parameter (physical meaning)
# ---------------------------------------------------------------------
# w_M1, w_M2  : Gate widths of the input differential NMOS pair (meters). Controls transconductance,
#               current per device, and input pair loading. L is fixed (45 nm); W is optimized.
# w_M3, w_M4  : Gate widths of the PMOS active loads (meters). Affect gain (load resistance) and biasing.
# w_Mtail     : Gate width of the NMOS tail current source (meters). Controls tail current and bias point.
#
# Vbiasn      : Gate bias voltage for the tail NMOS (Volts). Sets tail current (together with Mtail sizing),
#               must remain below Vdd (1.2 V) and chosen conservatively relative to Vth=0.22 V.
# Vbiasp      : Gate bias voltage for the PMOS active loads (Volts). Fixed gate bias prevents latch-up/cross-coupling;
#               tuned within ±20% of original but ≤ 1.2 V.
#
# Notes / design choices:
# - The channel length (l) is fixed to 45 nm (0.045e-6 m) for all devices per the original netlist and is
#   intentionally not included in the optimization (only W/L ratio matters for sizing sweeps).
# - Vdd and input supply nodes (Vinp, Vinn) are fixed at their original values (1.2 V supply, 0.6 V inputs)
#   and are intentionally excluded from parameter search; inputs are expected to be swept by the analysis framework.
# - No load capacitors or resistors were present in the original netlist; thus none are parameterized.
# - Width ranges use logarithmic search advice (log: True) to aid optimizers when sweeping across many decades of W.
# ---------------------------------------------------------------------
