from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Opamp (GBW-optimized)')
# Define MOSFET models (assumed provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Bias sources (DC biases only, per tips using Vth = 0.22V)
# Vbiasn = Vth + 0.20 = 0.42 V (tail NMOS gate)
# Vbiasp = Vdd - |Vth| - 0.20 = 0.78 V (PMOS gate bias)
circuit.V('biasn', 'Vbiasn', circuit.gnd, 0.42)
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78)
# Inputs (DC common-mode bias). These are explicit nodes required by the problem.
# Choose a reasonable common-mode (~Vdd/2) to place devices in region of operation.
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Node names:
# - "S" : common source node of input pair (drain of tail current source)
# - "D1": drain of left input transistor (connected to left PMOS load)
# - "Vout": single-ended output (drain of right input transistor)
# Transistor sizing (45 nm technology node; lengths in meters: 0.045e-6)
l_min = 0.045e-6
# Input pair NMOS (M1 - left, M2 - right). Bulk connected to source (node "S").
circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S', model='nmos_model', w=20e-6, l=l_min)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', 'S', model='nmos_model', w=20e-6, l=l_min)
# PMOS active loads (gates tied to fixed bias Vbiasp to avoid cross-coupling / positive feedback)
# Bulks tied to Vdd (their sources)
circuit.MOSFET('M3', 'D1', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=l_min)
circuit.MOSFET('M4', 'Vout', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=l_min)
# Tail current source (NMOS). Bulk tied to ground (source).
circuit.MOSFET('Mtail', 'S', 'Vbiasn', circuit.gnd, circuit.gnd, model='nmos_model', w=60e-6, l=l_min)
# Create simulator (no further analysis code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p56/0/p56_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
