from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact original values)
    'w_M1'       : 20e-6,
    'w_M2'       : 20e-6,
    'w_Mtail'    : 8e-6,
    'w_MPpc1'    : 60e-6,
    'w_MPpc2'    : 60e-6,
    'w_MPL1'     : 40e-6,
    'w_MPL2'     : 40e-6,
    'w_M7'       : 30e-6,
    'w_MPpc_out' : 60e-6,
    'w_MPout'    : 40e-6,
    # Bias voltages (exact original values)
    'Vb_pcas'    : 0.78,
    'Vb_tail'    : 0.42,
}
