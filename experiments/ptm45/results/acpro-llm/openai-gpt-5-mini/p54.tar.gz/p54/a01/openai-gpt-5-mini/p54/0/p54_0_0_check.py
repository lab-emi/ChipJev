from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp (no positive feedback)')
# Define MOSFET models (assumed provided in imported module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('bpc', 'Vb_pcas', circuit.gnd, 0.78)                    # PMOS cascode gate bias
circuit.V('btail', 'Vb_tail', circuit.gnd, 0.42)                  # NMOS tail gate bias
# Technology nominal dimensions (45 nm)
L = 0.045e-6
# First stage: NMOS differential pair with NMOS tail
# M1: left input
circuit.MOSFET('M1', 'Out1', 'Vinp', 'SN', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# M2: right input
circuit.MOSFET('M2', 'Out2', 'Vinn', 'SN', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# Tail current source Mtail (NMOS)
circuit.MOSFET('Mtail', 'SN', 'Vb_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=8e-6, l=L)
# PMOS cascode + mirror load stack on both branches
# Left branch cascode MPpc1: Vdd -> MPpc1 -> node_pc1
circuit.MOSFET('MPpc1', 'node_pc1', 'Vb_pcas', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=L)
# Right branch cascode MPpc2: Vdd -> MPpc2 -> node_pc2
circuit.MOSFET('MPpc2', 'node_pc2', 'Vb_pcas', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=L)
# PMOS mirror loads: sources tied to node_pcX, bulks tied to the same node
# Mirror transistor for left branch MPL1 (gate tied to Out2 to mirror MPL2)
circuit.MOSFET('MPL1', 'Out1', 'Out2', 'node_pc1', 'node_pc1', model='pmos_model', w=40e-6, l=L)
# Diode-connected mirror transistor for right branch MPL2 (gate tied to Out2)
circuit.MOSFET('MPL2', 'Out2', 'Out2', 'node_pc2', 'node_pc2', model='pmos_model', w=40e-6, l=L)
# Second stage: NMOS common-source amplifier (driven by Out1)
# M7: second stage NMOS (input Out1 -> gate)
circuit.MOSFET('M7', 'Vout', 'Out1', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=L)
# PMOS cascode + diode-connected load for the second stage (to maximize ro)
# MPpc_out: cascode from Vdd to node_pcout
circuit.MOSFET('MPpc_out', 'node_pcout', 'Vb_pcas', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=L)
# MPout: diode-connected PMOS load: source = node_pcout, gate = Vout, drain = Vout (diode)
circuit.MOSFET('MPout', 'Vout', 'Vout', 'node_pcout', 'node_pcout', model='pmos_model', w=40e-6, l=L)
# Ensure the required node names appear (Vinp, Vinn, Vout) -- Vout is the drain of M7 / MPout
# No explicit resistors or additional feedback networks are added (topology avoids positive feedback)
# Simulation object (user may run operating point or other analyses)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)