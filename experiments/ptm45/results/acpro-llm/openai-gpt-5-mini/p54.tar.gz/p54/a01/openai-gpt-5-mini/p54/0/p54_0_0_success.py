from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp (no positive feedback)')
# Define MOSFET models (assumed provided in imported module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)                        # Vinp DC (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)                        # Vinn DC (common-mode)
circuit.V('bpc', 'Vb_pcas', circuit.gnd, 0.78)                    # PMOS cascode gate bias
circuit.V('btail', 'Vb_tail', circuit.gnd, 0.42)                  # NMOS tail gate bias
# Technology nominal dimensions (45 nm)
L = 0.045e-6
# First stage: NMOS differential pair with NMOS tail
# M1: left input
circuit.MOSFET('M1', 'Out1', 'Vinp', 'SN', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# M2: right input
circuit.MOSFET('M2', 'Out2', 'Vinn', 'SN', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# Tail current source Mtail (NMOS)
circuit.MOSFET('Mtail', 'SN', 'Vb_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=8e-6, l=L)
# PMOS cascode + mirror load stack on both branches
# Left branch cascode MPpc1: Vdd -> MPpc1 -> node_pc1
circuit.MOSFET('MPpc1', 'node_pc1', 'Vb_pcas', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=L)
# Right branch cascode MPpc2: Vdd -> MPpc2 -> node_pc2
circuit.MOSFET('MPpc2', 'node_pc2', 'Vb_pcas', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=L)
# PMOS mirror loads: sources tied to node_pcX, bulks tied to the same node
# Mirror transistor for left branch MPL1 (gate tied to Out2 to mirror MPL2)
circuit.MOSFET('MPL1', 'Out1', 'Out2', 'node_pc1', 'node_pc1', model='pmos_model', w=40e-6, l=L)
# Diode-connected mirror transistor for right branch MPL2 (gate tied to Out2)
circuit.MOSFET('MPL2', 'Out2', 'Out2', 'node_pc2', 'node_pc2', model='pmos_model', w=40e-6, l=L)
# Second stage: NMOS common-source amplifier (driven by Out1)
# M7: second stage NMOS (input Out1 -> gate)
circuit.MOSFET('M7', 'Vout', 'Out1', circuit.gnd, circuit.gnd, model='nmos_model', w=30e-6, l=L)
# PMOS cascode + diode-connected load for the second stage (to maximize ro)
# MPpc_out: cascode from Vdd to node_pcout
circuit.MOSFET('MPpc_out', 'node_pcout', 'Vb_pcas', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=L)
# MPout: diode-connected PMOS load: source = node_pcout, gate = Vout, drain = Vout (diode)
circuit.MOSFET('MPout', 'Vout', 'Vout', 'node_pcout', 'node_pcout', model='pmos_model', w=40e-6, l=L)
# Ensure the required node names appear (Vinp, Vinn, Vout) -- Vout is the drain of M7 / MPout
# No explicit resistors or additional feedback networks are added (topology avoids positive feedback)
# Simulation object (user may run operating point or other analyses)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
