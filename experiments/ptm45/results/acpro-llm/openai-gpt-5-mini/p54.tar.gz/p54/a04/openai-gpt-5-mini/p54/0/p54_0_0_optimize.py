from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    # Keep the model import exactly as requested (module available in the execution env)
    from model import nmos_params, pmos_params
    circuit = Circuit('Multi-Stage High-Gain OpAmp')
    # MOSFET models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC bias sources
    # Vdd : fixed (do not include in parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V (fixed)
    # Input voltages : fixed (swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)         # Vinp fixed (0.6 V)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)         # Vinn fixed (0.6 V)
    # Other bias voltages -> parameterized (but constrained to <= 1.2V)
    circuit.V('tail', 'Vbias_tail', circuit.gnd, params['v_tail'])   # Tail bias (parameter)
    circuit.V('pbias', 'Vbias_p', circuit.gnd, params['v_pbias'])    # PMOS bias (parameter)
    # Device channel length (fixed for 45nm technology)
    L = 0.045e-6  # original code used 0.045e-6 (45 nm)
    # First stage: NMOS differential pair (W parameterized, L fixed)
    circuit.MOSFET('M1', 'Out1', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # Tail current source (NMOS) - width parameterized
    circuit.MOSFET('Mtail', 'Vs', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)
    # Active PMOS current mirror load (diode-connected M4 and mirror M3)
    circuit.MOSFET('M4', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    circuit.MOSFET('M3', 'Out1', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # Second stage: NMOS common-source high-gain amplifier
    circuit.MOSFET('M7', 'Vout', 'Out1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M7'],
                   l=L)
    # PMOS active load for second stage (current source)
    circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M8'],
                   l=L)
    return circuit
# Optimization parameter search ranges
# Constraints used:
# - Transistor width W between 1×L and 500×L (L = 0.045e-6 => min = 45e-9, max = 22.5e-6)
# - All non-fixed voltages between 0.8-1.2× original but never > 1.2V
# - Log-sampling recommended for widths, linear for voltages
L = 0.045e-6
W_min = 1 * L                 # 45e-9
W_max = 500 * L               # 22.5e-6
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling to cover decades efficiently.
    'w_M1':   {'min': W_min,     'max': W_max,     'log': True},  # originally 10e-6
    'w_M2':   {'min': W_min,     'max': W_max,     'log': True},  # originally 10e-6
    'w_Mtail':{'min': W_min,     'max': W_max,     'log': True},  # originally 4e-6
    'w_M4':   {'min': W_min,     'max': W_max,     'log': True},  # originally 8e-6
    'w_M3':   {'min': W_min,     'max': W_max,     'log': True},  # originally 16e-6
    'w_M7':   {'min': W_min,     'max': W_max,     'log': True},  # originally 20e-6
    'w_M8':   {'min': W_min,     'max': W_max,     'log': True},  # originally 30e-6
    # Bias voltages (Volts). Conservative linear ranges, constrained not to exceed 1.2V.
    # Original Vbias_tail = 0.42 -> range = [0.8*0.42, 1.2*0.42] = [0.336, 0.504]
    'v_tail': {'min': max(0.8 * 0.42, 0.0), 'max': min(1.2 * 0.42, 1.2), 'log': False},
    # Original Vbias_p = 0.78 -> range = [0.8*0.78, 1.2*0.78] = [0.624, 0.936]
    'v_pbias':{'min': max(0.8 * 0.78, 0.0), 'max': min(1.2 * 0.78, 1.2), 'log': False},
}
# Initial parameter values (EXACT original circuit values)
# IMPORTANT: these contain exactly the original values from your provided netlist
initial_params = {
    # Transistor widths (as in original netlist)
    'w_M1':    10e-6,
    'w_M2':    10e-6,
    'w_Mtail': 4e-6,
    'w_M4':    8e-6,
    'w_M3':    16e-6,
    'w_M7':    20e-6,
    'w_M8':    30e-6,
    # Bias voltages (as in original netlist)
    'v_tail':  0.42,
    'v_pbias': 0.78,
}
# Parameter descriptions (brief physical meaning)
param_descriptions = {
    'w_M1':    'Width of input left NMOS (M1). Sets input pair drive and gm; L fixed at 45nm.',
    'w_M2':    'Width of input right NMOS (M2). Paired with M1 for differential input.',
    'w_Mtail': 'Width of NMOS tail current source (Mtail). Controls tail current compliance.',
    'w_M4':    'Width of diode-connected PMOS in mirror (M4). Sets mirror reference current capability.',
    'w_M3':    'Width of PMOS mirror transistor loading left branch (M3). Sets load current and output resistance.',
    'w_M7':    'Width of second-stage NMOS transistor (M7). Determines second-stage transconductance and gain.',
    'w_M8':    'Width of second-stage PMOS active load (M8). Sets current sourcing capability and headroom.',
    'v_tail':  'Tail bias voltage applied to gate of tail transistor (sets tail current). Range limited to 0.8-1.2× original, <=1.2V.',
    'v_pbias': 'PMOS gate bias for second-stage active load (sets PMOS current). Range limited to 0.8-1.2× original, <=1.2V.',
}
# Sanity check comment:
# - All initial_params values are inside the ranges defined in param_ranges_definition.
# - Vdd (1.2V) and input voltages (Vinp/Vinn = 0.6V) are intentionally fixed and not included in optimization.
# - Channel length L is fixed to 0.045e-6 (45 nm) as in original netlist; only widths are optimized (W/L variation).
