from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage High-Gain OpAmp')
# MOSFET models (provided via the imported module parameters)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC bias sources (only DC, no AC)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # Vinp DC bias (mid-supply)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # Vinn DC bias (mid-supply)
circuit.V('tail', 'Vbias_tail', circuit.gnd, 0.42) # Tail bias ~ Vth + 0.2
circuit.V('pbias', 'Vbias_p', circuit.gnd, 0.78)  # PMOS bias ~ Vdd - (Vth + 0.2)
# Node names used:
# Vs   : source node of input differential pair (tail node)
# Out1 : single-ended output of first stage (drain of left input transistor)
# D2   : diode node on right branch of mirror
# First stage: NMOS differential pair
# M1: left input transistor
circuit.MOSFET('M1', 'Out1', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=10e-6, l=0.045e-6)
# M2: right input transistor
circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=10e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=0.045e-6)
# Active PMOS current mirror load
# M4: diode-connected PMOS on right branch (sets mirror reference)
circuit.MOSFET('M4', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=8e-6, l=0.045e-6)
# M3: PMOS mirror transistor loading left branch (Out1)
circuit.MOSFET('M3', 'Out1', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=16e-6, l=0.045e-6)
# Second stage: NMOS common-source high-gain amplifier
circuit.MOSFET('M7', 'Vout', 'Out1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS active load for second stage (current source)
circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Create simulator
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
