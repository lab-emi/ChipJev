from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp')
# MOSFET models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.605)       # Vinp DC (common-mode ~0.6 V plus small offset)
circuit.V('inn', 'Vinn', circuit.gnd, 0.595)       # Vinn DC (small differential -10 mV)
circuit.V('tail', 'Vtail', circuit.gnd, 0.60)      # Tail bias for NMOS tail current source (~0.6 V)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)   # PMOS bias gate (~Vdd - (Vth+0.2) ≈ 0.78 V)
# Node names used:
# Vs  - common source node of input pair (tail node)
# D1  - drain of M1 (single-ended node that drives second stage)
# D2  - drain of M2 and diode-connected PMOS gate/drain
# Stage A: Differential NMOS pair with PMOS current-mirror active load
# M1: input NMOS for Vinp
circuit.MOSFET('M1', 'D1', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=10e-6, l=0.045e-6)
# M2: input NMOS for Vinn
circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=10e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# PMOS current mirror load
# M3: diode-connected PMOS between Vdd and D2 (drain and gate tied to D2)
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M4: mirror PMOS between Vdd and D1 (gate tied to D2)
circuit.MOSFET('M4', 'D1', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Stage B: Single-ended high-gain common-source stage
# M7: NMOS amplifier transistor driven by D1 (second stage input)
circuit.MOSFET('M7', 'Vout', 'D1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.09e-6)
# M8: PMOS load (active current source) between Vdd and Vout, gate biased by Vbias_p
circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.09e-6)
# Ensure required node names appear in the netlist
# Nodes used explicitly: Vinp, Vinn, Vout
# Run simulator (operating point / DC)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
