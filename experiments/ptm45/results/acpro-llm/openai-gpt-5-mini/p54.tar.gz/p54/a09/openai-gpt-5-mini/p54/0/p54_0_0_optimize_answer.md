```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # The model import must appear exactly as requested
    from model import nmos_params, pmos_params

    circuit = Circuit('High-Gain Multi-Stage Opamp')

    # MOSFET models (provided by external model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply and DC bias nodes
    # Keep Vdd and input voltages fixed (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.605)       # Vinp DC (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.595)       # Vinn DC (fixed)

    # Parameterized bias voltages (subject to optimization)
    # Note: ranges for these parameters are enforced externally via param_ranges_definition
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])      # Tail bias for NMOS tail current source
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p']) # PMOS bias gate

    # Node names used:
    # Vs  - common source node of input pair (tail node)
    # D1  - drain of M1 (single-ended node that drives second stage)
    # D2  - drain of M2 and diode-connected PMOS gate/drain

    # Transistor lengths are kept fixed (as in original netlist). Only widths are parameterized.
    # Note: for devices originally declared with 0.045e-6 length we keep L = 0.045e-6 (45 nm).
    #       for devices originally declared with 0.09e-6 length we keep L = 0.09e-6 (90 nm).

    # Stage A: Differential NMOS pair with PMOS current-mirror active load
    # M1: input NMOS for Vinp
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)

    # M2: input NMOS for Vinn
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=0.045e-6)

    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Vs', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=0.045e-6)

    # PMOS current mirror load
    # M3: diode-connected PMOS between Vdd and D2 (drain and gate tied to D2)
    circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=0.045e-6)

    # M4: mirror PMOS between Vdd and D1 (gate tied to D2)
    circuit.MOSFET('M4', 'D1', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=0.045e-6)

    # Stage B: Single-ended high-gain common-source stage
    # M7: NMOS amplifier transistor driven by D1 (second stage input)
    circuit.MOSFET('M7', 'Vout', 'D1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M7'],
                   l=0.09e-6)   # original L = 0.09e-6 retained

    # M8: PMOS load (active current source) between Vdd and Vout, gate biased by Vbias_p
    circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M8'],
                   l=0.09e-6)   # original L = 0.09e-6 retained

    # Note: There were no explicit resistors or capacitors in the original netlist
    #       (load capacitors should stay fixed and are not present here).

    return circuit


# Optimization parameter search ranges (annotated for use with Optuna or similar)
# Constraints applied:
# - Transistor width W: 1×L to 500×L (ensures 1-500× length)
# - Bias voltages (v_tail, v_bias_p): 0.8–1.2× original, clipped to <= 1.2 V
# - All initial parameter values below match the original netlist exactly

param_ranges_definition = {
    # Stage A NMOS / PMOS widths (W in meters)
    # M1 original: w = 10e-6, L = 0.045e-6  => W range: [1*L, 500*L] = [45e-9, 22.5e-6]
    'w_M1': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},

    # M2 original: w = 10e-6, L = 0.045e-6
    'w_M2': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},

    # Mtail original: w = 2e-6, L = 0.045e-6
    'w_Mtail': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},

    # M3 original: w = 20e-6, L = 0.045e-6
    'w_M3': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},

    # M4 original: w = 20e-6, L = 0.045e-6
    'w_M4': {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},

    # Stage B devices have L = 0.09e-6 (90 nm) in the original netlist,
    # so we use their L to set the 1-500×L constraint to ensure original
    # initial widths remain in-range.
    # M7 original: w = 20e-6, L = 0.09e-6 => W range: [90e-9, 45e-6]
    'w_M7': {'min': 0.09e-6, 'max': 45e-6, 'log': True},

    # M8 original: w = 40e-6, L = 0.09e-6
    'w_M8': {'min': 0.09e-6, 'max': 45e-6, 'log': True},

    # Bias voltages (linear sampling)
    # v_tail original = 0.60 V -> allowed range = [0.8*0.60, min(1.2,1.2*0.60)] = [0.48, 0.72]
    'v_tail': {'min': 0.48, 'max': 0.72, 'log': False},

    # v_bias_p original = 0.78 V -> allowed range = [0.8*0.78, min(1.2,1.2*0.78)] = [0.624, 0.936]
    # (all voltages capped at <= 1.2 V by spec)
    'v_bias_p': {'min': 0.624, 'max': 0.936, 'log': False},
}

# Initial parameter values (EXACT original circuit values; must not be changed)
initial_params = {
    # Transistor widths (exact values from original netlist)
    'w_M1': 10e-6,     # M1: input NMOS for Vinp
    'w_M2': 10e-6,     # M2: input NMOS for Vinn
    'w_Mtail': 2e-6,   # Mtail: tail NMOS current source
    'w_M3': 20e-6,     # M3: diode-connected PMOS (load)
    'w_M4': 20e-6,     # M4: mirror PMOS
    'w_M7': 20e-6,     # M7: second-stage NMOS amplifier
    'w_M8': 40e-6,     # M8: second-stage PMOS load

    # Voltages (exact values from original netlist)
    'v_tail': 0.60,    # Tail bias for NMOS tail current source
    'v_bias_p': 0.78,  # PMOS bias gate
}

# Brief description of each parameter (physical meaning)
param_descriptions = {
    'w_M1':   'Gate width of input NMOS M1 (driven by Vinp). Controls current drive and gm of left input transistor.',
    'w_M2':   'Gate width of input NMOS M2 (driven by Vinn). Controls current drive and gm of right input transistor.',
    'w_Mtail':'Gate width of NMOS tail current source. Controls tail current and common-source node impedance.',
    'w_M3':   'Gate/Drain tied PMOS device in the active-load mirror (diode-connected). Sets mirror reference current and headroom.',
    'w_M4':   'Gate-tied mirror PMOS device supplying the other input load. Sets load current & gain balance.',
    'w_M7':   'Gate width of second-stage NMOS amplifier transistor. Strong effect on gain and output swing.',
    'w_M8':   'Gate width of second-stage PMOS active load (current source). Sets second-stage bias and output swing.',
    'v_tail': 'Voltage applied to tail bias node (Vtail). Sets tail current through the NMOS tail transistor when combined with device sizes.',
    'v_bias_p':'Gate bias applied to PMOS active load (Vbias_p). Tunes PMOS current and operating point of second stage.',
}

# Note on units and usage:
# - Widths (w_*) are in meters (e.g., 10e-6 = 10 µm). These map directly to the MOSFET "w=" argument in PySpice.
# - Lengths are used as fixed values inside create_circuit (kept consistent with the original netlist).
# - Voltages are in volts and are enforced to always be <= 1.2 V by the ranges above.
# - There were no explicit resistors or capacitors in the given netlist; if you add them, follow the stated
#   multiplier constraints (resistors: 0.5-2×, comp caps: 0.5-5×, other caps: 0.8-1.5×).
```