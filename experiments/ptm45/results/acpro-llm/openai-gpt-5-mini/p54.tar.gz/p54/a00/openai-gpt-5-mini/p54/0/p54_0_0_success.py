from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage OpAmp (Differential -> Single-Ended)')
# Define MOSFET models (from provided parameter dictionaries)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('vinp', 'Vinp', circuit.gnd, 0.6)    # Vinp DC common-mode (0.6 V)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.6)    # Vinn DC common-mode (0.6 V)
circuit.V('tailbias', 'Vtail', circuit.gnd, 0.42)  # Tail bias ~ Vth + 0.2 = 0.42 V
circuit.V('pbias', 'Vbiasp', circuit.gnd, 0.78)    # PMOS bias ~ Vdd - (|Vth| + 0.2) = 0.78 V
# Nodes:
# D1  : first-stage single-ended node (drain of M1 and drain of mirror transistor M3)
# D2  : drain of M2 and diode-connected PMOS (mirror reference)
# Sbar: common source node of differential pair (drain of tail transistor)
# Vout: final single-ended output
# First stage: NMOS differential pair
# M1: Vinp
circuit.MOSFET('M1', 'D1', 'Vinp', 'Sbar', 'Sbar', model='nmos_model', w=10e-6, l=0.045e-6)
# M2: Vinn
circuit.MOSFET('M2', 'D2', 'Vinn', 'Sbar', 'Sbar', model='nmos_model', w=10e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Sbar', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS mirror active load for the differential pair
# M4: diode-connected reference on D2
circuit.MOSFET('M4', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M3: mirror device, gate tied to D2
circuit.MOSFET('M3', 'D1', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Second stage: high-gain common-source NMOS amplifier
# M7: NMOS common-source stage, input from D1
circuit.MOSFET('M7', 'Vout', 'D1', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
# M8: PMOS cascode/current-source load for second stage (bias on gate = Vbiasp)
circuit.MOSFET('M8', 'Vout', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=30e-6, l=0.045e-6)
# Prepare simulator (operating point / DC)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
