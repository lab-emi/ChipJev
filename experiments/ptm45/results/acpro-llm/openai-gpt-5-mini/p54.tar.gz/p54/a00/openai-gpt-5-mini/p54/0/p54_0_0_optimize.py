from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized PySpice circuit.
    The module import "from model import nmos_params, pmos_params" is kept exactly as required.
    params: dict containing parameter values (widths in meters, voltages in volts).
    """
    # Import the transistor model parameter dictionaries (kept exactly as requested)
    from model import nmos_params, pmos_params
    circuit = Circuit('High-Gain Multi-Stage OpAmp (Differential -> Single-Ended)')
    # Models
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and input supplies (fixed per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # vdd fixed at 1.2V (do not include in search)
    circuit.V('vinp', 'Vinp', circuit.gnd, 0.6)     # Vinp fixed (swept externally)
    circuit.V('vinn', 'Vinn', circuit.gnd, 0.6)     # Vinn fixed (swept externally)
    # Parameterized bias voltages (search parameters)
    # All bias voltages are constrained to <= 1.2V by design of the search ranges.
    circuit.V('tailbias', 'Vtail', circuit.gnd, params['v_tail'])   # tail bias (NMOS)
    circuit.V('pbias', 'Vbiasp', circuit.gnd, params['v_pbias'])    # PMOS bias
    # Fixed length for this technology (45 nm)
    L = 0.045e-6
    # First stage: NMOS differential pair
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Sbar', 'Sbar',
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Sbar', 'Sbar',
                   model='nmos_model', w=params['w_M2'], l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Sbar', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L)
    # PMOS mirror active load for the differential pair
    circuit.MOSFET('M4', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)  # diode-connected device
    circuit.MOSFET('M3', 'D1', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)  # mirror device
    # Second stage: NMOS common-source amplifier
    circuit.MOSFET('M7', 'Vout', 'D1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M7'], l=L)
    # PMOS cascode/current-source load for second stage (gate biased by Vbiasp)
    circuit.MOSFET('M8', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M8'], l=L)
    return circuit
# -------------------------
# Optimization parameter search ranges (annotated)
# -------------------------
# Notes on constraints applied:
# - Length L is fixed at 45 nm (0.045e-6 m). Only widths (W) are optimized.
# - W ranges obey the rule: 1×L <= W <= 500×L  => 0.045e-6 m .. 22.5e-6 m
# - Bias voltages (v_tail, v_pbias) use conservative 0.8–1.2× original but clamped <= 1.2 V.
# - All initial parameter values (initial_params) are EXACTLY the original values from the provided netlist.
param_ranges_definition = {
    # Transistor widths (meters). Large dynamic range: log sampling recommended.
    'w_M1':   {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 10e-6
    'w_M2':   {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 10e-6
    'w_Mtail':{'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 5e-6
    'w_M4':   {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 20e-6
    'w_M3':   {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 20e-6
    'w_M7':   {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 20e-6
    'w_M8':   {'min': 0.045e-6, 'max': 22.5e-6, 'log': True},  # originally 30e-6
    # Bias voltages (volts). Conservative linear sampling.
    # v_tail original = 0.42 V  => 0.8*0.42 = 0.336 .. 1.2*0.42 = 0.504 (<= 1.2V)
    'v_tail': {'min': max(0.8 * 0.42, 0.0), 'max': min(1.2 * 0.42, 1.2), 'log': False},
    # v_pbias original = 0.78 V => 0.8*0.78 = 0.624 .. 1.2*0.78 = 0.936 (<= 1.2V)
    'v_pbias':{'min': max(0.8 * 0.78, 0.0), 'max': min(1.2 * 0.78, 1.2), 'log': False},
}
# -------------------------
# Initial parameter values (EXACT original circuit values)
# These values must be preserved as the starting point for optimization.
# -------------------------
initial_params = {
    # Transistor widths (as given in original netlist)
    'w_M1':    10e-6,
    'w_M2':    10e-6,
    'w_Mtail': 5e-6,
    'w_M4':    20e-6,
    'w_M3':    20e-6,
    'w_M7':    20e-6,
    'w_M8':    30e-6,
    # Bias voltages (as given in original netlist)
    'v_tail':  0.42,
    'v_pbias': 0.78,
}
# -------------------------
# Brief description of each parameter (physical meaning)
# -------------------------
parameter_descriptions = {
    # Widths (W) — only W is varied; L fixed at 45 nm in the circuit:
    'w_M1':    'Width of NMOS M1 (differential pair, Vinp side). Affects gm and current steering.',
    'w_M2':    'Width of NMOS M2 (differential pair, Vinn side). Affects gm and current steering.',
    'w_Mtail': 'Width of NMOS tail transistor (current source). Controls tail current compliance and headroom.',
    'w_M4':    'Width of PMOS diode-connected device (mirror reference). Sets mirror reference current.',
    'w_M3':    'Width of PMOS mirror device (active load). Affects load resistance and gain of first stage.',
    'w_M7':    'Width of NMOS M7 (second-stage common-source). Controls gm and output drive of stage 2.',
    'w_M8':    'Width of PMOS M8 (cascode/current-source load for stage 2). Affects output impedance and gain.',
    # Bias voltages:
    'v_tail':  'Tail bias voltage applied to tail transistor gate (Vtail). Adjusts tail current; must remain <= Vdd.',
    'v_pbias': 'PMOS bias voltage applied to gate of M8 (Vbiasp). Sets operating point of PMOS load; must remain <= Vdd.',
}
# Note:
# - vdd is intentionally fixed at 1.2 V and is NOT part of the optimization parameters.
# - Vinp and Vinn are fixed at 0.6 V (they will be externally swept during DC analysis).
# - No explicit resistors or capacitors were present in the original netlist; thus none are parameterized.
# - If you later introduce compensation or load capacitors/resistors, follow these guidelines:
#     - Resistors: 0.5–2× original value
#     - Critical compensation capacitors: 0.5–5× original
#     - Other capacitors: 0.8–1.5× original
