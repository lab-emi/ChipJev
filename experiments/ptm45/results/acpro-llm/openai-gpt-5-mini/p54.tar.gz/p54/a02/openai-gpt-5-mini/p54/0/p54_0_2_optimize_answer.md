```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    """
    Create the parameterized PySpice circuit.

    Note: keep the import of transistor model parameter dicts exactly as requested.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('High-Gain Multi-Stage OpAmp (parametrized)')

    # MOSFET models (external)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed 1.2 V (do not include in optimization)

    # Differential input DC biases (fixed, these will be swept externally and should not be parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 1.0)
    circuit.V('inn', 'Vinn', circuit.gnd, 1.0)

    # Bias voltages (parameterized; ranges defined externally)
    circuit.V('bp', 'Vbias_p', circuit.gnd, params['v_bias_p'])
    circuit.V('bt', 'Vbias_tail', circuit.gnd, params['v_bias_tail'])

    # Differential pair (NMOS) - bulk tied to source (Snode)
    # Lengths are kept exactly as original and fixed; only widths are parameterized.
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Snode', 'Snode',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)   # original length kept (45 nm, written as in original code)

    circuit.MOSFET('M2', 'D2', 'Vinn', 'Snode', 'Snode',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=0.045e-6)   # original length (45 nm)

    # Tail current source (NMOS) - bulk tied to ground
    circuit.MOSFET('Mtail', 'Snode', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=0.18e-6)    # original length (180 nm)

    # PMOS current mirror load (active load converting diff -> single-ended)
    # M3: diode-connected PMOS on left node (bulk tied to Vdd)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=0.12e-6)    # original length (120 nm)

    # M4: mirror PMOS that mirrors current into D2 (bulk tied to Vdd)
    circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=0.12e-6)    # original length (120 nm)

    # Second stage: common-source NMOS amplifier (driven by D2)
    circuit.MOSFET('M7', 'Vout', 'D2', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M7'],
                   l=0.12e-6)    # original length (120 nm)

    # PMOS current-source load for second stage (bulk tied to Vdd)
    circuit.MOSFET('M9', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M9'],
                   l=0.12e-6)    # original length (120 nm)

    return circuit


# ---------------------------------------------------------------------
# Parameter search ranges (annotated for Optuna or similar frameworks)
# ---------------------------------------------------------------------
# Notes on ranges:
# - Transistor widths W: 1x - 500x their device length L (keeps W/L in reasonable bounds)
# - Voltage biases (v_bias_p, v_bias_tail): 0.8 - 1.2 × original, but never exceeding 1.2 V
# - All initial_params below are EXACTLY the original numeric values from the provided netlist
# - All initial values are chosen to be inside the corresponding ranges
#
# Units:
# - Widths in meters (m)
# - Voltages in volts (V)
# - Lengths are fixed in the create_circuit code as in the original netlist

param_ranges_definition = {
    # Transistor widths (W). min = 1 * L, max = 500 * L (per requirement).
    # M1, M2: L = 0.045e-6 (45 nm) -> W range: [0.045e-6, 0.045e-6 * 500]
    'w_M1': {'min': 0.045e-6 * 1.0,   'max': 0.045e-6 * 500.0, 'log': True},
    'w_M2': {'min': 0.045e-6 * 1.0,   'max': 0.045e-6 * 500.0, 'log': True},

    # Mtail: L = 0.18e-6 (180 nm)
    'w_Mtail': {'min': 0.18e-6 * 1.0,  'max': 0.18e-6 * 500.0,  'log': True},

    # M3, M4, M7, M9: L = 0.12e-6 (120 nm)
    'w_M3': {'min': 0.12e-6 * 1.0,    'max': 0.12e-6 * 500.0,  'log': True},
    'w_M4': {'min': 0.12e-6 * 1.0,    'max': 0.12e-6 * 500.0,  'log': True},
    'w_M7': {'min': 0.12e-6 * 1.0,    'max': 0.12e-6 * 500.0,  'log': True},
    'w_M9': {'min': 0.12e-6 * 1.0,    'max': 0.12e-6 * 500.0,  'log': True},

    # Bias voltages: 0.8 - 1.2 × original, but clipped to <= 1.2 V (and expressed linearly).
    # Original v_bias_p = 0.40 V -> range [0.32, 0.48] V
    'v_bias_p': {'min': max(0.40 * 0.8, 0.0), 'max': min(0.40 * 1.2, 1.2), 'log': False},

    # Original v_bias_tail = 0.90 V -> range [0.72, 1.08] V (<= 1.2)
    # Note: these bias ranges were chosen conservatively and respect the MOSFET Vth (~0.22 V)
    'v_bias_tail': {'min': max(0.90 * 0.8, 0.0), 'max': min(0.90 * 1.2, 1.2), 'log': False},
}

# ---------------------------------------------------------------------
# Initial parameters (EXACT original values from the provided netlist)
# ---------------------------------------------------------------------
initial_params = {
    # Transistor widths (exactly as in original code)
    'w_M1': 10e-6,    # Original: w=10e-6
    'w_M2': 10e-6,    # Original: w=10e-6
    'w_Mtail': 5e-6,  # Original: w=5e-6
    'w_M3': 40e-6,    # Original: w=40e-6
    'w_M4': 40e-6,    # Original: w=40e-6
    'w_M7': 20e-6,    # Original: w=20e-6
    'w_M9': 40e-6,    # Original: w=40e-6

    # Bias voltages (exact original values)
    'v_bias_p': 0.40,   # Original: 0.40 V (bp)
    'v_bias_tail': 0.90,# Original: 0.90 V (bt)
}

# ---------------------------------------------------------------------
# Brief physical description of each parameter
# ---------------------------------------------------------------------
parameter_descriptions = {
    'w_M1': "Width of input NMOS M1 (left transistor of the differential pair). Affects gm and input pair tail current splitting.",
    'w_M2': "Width of input NMOS M2 (right transistor of the differential pair). Affects gm and input pair tail current splitting.",
    'w_Mtail': "Width of NMOS tail transistor. Controls tail current magnitude and tail output resistance.",
    'w_M3': "Width of diode-connected PMOS M3 (left side of active load). Sets mirror gate voltage and load compliance.",
    'w_M4': "Width of mirror PMOS M4 (right side of active load). Controls mirrored current and load resistance/ro.",
    'w_M7': "Width of second-stage NMOS M7 (common-source amplifier). Affects gain and output drive of second stage.",
    'w_M9': "Width of PMOS current-source load M9 for the second stage. Controls second-stage bias and load resistance.",
    'v_bias_p': "PMOS load bias (Vbias_p). Sets PMOS M9 gate voltage and thus the PMOS load current; constrained conservatively to maintain active region operation.",
    'v_bias_tail': "NMOS tail bias (Vbias_tail). Sets the gate voltage of the tail current source (Mtail) and therefore the tail current. Range chosen to keep transistor in conduction and to respect Vdd.",
}

# ---------------------------------------------------------------------
# Important notes / constraints recap
# ---------------------------------------------------------------------
# - vdd (1.2 V) and differential input sources (Vinp, Vinn at 1.0 V) remain fixed and are not included in the parameter search.
# - All voltage ranges for biases were chosen as 0.8-1.2× original values and explicitly clipped to <= 1.2 V.
# - All transistor lengths are fixed to the exact numerical values from the original netlist; only widths are optimized.
# - There were no explicit resistors or capacitors in the provided netlist; if added later, follow the requested scaling rules:
#     * Resistors: 0.5-2× original
#     * Critical caps: 0.5-5× original
#     * Other caps: 0.8-1.5× original
# - Ensure any optimizer uses these ranges and that the initial_params dictionary is used as the starting point.
```