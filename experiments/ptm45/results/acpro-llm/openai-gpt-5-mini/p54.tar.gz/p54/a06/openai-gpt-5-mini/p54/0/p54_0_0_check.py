from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp')
# Define MOSFET models (45 nm technology model parameters provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Supply and bias voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('Vin_p', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('Vin_n', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)    # Tail bias using Vth guideline (0.42 V)
circuit.V('pbias', 'Vbias_p', circuit.gnd, 0.78) # PMOS bias using Vth guideline (0.78 V)
# Device sizing (45 nm node: L = 45e-9 m)
L = 45e-9
# ---------- Stage 1: Differential pair with PMOS active-load mirror ----------
# Node naming:
#  - n1: drain of M1 (left differential drain) -> single-ended output of stage-1 -> input to stage-2
#  - n2: drain of M2 (right differential drain), used as diode node for mirror
#  - S: common source node of M1/M2 (connected to drain of tail Mt)
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'n1', 'Vinp', 'S', 'S', model='nmos_model', w=6e-6, l=L)
circuit.MOSFET('M2', 'n2', 'Vinn', 'S', 'S', model='nmos_model', w=6e-6, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mt', 'S', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=L)
# PMOS active-load mirror
# M3 is diode-connected on node n2 (gate tied to n2); M4 mirrors to n1
circuit.MOSFET('M3', 'n2', 'n2', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)  # diode-connected PMOS
circuit.MOSFET('M4', 'n1', 'n2', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)  # mirrored PMOS
# ---------- Stage 2: Single-ended common-source stage for extra gain ----------
# M7: NMOS input device for second stage, gate tied to n1 (stage-1 single-ended node)
# M8: PMOS current-source load (high impedance) tied to Vdd, gate to Vbias_p
circuit.MOSFET('M7', 'Vout', 'n1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=L)
circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L)
# End of netlist; create simulator for operating point / further analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)