from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: The model import must appear exactly as below inside create_circuit (per requirements)
def create_circuit(params):
    from model import nmos_params, pmos_params  # required import as specified
    circuit = Circuit('High-Gain Multi-Stage Opamp (parameterized)')
    # MOS models (parameters provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed supply and input voltages (not parameterized per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd fixed = 1.2 V (45 nm)
    circuit.V('Vin_p', 'Vinp', circuit.gnd, 0.6)     # Vinp fixed (swept externally)
    circuit.V('Vin_n', 'Vinn', circuit.gnd, 0.6)     # Vinn fixed (swept externally)
    # Parameterized bias voltages (kept <= 1.2 V and within 0.8-1.2× original)
    circuit.V('tail', 'Vtail', circuit.gnd, params['V_tail'])    # tail bias (parameterized)
    circuit.V('pbias', 'Vbias_p', circuit.gnd, params['V_pbias'])# pmos bias (parameterized)
    # Process length (fixed for 45nm technology)
    L = 45e-9
    # ---------- Stage 1: Differential pair with PMOS active-load mirror ----------
    # Input differential pair (NMOS) - widths parameterized, length fixed
    circuit.MOSFET('M1', 'n1', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'n2', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('Mt', 'S', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mt'],
                   l=L)
    # PMOS active-load mirror (M3 diode-connected on n2, M4 mirror to n1)
    circuit.MOSFET('M3', 'n2', 'n2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)  # diode-connected PMOS
    circuit.MOSFET('M4', 'n1', 'n2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)  # mirrored PMOS
    # ---------- Stage 2: Single-ended common-source stage for extra gain ----------
    circuit.MOSFET('M7', 'Vout', 'n1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M7'],
                   l=L)
    circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M8'],
                   l=L)
    # Note: There were no explicit resistors or capacitors in the original netlist.
    # If you add compensation / load capacitors or resistors, follow the search-range rules.
    return circuit
# -----------------------------
# Optimization parameter search ranges (annotated)
# -----------------------------
# Constraints applied:
# - Transistor width W range: [1×L, 500×L] (L = 45e-9 m) => [45e-9, 22.5e-6]
# - Voltage sources (except Vdd and input Vinp/Vinn) range: 0.8-1.2× original, but never > 1.2 V
# - All initial_params are EXACT original values and must lie inside these ranges
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling recommended for wide dynamic range.
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 6e-6
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 6e-6
    'w_Mt': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 2e-6
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 12e-6
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 12e-6
    'w_M7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6
    'w_M8': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6
    # Bias voltages (volts) - 0.8-1.2× original, clipped to <= 1.2 V
    # V_tail original = 0.42 V -> range [0.8*0.42, 1.2*0.42] = [0.336, 0.504]
    'V_tail': {'min': 0.336, 'max': 0.504, 'log': False},
    # V_pbias original = 0.78 V -> range [0.8*0.78, 1.2*0.78] = [0.624, 0.936]
    'V_pbias': {'min': 0.624, 'max': 0.936, 'log': False},
}
# -----------------------------
# Initial parameter values (EXACT original circuit values)
# These must match the original netlist exactly (no modification).
# -----------------------------
initial_params = {
    # Transistor widths (exact originals from provided netlist)
    'w_M1': 6e-6,
    'w_M2': 6e-6,
    'w_Mt': 2e-6,
    'w_M3': 12e-6,
    'w_M4': 12e-6,
    'w_M7': 10e-6,
    'w_M8': 20e-6,
    # Bias voltages (exact originals)
    'V_tail': 0.42,
    'V_pbias': 0.78,
}
# -----------------------------
# Parameter descriptions (brief)
# -----------------------------
parameter_descriptions = {
    'w_M1': 'Width of input NMOS M1 (left differential transistor). Controls gm and current, W/L determines operating point.',
    'w_M2': 'Width of input NMOS M2 (right differential transistor). Symmetric to M1.',
    'w_Mt': 'Width of tail NMOS Mt (current source). Controls tail current and common-source node bias.',
    'w_M3': 'Width of diode-connected PMOS M3 in the active-load mirror (sets mirror reference).',
    'w_M4': 'Width of mirrored PMOS M4 that loads the M1 drain (sets mirror current scaling).',
    'w_M7': 'Width of second-stage NMOS M7 (common-source input of stage 2). Affects stage-2 gain and output drive.',
    'w_M8': 'Width of PMOS load M8 for stage 2 (current-source load). Sets bias and output impedance of stage 2.',
    'V_tail': 'Tail bias voltage (node Vtail) that drives tail transistor. Parameterized to tune tail current while constrained to safe range.',
    'V_pbias': 'PMOS bias voltage (Vbias_p) that sets gate of M8 (PMOS load). Parameterized to tune load current and operating region.',
}
# Note:
# - Vdd and the input sources (Vinp, Vinn) are intentionally NOT parameterized and remain fixed,
#   since sweeps of Vin inputs are performed externally during DC operating-point analysis.
# - No resistors or capacitors were present in the original netlist. If you later add them:
#     - Resistors: 0.5-2× original
#     - Critical compensation capacitors: 0.5-5× original
#     - Other capacitors: 0.8-1.5× original
# - All parameter initial values are inside the declared ranges above.
