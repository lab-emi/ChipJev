from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp')
# Define MOSFET models (45 nm technology model parameters provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Supply and bias voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('Vin_p', 'Vinp', circuit.gnd, 0.6)     # DC common-mode for Vinp
circuit.V('Vin_n', 'Vinn', circuit.gnd, 0.6)     # DC common-mode for Vinn
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)    # Tail bias using Vth guideline (0.42 V)
circuit.V('pbias', 'Vbias_p', circuit.gnd, 0.78) # PMOS bias using Vth guideline (0.78 V)
# Device sizing (45 nm node: L = 45e-9 m)
L = 45e-9
# ---------- Stage 1: Differential pair with PMOS active-load mirror ----------
# Node naming:
#  - n1: drain of M1 (left differential drain) -> single-ended output of stage-1 -> input to stage-2
#  - n2: drain of M2 (right differential drain), used as diode node for mirror
#  - S: common source node of M1/M2 (connected to drain of tail Mt)
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'n1', 'Vinp', 'S', 'S', model='nmos_model', w=6e-6, l=L)
circuit.MOSFET('M2', 'n2', 'Vinn', 'S', 'S', model='nmos_model', w=6e-6, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mt', 'S', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=L)
# PMOS active-load mirror
# M3 is diode-connected on node n2 (gate tied to n2); M4 mirrors to n1
circuit.MOSFET('M3', 'n2', 'n2', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)  # diode-connected PMOS
circuit.MOSFET('M4', 'n1', 'n2', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)  # mirrored PMOS
# ---------- Stage 2: Single-ended common-source stage for extra gain ----------
# M7: NMOS input device for second stage, gate tied to n1 (stage-1 single-ended node)
# M8: PMOS current-source load (high impedance) tied to Vdd, gate to Vbias_p
circuit.MOSFET('M7', 'Vout', 'n1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=L)
circuit.MOSFET('M8', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L)
# End of netlist; create simulator for operating point / further analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
