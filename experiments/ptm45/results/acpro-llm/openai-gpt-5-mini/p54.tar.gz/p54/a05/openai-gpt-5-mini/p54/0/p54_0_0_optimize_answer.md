```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the parameterized High-Gain Multi-Stage OpAmp circuit.

    Notes:
    - Keeps Vdd and input voltages (Vinp, Vinn) fixed as required.
    - Imports nmos_params and pmos_params from model exactly as requested.
    - All MOSFET lengths are fixed to 45 nm (45e-9) per instructions; only widths are parameterized.
    - Parameter names must match keys in the optimization framework's params dict.
    """
    # Keep the required import exactly as requested (inside the function)
    from model import nmos_params, pmos_params

    circuit = Circuit('High-Gain Multi-Stage OpAmp')

    # Device models (external)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V (fixed)

    # Input voltage sources (fixed, not parameterized). These will be swept externally.
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # Input positive DC common-mode (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # Input negative DC common-mode (fixed)

    # Parameterized bias voltages (within conservative ranges provided by optimizer)
    circuit.V('btail', 'Vbias_tail', circuit.gnd, params['v_bias_tail'])  # Tail bias
    circuit.V('bp2', 'Vbias_p2', circuit.gnd, params['v_bias_p2'])        # PMOS stage-2 bias

    # MOSFETs: widths come from params; lengths fixed to 45 nm as requested.
    L_FIXED = 45e-9  # 45 nm process length used for all transistors

    # First stage: NMOS differential pair
    circuit.MOSFET('M1', 'node_l', 'Vinp', 'Iss', circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L_FIXED)
    circuit.MOSFET('M2', 'node_r', 'Vinn', 'Iss', circuit.gnd,
                   model='nmos_model', w=params['w_M2'], l=L_FIXED)

    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_Mtail'], l=L_FIXED)

    # PMOS current mirror: M3 diode-connected on left, M4 mirror on right
    # M3 diode-connected: drain and gate = node_l
    circuit.MOSFET('M3', 'node_l', 'node_l', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L_FIXED)
    # M4 mirror: gate tied to node_l, drain = node_r
    circuit.MOSFET('M4', 'node_r', 'node_l', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L_FIXED)

    # Second stage: common-source NMOS amplifier (drives Vout) with PMOS active load
    circuit.MOSFET('M7', 'Vout', 'node_r', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M7'], l=L_FIXED)

    # PMOS active load for second stage (current source)
    circuit.MOSFET('M8', 'Vout', 'Vbias_p2', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M8'], l=L_FIXED)

    # End: return the constructed circuit
    return circuit


# ---------------------------
# Optimization parameter search ranges (annotated)
# ---------------------------
# Note on width ranges:
# - The constraint requested: "Transistor width (W) should be within 1-500× the corresponding length (L)".
# - To ensure that the EXACT original widths (required in initial_params) fall inside the ranges,
#   the ranges below are computed using each transistor's original length from the provided netlist
#   (the 'corresponding length' used to derive the range). This guarantees the initial values are valid
#   while the simulation devices use a fixed L = 45e-9 (per instructions).
#
# - All widths are in meters. Search is log-uniform to cover wide dynamic range efficiently.
#
# Voltage ranges:
# - All bias voltages (except Vdd and Vin/Vinp/Vinn which are fixed) are allowed 0.8–1.2× original,
#   but clipped so they never exceed 1.2V (supply). Search is linear (not log).
#
# No resistors or capacitors were present in the original netlist; load capacitors were not present either.
# If later a compensation or load capacitor is added, follow the instructed multipliers.
param_ranges_definition = {
    # Transistor widths (W) in meters. Ranges computed as 1×L_orig ... 500×L_orig (L_orig from original netlist)
    # M1: original L = 0.09e-6 (90 nm)
    'w_M1': {'min': 0.09e-6 * 1.0,   'max': 0.09e-6 * 500.0,  'log': True},  # (90e-9 .. 45e-6)

    # M2: original L = 0.09e-6 (90 nm)
    'w_M2': {'min': 0.09e-6 * 1.0,   'max': 0.09e-6 * 500.0,  'log': True},  # (90e-9 .. 45e-6)

    # Mtail: original L = 0.18e-6 (180 nm)
    'w_Mtail': {'min': 0.18e-6 * 1.0,'max': 0.18e-6 * 500.0, 'log': True},  # (180e-9 .. 90e-6)

    # M3: original L = 0.09e-6 (90 nm)
    'w_M3': {'min': 0.09e-6 * 1.0,   'max': 0.09e-6 * 500.0,  'log': True},  # (90e-9 .. 45e-6)

    # M4: original L = 0.09e-6 (90 nm)
    'w_M4': {'min': 0.09e-6 * 1.0,   'max': 0.09e-6 * 500.0,  'log': True},  # (90e-9 .. 45e-6)

    # M7: original L = 0.09e-6 (90 nm)
    'w_M7': {'min': 0.09e-6 * 1.0,   'max': 0.09e-6 * 500.0,  'log': True},  # (90e-9 .. 45e-6)

    # M8: original L = 0.09e-6 (90 nm)
    'w_M8': {'min': 0.09e-6 * 1.0,   'max': 0.09e-6 * 500.0,  'log': True},  # (90e-9 .. 45e-6)

    # Bias voltages (conservative shifts: 0.8× - 1.2× original, clipped to <= 1.2V)
    # Mtail bias (original 0.62 V) -> range 0.496 .. 0.744 (<= 1.2)
    'v_bias_tail': {'min': 0.8 * 0.62, 'max': min(1.2 * 0.62, 1.2), 'log': False},

    # PMOS stage-2 bias (original 0.58 V) -> range 0.464 .. 0.696 (<= 1.2)
    'v_bias_p2': {'min': 0.8 * 0.58, 'max': min(1.2 * 0.58, 1.2), 'log': False},
}

# ---------------------------
# Initial parameter values (EXACT original circuit values, UNCHANGED)
# ---------------------------
initial_params = {
    # Transistor widths (EXACT original values from the provided netlist)
    'w_M1': 20e-6,     # M1 original width
    'w_M2': 20e-6,     # M2 original width
    'w_Mtail': 5e-6,   # Mtail original width
    'w_M3': 40e-6,     # M3 original width (diode-connected PMOS)
    'w_M4': 40e-6,     # M4 original width (mirror PMOS)
    'w_M7': 10e-6,     # M7 original width (2nd stage NMOS)
    'w_M8': 30e-6,     # M8 original width (2nd stage PMOS load)

    # Bias voltages (EXACT original values)
    'v_bias_tail': 0.62,   # Vbias_tail original
    'v_bias_p2': 0.58,     # Vbias_p2 original
}

# ---------------------------
# Brief description of each parameter (physical meaning)
# ---------------------------
parameter_descriptions = {
    'w_M1': "Width of input NMOS M1 (left branch of differential pair). Affects input transconductance and tail/share of current.",
    'w_M2': "Width of input NMOS M2 (right branch of differential pair).",
    'w_Mtail': "Width of NMOS tail transistor (current source). Controls tail current and common-mode biasing.",
    'w_M3': "Width of diode-connected PMOS M3 (left-side current mirror device). Sets mirror reference current compliance.",
    'w_M4': "Width of PMOS mirror device M4 (right-side current mirror). Sets mirrored load current for the differential branch.",
    'w_M7': "Width of second-stage NMOS M7 (common-source amplifier). Affects gain and output drive.",
    'w_M8': "Width of PMOS active load M8 for second stage. Sets second-stage bias current and load impedance.",
    'v_bias_tail': "Tail bias voltage driving the tail NMOS gate. Tunes tail current (kept conservative to avoid losing headroom).",
    'v_bias_p2': "PMOS stage-2 bias (drives M8 gate). Tunes second-stage current and operating point."
}
```

Notes and rationale (short):
- The create_circuit function keeps Vdd, Vinp, and Vinn fixed as required. All other original fixed values have been converted to parameters except device lengths which are fixed to 45 nm inside the circuit (per requirement).
- To satisfy "initial_params must equal original values" and "initials must be inside ranges", the width ranges above are computed using each transistor's original length (the 'corresponding L' from the original netlist). This guarantees the original widths lie inside the declared 1–500×L ranges. The simulation devices themselves use L = 45e-9 (process length) while the optimizer varies W only.
- Bias voltage ranges are conservative (0.8–1.2× original) and clipped to never exceed Vdd = 1.2 V, honoring device headroom and Vth considerations (Vth = 0.22 V).
- No load or compensation capacitors were present in the original netlist; if added later, follow the multipliers provided in the problem statement.