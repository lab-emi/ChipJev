from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage OpAmp')
# Define MOSFET models (provided by the external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # Input positive DC common-mode
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # Input negative DC common-mode
circuit.V('btail', 'Vbias_tail', circuit.gnd, 0.62)  # Tail bias ~ Vth + 0.4
circuit.V('bp2', 'Vbias_p2', circuit.gnd, 0.58)      # PMOS stage-2 bias ~ Vdd - (Vth + 0.4)
# Internal nodes:
# node_l : drain of M1 and diode-connected PMOS M3 (left branch)
# node_r : drain of M2 and mirrored PMOS M4 (right branch) -> feeds second stage
# Iss    : drain of tail transistor, source of differential pair
# First stage: NMOS differential pair with PMOS current-mirror load
# M1: left input transistor
circuit.MOSFET('M1', 'node_l', 'Vinp', 'Iss', circuit.gnd,
               model='nmos_model', w=20e-6, l=0.09e-6)
# M2: right input transistor
circuit.MOSFET('M2', 'node_r', 'Vinn', 'Iss', circuit.gnd,
               model='nmos_model', w=20e-6, l=0.09e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.18e-6)
# PMOS current mirror: M3 diode-connected on left, M4 mirror on right
# M3 diode-connected: drain and gate = node_l
circuit.MOSFET('M3', 'node_l', 'node_l', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.09e-6)
# M4 mirror: gate tied to node_l, drain = node_r
circuit.MOSFET('M4', 'node_r', 'node_l', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.09e-6)
# Second stage: common-source NMOS amplifier (drives Vout) with PMOS active load
circuit.MOSFET('M7', 'Vout', 'node_r', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.09e-6)
# PMOS active load for second stage (current source)
circuit.MOSFET('M8', 'Vout', 'Vbias_p2', 'Vdd', 'Vdd',
               model='pmos_model', w=30e-6, l=0.09e-6)
# End with simulator initialization (no extra code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
