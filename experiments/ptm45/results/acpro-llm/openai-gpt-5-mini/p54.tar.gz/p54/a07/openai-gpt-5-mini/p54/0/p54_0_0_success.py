from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp')
# Define the MOSFET models (assumed provided in model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('vinp', 'Vinp', circuit.gnd, 0.60)      # DC common-mode input (operating point)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.60)      # DC common-mode input (operating point)
# Bias voltages chosen using Vth = 0.22 V
circuit.V('b_tail', 'Vb_tail', circuit.gnd, 0.42)   # Vth + 0.2 = 0.42 V
circuit.V('b_pmos', 'Vb_pmos', circuit.gnd, 0.78)   # Vdd - |Vth| - 0.2 = 0.78 V
circuit.V('b_pcas', 'Vb_pcas', circuit.gnd, 0.78)   # PMOS cascode gate bias (same nominal)
# First stage: NMOS differential pair
# M1: left input transistor
circuit.MOSFET('M1', 'D_L', 'Vinp', 'S_tail', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# M2: right input transistor
circuit.MOSFET('M2', 'D_R', 'Vinn', 'S_tail', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current mirror load
# M3: diode-connected reference (left side)
circuit.MOSFET('M3', 'D_L', 'D_L', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# M4: mirror device (feeds right drain -> single-ended node)
circuit.MOSFET('M4', 'D_R', 'D_L', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('M7', 'S_tail', 'Vb_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# Second stage: NMOS common-source with cascoded PMOS load
# M8: second-stage NMOS transistor (gate driven by first-stage single-ended node D_R)
circuit.MOSFET('M8', 'Vout', 'D_R', circuit.gnd, circuit.gnd,
               model='nmos_model', w=40e-6, l=0.045e-6)
# Cascoded PMOS load: top load M9 and cascode M10 (Vdd -> M9 -> NODE_C -> M10 -> Vout)
circuit.MOSFET('M9', 'NODE_C', 'Vb_pmos', 'Vdd', 'Vdd',
               model='pmos_model', w=80e-6, l=0.045e-6)
circuit.MOSFET('M10', 'Vout', 'Vb_pcas', 'NODE_C', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Ensure the required node name appears exactly as requested
# Output node is 'Vout' (declared as a net above by use in MOSFETs)
# Inputs 'Vinp' and 'Vinn' are declared by voltage sources above
# Create simulator (do not append any other code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
