from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized High-Gain Multi-Stage Opamp circuit.
    The import line "from model import nmos_params, pmos_params" is required
    and kept exactly as requested (above, at file scope).
    """
    circuit = Circuit('High-Gain Multi-Stage Opamp')
    # MOSFET models (provided by model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Fixed power and input rails (not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd fixed at 1.2 V (45nm technology)
    circuit.V('vinp', 'Vinp', circuit.gnd, 0.60)      # Input positive (fixed; swept externally)
    circuit.V('vinn', 'Vinn', circuit.gnd, 0.60)      # Input negative (fixed; swept externally)
    # Parameterized bias voltages (allowed to vary within conservative range)
    circuit.V('b_tail', 'Vb_tail', circuit.gnd, params['Vb_tail'])   # Tail bias (NMOS current source gate)
    circuit.V('b_pmos', 'Vb_pmos', circuit.gnd, params['Vb_pmos'])   # PMOS load gate bias
    circuit.V('b_pcas', 'Vb_pcas', circuit.gnd, params['Vb_pcas'])   # PMOS cascode gate bias
    # Fixed device channel length for this technology (45 nm expressed as in original netlist)
    L = 0.045e-6
    # First stage: NMOS differential pair
    circuit.MOSFET('M1', 'D_L', 'Vinp', 'S_tail', circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L)
    circuit.MOSFET('M2', 'D_R', 'Vinn', 'S_tail', circuit.gnd,
                   model='nmos_model', w=params['w_M2'], l=L)
    # PMOS current mirror load
    circuit.MOSFET('M3', 'D_L', 'D_L', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)   # diode-connected PMOS
    circuit.MOSFET('M4', 'D_R', 'D_L', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)   # mirror device
    # Tail current source (NMOS)
    circuit.MOSFET('M7', 'S_tail', 'Vb_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M7'], l=L)
    # Second stage: NMOS common-source
    circuit.MOSFET('M8', 'Vout', 'D_R', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M8'], l=L)
    # Cascoded PMOS load (M9 top, M10 cascode)
    circuit.MOSFET('M9', 'NODE_C', 'Vb_pmos', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M9'], l=L)
    circuit.MOSFET('M10', 'Vout', 'Vb_pcas', 'NODE_C', 'Vdd',
                   model='pmos_model', w=params['w_M10'], l=L)
    # Note: No load capacitor was present in the original netlist; if a fixed
    # output capacitor exists it should be added here with the original value (not parameterized).
    return circuit
# -------------------------
# Optimization parameter search ranges (annotated)
# -------------------------
# Technology channel length (fixed): L = 0.045e-6 (45 nm)
# Transistor widths: constrained to 1×L .. 500×L
L = 0.045e-6
W_min = 1.0 * L           # minimum width (1×L)
W_max = 500.0 * L         # maximum width (500×L)
param_ranges_definition = {
    # Transistor widths (meters). Use log search to cover wide dynamic range efficiently.
    'w_M1':  {'min': W_min, 'max': W_max, 'log': True},   # Left input NMOS
    'w_M2':  {'min': W_min, 'max': W_max, 'log': True},   # Right input NMOS
    'w_M3':  {'min': W_min, 'max': W_max, 'log': True},   # PMOS diode (mirror reference)
    'w_M4':  {'min': W_min, 'max': W_max, 'log': True},   # PMOS mirror device
    'w_M7':  {'min': W_min, 'max': W_max, 'log': True},   # Tail NMOS
    'w_M8':  {'min': W_min, 'max': W_max, 'log': True},   # 2nd-stage NMOS
    'w_M9':  {'min': W_min, 'max': W_max, 'log': True},   # PMOS top load
    'w_M10': {'min': W_min, 'max': W_max, 'log': True},   # PMOS cascode
    # Bias voltages: allowed to vary conservatively in [0.8×orig, 1.2×orig], but never > 1.2 V.
    # These govern device gate biases and must stay in a safe region relative to Vth=0.22V.
    'Vb_tail': {'min': max(0.8 * 0.42, 0.0), 'max': min(1.2 * 0.42, 1.2), 'log': False},
    'Vb_pmos': {'min': max(0.8 * 0.78, 0.0), 'max': min(1.2 * 0.78, 1.2), 'log': False},
    'Vb_pcas': {'min': max(0.8 * 0.78, 0.0), 'max': min(1.2 * 0.78, 1.2), 'log': False},
}
# -------------------------
# Initial parameter values (EXACT original circuit values)
# These values are the original values appearing in your provided netlist and
# must be preserved exactly as the starting point for optimization.
# -------------------------
initial_params = {
    # Exact original transistor widths
    'w_M1': 10e-6,   # Original width for M1
    'w_M2': 10e-6,   # Original width for M2
    'w_M3': 40e-6,   # Original width for M3
    'w_M4': 40e-6,   # Original width for M4
    'w_M7': 10e-6,   # Original width for M7
    'w_M8': 40e-6,   # Original width for M8
    'w_M9': 80e-6,   # Original width for M9
    'w_M10': 40e-6,  # Original width for M10
    # Exact original bias voltages
    'Vb_tail': 0.42,   # Vth + 0.2 (original)
    'Vb_pmos': 0.78,   # Vdd - |Vth| - 0.2 (original)
    'Vb_pcas': 0.78,   # PMOS cascode gate bias (original)
}
# -------------------------
# Brief description of each parameter (physical meaning)
# -------------------------
# w_Mx (meters) : Channel width of MOSFET Mx. Width controls current drive (Id) and device gm.
#                 L is fixed at 0.045e-6 (45 nm); optimization changes W only (W/L affects behavior).
#
# Vb_tail (volts) : Gate bias for tail NMOS current source (M7). Alters tail current and input pair operating point.
# Vb_pmos (volts) : Gate bias for top PMOS of the cascode/load (M9). Sets operating point of PMOS load stack.
# Vb_pcas (volts) : Gate bias for PMOS cascode device (M10). Controls headroom at cascode node and output swing.
#
# Notes / Constraints enforced:
# - All widths constrained to [1×L, 500×L] = [0.045e-6, 22.5e-6] m (covers 1–500× L).
# - All bias voltages constrained to 0.8–1.2× original values, but capped at 1.2 V (supply).
# - Vdd (1.2 V) and input rails (Vinp, Vinn = 0.60 V) are fixed and NOT part of the search.
# - No load capacitances were present in the original netlist; if present, they should be kept fixed
#   (per your requirement) and not included in the parameter search.
#
# All initial_params values above are identical to the original numbers in your provided netlist
# and lie inside the declared search ranges.
