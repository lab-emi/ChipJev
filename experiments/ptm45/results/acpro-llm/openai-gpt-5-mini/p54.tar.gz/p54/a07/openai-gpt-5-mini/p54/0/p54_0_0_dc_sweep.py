from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage Opamp')
# Define the MOSFET models (assumed provided in model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('dc', 'Vinn', 'Vinp', 0.0)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.60)      # DC common-mode input (operating point)
# Bias voltages chosen using Vth = 0.22 V
circuit.V('b_tail', 'Vb_tail', circuit.gnd, 0.42)   # Vth + 0.2 = 0.42 V
circuit.V('b_pmos', 'Vb_pmos', circuit.gnd, 0.78)   # Vdd - |Vth| - 0.2 = 0.78 V
circuit.V('b_pcas', 'Vb_pcas', circuit.gnd, 0.78)   # PMOS cascode gate bias (same nominal)
# First stage: NMOS differential pair
# M1: left input transistor
circuit.MOSFET('M1', 'D_L', 'Vinp', 'S_tail', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# M2: right input transistor
circuit.MOSFET('M2', 'D_R', 'Vinn', 'S_tail', circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current mirror load
# M3: diode-connected reference (left side)
circuit.MOSFET('M3', 'D_L', 'D_L', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# M4: mirror device (feeds right drain -> single-ended node)
circuit.MOSFET('M4', 'D_R', 'D_L', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('M7', 'S_tail', 'Vb_tail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
# Second stage: NMOS common-source with cascoded PMOS load
# M8: second-stage NMOS transistor (gate driven by first-stage single-ended node D_R)
circuit.MOSFET('M8', 'Vout', 'D_R', circuit.gnd, circuit.gnd,
               model='nmos_model', w=40e-6, l=0.045e-6)
# Cascoded PMOS load: top load M9 and cascode M10 (Vdd -> M9 -> NODE_C -> M10 -> Vout)
circuit.MOSFET('M9', 'NODE_C', 'Vb_pmos', 'Vdd', 'Vdd',
               model='pmos_model', w=80e-6, l=0.045e-6)
circuit.MOSFET('M10', 'Vout', 'Vb_pcas', 'NODE_C', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Ensure the required node name appears exactly as requested
# Output node is 'Vout' (declared as a net above by use in MOSFETs)
# Inputs 'Vinp' and 'Vinn' are declared by voltage sources above
# Create simulator (do not append any other code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

import numpy as np

# Get the VDD value from the circuit
try:
    dc_value = circuit.element('Vdd').dc_value
    if type(dc_value) == str:
        v_dd_value = float(dc_value.split()[0])
    else:
        v_dd_value = float(dc_value)
except:
    # Try alternative name formats
    try:
        dc_value = circuit.element('VDD').dc_value
        if type(dc_value) == str:
            v_dd_value = float(dc_value.split()[0])
        else:
            v_dd_value = float(dc_value)
    except:
        # Default to 1.2V if VDD cannot be found
        v_dd_value = 1.2

# Define reasonable voltage range for differential amplifier biasing
# Avoid regions too close to rails where transistors might not be in saturation
min_voltage = 0.2
max_voltage = v_dd_value - 0.2  # Avoid saturation region

# Target output voltage is typically VDD/2 for many amplifier circuits
target_vout = v_dd_value / 2

# Save the data to file in two lines
fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_dc.txt", "w")


for element in circuit.elements:
    if element.name == "Vvinn":
        vin_pin_name = element.pins[0].node
# Three-level scanning strategy
# Level 1: Coarse scan across reasonable operating range
coarse_step = (max_voltage - min_voltage) / 20  # Adaptive step size
analysis_coarse = simulator.dc(Vvinn=slice(min_voltage, max_voltage, coarse_step))
out_voltage_coarse = np.array(analysis_coarse.Vout)
in_voltage_coarse = np.array(getattr(analysis_coarse, vin_pin_name))

# Find the approximate best point
best_vin_coarse = v_dd_value / 2  # Initial guess
min_diff_coarse = float('inf')
for i, vout in enumerate(out_voltage_coarse):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_coarse:
        min_diff_coarse = diff
        best_vin_coarse = float(in_voltage_coarse[i])

# Level 2: Medium resolution scan around best point from coarse scan
mid_range = (max_voltage - min_voltage) / 4  # 25% of the range
mid_step = (max_voltage - min_voltage) / 200  # Higher resolution
mid_min = max(min_voltage, best_vin_coarse - mid_range/2)
mid_max = min(max_voltage, best_vin_coarse + mid_range/2)

# get vin pin name



analysis_mid = simulator.dc(Vvinn=slice(mid_min, mid_max, mid_step))
out_voltage_mid = np.array(analysis_mid.Vout)
in_voltage_mid = np.array(getattr(analysis_mid, vin_pin_name))

# Find the best point in medium resolution scan
best_vin_mid = best_vin_coarse
min_diff_mid = float('inf')
for i, vout in enumerate(out_voltage_mid):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_mid:
        min_diff_mid = diff
        best_vin_mid = float(in_voltage_mid[i])

# Level 3: Ultra-high resolution scan around best point from medium scan
fine_range = (max_voltage - min_voltage) / 40  # ~2.5% of the range
fine_step = (max_voltage - min_voltage) / 2000  # Ultra-fine resolution
fine_min = max(min_voltage, best_vin_mid - fine_range/2)
fine_max = min(max_voltage, best_vin_mid + fine_range/2)

analysis_fine = simulator.dc(Vvinn=slice(fine_min, fine_max, fine_step))
out_voltage = np.array(analysis_fine.Vout)
in_voltage = np.array(getattr(analysis_fine, vin_pin_name))

# Print information about the search
print(f"VDD = {v_dd_value:.3f}V, Target Vout = {target_vout:.3f}V")
print(f"Search range: {min_voltage:.3f}V to {max_voltage:.3f}V")
print(f"Coarse scan result: Best Vin ≈ {best_vin_coarse:.6f}V")
print(f"Medium scan result: Best Vin ≈ {best_vin_mid:.6f}V")

# Find best point in fine scan
best_vin_fine = best_vin_mid
best_vout_fine = target_vout
min_diff_fine = float('inf')
for i, vout in enumerate(out_voltage):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_fine:
        min_diff_fine = diff
        best_vin_fine = float(in_voltage[i])
        best_vout_fine = float(vout)

print(f"Fine scan result: Best Vin = {best_vin_fine:.6f}V (Vout ≈ {best_vout_fine:.6f}V)")

# Combine all results for comprehensive data output
all_out_voltage = np.concatenate((out_voltage_coarse, out_voltage_mid, out_voltage))
all_in_voltage = np.concatenate((in_voltage_coarse, in_voltage_mid, in_voltage))

for item in all_in_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
for item in all_out_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
fopen.close()