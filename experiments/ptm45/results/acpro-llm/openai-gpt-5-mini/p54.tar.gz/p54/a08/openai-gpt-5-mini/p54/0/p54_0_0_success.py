from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage OpAmp')
# Define MOS models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('vb_tail', 'Vbias_tail', circuit.gnd, 0.42)  # tail NMOS bias (Vth + ~0.2V)
circuit.V('vb_p', 'Vbias_p', circuit.gnd, 0.78)     # PMOS current-source gate bias
# DC input bias nodes (no AC sources, just DC operating points)
# Choose differential DC bias around mid operating region
circuit.V('inp', 'Vinp', circuit.gnd, 0.60)
circuit.V('inn', 'Vinn', circuit.gnd, 0.58)
# Device sizing (45 nm channel length = 45e-9 m)
L_min = 45e-9
# First stage: NMOS differential pair with NMOS tail current source
# M1: Vin+ transistor
circuit.MOSFET('M1', 'Outp', 'Vinp', 'Ns', 'Ns', model='nmos_model', w=20e-6, l=L_min)
# M2: Vin- transistor
circuit.MOSFET('M2', 'Outm', 'Vinn', 'Ns', 'Ns', model='nmos_model', w=20e-6, l=L_min)
# Mtail: tail current source
circuit.MOSFET('Mtail', 'Ns', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=L_min)
# PMOS differential-to-single-ended mirror load
# M3: diode-connected PMOS on the negative branch (reference)
circuit.MOSFET('M3', 'Outm', 'Outm', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_min)
# M4: PMOS mirror device driving the positive branch (active load)
circuit.MOSFET('M4', 'Outp', 'Outm', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_min)
# Second stage: NMOS common-source amplifier with PMOS current-source load
circuit.MOSFET('M6', 'Vout', 'Outp', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=L_min)
circuit.MOSFET('M7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=L_min)
# The following line creates the simulator object for analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
