```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

def create_circuit(params):
    """
    Create the parameterized PySpice circuit.

    Required: this function name must be exactly `create_circuit`.
    The module `model` providing `nmos_params` and `pmos_params` must exist
    and is imported above (line must be kept exactly as required).
    """
    circuit = Circuit('High-Gain Multi-Stage OpAmp')

    # MOS models (unchanged)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed supply for 45nm process

    # Bias and input sources
    # vb_tail and vb_p are parameterized (subject to constrained search ranges)
    circuit.V('vb_tail', 'Vbias_tail', circuit.gnd, params['vb_tail'])  # tail NMOS bias
    circuit.V('vb_p', 'Vbias_p', circuit.gnd, params['vb_p'])          # PMOS current-source gate bias

    # DC input bias nodes (fixed, not parameterized; they will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.60)   # fixed Vinp
    circuit.V('inn', 'Vinn', circuit.gnd, 0.58)   # fixed Vinn

    # Process length (fixed)
    L = 45e-9

    # First stage: NMOS differential pair with NMOS tail current source
    # M1: Vin+ transistor
    circuit.MOSFET('M1', 'Outp', 'Vinp', 'Ns', 'Ns',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # M2: Vin- transistor
    circuit.MOSFET('M2', 'Outm', 'Vinn', 'Ns', 'Ns',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # Mtail: tail current source
    circuit.MOSFET('Mtail', 'Ns', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)

    # PMOS differential-to-single-ended mirror load
    # M3: diode-connected PMOS on the negative branch (reference)
    circuit.MOSFET('M3', 'Outm', 'Outm', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)

    # M4: PMOS mirror device driving the positive branch (active load)
    circuit.MOSFET('M4', 'Outp', 'Outm', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # Second stage: NMOS common-source amplifier with PMOS current-source load
    circuit.MOSFET('M6', 'Vout', 'Outp', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M6'],
                   l=L)

    circuit.MOSFET('M7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M7'],
                   l=L)

    # No explicit resistors or capacitors were in the original netlist.
    # If you add load caps/resistors later, follow the constraints provided.

    return circuit


# Optimization parameter search ranges
# All widths W are constrained to 1 - 500 × L (L = 45e-9 m) => [45e-9, 22.5e-6] m
# Voltage biases (vb_tail, vb_p) are constrained to 0.8 - 1.2 × original, but never exceed 1.2 V.
# These ranges are conservative and keep bias points above Vth = 0.22 V where appropriate.

param_ranges_definition = {
    # Transistor widths (meters). Use log sampling for widths (wide dynamic range).
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 20e-6
    'w_Mtail': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6 (pmos)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6 (pmos)
    'w_M6': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6
    'w_M7': {'min': 45e-9, 'max': 22.5e-6, 'log': True},  # original 10e-6 (pmos)

    # Voltage bias ranges (linear sampling recommended)
    # vb_tail original = 0.42 V -> [0.8*0.42, 1.2*0.42] = [0.336, 0.504]
    'vb_tail': {'min': max(0.336, 0.0), 'max': min(0.504, 1.2), 'log': False},

    # vb_p original = 0.78 V -> [0.8*0.78, 1.2*0.78] = [0.624, 0.936] (<= 1.2 V)
    'vb_p': {'min': max(0.624, 0.0), 'max': min(0.936, 1.2), 'log': False},
}

# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (exactly as in original code)
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_Mtail': 10e-6,
    'w_M3': 10e-6,
    'w_M4': 10e-6,
    'w_M6': 10e-6,
    'w_M7': 10e-6,

    # Voltages (exact original)
    'vb_tail': 0.42,
    'vb_p': 0.78,
}

# Physical meaning of each parameter (brief)
param_descriptions = {
    'w_M1': "Channel width (W) of input NMOS transistor M1 (Vinp -> Outp). L fixed at 45 nm.",
    'w_M2': "Channel width (W) of input NMOS transistor M2 (Vinn -> Outm). L fixed at 45 nm.",
    'w_Mtail': "Channel width (W) of the tail NMOS current source (Mtail).",
    'w_M3': "Channel width (W) of diode-connected PMOS (M3) in the mirror load (Outm).",
    'w_M4': "Channel width (W) of PMOS mirror device (M4) driving Outp.",
    'w_M6': "Channel width (W) of second-stage NMOS common-source transistor (M6).",
    'w_M7': "Channel width (W) of second-stage PMOS current-source load (M7).",
    'vb_tail': "Gate bias voltage for tail NMOS (Vbias_tail). Must remain ≤ Vdd and is constrained to 0.8–1.2× original.",
    'vb_p': "Gate bias voltage for PMOS current-source (Vbias_p). Must remain ≤ Vdd and is constrained to 0.8–1.2× original.",
}

# Notes:
# - vdd (1.2 V) and input voltages (Vinp=0.60 V, Vinn=0.58 V) remain fixed and are NOT part of the search.
# - L is fixed at 45e-9 m (45 nm); only W is varied because W/L governs device behavior for this optimization.
# - No resistors or capacitors were present in the original netlist. If you add them later,
#   follow the provided multiplicative constraints (resistors 0.5-2×, critical caps 0.5-5×, others 0.8-1.5×).
# - All bias lower bounds were chosen to remain above the MOSFET threshold Vth = 0.22 V (as requested),
#   ensuring devices remain biased in reasonable operating regions.
```

