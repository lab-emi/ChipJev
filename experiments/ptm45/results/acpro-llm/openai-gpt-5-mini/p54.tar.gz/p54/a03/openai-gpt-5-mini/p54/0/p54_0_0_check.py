from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage OpAmp')
# Define transistor models (assumed parameters are provided in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
# Bias voltages chosen using Vth = 0.22 V
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78)   # PMOS gate bias (Vdd - Vth - 0.2)
circuit.V('biasn', 'Vbiasn', circuit.gnd, 0.42)   # NMOS tail bias (Vth + 0.2)
# Technology sizing (45 nm)
L = 45e-9  # 45 nm
# First stage: NMOS differential pair with PMOS current-mirror active load
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbiasn', circuit.gnd, circuit.gnd,
               model='nmos_model', w=1e-6, l=L)
# Differential pair
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss',
               model='nmos_model', w=2e-6, l=L)
circuit.MOSFET('M2', 'D2', 'Vinn', 'Iss', 'Iss',
               model='nmos_model', w=2e-6, l=L)
# PMOS current mirror load: P3 diode-connected on D2, P4 mirrors to D1
circuit.MOSFET('P3', 'D2', 'D2', 'Vdd', 'Vdd',
               model='pmos_model', w=4e-6, l=L)   # diode-connected
circuit.MOSFET('P4', 'D1', 'D2', 'Vdd', 'Vdd',
               model='pmos_model', w=4e-6, l=L)   # mirror device (gate tied to D2)
# Second stage: NMOS common-source amplifier with PMOS active load
circuit.MOSFET('M6', 'Vout', 'D1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=L)
circuit.MOSFET('P7', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=L)
# Create simulator (user requested to stop after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)