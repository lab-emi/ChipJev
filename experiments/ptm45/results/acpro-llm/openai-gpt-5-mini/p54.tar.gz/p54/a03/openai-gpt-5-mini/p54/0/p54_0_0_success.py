from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-Gain Multi-Stage OpAmp')
# Define transistor models (assumed parameters are provided in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # DC bias for positive input node
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # DC bias for negative input node
# Bias voltages chosen using Vth = 0.22 V
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78)   # PMOS gate bias (Vdd - Vth - 0.2)
circuit.V('biasn', 'Vbiasn', circuit.gnd, 0.42)   # NMOS tail bias (Vth + 0.2)
# Technology sizing (45 nm)
L = 45e-9  # 45 nm
# First stage: NMOS differential pair with PMOS current-mirror active load
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbiasn', circuit.gnd, circuit.gnd,
               model='nmos_model', w=1e-6, l=L)
# Differential pair
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss',
               model='nmos_model', w=2e-6, l=L)
circuit.MOSFET('M2', 'D2', 'Vinn', 'Iss', 'Iss',
               model='nmos_model', w=2e-6, l=L)
# PMOS current mirror load: P3 diode-connected on D2, P4 mirrors to D1
circuit.MOSFET('P3', 'D2', 'D2', 'Vdd', 'Vdd',
               model='pmos_model', w=4e-6, l=L)   # diode-connected
circuit.MOSFET('P4', 'D1', 'D2', 'Vdd', 'Vdd',
               model='pmos_model', w=4e-6, l=L)   # mirror device (gate tied to D2)
# Second stage: NMOS common-source amplifier with PMOS active load
circuit.MOSFET('M6', 'Vout', 'D1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=L)
circuit.MOSFET('P7', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=L)
# Create simulator (user requested to stop after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p54/0/p54_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
