```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: per requirements, the model import must appear exactly as written inside create_circuit

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Two-Stage Differential Op-Amp for Max GBW - Parameterized')

    # MOS models (provided externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # -----------------------
    # Power and bias supplies
    # -----------------------
    # Vdd is fixed and must remain 1.2V (not part of optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V

    # Input voltages are fixed (will be swept externally during DC analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # DC input Vinp (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # DC input Vinn (fixed)

    # Tail and PMOS bias are parameterized (searchable)
    # Ensure values passed in params are in volts (float)
    circuit.V('tail', 'Vtail', circuit.gnd, params['V_tail'])     # Tail bias (parameter)
    circuit.V('pbias', 'VbiasP', circuit.gnd, params['V_biasP'])  # PMOS bias (parameter)

    # -----------------------
    # Device geometry
    # -----------------------
    # Keep channel length fixed for technology (45 nm)
    L = 45e-9

    # First stage: NMOS differential pair with PMOS active mirror load
    circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'S', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)

    # PMOS active mirror load:
    # M3 diode-connected: drain=gate=D1; source=Vdd; bulk=Vdd
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # M4 mirror transistor: drain=D2; gate=D1; source=Vdd; bulk=Vdd
    circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # -----------------------
    # Second stage: NMOS common-source with PMOS current-source load
    # -----------------------
    circuit.MOSFET('M5', 'Vout', 'D2', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    circuit.MOSFET('M6', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L)

    # -----------------------
    # Compensation capacitor (Miller cap)
    # -----------------------
    # Ccomp is parameterized (critical compensation capacitor)
    # Value is in Farads (float)
    circuit.C('Ccomp', 'D2', 'Vout', params['c_Ccomp'])  # Miller cap (parameterized)

    return circuit


# -----------------------
# Optimization parameter search ranges (for Optuna or similar)
# -----------------------
# Notes on ranges:
# - Transistor width (W) bounds follow 1×L to 500×L where L = 45e-9 -> [45e-9, 22.5e-6]
# - All voltage parameters (except Vdd, Vinp, Vinn) use 0.8–1.2× original values but never exceed 1.2 V
# - Compensation capacitor uses 0.5–5× its original value
# - Use log sampling for geometric quantities (W, C) where sensible
L = 45e-9
param_ranges_definition = {
    # Transistor widths (meters) - sampling recommended on log scale
    'w_M1': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},   # M1 original 6e-6
    'w_M2': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},   # M2 original 6e-6
    'w_Mtail': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},# Mtail original 4e-6
    'w_M3': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},   # M3 original 10e-6
    'w_M4': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},   # M4 original 10e-6
    'w_M5': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},   # M5 original 10e-6
    'w_M6': {'min': 1.0 * L, 'max': 500.0 * L, 'log': True},   # M6 original 20e-6

    # Bias voltages (volts) - constrained to 0.8-1.2× original (and <= 1.2 V)
    # Original V_tail = 0.42 V -> [0.8*0.42, 1.2*0.42] = [0.336, 0.504]
    'V_tail': {'min': 0.8 * 0.42, 'max': 1.2 * 0.42, 'log': False},

    # Original VbiasP = 0.78 V -> [0.8*0.78, 1.2*0.78] = [0.624, 0.936]
    # Also ensured <= 1.2 V (0.936 < 1.2)
    'V_biasP': {'min': 0.8 * 0.78, 'max': 1.2 * 0.78, 'log': False},

    # Compensation capacitor (Farads) - critical comp cap: 0.5–5× original
    # Original c_Ccomp = 2e-15 F -> [1e-15, 1e-14]
    'c_Ccomp': {'min': 0.5 * 2e-15, 'max': 5.0 * 2e-15, 'log': True},
}

# -----------------------
# Initial parameter values (EXACT original circuit values) - MUST match the original netlist
# -----------------------
# These are the starting points for optimization and MUST lie within the ranges above.
initial_params = {
    # Transistor widths (exact original values from your netlist)
    'w_M1': 6e-6,     # Original M1 width
    'w_M2': 6e-6,     # Original M2 width
    'w_Mtail': 4e-6,  # Original Mtail width
    'w_M3': 10e-6,    # Original M3 width
    'w_M4': 10e-6,    # Original M4 width
    'w_M5': 10e-6,    # Original M5 width
    'w_M6': 20e-6,    # Original M6 width

    # Voltages (exact original values)
    'V_tail': 0.42,   # Original tail bias
    'V_biasP': 0.78,  # Original PMOS bias

    # Compensation capacitor (exact original value)
    'c_Ccomp': 2e-15, # Original Miller cap (2 fF)
}

# -----------------------
# Parameter descriptions (brief)
# -----------------------
parameter_descriptions = {
    'w_M1':   "Width of input NMOS M1 (left differential transistor). Controls drive current, gm, input pair transconductance.",
    'w_M2':   "Width of input NMOS M2 (right differential transistor).",
    'w_Mtail':"Width of tail NMOS current source Mtail. Affects tail current and headroom.",
    'w_M3':   "Width of diode-connected PMOS M3 (mirror reference transistor). Sets mirror bias current and output resistance.",
    'w_M4':   "Width of mirrored PMOS M4 (active load). Works with M3 to set load current and output resistance.",
    'w_M5':   "Width of second-stage NMOS M5 (gain transistor). Affects gain and output stage bandwidth.",
    'w_M6':   "Width of PMOS load M6 (second-stage current source). Sets load current for the second stage.",
    'V_tail': "Tail bias voltage applied to tail NMOS gate (sets tail current). Search range limited to 0.8–1.2× original and <= 1.2 V.",
    'V_biasP':"PMOS bias voltage (gate of M6) that programs the PMOS load current. Search range limited to 0.8–1.2× original and <= 1.2 V.",
    'c_Ccomp':"Compensation (Miller) capacitor between first/second stage (D2 <-> Vout). Critical for stability and GBW tuning.",
}

# End of parameterized circuit module
```