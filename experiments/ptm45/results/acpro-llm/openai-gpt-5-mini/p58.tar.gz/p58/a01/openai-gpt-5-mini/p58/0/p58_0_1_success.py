from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # required import (kept as requested)
circuit = Circuit('Two-Stage Differential Op-Amp for Max GBW - Corrected')
# MOS models (provided externally via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# -----------------------
# Power and bias supplies
# -----------------------
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # DC input Vinp (operating point)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # DC input Vinn (operating point)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)     # Tail bias (Vth + 0.2) = 0.42 V
circuit.V('pbias', 'VbiasP', circuit.gnd, 0.78)   # PMOS bias Vdd - (Vth + 0.2) = 0.78 V
# Node naming note:
# - 'D1' : drain of M1 and diode-connected PMOS gate/drain (mirror bias node)
# - 'D2' : drain of M2 -> single-ended intermediate node (drives 2nd stage)
# - 'S'  : common source node (connected to tail current source)
# -----------------------
# First stage: NMOS diff pair with PMOS mirror load
# -----------------------
# M1 and M2: input NMOS pair
# MOSFET signature: circuit.MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S', model='nmos_model', w=6e-6, l=45e-9)
circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S', model='nmos_model', w=6e-6, l=45e-9)
# Tail current source (NMOS)
# Ensure bulk tied to source (ground)
circuit.MOSFET('Mtail', 'S', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=45e-9)
# PMOS active mirror load:
# - M3 is diode-connected: drain = gate = D1; source = Vdd; bulk = Vdd (bulk tied to source)
# - M4 is mirror transistor: drain = D2; gate = D1; source = Vdd; bulk = Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=45e-9)
circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=45e-9)
# -----------------------
# Second stage: NMOS common-source with PMOS current-source load
# -----------------------
# M5: second-stage NMOS amplifier; bulk tied to source (ground)
circuit.MOSFET('M5', 'Vout', 'D2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=45e-9)
# M6: PMOS load current source; gate tied to external bias VbiasP; bulk tied to source Vdd
circuit.MOSFET('M6', 'Vout', 'VbiasP', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)
# -----------------------
# Compensation capacitor (Miller cap)
# -----------------------
# MODIFICATION 1 (fix): Use an explicit SI value for the capacitor rather than an undefined unit alias.
# - Previously used "2@u_f" which caused NameError: u_f undefined.
# - Here we use 2e-15 (2 fF) to avoid reliance on unit aliases that may not exist in the environment.
#
# Note: Using a plain float (in Farads) is robust and accepted by PySpice.
circuit.C('Ccomp', 'D2', 'Vout', 2e-15)  # 2 fF Miller cap (explicit SI value used to avoid undefined u_f)
# End with simulator creation (no additional code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
