from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Differential Op-Amp for Max GBW')
# MOS models (provided externally via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # DC input Vinp (operating point)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # DC input Vinn (operating point)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)     # Tail bias (Vth + 0.2) = 0.42 V
circuit.V('pbias', 'VbiasP', circuit.gnd, 0.78)   # PMOS bias Vdd - (Vth + 0.2) = 0.78 V
# Node names:
# - D1: drain of M1 (diode-connected PMOS ties to this node to form mirror)
# - D2: drain of M2 -> intermediate single-ended node (drives 2nd stage)
# - S : common source node of input pair (drain of tail current source)
# First stage: differential pair (NMOS) with PMOS mirror active load
circuit.MOSFET('M1', 'D1', 'Vinp', 'S', 'S', model='nmos_model', w=6e-6, l=45e-9)
circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S', model='nmos_model', w=6e-6, l=45e-9)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'S', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=45e-9)
# PMOS active mirror load for differential pair
# M3 is diode-connected to bias the mirror (drain=gate=D1)
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=45e-9)
# M4 is the mirror device (gate tied to D1)
circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=45e-9)
# Second stage: NMOS common-source with PMOS current-source load
circuit.MOSFET('M5', 'Vout', 'D2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=45e-9)
circuit.MOSFET('M6', 'Vout', 'VbiasP', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)
# Miller (compensation) capacitor between first-stage output (D2) and Vout
circuit.C('ccomp', 'D2', 'Vout', 2@u_f)  # 2 fF Miller cap (adjustable)
# End with simulator creation (no additional code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
