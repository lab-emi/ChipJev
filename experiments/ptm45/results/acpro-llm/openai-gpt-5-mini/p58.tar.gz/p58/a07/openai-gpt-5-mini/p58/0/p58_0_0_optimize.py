from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import must appear inside create_circuit as required by the framework
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('High-GBW Two-Stage OpAmp')
    # MOS models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supplies and DC biases
    # Vdd is fixed (do not parameterize)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V (fixed)
    # Input voltages are fixed (will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp DC common-mode (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn DC common-mode (fixed)
    # Other bias voltages are parameterized (but constrained <= 1.2 V)
    circuit.V('vbp', 'Vbias_p', circuit.gnd, params['v_vbp'])   # PMOS bias (parameter)
    circuit.V('vbn', 'Vbias_n', circuit.gnd, params['v_vbn'])   # NMOS tail gate bias (parameter)
    # Process length (fixed for this technology)
    L = 0.045e-6  # 45 nm (fixed)
    # First stage - differential pair (NMOS) with PMOS current mirror load
    circuit.MOSFET('M1', 'Vx', 'Vinp', 'Vtail', 'Vtail',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Vtail', 'Vtail',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('Mtail', 'Vtail', 'Vbias_n', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)
    # PMOS mirror load: diode-connected reference and mirror transistor
    circuit.MOSFET('M3', 'Vx', 'Vx', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)   # diode-connected PMOS (gate tied to drain)
    circuit.MOSFET('M4', 'Vmid', 'Vx', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)  # mirror PMOS
    # Second stage - common-source NMOS with PMOS current source load
    circuit.MOSFET('M5', 'Vout', 'Vmid', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)  # 2nd stage NMOS
    circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M6'],
                   l=L)           # PMOS load for 2nd stage
    # Miller compensation capacitor (parameterized)
    circuit.C('ccomp', 'Vmid', 'Vout', params['c_ccomp'])  # Farads
    # Note: optional output load (C_load/R_load) is intentionally NOT included here
    # as per instructions (load caps remain fixed externally and are not part of the search).
    return circuit
# ----------------------------
# Parameter search ranges
# ----------------------------
# L = 45e-9 (fixed). By design transistor behavior depends on W/L; L is fixed and W is optimized.
L = 0.045e-6
# Constraint: W in [1*L, 500*L]. The original netlist uses some widths > 500*L (e.g. 50e-6).
# To satisfy both the "1-500×L" guidance and the requirement that initial parameters
# remain inside the search ranges, upper bounds below are set to max(500*L, original_W)
# so the initial/original point is always inside the range. If you want a strict 500×L
# upper bound, set the corresponding 'max' to 500*L (22.5e-6) and adjust initial params accordingly.
param_ranges_definition = {
    # Transistor widths (meters). Log-scale search recommended for device widths.
    'w_M1': {'min': 1 * L, 'max': max(500 * L, 50e-6), 'log': True},   # M1 original 50e-6
    'w_M2': {'min': 1 * L, 'max': max(500 * L, 50e-6), 'log': True},   # M2 original 50e-6
    'w_Mtail': {'min': 1 * L, 'max': max(500 * L, 5e-6), 'log': True}, # Mtail original 5e-6
    'w_M3': {'min': 1 * L, 'max': max(500 * L, 12e-6), 'log': True},   # M3 (PMOS diode) original 12e-6
    'w_M4': {'min': 1 * L, 'max': max(500 * L, 12e-6), 'log': True},   # M4 (PMOS mirror) original 12e-6
    'w_M5': {'min': 1 * L, 'max': max(500 * L, 20e-6), 'log': True},   # M5 second stage original 20e-6
    'w_M6': {'min': 1 * L, 'max': max(500 * L, 12e-6), 'log': True},   # M6 PMOS load original 12e-6
    # Bias voltages (Volts). Range: 0.8-1.2× original, but never exceed 1.2 V (supply).
    # Conservative ranges to avoid driving transistors into wrong region. Vth = 0.22V considered.
    'v_vbp': {'min': max(0.0, 0.8 * 0.78), 'max': min(1.2, 1.2 * 0.78), 'log': False},  # PMOS bias
    'v_vbn': {'min': max(0.0, 0.8 * 0.47), 'max': min(1.2, 1.2 * 0.47), 'log': False},  # NMOS tail gate bias
    # Compensation capacitor (Farads). Critical compensation cap: 0.5 - 5× original
    'c_ccomp': {'min': 0.5 * 5e-15, 'max': 5.0 * 5e-15, 'log': True},
}
# ----------------------------
# Initial parameter values (EXACT original values)
# These values must be preserved exactly as the starting point for optimization.
# ----------------------------
initial_params = {
    # Transistor widths (meters) - EXACT original values from the provided netlist
    'w_M1': 50e-6,    # original M1 width
    'w_M2': 50e-6,    # original M2 width
    'w_Mtail': 5e-6,  # original Mtail width
    'w_M3': 12e-6,    # original M3 width
    'w_M4': 12e-6,    # original M4 width
    'w_M5': 20e-6,    # original M5 width
    'w_M6': 12e-6,    # original M6 width
    # Bias voltages (Volts) - EXACT original values
    'v_vbp': 0.78,    # original Vbias_p
    'v_vbn': 0.47,    # original Vbias_n
    # Compensation capacitor (Farads) - EXACT original value
    'c_ccomp': 5e-15,  # original Miller capacitor (5 fF)
}
# Sanity check note:
# All initial_params above are guaranteed to be inside the numeric ranges specified in
# param_ranges_definition (the widths upper bounds were extended to include the original
# widths where necessary). If you prefer strictly enforcing the 500×L upper bound for W,
# reduce the corresponding 'max' entries to 500 * L (22.5e-6) and update initial_params
# accordingly before running the optimizer.
