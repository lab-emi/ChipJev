from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-GBW Two-Stage OpAmp')
# MOS models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp DC common-mode
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn DC common-mode
circuit.V('vbp', 'Vbias_p', circuit.gnd, 0.78)   # PMOS bias (Vdd - |Vth| - 0.2)
circuit.V('vbn', 'Vbias_n', circuit.gnd, 0.47)   # NMOS tail gate bias (Vth + ~0.25)
# Node names:
# Vx  - drain of M1 (diode-connected PMOS ties here)
# Vmid - single-ended node after differential pair (input to 2nd stage)
# Vtail - source node of input pair (drain of tail current source)
# Vout - final output node
# Transistor dimensions (45 nm technology)
L = 0.045e-6  # 45 nm
# First stage - differential pair (NMOS) with PMOS current mirror load
circuit.MOSFET('M1', 'Vx', 'Vinp', 'Vtail', 'Vtail', model='nmos_model', w=50e-6, l=L)
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Vtail', 'Vtail', model='nmos_model', w=50e-6, l=L)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Vtail', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=L)
# PMOS mirror load: diode-connected reference and mirror transistor
circuit.MOSFET('M3', 'Vx', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)   # diode-connected PMOS (gate tied to drain)
circuit.MOSFET('M4', 'Vmid', 'Vx', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)  # mirror PMOS
# Second stage - common-source NMOS with PMOS current source load
circuit.MOSFET('M5', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=L)  # 2nd stage NMOS
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=12e-6, l=L)           # PMOS load for 2nd stage
# Miller compensation capacitor between Vmid and Vout
circuit.C('ccomp', 'Vmid', 'Vout', 5e-15)  # 5 fF Miller capacitor (adjustable)
# (Optional) output load capacitor or resistor can be added externally if needed.
# Ensure nodes Vinp, Vinn, and Vout appear in the netlist as required.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
