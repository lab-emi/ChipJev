from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('High-GBW Two-Stage OpAmp')
    # MOSFET models (assumed defined in model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V (fixed)
    # Input voltage sources (fixed, not parameterized; will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp: common-mode input (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn: common-mode input (fixed)
    # Parameterized bias voltages (constrained to <= 1.2 V in param ranges)
    circuit.V('biasp', 'Vbiasp', circuit.gnd, params['v_biasp'])  # PMOS bias
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])     # NMOS tail bias
    # Technology length (fixed, do not include in search)
    L = 0.045e-6  # 45 nm (fixed)
    # Differential pair (NMOS)
    # M1: left input transistor
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Tail', 'Tail',
                   model='nmos_model', w=params['w_M1'], l=L)
    # M2: right input transistor
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Tail', 'Tail',
                   model='nmos_model', w=params['w_M2'], l=L)
    # PMOS active load (current mirror)
    # M3: diode-connected PMOS on left branch (reference)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=L)
    # M4: mirror PMOS on right branch (provides single-ended output at D2)
    circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L)
    # Tail current source (NMOS)
    circuit.MOSFET('M5', 'Tail', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=L)
    # Second-stage common-source amplifier (NMOS) with PMOS current-source load
    circuit.MOSFET('M6', 'Vout', 'D2', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M6'], l=L)
    circuit.MOSFET('M7', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M7'], l=L)
    # No load capacitors in the original netlist; keep none parameterized.
    return circuit
# ---------------------------------------------------------------------------
# Optimization parameter search ranges (param_ranges_definition)
# - Widths: min = 1 * L (45 nm), max = max(500*L, original_value) to ensure
#   the original (user-provided) widths remain inside the search range.
#   (Note: a few original W values exceed 500*L; upper bound is relaxed
#   to include the exact original values as required.)
# - Voltages (except Vdd and Vinp/Vinn): 0.8 - 1.2 × original, but never >1.2 V.
# - All voltage ranges are linear; widths use log sampling to cover orders of magnitude.
# ---------------------------------------------------------------------------
L = 0.045e-6  # 45 nm (used to compute 1-500× ranges)
_max_w_recommended = 500 * L  # 22.5e-6 (22.5 µm)
param_ranges_definition = {
    # Transistor widths (meters). Min = L, Max = max(500*L, original) to include original.
    'w_M1': {'min': L, 'max': max(_max_w_recommended, 20e-6), 'log': True},  # M1 original: 20e-6
    'w_M2': {'min': L, 'max': max(_max_w_recommended, 20e-6), 'log': True},  # M2 original: 20e-6
    # Original M3/M4/M7 are 40e-6 (>> 500*L). To satisfy the "initial_params must be inside ranges"
    # we relax the strict 500× rule by setting the upper bound to include the original 40e-6.
    'w_M3': {'min': L, 'max': max(_max_w_recommended, 40e-6), 'log': True},  # M3 original: 40e-6
    'w_M4': {'min': L, 'max': max(_max_w_recommended, 40e-6), 'log': True},  # M4 original: 40e-6
    'w_M5': {'min': L, 'max': max(_max_w_recommended, 5e-6),  'log': True},  # M5 original: 5e-6
    'w_M6': {'min': L, 'max': max(_max_w_recommended, 20e-6), 'log': True},  # M6 original: 20e-6
    'w_M7': {'min': L, 'max': max(_max_w_recommended, 40e-6), 'log': True},  # M7 original: 40e-6
    # Bias voltages (Volts) - 0.8x to 1.2x original, capped at 1.2 V (supply).
    # Consider Vth = 0.22 V when picking these conservative shifts (we keep close to original).
    'v_biasp': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},  # original 0.78 V
    'v_tail' : {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},  # original 0.42 V
}
# Initial parameter values (EXACT original circuit values)
# IMPORTANT: These are the exact original numeric values found in your netlist.
initial_params = {
    # Widths (meters) - EXACT original values
    'w_M1': 20e-6,   # original M1 width
    'w_M2': 20e-6,   # original M2 width
    'w_M3': 40e-6,   # original M3 width
    'w_M4': 40e-6,   # original M4 width
    'w_M5': 5e-6,    # original M5 width
    'w_M6': 20e-6,   # original M6 width
    'w_M7': 40e-6,   # original M7 width
    # Length is fixed in the circuit, not part of optimization, but listed here for clarity
    # (Do NOT include length in optimization; l is fixed at 0.045e-6 in create_circuit.)
    'l_fixed': 0.045e-6,  # 45 nm (fixed)
    # Voltages (Volts) - EXACT original values for the parameterized biases
    'v_biasp': 0.78,  # original PMOS bias
    'v_tail' : 0.42,  # original NMOS tail bias
}
# Sanity check notes (for the user / optimizer):
# - Vdd is fixed at 1.2 V and Vinp/Vinn are fixed at 0.6 V (these are not included in the search).
# - All parameterized voltages are constrained <= 1.2 V by the ranges above.
# - Width ranges are chosen to respect the 1-500×L guideline where possible; for devices whose
#   original sizes exceed 500×L, the upper bound was relaxed so the exact original values
#   are inside the search space (this preserves your requirement that initial_params be exact).
# - There are no resistors or capacitors in the original netlist. If you add them later,
#   apply the requested multiplier ranges (resistors 0.5-2×, comp caps 0.5-5×, other caps 0.8-1.5×).
