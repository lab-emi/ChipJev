from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-GBW Two-Stage OpAmp')
# MOSFET models (assumed defined in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp DC (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn DC (common-mode)
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78)  # PMOS bias (Vdd - |Vth| - 0.2)
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)    # NMOS tail bias (Vth + 0.2)
# Node names used: D1, D2, Tail, Vout
# Differential pair (NMOS)
# M1: left input transistor
circuit.MOSFET('M1', 'D1', 'Vinp', 'Tail', 'Tail', model='nmos_model', w=20e-6, l=0.045e-6)
# M2: right input transistor
circuit.MOSFET('M2', 'D2', 'Vinn', 'Tail', 'Tail', model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS active load (current mirror)
# M3: diode-connected PMOS on left branch (reference)
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# M4: mirror PMOS on right branch (provides single-ended output at D2)
circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('M5', 'Tail', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second-stage common-source amplifier (NMOS) with PMOS current-source load
circuit.MOSFET('M6', 'Vout', 'D2', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M7', 'Vout', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Create simulator (stop here as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
