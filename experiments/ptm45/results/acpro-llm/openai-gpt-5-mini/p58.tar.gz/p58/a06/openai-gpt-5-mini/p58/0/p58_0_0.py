from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage OpAmp for GBW')
# Define MOS models (provided by the external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                  # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)                # input positive DC common-mode
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)                # input negative DC common-mode
circuit.V('vb_tail', 'Vbias_tail', circuit.gnd, 0.52)     # tail bias (Vth + 0.30) = 0.52 V
circuit.V('vb_p', 'Vbias_p', circuit.gnd, 0.68)           # PMOS bias (Vdd - (|Vth| + 0.30)) = 0.68 V
# Node naming:
# Iss  - common source of input pair and drain of tail current source
# D1   - drain of M1 and diode-connected PMOS M3
# Vmid - drain of M2 and gate of second stage (single-ended internal node)
# Vout_int - drain of second stage (internal high-impedance node)
# Vout - external output (source follower output)
# First stage: NMOS differential pair
# M1: drain D1, gate Vinp, source Iss, bulk tied to Iss
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=8e-6, l=45e-9)
# M2: drain Vmid, gate Vinn, source Iss, bulk tied to Iss
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=8e-6, l=45e-9)
# Tail current source M5 (NMOS): drain Iss, gate Vbias_tail, source GND, bulk GND
circuit.MOSFET('M5', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=45e-9)
# PMOS active load / current mirror for differential pair
# M3: diode-connected PMOS on D1 (drain=gate=D1), source = Vdd, bulk = Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)
# M4: mirror PMOS on Vmid, gate tied to D1, source = Vdd, bulk = Vdd
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)
# Second stage: NMOS common-source amplifier
# M6: NMOS gain transistor. drain = Vout_int, gate = Vmid, source = GND, bulk = GND
circuit.MOSFET('M6', 'Vout_int', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=12e-6, l=45e-9)
# M7: PMOS active load for second stage, source = Vdd, gate = Vbias_p, drain = Vout_int, bulk = Vdd
circuit.MOSFET('M7', 'Vout_int', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=45e-9)
# Output buffer: NMOS source follower
# M8: drain = Vdd, gate = Vout_int, source = Vout, bulk = Vout (bulk tied to source as required)
circuit.MOSFET('M8', 'Vdd', 'Vout_int', 'Vout', 'Vout', model='nmos_model', w=12e-6, l=45e-9)
# The external nodes appear as required: Vinp, Vinn, Vout.
# Create simulator (no AC sources used; operating point / transient or small-signal analysis can be performed afterwards)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
