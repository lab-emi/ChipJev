from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage OpAmp for GBW (fixed output stage)')
# Define MOS models (provided by the external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                  # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('vb_tail', 'Vbias_tail', circuit.gnd, 0.52)     # tail bias (Vth + 0.30) = 0.52 V
circuit.V('vb_p', 'Vbias_p', circuit.gnd, 0.68)           # PMOS bias (Vdd - (|Vth| + 0.30)) = 0.68 V
# Node naming:
# Iss  - common source of input pair and drain of tail current source
# D1   - drain of M1 and diode-connected PMOS M3
# Vmid - drain of M2 and gate of second stage (single-ended internal node)
# Vout_int - drain of second stage (internal high-impedance node)
# Vout - external output (drain of output NMOS)
# First stage: NMOS differential pair
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=8e-6, l=45e-9)
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=8e-6, l=45e-9)
# Tail current source M5 (NMOS): drain Iss, gate Vbias_tail, source GND, bulk GND
circuit.MOSFET('M5', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=45e-9)
# PMOS active load / current mirror for differential pair
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)  # diode-connected
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)  # mirror
# Second stage: NMOS common-source amplifier
circuit.MOSFET('M6', 'Vout_int', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=12e-6, l=45e-9)
circuit.MOSFET('M7', 'Vout_int', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=25e-6, l=45e-9)
# Output stage: NMOS common-source output device
# M8: drain = Vout (external), gate = Vout_int, source = GND, bulk = GND
circuit.MOSFET('M8', 'Vout', 'Vout_int', circuit.gnd, circuit.gnd, model='nmos_model', w=12e-6, l=45e-9)
# Pull-up resistor from Vdd to Vout (load) to define operating point and allow M8 to pull node down
circuit.R('out_load', 'Vout', 'Vdd', 10@u_kΩ)
# The external nodes appear as required: Vinp, Vinn, Vout.
# Create simulator (no AC sources used; operating point / transient or small-signal analysis can be performed afterwards)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)