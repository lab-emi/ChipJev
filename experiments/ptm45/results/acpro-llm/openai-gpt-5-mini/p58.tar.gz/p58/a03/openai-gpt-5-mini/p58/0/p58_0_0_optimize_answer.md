```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Two-Stage Differential Opamp - GBW Optimized')

    # MOS models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and DC bias sources
    # Vdd is fixed per requirement (do NOT include in optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                      # Vdd = 1.2 V

    # Input common-mode voltages are fixed and will be swept externally (do NOT include in optimization)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)                   # input common-mode DC (no AC)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)                   # input common-mode DC (no AC)

    # Parameterized bias voltages (subject to optimization, but always <= 1.2 V)
    circuit.V('btail', 'Vbias_tail', circuit.gnd, params['Vbias_tail'])   # tail bias for NMOS current source
    circuit.V('bp', 'Vbias_p', circuit.gnd, params['Vbias_p'])           # PMOS gate bias for second-stage load

    # Nodes:
    # SS - common source node for differential pair
    # Vd_p - drain & gate of diode-connected PMOS (left branch)
    # Vout_int - single-ended internal node after first stage (right branch)
    # Vout - final output node

    # Technology length is fixed (only W is optimized)
    Lch = 0.045e-6  # 45 nm (fixed)

    # First stage: Differential NMOS pair with PMOS current-mirror load
    circuit.MOSFET('M1', 'Vd_p', 'Vinp', 'SS', circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=Lch)
    circuit.MOSFET('M2', 'Vout_int', 'Vinn', 'SS', circuit.gnd,
                   model='nmos_model', w=params['w_M2'], l=Lch)

    # PMOS active load: M3 diode-connected, M4 mirror
    circuit.MOSFET('M3', 'Vd_p', 'Vd_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M3'], l=Lch)  # diode-connected
    circuit.MOSFET('M4', 'Vout_int', 'Vd_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=Lch)  # mirror

    # Tail current source (NMOS)
    circuit.MOSFET('M7', 'SS', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M7'], l=Lch)

    # Second stage: NMOS common-source with PMOS current-source load
    circuit.MOSFET('M5', 'Vout', 'Vout_int', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M5'], l=Lch)
    circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M6'], l=Lch)

    # Miller compensation capacitor between Vout_int and Vout (parameterized)
    circuit.C('ccomp', 'Vout_int', 'Vout', params['c_ccomp'])  # Farads

    # (Optional) small output load capacitance to emulate load (kept fixed if present)
    # Example (kept fixed/not optimized per instructions):
    # circuit.C('cload', 'Vout', circuit.gnd, 5e-15)  # 5 fF (fixed)

    return circuit


# ---------------------------
# Optimization parameter search ranges
# ---------------------------
# Notes on constraints applied when forming ranges:
# - L is fixed at 45 nm (Lch = 0.045e-6). Only W is optimized.
# - Recommended transistor width bounds: 1×L to 500×L. To preserve the exact original
#   initial values (as required), if an original W exceeds 500×L we extend the upper bound
#   to include that original value. (This is annotated per-device below.)
# - Vbias values use 0.8–1.2× the original values but are clipped not to exceed 1.2 V.
# - ccomp (critical compensation capacitor) uses 0.5–5× the original value.
# - All initial parameter values below are EXACT original values from the provided netlist.

# Technology length
_Lch = 0.045e-6  # 45 nm
_W_min = 1.0 * _Lch
_W_max_500x = 500.0 * _Lch  # 500 * L

param_ranges_definition = {
    # Transistor widths (meters). Use log-uniform search recommended for device widths.
    'w_M1': {'min': _W_min, 'max': max(_W_max_500x, 20e-6), 'log': True},  # original 20e-6
    'w_M2': {'min': _W_min, 'max': max(_W_max_500x, 20e-6), 'log': True},  # original 20e-6
    # Note: original M3/M4 widths are 40e-6 which exceed 500×L (22.5e-6). To keep the
    # initial parameters exact (per requirement) we set the upper bound to original value.
    'w_M3': {'min': _W_min, 'max': max(_W_max_500x, 40e-6), 'log': True},  # original 40e-6
    'w_M4': {'min': _W_min, 'max': max(_W_max_500x, 40e-6), 'log': True},  # original 40e-6
    'w_M7': {'min': _W_min, 'max': max(_W_max_500x, 4e-6),  'log': True},  # original 4e-6
    'w_M5': {'min': _W_min, 'max': max(_W_max_500x, 10e-6), 'log': True},  # original 10e-6
    'w_M6': {'min': _W_min, 'max': max(_W_max_500x, 20e-6), 'log': True},  # original 20e-6

    # Bias voltages: 0.8-1.2× original, but never > 1.2 V (supply). Use linear search.
    # Also ensure conservative bounds with respect to Vth (Vth=0.22V) — these bounds are well above Vth.
    'Vbias_tail': {'min': 0.8 * 0.60, 'max': min(1.2 * 0.60, 1.2), 'log': False},  # original 0.60 V
    'Vbias_p':    {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},  # original 0.78 V

    # Compensation capacitor (critical): 0.5-5× original (Farads). Use log-uniform.
    'c_ccomp': {'min': 0.5 * 2e-15, 'max': 5.0 * 2e-15, 'log': True},  # original 2e-15 F
}

# ---------------------------
# Initial parameter values (EXACT original values from the provided netlist)
# ---------------------------
initial_params = {
    # Transistor widths (meters) — EXACT original values
    'w_M1': 20e-6,
    'w_M2': 20e-6,
    'w_M3': 40e-6,
    'w_M4': 40e-6,
    'w_M7': 4e-6,
    'w_M5': 10e-6,
    'w_M6': 20e-6,

    # Bias voltages (Volts) — EXACT original values
    'Vbias_tail': 0.60,
    'Vbias_p':    0.78,

    # Compensation capacitor (Farads) — EXACT original value
    'c_ccomp': 2e-15,
}

# ---------------------------
# Short descriptions of parameters (physical meaning)
# ---------------------------
param_descriptions = {
    # Widths (W) for each transistor (length L fixed at 45 nm)
    'w_M1': 'Width of input NMOS M1 (left differential transistor). Controls its current and gm.',
    'w_M2': 'Width of input NMOS M2 (right differential transistor). Controls its current and gm.',
    'w_M3': 'Width of PMOS diode-connected load transistor M3 (left load). Affects mirror bias and load resistance.',
    'w_M4': 'Width of PMOS mirror transistor M4 (right load). Affects mirror accuracy and load resistance.',
    'w_M7': 'Width of NMOS tail current source M7. Controls tail current magnitude and bias compliance.',
    'w_M5': 'Width of second-stage NMOS M5 (gain transistor). Controls gm and output drive of the second stage.',
    'w_M6': 'Width of PMOS load M6 for second stage. Controls load current and headroom of the second stage.',

    # Voltages
    'Vbias_tail': 'Bias voltage for tail NMOS gate (sets tail current through M7). Tunable but <= 1.2 V.',
    'Vbias_p': 'Bias voltage applied to PMOS load gate for M6 (sets second-stage bias). Tunable but <= 1.2 V.',

    # Capacitor
    'c_ccomp': 'Miller compensation capacitor between Vout_int and Vout (critical for GBW and phase margin).',
}

# End of parameterization file
```

Notes/clarifications:
- The create_circuit function contains the required line "from model import nmos_params, pmos_params" exactly as requested.
- Vdd and the input common-mode sources (Vinp, Vinn) are fixed per your requirements and are not included in the optimization parameter set.
- All initial_params values are exactly the numbers from your original netlist.
- The transistor width ranges use 1×L to 500×L by default; however, M3 and M4 original widths (40e-6) exceed 500×L (22.5e-6). To keep the initial parameters exactly as originally provided (a strict requirement), the upper bounds for w_M3 and w_M4 are extended to include the original values. If you prefer strict enforcement of the 500×L maximum, set the corresponding 'max' to 500 * L (22.5e-6) and adjust the initial values accordingly.
- All bias voltage ranges were computed as 0.8–1.2× original but clipped to be <= 1.2 V as required.