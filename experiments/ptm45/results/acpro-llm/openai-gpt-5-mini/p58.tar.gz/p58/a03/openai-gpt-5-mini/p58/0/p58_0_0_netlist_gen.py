from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage Differential Opamp - GBW Optimized')
# MOS models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                      # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)                   # input common-mode DC (no AC)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)                   # input common-mode DC (no AC)
circuit.V('btail', 'Vbias_tail', circuit.gnd, 0.60)          # tail bias for NMOS current source
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.78)                # PMOS gate bias for second-stage load
# Nodes:
# SS - common source node for differential pair
# Vd_p - drain & gate of diode-connected PMOS (left branch)
# Vout_int - single-ended internal node after first stage (right branch)
# Vout - final output node
# First stage: Differential NMOS pair with PMOS current-mirror load
Lch = 0.045e-6  # 45 nm
# Input pair
circuit.MOSFET('M1', 'Vd_p', 'Vinp', 'SS', circuit.gnd, model='nmos_model', w=20e-6, l=Lch)
circuit.MOSFET('M2', 'Vout_int', 'Vinn', 'SS', circuit.gnd, model='nmos_model', w=20e-6, l=Lch)
# PMOS active load: M3 diode-connected, M4 mirror
circuit.MOSFET('M3', 'Vd_p', 'Vd_p', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=Lch)  # diode-connected
circuit.MOSFET('M4', 'Vout_int', 'Vd_p', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=Lch) # mirror
# Tail current source (NMOS)
circuit.MOSFET('M7', 'SS', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=4e-6, l=Lch)
# Second stage: NMOS common-source with PMOS current-source load
circuit.MOSFET('M5', 'Vout', 'Vout_int', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=Lch)
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=Lch)
# Miller compensation capacitor between Vout_int and Vout (small to favor GBW)
circuit.C('ccomp', 'Vout_int', 'Vout', 2e-15)  # 2 fF
# (Optional) small output load capacitance to emulate load (kept small)
# circuit.C('cload', 'Vout', circuit.gnd, 5e-15)  # 5 fF if desired
# Create simulator (no AC sources per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
