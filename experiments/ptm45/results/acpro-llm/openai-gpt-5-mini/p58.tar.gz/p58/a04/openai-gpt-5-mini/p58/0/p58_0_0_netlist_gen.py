from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage OpAmp Optimized for GBW')
# MOSFET models (provided via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input nodes (DC operating points provided; keep nodes present)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # DC bias on + input
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # DC bias on - input
# Bias nodes (based on Vth = 0.22V guideline)
circuit.V('btail', 'Vbias_tail', circuit.gnd, 0.42)  # NMOS tail bias ~ Vth + 0.2
circuit.V('bp', 'Vbias_pmos', circuit.gnd, 0.78)    # PMOS bias ~ Vdd - |Vth| - 0.2
# Nodes: Dp (left drain), Dn (internal node), Snode (common source), Vout
# First stage: NMOS differential pair
# M1: left input
circuit.MOSFET('M1', 'Dp', 'Vinp', 'Snode', 'Snode',
                model='nmos_model', w=50e-6, l=0.045e-6)
# M2: right input
circuit.MOSFET('M2', 'Dn', 'Vinn', 'Snode', 'Snode',
                model='nmos_model', w=50e-6, l=0.045e-6)
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Snode', 'Vbias_tail', circuit.gnd, circuit.gnd,
                model='nmos_model', w=5e-6, l=0.045e-6)
# PMOS current mirror load for the differential pair
# M3 diode-connected on left branch (gate tied to Dp)
circuit.MOSFET('M3', 'Dp', 'Dp', 'Vdd', 'Vdd',
                model='pmos_model', w=20e-6, l=0.045e-6)
# M4 mirrored device provides current to the right branch (Dn)
circuit.MOSFET('M4', 'Dn', 'Dp', 'Vdd', 'Vdd',
                model='pmos_model', w=20e-6, l=0.045e-6)
# Second stage: Common-source NMOS amplifier (single-ended)
circuit.MOSFET('M6', 'Vout', 'Dn', circuit.gnd, circuit.gnd,
                model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current source load for second stage
circuit.MOSFET('M7', 'Vout', 'Vbias_pmos', 'Vdd', 'Vdd',
                model='pmos_model', w=10e-6, l=0.045e-6)
# Miller compensation capacitor (dominant pole)
circuit.C('comp', 'Vout', 'Dn', 2e-15)  # 2 fF Miller cap
# End of netlist; ready for operating-point or transient/small-signal analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
