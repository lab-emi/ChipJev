from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Differential Two-Stage Op-Amp (GBW-optimized)')
# MOS models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input nodes (DC common-mode bias for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.60)  # Vin+ bias = 0.60 V (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.60)  # Vin- bias = 0.60 V
# Tail bias (uses Vth = 0.22 V: Vb_tail ~ Vth + 0.40 = 0.62 V)
circuit.V('tail', 'Vb_tail', circuit.gnd, 0.62)
# First stage: NMOS differential pair with NMOS tail current source
# M1: drain D1, gate Vinp, source Vs, bulk = Vs
circuit.MOSFET('M1', 'D1', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=0.045e-6)
# M2: drain D2, gate Vinn, source Vs, bulk = Vs
circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=0.045e-6)
# Tail current source Mtail: drain Vs, gate Vb_tail, source gnd, bulk gnd
circuit.MOSFET('Mtail', 'Vs', 'Vb_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# PMOS current mirror active load (diode-connected M3 and mirror M4)
# M3 diode-connected: drain D1, gate D1, source Vdd, bulk Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# M4 mirror: drain D2, gate tied to D1, source Vdd, bulk Vdd
circuit.MOSFET('M4', 'D2', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=0.045e-6)
# Second stage: NMOS common-source amplifier
# M5: drain Vout, gate D2, source gnd, bulk gnd
circuit.MOSFET('M5', 'Vout', 'D2', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
# Resistive load from Vout to Vdd
circuit.R('1', 'Vout', 'Vdd', 3@u_kOhm)
# Miller compensation capacitor (small to push GBW higher)
# Use 2 fF for small Miller cap
circuit.C('c1', 'Vout', 'D2', 2e-15)
# End: ready for operating point / further analyses
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
