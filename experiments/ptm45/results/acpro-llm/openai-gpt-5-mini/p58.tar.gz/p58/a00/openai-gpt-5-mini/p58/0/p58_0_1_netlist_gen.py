from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
# Create circuit
circuit = Circuit('Two-Stage OpAmp Optimized for GBW - Corrected')
# Define transistor models (provided in model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78) # PMOS bias (Vdd - |Vth| - 0.2 = 0.78 V)
circuit.V('biasn', 'Vbiasn', circuit.gnd, 0.42) # NMOS tail bias (Vth + 0.2 = 0.42 V)
# Input DC bias sources (operating-point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # Input positive DC bias
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # Input negative DC bias
# --------------------------
# First stage: Differential NMOS pair with PMOS mirror load
# --------------------------
# M1: left input transistor
# Order: name, drain, gate, source, bulk, model, w, l
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=20e-6, l=45e-9)
# M2: right input transistor (output of first stage at node Vmid)
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=20e-6, l=45e-9)
# PMOS active load: M3 diode-connected (gate tied to its drain at node D1), M4 mirror feeding Vmid
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)  # diode-connected PMOS
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=45e-9)  # mirror device
# Input tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbiasn', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=45e-9)
# --------------------------
# Second stage: Common-source NMOS with PMOS current-source load
# --------------------------
circuit.MOSFET('M5', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=45e-9)
circuit.MOSFET('M6', 'Vout', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=45e-9)
# --------------------------
# Compensation capacitor (Miller) between Vout and Vmid
# --------------------------
# MOD 1 (fix): The original used an undefined unit 'u_fF' causing NameError.
#   - Change: use a numeric literal for capacitance in Farads (2e-15 F = 2 fF).
#   - Alternately could use a defined PySpice unit like (2e-15@u_F) if desired, but numeric is simplest.
#
# Rationale: This corrects the NameError while keeping the small Miller cap value intended to maximize GBW.
circuit.C('Ccomp', 'Vout', 'Vmid', 2e-15)  # 2 fF Miller cap (numeric literal in farads)
# Notes on correctness / structural checks:
# - All MOSFET bulk nodes are tied to their sources as required.
# - Active load is a PMOS mirror (M3 diode-connected at D1, M4 gate tied to D1) — no positive feedback loop introduced.
# - Input and output node names (Vinp, Vinn, Vout) appear explicitly as required.
# - Device sizes use 45 nm technology (L = 45e-9 m).
# - Bias nodes Vbiasp and Vbiasn are provided as DC voltage sources (no AC sources).
# - No subcircuits or placeholders are used.
#
# Create simulator for operating point / AC analysis as needed.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
