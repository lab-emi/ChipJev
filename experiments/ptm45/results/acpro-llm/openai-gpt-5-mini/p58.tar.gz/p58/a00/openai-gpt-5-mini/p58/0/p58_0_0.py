from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Two-Stage OpAmp Optimized for GBW')
# Define transistor models (provided in model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('biasp', 'Vbiasp', circuit.gnd, 0.78) # PMOS bias (Vdd - |Vth| - 0.2)
circuit.V('biasn', 'Vbiasn', circuit.gnd, 0.42) # NMOS tail bias (Vth + 0.2)
# Input DC nodes (for operating point)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)     # input positive (DC bias)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)     # input negative (DC bias)
# First stage: differential NMOS pair with PMOS current-mirror active load
# M1: left input transistor (drain D1)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=20e-6, l=0.045e-6)
# M2: right input transistor (drain = Vmid) - this node becomes the single-ended first-stage output
circuit.MOSFET('M2', 'Vmid', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=20e-6, l=0.045e-6)
# PMOS active load: M3 diode-connected, M4 mirror
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # diode-connected
circuit.MOSFET('M4', 'Vmid', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)  # mirror device
# Input tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbiasn', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second stage: common-source NMOS with PMOS current-source load
circuit.MOSFET('M5', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M6', 'Vout', 'Vbiasp', 'Vdd', 'Vdd', model='pmos_model', w=10e-6, l=0.045e-6)
# Miller compensation capacitor between Vout and Vmid (small to maximize GBW)
circuit.C('Ccomp', 'Vout', 'Vmid', 2@u_fF)
# The required node names (Vinp, Vinn, Vout) appear in the circuit.
# Create a simulator for operating-point / transient / AC analysis as needed.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
