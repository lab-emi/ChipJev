from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-GBW Multi-Stage OpAmp')
# MOSFET models (assumed provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input nodes (DC operating point / common-mode)
circuit.V('inp', 'Vinp', circuit.gnd, "dc 0.60 ac 1n")
circuit.V('inn', 'Vinn', circuit.gnd, "dc 0.60 ac 1n")
# Bias voltages chosen using Vth = 0.22 V
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.42)  # NMOS tail gate bias (Vth + 0.2)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)  # PMOS current-source gate bias (Vdd - |Vth| - 0.2)
# Node names used:
# D1 - single-ended output of first (input) stage (feeds second stage)
# D2 - diode-connected node for PMOS mirror
# Iss - common source node of input pair (connects to tail transistor drain)
# Device dimensions (45 nm technology)
L = 0.045e-6
# First stage: differential NMOS pair with PMOS current-mirror active load
# M1: NMOS input (Vinp)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=2.0e-6, l=L)
# M2: NMOS input (Vinn)
circuit.MOSFET('M2', 'D2', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=2.0e-6, l=L)
# M3: PMOS diode-connected device (diode tied at D2)
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=10.0e-6, l=L)
# M4: PMOS mirror device, gate tied to D2, load for M1 (creates single-ended output at D1)
circuit.MOSFET('M4', 'D1', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=10.0e-6, l=L)
# Tail NMOS current source (Mtail) for the input pair
circuit.MOSFET('Mtail', 'Iss', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=0.6e-6, l=L)
# Second stage: NMOS common-source amplifier (driven by D1) with PMOS current source load
# M5: second-stage NMOS (common-source)
circuit.MOSFET('M5', 'Vout', 'D1', circuit.gnd, circuit.gnd, model='nmos_model', w=8.0e-6, l=L)
# M6: PMOS current-source load for second stage (gate tied to Vbias_p)
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=12.0e-6, l=L)
# (No explicit resistors or capacitors added to maximize raw GBW; compensation would trade GBW for stability.)
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)