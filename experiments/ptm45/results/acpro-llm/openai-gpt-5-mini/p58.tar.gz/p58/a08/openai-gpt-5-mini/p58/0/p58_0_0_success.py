from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('High-GBW Multi-Stage OpAmp')
# MOSFET models (assumed provided by model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input nodes (DC operating point / common-mode)
circuit.V('inp', 'Vinp', circuit.gnd, 0.60)   # input positive DC common-mode
circuit.V('inn', 'Vinn', circuit.gnd, 0.60)   # input negative DC common-mode
# Bias voltages chosen using Vth = 0.22 V
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.42)  # NMOS tail gate bias (Vth + 0.2)
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)  # PMOS current-source gate bias (Vdd - |Vth| - 0.2)
# Node names used:
# D1 - single-ended output of first (input) stage (feeds second stage)
# D2 - diode-connected node for PMOS mirror
# Iss - common source node of input pair (connects to tail transistor drain)
# Device dimensions (45 nm technology)
L = 0.045e-6
# First stage: differential NMOS pair with PMOS current-mirror active load
# M1: NMOS input (Vinp)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=2.0e-6, l=L)
# M2: NMOS input (Vinn)
circuit.MOSFET('M2', 'D2', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=2.0e-6, l=L)
# M3: PMOS diode-connected device (diode tied at D2)
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=10.0e-6, l=L)
# M4: PMOS mirror device, gate tied to D2, load for M1 (creates single-ended output at D1)
circuit.MOSFET('M4', 'D1', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=10.0e-6, l=L)
# Tail NMOS current source (Mtail) for the input pair
circuit.MOSFET('Mtail', 'Iss', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=0.6e-6, l=L)
# Second stage: NMOS common-source amplifier (driven by D1) with PMOS current source load
# M5: second-stage NMOS (common-source)
circuit.MOSFET('M5', 'Vout', 'D1', circuit.gnd, circuit.gnd, model='nmos_model', w=8.0e-6, l=L)
# M6: PMOS current-source load for second stage (gate tied to Vbias_p)
circuit.MOSFET('M6', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=12.0e-6, l=L)
# (No explicit resistors or capacitors added to maximize raw GBW; compensation would trade GBW for stability.)
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
