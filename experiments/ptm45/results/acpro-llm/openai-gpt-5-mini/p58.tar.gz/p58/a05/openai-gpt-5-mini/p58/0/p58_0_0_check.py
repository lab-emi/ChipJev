from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # required import (provided externally)
circuit = Circuit('Two-Stage OpAmp for High GBW')
# Device models (provided via model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Supply
circuit.V('vinp', 'Vinp', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('vinn', 'Vinn', circuit.gnd, "dc 0.6 ac 1n")
circuit.V('vb_tail', 'Vbias_tail', circuit.gnd, 0.50)  # Tail bias for NMOS tail current source
circuit.V('vb_p', 'Vbias_p', circuit.gnd, 0.73)        # PMOS load bias (absolute node voltage)
# First stage: differential NMOS pair with PMOS current-mirror active load
# Node naming:
# - Vmid : drain of M1 (left branch) -> single-ended node into second stage
# - Vref : drain/gate of diode-connected PMOS (right branch reference)
# - Iss  : sources of M1/M2 tied together and to the drain of the tail device
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'Vmid', 'Vinp', 'Iss', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vref', 'Vinn', 'Iss', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# PMOS active load: diode-connected device on right branch (M3), mirror on left branch (M4)
circuit.MOSFET('M3', 'Vref', 'Vref', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=0.045e-6)  # diode-connected PMOS
circuit.MOSFET('M4', 'Vmid', 'Vref', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=0.045e-6)   # mirror PMOS
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second stage: single-ended common-source NMOS with PMOS current-source load
# - M6: NMOS amplifier (drain -> Vout)
# - M7: PMOS current source (gate biased at Vbias_p)
circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=0.045e-6)
# Miller compensation capacitor (small, to maximize GBW while ensuring dominant pole)
circuit.C('Cc', 'Vmid', 'Vout', 3e-15)  # 3 fF
# End: prepare simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = "Vout"

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Common-Mode Gain (Av) at 100 Hz: {gain}")

vinn_name = ""
for element in circuit.elements:
    # print("element name", element.name)
    # for pin in element.pins:
    #     print("pin name", pin.node)
    if "vinn" in [str(pin.node).lower() for pin in element.pins] and element.name.lower().startswith("v"):
        vinn_name = element.name


circuit.element(vinn_name).dc_value += " 180"

simulator2 = circuit.simulator()
analysis2 = simulator2.ac(start_frequency=frequency, stop_frequency=frequency, 
                        number_of_points=1, variation='dec')

output_voltage2 = np.abs(analysis2[node].as_ndarray()[0])
gain2 = output_voltage2 / (1e-9)

print(f"Differential-Mode Gain (Av) at 100 Hz: {gain2}")

required_gain = 1e-5
import sys

if gain < gain2 - 1e-5 and gain2 > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)

if gain >= gain2 - 1e-5:
    print("Common-Mode gain is larger than Differential-Mode gain.\n")

if gain2 < required_gain:
    print("Differential-Mode gain is smaller than 1e-5.\n")

print("The circuit does not function correctly.\n"
    "Please fix the wrong operating point.\n")
sys.exit(2)