from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # required import (provided externally)
circuit = Circuit('Two-Stage OpAmp for High GBW')
# Device models (provided via model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Supply
circuit.V('vinp', 'Vinp', circuit.gnd, 0.6)        # Input positive DC bias (common-mode)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.6)        # Input negative DC bias (common-mode)
circuit.V('vb_tail', 'Vbias_tail', circuit.gnd, 0.50)  # Tail bias for NMOS tail current source
circuit.V('vb_p', 'Vbias_p', circuit.gnd, 0.73)        # PMOS load bias (absolute node voltage)
# First stage: differential NMOS pair with PMOS current-mirror active load
# Node naming:
# - Vmid : drain of M1 (left branch) -> single-ended node into second stage
# - Vref : drain/gate of diode-connected PMOS (right branch reference)
# - Iss  : sources of M1/M2 tied together and to the drain of the tail device
# Input differential pair (NMOS)
circuit.MOSFET('M1', 'Vmid', 'Vinp', 'Iss', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vref', 'Vinn', 'Iss', circuit.gnd, model='nmos_model', w=40e-6, l=0.045e-6)
# PMOS active load: diode-connected device on right branch (M3), mirror on left branch (M4)
circuit.MOSFET('M3', 'Vref', 'Vref', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=0.045e-6)  # diode-connected PMOS
circuit.MOSFET('M4', 'Vmid', 'Vref', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=0.045e-6)   # mirror PMOS
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=0.045e-6)
# Second stage: single-ended common-source NMOS with PMOS current-source load
# - M6: NMOS amplifier (drain -> Vout)
# - M7: PMOS current source (gate biased at Vbias_p)
circuit.MOSFET('M6', 'Vout', 'Vmid', circuit.gnd, circuit.gnd, model='nmos_model', w=20e-6, l=0.045e-6)
circuit.MOSFET('M7', 'Vout', 'Vbias_p', 'Vdd', 'Vdd', model='pmos_model', w=60e-6, l=0.045e-6)
# Miller compensation capacitor (small, to maximize GBW while ensuring dominant pole)
circuit.C('Cc', 'Vmid', 'Vout', 3e-15)  # 3 fF
# End: prepare simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p58/0/p58_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
