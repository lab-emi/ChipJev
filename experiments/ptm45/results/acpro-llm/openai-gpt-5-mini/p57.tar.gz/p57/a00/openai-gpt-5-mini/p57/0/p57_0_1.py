from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed M5 DC Bias')
# MOSFET models (external module provides parameter dicts)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# DC input bias (no AC here, only operating point)
# Use Vth = 0.22 V per instructions: Vin bias = Vth + 0.2 = 0.42 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)
# Bias nodes for PMOS current-source loads:
# Vb = Vdd - (Vth + 0.2) = 1.2 - (0.22 + 0.2) = 0.78 V
circuit.V('b1', 'Vb1', circuit.gnd, 0.78)
circuit.V('b2', 'Vb2', circuit.gnd, 0.78)
# Device geometry (45 nm technology)
L = 0.045e-6  # 45 nm
# Stage 1: Common-Source input with PMOS active load
# M1: NMOS input (drain n1, gate Vin, source gnd, bulk = source)
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)
# M2: PMOS current-source load (drain n1, gate Vb1, source Vdd, bulk = source)
circuit.MOSFET('M2', 'n1', 'Vb1', 'Vdd', 'Vdd',
               model='pmos_model', w=24e-6, l=L)
# Stage 2: Common-Source mid-stage with PMOS active load
# M3: NMOS (drain n2, gate n1, source gnd, bulk = source)
circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=24e-6, l=L)
# M4: PMOS current-source load for stage 2 (drain n2, gate Vb2, source Vdd, bulk = source)
circuit.MOSFET('M4', 'n2', 'Vb2', 'Vdd', 'Vdd',
               model='pmos_model', w=48e-6, l=L)
# Output buffer: NMOS source follower
# M5: NMOS source follower (drain Vdd, gate n2, source Vout, bulk tied to source Vout)
circuit.MOSFET('M5', 'Vdd', 'n2', 'Vout', 'Vout',
               model='nmos_model', w=40e-6, l=L)
# Add a DC pull-down resistor at the output to establish a valid DC operating point
# This pulls Vout low enough so that V_GS (n2 - Vout) for M5 is > Vth
circuit.R('load', 'Vout', circuit.gnd, 100@u_kΩ)
# The named nodes Vin and Vout appear as required.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
