from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the model import requested by the framework must appear inside create_circuit
# as exactly: from model import nmos_params, pmos_params
# Fixed process length (45 nm)
L = 0.045e-6  # meters (45 nm)
def create_circuit(params):
    """
    Create the PySpice Circuit for the Multi-Stage GBW-Optimized Amplifier.
    Required: the execution environment must provide `model.nmos_params` and `model.pmos_params`.
    The import below must appear exactly as written for compatibility with the provided environment.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed M5 DC Bias (Rload=10k)')
    # MOSFET models (external module provides parameter dicts)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (45 nm)
    # Input voltage source (fixed; swept externally during DC analysis)
    # Keep input bias exactly as in the original netlist:
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Vin = Vth + 0.2 = 0.22 + 0.2
    # Bias nodes for PMOS current-source loads (parameterized, conservative range applied)
    circuit.V('b1', 'Vb1', circuit.gnd, params['v_b1'])
    circuit.V('b2', 'Vb2', circuit.gnd, params['v_b2'])
    # Stage 1: Common-Source input with PMOS active load
    circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'n1', 'Vb1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)
    # Stage 2: Common-Source mid-stage with PMOS active load
    circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M3'],
                   l=L)
    circuit.MOSFET('M4', 'n2', 'Vb2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    # Output buffer: NMOS source follower (drain to Vdd, gate n2, source Vout, bulk tied to source)
    circuit.MOSFET('M5', 'Vdd', 'n2', 'Vout', 'Vout',
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    # Output load resistor (parameterized). Represented in kΩ in params for readability:
    # PySpice accepts strings like "10k", so we format accordingly.
    circuit.R('load', 'Vout', circuit.gnd, f"{params['r_load']}k")
    # Note: The original netlist did not include any capacitors; any load/compensation caps
    # are to remain fixed if present. The user requested that load capacitors remain fixed
    # and not part of the search; since none exist in the original, we do not add any here.
    return circuit
# -------------------------
# Optimization parameter search ranges (for Optuna or similar)
# -------------------------
# Process length used for deriving W ranges:
L_val = L  # 45e-9 m
# Base 1-500× range
W_min = L_val * 1.0
W_max_typical = L_val * 500.0
# The original netlist contains one transistor (M5) with width = 80e-6 m, which exceeds 500*L
# (500*L = 22.5e-6 m). To satisfy the hard requirement that "initial_params" equals the original
# values and stays inside the search range, we expand the upper bound to include the original M5
# width. This is a practical exception so the original design is an allowed starting point.
param_ranges_definition = {
    # Transistor widths (meters) - search as continuous, log-scale recommended
    # Typical constraint: 1-500 × L. For each transistor, set max = max(500*L, original_width)
    'w_M1': {'min': W_min, 'max': max(W_max_typical, 12e-6), 'log': True},   # M1 original 12e-6
    'w_M2': {'min': W_min, 'max': max(W_max_typical, 24e-6), 'log': True},   # M2 original 24e-6
    'w_M3': {'min': W_min, 'max': max(W_max_typical, 24e-6), 'log': True},   # M3 original 24e-6
    'w_M4': {'min': W_min, 'max': max(W_max_typical, 48e-6), 'log': True},   # M4 original 48e-6
    # M5 original width (80e-6) > 500*L; include it by increasing max to original width (exception)
    'w_M5': {'min': W_min, 'max': max(W_max_typical, 80e-6), 'log': True},   # M5 original 80e-6
    # Bias voltages (V): 0.8 - 1.2 × original, but never exceed 1.2 V supply.
    # Original Vb1 = Vb2 = 0.78 V -> allowed [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    'v_b1': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
    'v_b2': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
    # Load resistor (kΩ): 0.5 - 2 × original
    # Original r_load = 10 kΩ -> allowed [5, 20] kΩ
    'r_load': {'min': 0.5 * 10.0, 'max': 2.0 * 10.0, 'log': True},
}
# -------------------------
# Initial parameter values (EXACT original circuit values)
# These values are the unmodified numbers from the original netlist and must be used
# as the starting point for optimization.
# -------------------------
initial_params = {
    # Transistor widths (meters) - exact originals:
    'w_M1': 12e-6,   # original M1 width
    'w_M2': 24e-6,   # original M2 width
    'w_M3': 24e-6,   # original M3 width
    'w_M4': 48e-6,   # original M4 width
    'w_M5': 80e-6,   # original M5 width (note: > 500 * L; allowed as initial point)
    # Bias voltages (V) - exact originals:
    'v_b1': 0.78,    # original Vb1
    'v_b2': 0.78,    # original Vb2
    # Load resistor (kΩ) - exact original:
    # The netlist used 10@u_kΩ so represent initial in kΩ the same way as param ranges above.
    'r_load': 10.0,  # original 10 kΩ
}
# -------------------------
# Brief description of each parameter (physical meaning)
# -------------------------
param_descriptions = {
    'w_M1': "Width (W) of NMOS M1 (input common-source transistor). Units: meters. L fixed at 45 nm.",
    'w_M2': "Width (W) of PMOS M2 (stage-1 active load). Units: meters. L fixed at 45 nm.",
    'w_M3': "Width (W) of NMOS M3 (mid-stage common-source transistor). Units: meters. L fixed at 45 nm.",
    'w_M4': "Width (W) of PMOS M4 (stage-2 active load). Units: meters. L fixed at 45 nm.",
    'w_M5': "Width (W) of NMOS M5 (output source-follower buffer). Units: meters. L fixed at 45 nm. "
            "Original design used a very large W (80e-6 m); range expanded to include that starting point.",
    'v_b1': "Bias voltage Vb1 applied to the gate of PMOS M2 (establishes PMOS current-source load). Units: V.",
    'v_b2': "Bias voltage Vb2 applied to the gate of PMOS M4 (establishes PMOS current-source load). Units: V.",
    'r_load': "External DC pull-down load at the amplifier output (Rload). Units: kΩ in the parameter dictionary; "
              "converted to string with 'k' suffix for PySpice when creating the circuit.",
}
# End of parameterized netlist and search-range definitions
