from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed M5 DC Bias (Rload=10k)')
# MOSFET models (external module provides parameter dicts)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# DC input bias (no AC here, only operating point)
# Use Vth = 0.22 V per instructions: Vin bias = Vth + 0.2 = 0.42 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
# Bias nodes for PMOS current-source loads:
# Vb = Vdd - (Vth + 0.2) = 1.2 - (0.22 + 0.2) = 0.78 V
circuit.V('b1', 'Vb1', circuit.gnd, 0.78)
circuit.V('b2', 'Vb2', circuit.gnd, 0.78)
# Device geometry (45 nm technology)
L = 0.045e-6  # 45 nm
# Stage 1: Common-Source input with PMOS active load
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)
circuit.MOSFET('M2', 'n1', 'Vb1', 'Vdd', 'Vdd',
               model='pmos_model', w=24e-6, l=L)
# Stage 2: Common-Source mid-stage with PMOS active load
circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=24e-6, l=L)
circuit.MOSFET('M4', 'n2', 'Vb2', 'Vdd', 'Vdd',
               model='pmos_model', w=48e-6, l=L)
# Output buffer: NMOS source follower (drain to Vdd, gate n2, source Vout, bulk tied to source)
# Increase M5 width to ensure it can conduct with the available V_GS
circuit.MOSFET('M5', 'Vdd', 'n2', 'Vout', 'Vout',
               model='nmos_model', w=80e-6, l=L)
# Reduced DC pull-down resistor at the output to establish a valid DC operating point
# (was 100k, reduced to 10k to pull Vout lower so that V_GS for M5 > Vth)
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)
# The named nodes Vin and Vout appear as required.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)