from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the required model import (exactly as requested) is placed inside create_circuit
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Cascoded CS + Source-Follower (GBW-optimized) - Fixed')
    # Transistor models (unchanged)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed 1.2V for 45nm technology
    # Input voltage (fixed, will be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # fixed input bias
    # Other bias voltages -> parameterized (ranges defined separately)
    circuit.V('pbias', 'Vbias_p', circuit.gnd, params['v_pbias'])   # PMOS gate bias (parameter)
    circuit.V('nbias', 'Vbias_n', circuit.gnd, params['v_nbias'])   # NMOS cascode gate bias (parameter)
    # Tech length (fixed)
    L45 = 45e-9
    # Stage 1: Cascoded common-source (widths parameterized; lengths fixed)
    # M1: input NMOS (drain=node1, gate=Vin, source=gnd, bulk=gnd)
    circuit.MOSFET('M1', 'node1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L45)
    # M2: NMOS cascode (drain=node2, gate=Vbias_n, source=node1, bulk tied to source node1)
    circuit.MOSFET('M2', 'node2', 'Vbias_n', 'node1', 'node1',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L45)
    # M3: PMOS current-source load (drain=node2, gate=Vbias_p, source=Vdd, bulk tied to source Vdd)
    circuit.MOSFET('M3', 'node2', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L45)
    # Stage 2: Source follower buffer (NMOS)
    # M4: drain=Vdd, gate=node2, source=Vout, bulk tied to source Vout
    circuit.MOSFET('M4', 'Vdd', 'node2', 'Vout', 'Vout',
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L45)
    # Load resistor to ground at Vout to pull the source down so V_GS(M4) > V_TH
    # Parameterized resistor value (expressed in kΩ units in params)
    circuit.R('L', 'Vout', circuit.gnd, f"{params['r_L']}k")
    # No load capacitors present in the original netlist; if added later keep fixed as required.
    return circuit
# Optimization parameter search ranges (annotated)
# Note: L = 45e-9 (fixed). Width ranges use 1x - 500x of L.
# All voltage ranges follow 0.8 - 1.2 × original, capped at 1.2 V.
# Resistances use 0.5 - 2 × original (original R_L = 10 kΩ) and are expressed in kΩ here.
L45 = 45e-9
param_ranges_definition = {
    # Transistor widths (meters) - 1×L .. 500×L
    'w_M1': {'min': 1.0 * L45, 'max': 500.0 * L45, 'log': True},  # M1 original = 4e-6
    'w_M2': {'min': 1.0 * L45, 'max': 500.0 * L45, 'log': True},  # M2 original = 2e-6
    'w_M3': {'min': 1.0 * L45, 'max': 500.0 * L45, 'log': True},  # M3 original = 8e-6
    'w_M4': {'min': 1.0 * L45, 'max': 500.0 * L45, 'log': True},  # M4 original = 10e-6
    # Bias voltages (V) - 0.8× .. 1.2× original, capped at 1.2V.
    # Original: v_pbias = 0.78 V  -> range = [0.624, 0.936]
    # Original: v_nbias = 0.42 V  -> range = [0.336, 0.504]
    'v_pbias': {'min': 0.8 * 0.78, 'max': min(1.2 * 0.78, 1.2), 'log': False},
    'v_nbias': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
    # Load resistor (kΩ) - 0.5× .. 2× original (original R_L = 10 kΩ)
    'r_L': {'min': 0.5 * 10.0, 'max': 2.0 * 10.0, 'log': True},
}
# Initial parameter values (EXACT original circuit values)
# These values are identical to the numbers used in the provided netlist.
initial_params = {
    # Transistor widths (meters)
    'w_M1': 4e-6,    # M1 original width
    'w_M2': 2e-6,    # M2 original width
    'w_M3': 8e-6,    # M3 original width
    'w_M4': 10e-6,   # M4 original width
    # Bias voltages (V)
    'v_pbias': 0.78,  # Vbias_p original
    'v_nbias': 0.42,  # Vbias_n original
    # Load resistor (kΩ)
    'r_L': 10.0,      # Original 10 kΩ represented as 10 (kΩ)
}
# Brief descriptions of each parameter (physical meaning)
param_descriptions = {
    'w_M1': 'Width of input NMOS (M1). Determines current drive and gm of input device; L fixed at 45 nm.',
    'w_M2': 'Width of NMOS cascode device (M2). Affects cascode impedance and headroom.',
    'w_M3': 'Width of PMOS current-source load (M3). Controls load current and output resistance of the load.',
    'w_M4': 'Width of NMOS source-follower (M4). Affects buffer drive strength and source follower output impedance.',
    'v_pbias': 'PMOS gate bias for current source (Vbias_p). Sets current through PMOS load; constrained 0.8-1.2× original and <= 1.2V.',
    'v_nbias': 'NMOS cascode gate bias (Vbias_n). Sets cascode operating point; constrained 0.8-1.2× original and <= 1.2V.',
    'r_L': 'Load resistor at Vout (in kΩ). Provides DC pull-down to ensure M4 turns on; original 10 kΩ. Range 0.5-2× original.',
}
# Quick sanity checks (not executed here, but useful notes):
# - All initial_params values are inside the provided ranges above.
# - Vth = 0.22 V for the process; chosen lower bounds for bias voltages remain safely above Vth.
# - L is kept fixed at 45e-9 m (45 nm); optimization only varies W to change W/L ratio.
