from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded CS + Source-Follower (GBW-optimized) - Fixed')
# Define transistor models (unchanged)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input and bias voltages (DC only)
circuit.V('in', 'Vin', circuit.gnd, "dc 0.42 ac 1n")
circuit.V('pbias', 'Vbias_p', circuit.gnd, 0.78) # PMOS gate bias for current source
circuit.V('nbias', 'Vbias_n', circuit.gnd, 0.42) # NMOS cascode gate bias
# Notes on sizing: 45 nm technology -> L = 45e-9 m
L45 = 45e-9
# Stage 1: Cascoded common-source
# Modification 1: Use model= keyword instead of passing model name positionally.
# M1: input NMOS (drain=node1, gate=Vin, source=gnd, bulk=gnd)
circuit.MOSFET('M1', 'node1', 'Vin', circuit.gnd, circuit.gnd,
                model='nmos_model', w=4e-6, l=L45)
# M2: NMOS cascode (drain=node2, gate=Vbias_n, source=node1, bulk tied to source node1)
# Ensure bulk tied to source: bulk = 'node1'
circuit.MOSFET('M2', 'node2', 'Vbias_n', 'node1', 'node1',
                model='nmos_model', w=2e-6, l=L45)
# M3: PMOS current-source load (drain=node2, gate=Vbias_p, source=Vdd, bulk tied to source Vdd)
circuit.MOSFET('M3', 'node2', 'Vbias_p', 'Vdd', 'Vdd',
                model='pmos_model', w=8e-6, l=L45)
# Stage 2: Source follower buffer (NMOS)
# M4: drain=Vdd, gate=node2, source=Vout, bulk tied to source Vout
# Modification 2: again use model= keyword and ensure bulk tied to source
circuit.MOSFET('M4', 'Vdd', 'node2', 'Vout', 'Vout',
                model='nmos_model', w=10e-6, l=L45)
# Load resistor to ground at Vout to pull the source down so V_GS(M4) > V_TH
# Modification 3: add Rload to ensure M4 turns on at DC operating point.
# Value chosen as 10k to provide a modest DC pull-down without heavy loading.
circuit.R('L', 'Vout', circuit.gnd, 10@u_kΩ)
# End: instantiate simulator (no additional code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)