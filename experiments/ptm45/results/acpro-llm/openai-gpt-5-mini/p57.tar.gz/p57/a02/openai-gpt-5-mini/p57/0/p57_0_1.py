from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded CS + Source-Follower (GBW-optimized) with Rload')
# Define transistor models
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input and bias voltages (DC biases only)
circuit.V('in', 'Vin', circuit.gnd, 0.42)       # Vin bias ~ Vth + 0.2
circuit.V('pbias', 'Vbias_p', circuit.gnd, 0.78) # PMOS gate bias for current source
circuit.V('nbias', 'Vbias_n', circuit.gnd, 0.42) # NMOS cascode gate bias
# Node naming:
# node1: drain of M1, source of M2
# node2: drain of M2, drain of M3, gate of M4 (internal amplifier output)
# Vout: source of M4 (final output)
# Stage 1: Cascoded common-source
# M1: input NMOS (drain node1, gate Vin, source gnd, bulk gnd)
circuit.MOSFET('M1', 'node1', 'Vin', circuit.gnd, circuit.gnd,
                'nmos_model', w=4e-6, l=0.045e-6)
# M2: NMOS cascode (drain node2, gate Vbias_n, source node1, bulk node1)
circuit.MOSFET('M2', 'node2', 'Vbias_n', 'node1', 'node1',
                'nmos_model', w=2e-6, l=0.045e-6)
# M3: PMOS current-source load (drain node2, gate Vbias_p, source Vdd, bulk Vdd)
circuit.MOSFET('M3', 'node2', 'Vbias_p', 'Vdd', 'Vdd',
                'pmos_model', w=8e-6, l=0.045e-6)
# Stage 2: Source follower buffer (NMOS)
# M4: drain Vdd, gate node2, source Vout, bulk Vout (bulk tied to source)
circuit.MOSFET('M4', 'Vdd', 'node2', 'Vout', 'Vout',
                'nmos_model', w=10e-6, l=0.045e-6)
# Load resistor to ground at Vout to pull the source down so V_GS(M4) > V_TH
# This ensures M4 is in active region at DC operating point.
circuit.R('L', 'Vout', circuit.gnd, 10@u_kΩ)
# End: instantiate simulator (no additional code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
