from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Wideband Two-Stage Amplifier (CG -> CS) - Fixed bias path')
# Define MOSFET models (from provided model parameters)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# DC biases (no AC sources)
circuit.V('in', 'Vin', circuit.gnd, 0.42)         # Vin DC operating point (Vth + 0.2)
circuit.V('biascg', 'VbiasCG', circuit.gnd, 1.02) # Bias for CG gate (Vin + ~0.6)
# Devices (45 nm channel length = 0.045e-6 m)
L = 0.045e-6
# Stage 1: Common-Gate NMOS (wide device to maximize gm and bandwidth)
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'N1', 'VbiasCG', 'Vin', 'Vin', model='nmos_model', w=20e-6, l=L)
# DC load for M1's drain to provide a DC path (fixes zero-current operating point)
# A resistor from N1 to Vdd provides the necessary bias current path.
circuit.R('2', 'N1', 'Vdd', 10@u_kOhm)
# Stage 2: Common-Source NMOS
circuit.MOSFET('M2', 'Vout', 'N1', circuit.gnd, circuit.gnd, model='nmos_model', w=10e-6, l=L)
# Resistive load converting current to voltage at the output
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
# Create simulator (operating point / time-domain or AC can be run afterwards)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
