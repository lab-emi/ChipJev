```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params

# Fixed process length (45 nm)
L = 0.045e-6  # meters (kept constant; only W is optimized)

def create_circuit(params):
    """
    Create the parameterized Wideband Two-Stage Amplifier (CG -> CS) circuit.

    Required params keys:
      - w_M1        : width of M1 (meters)
      - w_M2        : width of M2 (meters)
      - r_R2_k      : resistor R2 value in kOhm (N1 -> Vdd)
      - r_R1_k      : resistor R1 value in kOhm (Vout -> Vdd)
      - v_biasCG    : bias voltage for the CG gate (VbiasCG) in volts

    Notes:
      - vdd (1.2 V) and input Vin (0.42 V) are kept fixed (not optimized).
      - Load capacitors (if any) are kept fixed (not parameterized).
      - The MOSFET length is fixed to the process L = 45 nm.
    """
    circuit = Circuit('Wideband Two-Stage Amplifier (CG -> CS) - Fixed bias path')

    # Preserve the expected model imports and names
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (45nm supply)

    # Input voltage (fixed, not parameterized) - to be swept externally during DC analysis
    circuit.V('in', 'Vin', circuit.gnd, 0.42)

    # Parameterized bias voltage for CG gate (must be <= 1.2 V)
    circuit.V('biascg', 'VbiasCG', circuit.gnd, params['v_biasCG'])

    # Stage 1: Common-Gate NMOS (M1)
    # drain = N1, gate = VbiasCG, source = Vin, bulk = Vin (as in original)
    circuit.M('M1', 'N1', 'VbiasCG', 'Vin', 'Vin',
              model='nmos_model',
              w=params['w_M1'],
              l=L)

    # DC load for M1's drain -> resistor R2 from N1 to Vdd (parameterized, kOhm)
    # PySpice accepts values like "10k" -> use f-string to append 'k'
    circuit.R('2', 'N1', 'Vdd', f"{params['r_R2_k']}k")

    # Stage 2: Common-Source NMOS (M2)
    # drain = Vout, gate = N1, source = gnd, bulk = gnd
    circuit.M('M2', 'Vout', 'N1', circuit.gnd, circuit.gnd,
              model='nmos_model',
              w=params['w_M2'],
              l=L)

    # Resistive load at the output R1 (Vout -> Vdd), parameterized (kOhm)
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_R1_k']}k")

    # No explicit capacitors in the original netlist; load capacitors remain fixed
    return circuit


# -----------------------------
# Optimization parameter search ranges (annotated)
# All initial parameter values are provided below in initial_params
# and are guaranteed to lie inside the ranges defined here.
# -----------------------------
param_ranges = {
    # Transistor widths (meters). Constraint: 1 - 500 × L (L = 0.045e-6 m)
    # Use log-scale sampling because device behavior often spans many decades with respect to W
    'w_M1': {
        'min': L * 1.0,           # 1 × L  = 0.045e-6 m
        'max': L * 500.0,         # 500 × L = 22.5e-6 m
        'log': True
    },
    'w_M2': {
        'min': L * 1.0,
        'max': L * 500.0,
        'log': True
    },

    # Resistances given in kilo-ohms (kΩ).
    # Original resistors are 10 kΩ each; allowed range = 0.5 - 2 × original = [5, 20] kΩ
    # Use log-scale sampling to allow proportional exploration.
    'r_R2_k': {
        'min': 10.0 * 0.5,   # 5.0 (kΩ)
        'max': 10.0 * 2.0,   # 20.0 (kΩ)
        'log': True
    },
    'r_R1_k': {
        'min': 10.0 * 0.5,
        'max': 10.0 * 2.0,
        'log': True
    },

    # Bias voltage for the CG gate (VbiasCG).
    # Rule: within 0.8 - 1.2 × original, but never exceed 1.2 V supply.
    # Original = 1.02 V -> 0.8× = 0.816 V, 1.2× = 1.224 V -> capped at 1.2 V.
    # Use linear sampling since voltages are sensitive and should be explored conservatively.
    'v_biasCG': {
        'min': 1.02 * 0.8,    # 0.816 V
        'max': min(1.2, 1.02 * 1.2),  # 1.2 V (clipped to supply)
        'log': False
    }
}

# -----------------------------
# Initial parameter values (EXACT original values from the provided circuit)
# IMPORTANT: These values are the starting point for optimization and MUST match the original netlist.
# -----------------------------
initial_params = {
    # Transistor widths (meters) - EXACT original values
    'w_M1': 20e-6,    # Original M1 width = 20e-6 m
    'w_M2': 10e-6,    # Original M2 width = 10e-6 m

    # Resistances in kΩ - ORIGINAL values (10 kΩ each in the user's code)
    'r_R2_k': 10.0,   # Original R('2') = 10 kΩ
    'r_R1_k': 10.0,   # Original R('1') = 10 kΩ

    # Bias voltages - ORIGINAL value
    'v_biasCG': 1.02, # Original V('biascg') = 1.02 V
}

# -----------------------------
# Brief description of the physical meaning of each parameter
# -----------------------------
param_descriptions = {
    'w_M1': "Gate width of M1 (Common-Gate NMOS). Together with fixed length L determines W/L and device current, gm, parasitics, and bandwidth.",
    'w_M2': "Gate width of M2 (Common-Source NMOS). Controls bias current, gain, output resistance and parasitic capacitances.",
    'r_R2_k': "Resistor R2 (N1 -> Vdd) in kilo-ohms. Sets DC bias current through M1 and node N1 DC operating point.",
    'r_R1_k': "Resistor R1 (Vout -> Vdd) in kilo-ohms. Converts M2 drain current to output voltage and sets output DC level and load.",
    'v_biasCG': "Bias voltage applied to the common-gate transistor M1's gate (VbiasCG). Controls M1 operating region; constrained to ≤ Vdd (1.2 V)."
}
```

Notes and rationale:
- L is fixed at 45 nm (0.045e-6 m) because only W/L matters for optimization; the user requested keeping L constant.
- All initial parameter values in initial_params match the original values in your circuit code exactly.
- The transistor width ranges enforce 1–500× the channel length per your constraint; log sampling is recommended for widths and resistances to cover orders of magnitude efficiently.
- The CG bias voltage range is conservative (0.816–1.2 V) and respects the supply limit (≤ 1.2 V) and the 0.8–1.2× rule.
- Resistances are expressed in kΩ in the params (and appended with 'k' when creating the Circuit) to match common unit usage in PySpice and keep the initial values identical to your original netlist.