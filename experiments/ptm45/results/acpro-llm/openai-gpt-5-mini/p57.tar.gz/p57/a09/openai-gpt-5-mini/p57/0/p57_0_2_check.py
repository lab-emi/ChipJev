from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed OP')
# Define MOSFET models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)           # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, "dc 0.80 ac 1n")
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)   # PMOS gate bias = 0.78 V
# First stage: NMOS common-source (M1) with PMOS active load (M2)
# M1: drain Node1, gate Vin, source gnd, bulk gnd
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# M2: PMOS active load for M1: drain Node1, gate Vbias_p, source Vdd, bulk Vdd
circuit.MOSFET('M2', 'Node1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=12e-6, l=0.045e-6)
# Buffer 1: NMOS source follower (M3) with pull-up resistor Rb1 to Vdd
# M3: drain Buf1_d, gate Node1, source Buf1, bulk Buf1
circuit.MOSFET('M3', 'Buf1_d', 'Node1', 'Buf1', 'Buf1',
               model='nmos_model', w=10e-6, l=0.045e-6)
# Rb1: pull-up for M3 drain (stronger pull-up to ensure drain bias)
circuit.R('b1', 'Buf1_d', 'Vdd', 5@u_kΩ)
# R_s1: pull-down from Buf1 to ground to provide DC bias for source-follower (stronger bias)
circuit.R('s1', 'Buf1', circuit.gnd, 10@u_kΩ)
# Second stage: NMOS common-source (M4) with PMOS active load (M5)
# M4: drain Node2, gate Buf1 (buffer output), source gnd, bulk gnd
circuit.MOSFET('M4', 'Node2', 'Buf1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# M5: PMOS active load for M4: drain Node2, gate Vbias_p, source Vdd, bulk Vdd
circuit.MOSFET('M5', 'Node2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=12e-6, l=0.045e-6)
# Buffer 2: final NMOS source follower (M6) with pull-up resistor Rb2 to Vdd
# M6: drain Buf2_d, gate Node2, source Vout, bulk Vout
circuit.MOSFET('M6', 'Buf2_d', 'Node2', 'Vout', 'Vout',
               model='nmos_model', w=12e-6, l=0.045e-6)
# Rb2: pull-up for M6 drain (stronger pull-up)
circuit.R('b2', 'Buf2_d', 'Vdd', 5@u_kΩ)
# R_s2: pull-down from Vout to ground to provide DC bias for final source-follower (stronger bias)
circuit.R('s2', 'Vout', circuit.gnd, 10@u_kΩ)
# End with simulator creation (no AC sources; DC operating point is considered)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

simulator_id = circuit.simulator()
mosfet_names = []
import PySpice.Spice.BasicElement
for element in circuit.elements:
    if isinstance(element, PySpice.Spice.BasicElement.Mosfet):
        mosfet_names.append(element.name)

mosfet_name_ids = []
for mosfet_name in mosfet_names:
    mosfet_name_ids.append(f"@{mosfet_name}[id]")

simulator_id.save_internal_parameters(*mosfet_name_ids)
analysis_id = simulator_id.operating_point()

id_correct = 1
for mosfet_name in mosfet_names:
    mosfet_id = float(analysis_id[f"@{mosfet_name}[id]"][0])
    if mosfet_id < 1e-5:
        id_correct = 0
        print("The circuit does not function correctly. "
          "the current I_D for {} is 0. ".format(mosfet_name)
          .format(mosfet_name))

if id_correct == 0:
    print("Please fix the wrong operating point.\n")
    sys.exit(2)


frequency = 100@u_Hz
analysis = simulator.ac(start_frequency=frequency, stop_frequency=frequency*10, 
    number_of_points=2, variation='dec')

import numpy as np

node = 'vout'

# find whether vout in the circuit

has_node = False
# find any node with "vout"
for element in circuit.elements:
    # get pins
    for pin in element.pins:
        if "vout" == str(pin.node).lower():
            node = str(pin.node)
            has_node = True
            break

if has_node == False:
    for element in circuit.elements:
        for pin in element.pins:
            if "vout" in str(pin.node).lower():
                node = str(pin.node)
                break

output_voltage = analysis[node].as_ndarray()[0]
gain = np.abs(output_voltage / (1e-9))

print(f"Voltage Gain (Av) at 100 Hz: {gain}")

required_gain = 1e-5
import sys
if gain > required_gain:
    print("The circuit functions correctly at 100 Hz.\n")
    sys.exit(0)
else:
    print("The circuit does not function correctly.\n"
          "the gain is less than 1e-5.\n"
          "Please fix the wrong operating point.\n")
    sys.exit(2)