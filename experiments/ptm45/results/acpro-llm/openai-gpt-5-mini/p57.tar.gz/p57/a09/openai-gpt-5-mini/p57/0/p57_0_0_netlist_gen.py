from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier')
# Define MOSFET models (provided by external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)         # Vin DC bias = Vth + 0.2 = 0.42 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78) # PMOS gate bias = 0.78 V
# First stage: NMOS common-source (M1) with PMOS active load (M2)
# M1: drain Node1, gate Vin, source gnd, bulk gnd
circuit.MOSFET('M1', 'Node1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# M2: PMOS active load for M1: drain Node1, gate Vbias_p, source Vdd, bulk Vdd
circuit.MOSFET('M2', 'Node1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=12e-6, l=0.045e-6)
# Buffer 1: NMOS source follower (M3) with pull-up resistor Rb1 to Vdd
# M3: drain Buf1_d, gate Node1, source Buf1, bulk Buf1
circuit.MOSFET('M3', 'Buf1_d', 'Node1', 'Buf1', 'Buf1',
               model='nmos_model', w=10e-6, l=0.045e-6)
# Rb1: pull-up for M3 drain
circuit.R('b1', 'Buf1_d', 'Vdd', 10@u_kΩ)
# Second stage: NMOS common-source (M4) with PMOS active load (M5)
# M4: drain Node2, gate Buf1 (buffer output), source gnd, bulk gnd
circuit.MOSFET('M4', 'Node2', 'Buf1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=0.045e-6)
# M5: PMOS active load for M4: drain Node2, gate Vbias_p, source Vdd, bulk Vdd
circuit.MOSFET('M5', 'Node2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=12e-6, l=0.045e-6)
# Buffer 2: final NMOS source follower (M6) with pull-up resistor Rb2 to Vdd
# M6: drain Buf2_d, gate Node2, source Vout, bulk Vout
circuit.MOSFET('M6', 'Buf2_d', 'Node2', 'Vout', 'Vout',
               model='nmos_model', w=12e-6, l=0.045e-6)
# Rb2: pull-up for M6 drain
circuit.R('b2', 'Buf2_d', 'Vdd', 10@u_kΩ)
# End with simulator creation (no AC sources; DC operating point is considered)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
