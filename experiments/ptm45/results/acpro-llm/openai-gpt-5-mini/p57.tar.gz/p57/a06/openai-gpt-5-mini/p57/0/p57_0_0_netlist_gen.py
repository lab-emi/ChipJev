from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Cascoded Two-Stage GBW-Optimized Amplifier')
# Models (assumed provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)              # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.5)              # Vin DC bias ~0.5 V (input node present)
# Bias voltages computed using Vth = 0.22V (per instructions)
# Vbias_n ~ Vth + 0.25
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.47)      # NMOS cascode gate bias
# Vbias_p ~ Vdd - Vth - 0.25
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.73)      # PMOS active-load gate bias
# Transistor geometric parameters (45 nm node)
L = 0.045e-6  # 45 nm channel length
# First stage: NMOS common-source (M1) with NMOS cascode (M2) and PMOS active-load (M3)
# M1: drain NodeA, gate Vin, source gnd, bulk gnd
circuit.MOSFET('M1', 'NodeA', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)
# M2: cascode above M1: drain NodeN1 (first-stage output), gate Vbias_n, source NodeA, bulk NodeA
circuit.MOSFET('M2', 'NodeN1', 'Vbias_n', 'NodeA', 'NodeA',
               model='nmos_model', w=6e-6, l=L)
# M3: PMOS active load (current source): drain NodeN1, gate Vbias_p, source Vdd, bulk Vdd
circuit.MOSFET('M3', 'NodeN1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=24e-6, l=L)
# Second stage: NMOS common-source (M4) with cascode (M5) and resistive load R1
# M4: drain NodeB, gate NodeN1 (driven by stage1), source gnd, bulk gnd
circuit.MOSFET('M4', 'NodeB', 'NodeN1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=12e-6, l=L)
# M5: cascode above M4: drain Vout, gate Vbias_n, source NodeB, bulk NodeB
circuit.MOSFET('M5', 'Vout', 'Vbias_n', 'NodeB', 'NodeB',
               model='nmos_model', w=6e-6, l=L)
# Load resistor from Vout to Vdd
circuit.R('1', 'Vout', 'Vdd', 10@u_kOhm)
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
