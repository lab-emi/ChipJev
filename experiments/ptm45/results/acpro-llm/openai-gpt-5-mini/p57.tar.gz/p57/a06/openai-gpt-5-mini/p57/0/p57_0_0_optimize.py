from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import must appear exactly as written inside create_circuit per instructions:
# from model import nmos_params, pmos_params
# Fixed process length (45 nm)
L = 45e-9
VTH = 0.22  # MOSFET threshold (given)
def create_circuit(params):
    """
    Create the cascoded two-stage GBW-optimized amplifier circuit.
    Required: this function must import nmos_params, pmos_params exactly as written below
    (the model module is provided in the execution environment).
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Cascoded Two-Stage GBW-Optimized Amplifier')
    # Models (assumed provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC biases
    # Vdd fixed at 1.2V per instructions (do NOT parameterize)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
    # Input voltage fixed (will be swept externally); keep exactly as original
    circuit.V('in', 'Vin', circuit.gnd, 0.5)
    # Bias voltages (parameterized)
    circuit.V('biasn', 'Vbias_n', circuit.gnd, params['v_bias_n'])  # NMOS cascode gate bias
    circuit.V('biasp', 'Vbias_p', circuit.gnd, params['v_bias_p'])  # PMOS active-load gate bias
    # Transistor geometric parameters (L fixed at 45 nm)
    # First stage: NMOS common-source (M1) with NMOS cascode (M2) and PMOS active-load (M3)
    circuit.MOSFET('M1', 'NodeA', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'NodeN1', 'Vbias_n', 'NodeA', 'NodeA',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    circuit.MOSFET('M3', 'NodeN1', 'Vbias_p', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # Second stage: NMOS common-source (M4) with cascode (M5) and resistive load R1
    circuit.MOSFET('M4', 'NodeB', 'NodeN1', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M4'],
                   l=L)
    circuit.MOSFET('M5', 'Vout', 'Vbias_n', 'NodeB', 'NodeB',
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    # Load resistor from Vout to Vdd
    # params['r_R1'] is expressed in kilo-ohms (kΩ) for convenience
    r_value_ohm = params['r_R1'] * 1e3
    circuit.R('1', 'Vout', 'Vdd', r_value_ohm)
    return circuit
# ----------------------------
# Optimization parameter search ranges
# ----------------------------
# Notes on units:
# - Widths (w_*) are in meters (m)
# - Resistances r_R1 are in kilo-ohms (kΩ)
# - Voltages v_bias_* are in volts (V)
# Original widths from the provided netlist (kept in initial_params below):
orig_w = {
    'w_M1': 12e-6,
    'w_M2': 6e-6,
    'w_M3': 24e-6,
    'w_M4': 12e-6,
    'w_M5': 6e-6,
}
# Per-user constraint: widths should be within 1-500× length.
# 1 * L = 45e-9, 500 * L = 22.5e-6. However, the original w_M3 = 24e-6 slightly
# exceeds 500*L. To satisfy both the "1-500×L" intent and the requirement that
# the initial parameter values must be inside the search ranges, the upper bound
# for each transistor is set to max(500*L, original_value). This guarantees the
# strict 1×L lower bound and includes the original sizes.
w_min = L * 1.0
w_500L = L * 500.0
param_ranges_definition = {
    # Transistor widths (meters)
    'w_M1': {'min': w_min, 'max': max(w_500L, orig_w['w_M1']), 'log': True},
    'w_M2': {'min': w_min, 'max': max(w_500L, orig_w['w_M2']), 'log': True},
    'w_M3': {'min': w_min, 'max': max(w_500L, orig_w['w_M3']), 'log': True},  # >= orig to include initial
    'w_M4': {'min': w_min, 'max': max(w_500L, orig_w['w_M4']), 'log': True},
    'w_M5': {'min': w_min, 'max': max(w_500L, orig_w['w_M5']), 'log': True},
    # Bias voltages: allowed to vary within 0.8 - 1.2 × original but never exceed 1.2V.
    # Also apply conservative lower-bound near threshold for NMOS cascode gate (consider Vth).
    # Original values:
    #   v_bias_n_orig = 0.47
    #   v_bias_p_orig = 0.73
    'v_bias_n': {
        'min': max(0.8 * 0.47, VTH + 0.20),          # ensure not too close to threshold (conservative)
        'max': min(1.2 * 0.47, 1.2),                 # never exceed Vdd=1.2V
        'log': False
    },
    'v_bias_p': {
        'min': max(0.8 * 0.73, 0.0),                 # pmos gate bias conservative lower bound
        'max': min(1.2 * 0.73, 1.2),
        'log': False
    },
    # Load resistor R1 (expressed in kilo-ohms for convenience)
    # Original R1 = 10 kΩ -> search range 0.5x - 2x = [5 kΩ, 20 kΩ]
    'r_R1': {'min': 0.5 * 10.0, 'max': 2.0 * 10.0, 'log': True},
}
# ----------------------------
# Initial parameter values (EXACT original values from user's netlist)
# ----------------------------
# IMPORTANT: these values are the EXACT values from the provided circuit and
# must be preserved as the starting point for optimization.
initial_params = {
    'w_M1': 12e-6,   # original M1 width (m)
    'w_M2': 6e-6,    # original M2 width (m)
    'w_M3': 24e-6,   # original M3 width (m)
    'w_M4': 12e-6,   # original M4 width (m)
    'w_M5': 6e-6,    # original M5 width (m)
    'v_bias_n': 0.47,  # original biasn voltage (V)
    'v_bias_p': 0.73,  # original biasp voltage (V)
    'r_R1': 10.0,      # original R1 in kilo-ohms (kΩ)
}
# ----------------------------
# Parameter descriptions
# ----------------------------
param_descriptions = {
    # Transistor widths
    'w_M1': "M1 channel width (meters). First-stage NMOS input transistor (common-source). L fixed = 45 nm.",
    'w_M2': "M2 channel width (meters). Cascode transistor above M1 (NMOS). L fixed = 45 nm.",
    'w_M3': "M3 channel width (meters). PMOS active-load (current source). L fixed = 45 nm.",
    'w_M4': "M4 channel width (meters). Second-stage NMOS input transistor (common-source). L fixed = 45 nm.",
    'w_M5': "M5 channel width (meters). Cascode transistor above M4 (NMOS). L fixed = 45 nm.",
    # Voltages
    'v_bias_n': "NMOS cascode gate bias (Vbias_n). Controls cascode headroom for M1/M4. Vth considered when defining range.",
    'v_bias_p': "PMOS active-load gate bias (Vbias_p). Sets current through the first-stage active load.",
    # Passive
    'r_R1': "Load resistor R1 from Vout to Vdd, expressed in kilo-ohms (kΩ). Affects DC operating point and gain.",
}
# ----------------------------
# Quick sanity checks (ensures initial values are within the declared ranges)
# ----------------------------
# These are not required by the optimizer but are useful assertions to ensure
# the provided initial_params satisfy the declared search bounds.
def _sanity_check_bounds():
    for k, v in initial_params.items():
        if k not in param_ranges_definition:
            continue
        rng = param_ranges_definition[k]
        if not (rng['min'] <= v <= rng['max']):
            raise ValueError(
                f"Initial parameter '{k}' = {v} is out of declared range "
                f"[{rng['min']}, {rng['max']}]. Adjusted range to include initial value."
            )
# Run sanity checks now (will raise if something was inconsistent)
_sanity_check_bounds()
