from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier')
# Define device models (assumed available in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and bias
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)                  # Vdd = 1.2 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78)          # PMOS gate bias for current sources (~1.2-0.22-0.2)
circuit.V('in', 'Vin', circuit.gnd, 0.5)                  # DC input bias for operating point (no AC)
# Stage 1: NMOS M1 (CS) with PMOS current-source load M2
# MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'D1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M2', 'D1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Stage 2: NMOS M3 (CS) with PMOS current-source load M4
circuit.MOSFET('M3', 'D2', 'D1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=0.045e-6)
circuit.MOSFET('M4', 'D2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=0.045e-6)
# Stage 3: NMOS M5 (CS) driving Vout with resistor load R1
circuit.MOSFET('M5', 'Vout', 'D2', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=0.045e-6)
circuit.R('1', 'Vout', 'Vdd', 5@u_kOhm)
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
