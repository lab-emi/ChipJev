from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized PySpice circuit.
    - The module 'model' must provide nmos_params and pmos_params (imported above).
    - vdd and input voltages are fixed (not parameterized).
    - Transistor lengths are fixed to L_MIN (45 nm). Widths are taken from params.
    - Resistances are passed as kΩ values in params (stringified when creating R elements).
    - Vbp (PMOS gate bias) is parameterized but constrained inside create/param ranges.
    """
    circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed Operating Point')
    # transistor models (from external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2V (45nm technology)
    # Input DC bias (fixed, not parameterized)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # Vin fixed at 0.42V for DC operating point
    # PMOS bias for load transistors - parameterized
    circuit.V('bp', 'Vbp', circuit.gnd, params['Vbp'])  # parameterized but constrained <= 1.2V
    # Provide reasonable DC loading so nodes acquire well-defined operating points
    # Resistances are interpreted as kΩ in the params dict
    circuit.R('load', 'Vout', circuit.gnd, f"{params['r_load']}k")    # Output DC load (kΩ)
    circuit.R('pu_D2', 'D2', 'Vdd', f"{params['r_pu_D2']}k")           # Weak pull-up to bias gate of M5 (kΩ)
    # Device length (fixed for 45 nm technology)
    L_MIN = 0.045e-6  # 45 nm, fixed
    # Stage 1: Common-source NMOS M1 with PMOS active load M2
    # M1: drain = D1, gate = Vin, source = gnd, bulk = gnd
    circuit.MOSFET('M1', 'D1', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M1'], l=L_MIN)
    # M2: PMOS active load: drain = D1, gate = Vbp, source = Vdd, bulk = Vdd
    circuit.MOSFET('M2', 'D1', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M2'], l=L_MIN)
    # Stage 2: Common-source NMOS M3 with PMOS active load M4
    # M3: drain = D2, gate = D1, source = gnd, bulk = gnd
    circuit.MOSFET('M3', 'D2', 'D1', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=params['w_M3'], l=L_MIN)
    # M4: PMOS active load: drain = D2, gate = Vbp, source = Vdd, bulk = Vdd
    circuit.MOSFET('M4', 'D2', 'Vbp', 'Vdd', 'Vdd',
                   model='pmos_model', w=params['w_M4'], l=L_MIN)
    # Stage 3: Output buffer - NMOS source follower M5
    # M5: drain = Vdd, gate = D2, source = Vout, bulk = Vout (bulk tied to source per instruction)
    circuit.MOSFET('M5', 'Vdd', 'D2', 'Vout', 'Vout',
                   model='nmos_model', w=params['w_M5'], l=L_MIN)
    return circuit
# ======================================================================
# Optimization parameter search ranges (annotated)
# NOTE: units used:
#  - transistor widths: meters (m)
#  - resistors: kΩ (value placed into R as "<value>k")
#  - voltages: volts (V)
# The initial_params dict (below) contains EXACT original values from the provided circuit.
# ======================================================================
# Fixed length (for reference, not a parameter)
L_MIN = 0.045e-6  # 45 nm
# Helper: theoretical max width per "1-500×L" rule
_theoretical_max_W = 500 * L_MIN  # 500 * 45 nm = 22.5e-6 m
# Original widths from the user's netlist (used to ensure initial values are inside ranges)
# M1: 20e-6, M2: 40e-6, M3: 20e-6, M4: 40e-6, M5: 50e-6
# Because some original widths exceed 500*L (22.5e-6), ranges are set per the rule but expanded
# where necessary to include the exact original values (so the initial point is valid).
param_ranges_definition = {
    # Transistor widths (W). Length L is fixed (45 nm). W range nominally 1-500×L,
    # but expanded where the original width exceeds 500×L to ensure initial_params are valid.
    'w_M1': {
        'min': L_MIN,                      # 1 × L (45 nm)
        'max': max(_theoretical_max_W, 20e-6),  # allow at least original value if larger than 500×L
        'log': True
    },
    'w_M2': {
        'min': L_MIN,
        'max': max(_theoretical_max_W, 40e-6),  # original 40e-6 > 500×L, so max raised to include it
        'log': True
    },
    'w_M3': {
        'min': L_MIN,
        'max': max(_theoretical_max_W, 20e-6),
        'log': True
    },
    'w_M4': {
        'min': L_MIN,
        'max': max(_theoretical_max_W, 40e-6),
        'log': True
    },
    'w_M5': {
        'min': L_MIN,
        'max': max(_theoretical_max_W, 50e-6),  # original 50e-6 > 500×L, include it
        'log': True
    },
    # Resistive loads: original values are in kΩ (10 kΩ each).
    # Allowed range: 0.5 - 2 × original.
    'r_load': {
        'min': 0.5 * 10.0,   # 5 kΩ
        'max': 2.0 * 10.0,   # 20 kΩ
        'log': True
    },
    'r_pu_D2': {
        'min': 0.5 * 10.0,   # 5 kΩ
        'max': 2.0 * 10.0,   # 20 kΩ
        'log': True
    },
    # Bias voltages (except Vdd and Vin which are fixed):
    # Apply 0.8 - 1.2× original range but never exceed 1.2 V (supply).
    # Original Vbp = 0.78 V -> allowed range: [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    'Vbp': {
        'min': max(0.0, 0.8 * 0.78),   # 0.624 V
        'max': min(1.2, 1.2 * 0.78),   # 0.936 V (also capped by absolute 1.2 V)
        'log': False
    },
    # No capacitors present in the original netlist to parameterize.
    # Load capacitors (if present) were to be kept fixed; none to include here.
}
# Initial parameter values (EXACT original circuit values - MUST be preserved)
initial_params = {
    # Transistor widths (exact values from original netlist)
    'w_M1': 20e-6,   # M1 original width (m)
    'w_M2': 40e-6,   # M2 original width (m)
    'w_M3': 20e-6,   # M3 original width (m)
    'w_M4': 40e-6,   # M4 original width (m)
    'w_M5': 50e-6,   # M5 original width (m)
    # Resistances: original were 10 kΩ each. Represented here as numeric kΩ values.
    'r_load': 10.0,    # 10 kΩ
    'r_pu_D2': 10.0,   # 10 kΩ
    # Bias voltage (exact original)
    'Vbp': 0.78,      # original PMOS gate bias (V)
}
# ======================================================================
# Brief description of physical meaning of each parameter
# ======================================================================
# w_M1, w_M2, w_M3, w_M4, w_M5  : Transistor widths (meters). With fixed channel length
#                                 L = 45 nm, these set the device W/L ratio and hence current,
#                                 gm, output resistance and speed. Wider devices conduct more current,
#                                 increase gm but also increase parasitic capacitance and area.
#
# r_load                        : Output DC load resistor from Vout to ground (kΩ). Sets DC loading
#                                 on the amplifier output and influences DC operating point and gain.
#
# r_pu_D2                       : Weak pull-up resistor from D2 node to Vdd (kΩ). Provides biasing
#                                 to the gate of the output device M5. Adjusting it shifts DC node voltages.
#
# Vbp                           : Bias voltage applied to gates of PMOS active loads (Vbp). Sets
#                                 current through PMOS loads and therefore operating points of stages.
#
# Notes:
# - Vdd is fixed at 1.2 V (not parameterized).
# - Vin is fixed at 0.42 V (DC bias), not parameterized (to allow DC sweeps externally).
# - Transistor length L is fixed at 45 nm per 45 nm technology; only width is optimized.
# - The widths ranges nominally enforce 1-500×L; however, to satisfy the requirement that the
#   initial_params EXACTLY match the original netlist, the maximum widths are expanded where the
#   original widths exceed 500×L (these expansions are noted in the param_ranges_definition).
# ======================================================================
