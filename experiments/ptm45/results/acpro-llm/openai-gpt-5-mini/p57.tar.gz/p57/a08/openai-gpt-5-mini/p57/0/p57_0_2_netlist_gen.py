from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed Operating Point')
# Define transistor models (parameters provided by the external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# Input DC bias (Vin) - DC operating point (no AC source)
# Use Vin ~ Vth + 0.2 V to bias the input NMOS in moderate conduction (Vth = 0.22 V)
circuit.V('in', 'Vin', circuit.gnd, 0.42)  # 0.42 V
# PMOS bias for load transistors (Vbp)
circuit.V('bp', 'Vbp', circuit.gnd, 0.78)  # ~ Vdd - |Vth| - 0.2
# Provide reasonable DC loading so nodes acquire well-defined operating points
# Lower resistance values than before to ensure measurable DC currents in simulation.
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)    # Output DC load (10k)
circuit.R('pu_D2', 'D2', 'Vdd', 10@u_kΩ)           # Weak pull-up to bias gate of M5 (10k)
# Device dimensions (45 nm technology)
L_MIN = 0.045e-6  # 45 nm
# Stage 1: Common-source NMOS M1 with PMOS active load M2
# M1: drain = D1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'D1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L_MIN)
# M2: PMOS active load: drain = D1, gate = Vbp, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'D1', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L_MIN)
# Stage 2: Common-source NMOS M3 with PMOS active load M4
# M3: drain = D2, gate = D1, source = gnd, bulk = gnd
circuit.MOSFET('M3', 'D2', 'D1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L_MIN)
# M4: PMOS active load: drain = D2, gate = Vbp, source = Vdd, bulk = Vdd
circuit.MOSFET('M4', 'D2', 'Vbp', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=L_MIN)
# Stage 3: Output buffer - NMOS source follower M5
# M5: drain = Vdd, gate = D2, source = Vout, bulk = Vout (bulk tied to source per instruction)
circuit.MOSFET('M5', 'Vdd', 'D2', 'Vout', 'Vout',
               model='nmos_model', w=50e-6, l=L_MIN)
# End: prepare simulator (no extra code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
