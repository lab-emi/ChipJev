from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Fixed Operating Point')
# MOS models (provided externally in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias ~ Vth + Vov (0.42 V)
# Lowered PMOS bias voltage to strengthen PMOS current sources so node n2 is pulled higher
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.50)       # PMOS load gate bias (reduced from 0.78 to 0.50 V)
circuit.V('bn', 'Vbias_n', circuit.gnd, 0.42)       # Optional NMOS reference (0.42 V)
# First stage: NMOS common-source (M1) with PMOS active load (M2)
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=0.045e-6)
circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=12e-6, l=0.045e-6)
# Second stage: NMOS common-source (M3) with stronger PMOS active load (M4)
# Reduced M3 strength and increased M4 to bias node n2 higher (so M5 gate > Vth)
circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=0.045e-6)
circuit.MOSFET('M4', 'n2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# Output buffer: NMOS source-follower (M5)
# Bulk is connected to the source node 'Vout' per requirement (bulk connected to source).
# Increased M5 width to ensure adequate drive.
circuit.MOSFET('M5', 'Vdd', 'n2', 'Vout', 'Vout',
               model='nmos_model', w=12e-6, l=0.045e-6)
# Light load at output so M5 doesn't have to source large current to establish Vout < n2 - Vth
circuit.R('load', 'Vout', circuit.gnd, 100@u_kΩ)
# End: create simulator
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_2_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
