from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier - Corrected')
# MOS models (provided externally in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias ~ Vth + Vov (0.42 V)
circuit.V('bp', 'Vbias_p', circuit.gnd, 0.78)       # PMOS load gate bias (1.2 - (0.22+0.2) = 0.78 V)
circuit.V('bn', 'Vbias_n', circuit.gnd, 0.42)       # Optional NMOS reference (0.42 V)
# First stage: NMOS common-source (M1) with PMOS active load (M2)
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=4e-6, l=0.045e-6)
circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.045e-6)
# Second stage: NMOS common-source (M3) with PMOS active load (M4)
circuit.MOSFET('M3', 'n2', 'n1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=0.045e-6)
circuit.MOSFET('M4', 'n2', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=0.045e-6)
# Output buffer: NMOS source-follower (M5)
# Note: bulk is connected to the source node 'Vout' to satisfy MOSFET bulk-to-source rule.
circuit.MOSFET('M5', 'Vdd', 'n2', 'Vout', 'Vout',
               model='nmos_model', w=6e-6, l=0.045e-6)
# Load/pull-down at output to ensure Vout stays low enough so Vgs(M5)=V(n2)-V(Vout) > Vth
circuit.R('load', 'Vout', circuit.gnd, 10@u_kΩ)
# End: create simulator
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_1_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
