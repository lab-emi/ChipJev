from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier')
# MOS models (from provided model parameters)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC operating points only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('biasp', 'VbiasP', circuit.gnd, 0.78) # PMOS bias: Vdd - (|Vth| + 0.2) = 0.78 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)       # Vin DC bias: Vth + 0.2 = 0.42 V
# Technology sizing (45 nm)
L = 0.045e-6  # 45 nm channel length
# Stage 1: Common-source NMOS (M1) with PMOS active load (M2)
# M1: drain = N1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'N1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# M2: PMOS current-source load for stage 1: drain = N1, gate = VbiasP, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'N1', 'VbiasP', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=L)
# Stage 2: Common-source NMOS (M3) with PMOS active load (M4)
# M3: drain = Vout, gate = N1, source = gnd, bulk = gnd
circuit.MOSFET('M3', 'Vout', 'N1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# M4: PMOS current-source load for stage 2: drain = Vout, gate = VbiasP, source = Vdd, bulk = Vdd
circuit.MOSFET('M4', 'Vout', 'VbiasP', 'Vdd', 'Vdd',
               model='pmos_model', w=16e-6, l=L)
# The input node "Vin" and output node "Vout" are present as required.
# No AC sources are used; this netlist is suitable for DC operating point and further small-signal analysis.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
