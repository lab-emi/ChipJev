from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
# Create circuit
circuit = Circuit('Multi-Stage GBW-Optimized Amplifier')
# Define MOSFET models from provided params
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)       # Vin DC bias ~ Vth + 0.2 V
circuit.V('biasp', 'Vbias_p', circuit.gnd, 0.78) # PMOS current-source gate bias
# Node summary:
# Vin  - input node (provided)
# n1   - drain of first-stage CS (internal)
# Vout_pre - drain of second stage (internal)
# Vout - output node (provided)
# Technology length (45 nm)
L = 45e-9
# Stage 1: Input common-source NMOS (M1) with PMOS active current-source load (M2)
# M1: drain = n1, gate = Vin, source = gnd, bulk = gnd
circuit.MOSFET('M1', 'n1', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=10e-6, l=L)
# M2: PMOS current-source load: drain = n1, gate = Vbias_p, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'n1', 'Vbias_p', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
# Stage 2: Common-source NMOS (M3) driven from node n1, resistive load R1 to Vdd
# M3: drain = Vout_pre, gate = n1, source = gnd, bulk = gnd
circuit.MOSFET('M3', 'Vout_pre', 'n1', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=L)
# Resistive load to set bias and pole (choose modest value for bandwidth)
circuit.R('1', 'Vout_pre', 'Vdd', 5@u_kΩ)
# Stage 3: Source-follower buffer (M4)
# M4: drain = Vdd, gate = Vout_pre, source = Vout, bulk = Vout (bulk tied to source per rule)
circuit.MOSFET('M4', 'Vdd', 'Vout_pre', 'Vout', 'Vout',
               model='nmos_model', w=5e-6, l=L)
# End of netlist; simulator may be used for operating-point or AC/BW analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p57/0/p57_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
