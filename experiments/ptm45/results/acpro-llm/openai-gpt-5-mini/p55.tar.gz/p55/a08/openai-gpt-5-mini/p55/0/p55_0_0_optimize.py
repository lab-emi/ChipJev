from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
def create_circuit(params):
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage GBW-Optimized Amplifier')
    # MOSFET models (from provided model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (do not parameterize)
    # Input voltage (fixed, not parameterized; will be swept externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.50)  # Vin fixed at 0.50 V (do not parameterize)
    # PMOS gate bias (parameterized). Constrained so it never exceeds 1.2 V by design.
    circuit.V('pbias', 'Vpbias', circuit.gnd, params['V_pbias'])
    # Geometry: L is fixed for this technology (45 nm)
    L = 45e-9
    # M1: NMOS common-source amplifying transistor (W parameterized, L fixed)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    # M2: PMOS active current-source load (W parameterized, L fixed). Gate tied to Vpbias,
    # source tied to Vdd (bulk to Vdd).
    circuit.MOSFET('M2', 'Vout', 'Vpbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)
    # Note: No external load resistor or capacitor was present in the original netlist.
    # If you add passive components later, follow the same parameterization rules.
    return circuit
# Optimization parameter search ranges (annotated)
# NOTE: L = 45e-9 (fixed). Width ranges are given in meters.
L = 45e-9
original_w_M1 = 200e-6  # original (exact) value from provided netlist
original_w_M2 = 100e-6  # original (exact) value from provided netlist
original_V_pbias = 0.78  # original (exact) value from provided netlist
param_ranges_definition = {
    # Transistor widths (only W is optimized; L is fixed)
    # Target rule: W between 1×L and 500×L. However, the original widths exceed 500×L;
    # to satisfy the requirement that initial_params must be inside the ranges, the upper
    # bound is set to at least the original value. Where original <= 500×L the upper bound
    # is 500×L, otherwise it is expanded to include the original value.
    'w_M1': {
        'min': L * 1.0,                          # 1 × L
        'max': max(L * 500.0, original_w_M1),    # 500 × L OR expanded to include original
        'log': True                              # use log sampling for wide geometry ranges
    },
    'w_M2': {
        'min': L * 1.0,
        'max': max(L * 500.0, original_w_M2),
        'log': True
    },
    # Voltages (except Vdd and input voltages which are fixed)
    # Rule: 0.8-1.2× original value, but must not exceed 1.2 V (supply).
    # Use linear sampling for voltages.
    'V_pbias': {
        'min': max(0.0, 0.8 * original_V_pbias),  # 0.8× original
        'max': min(1.2, 1.2 * original_V_pbias),  # 1.2× original but never > 1.2 V
        'log': False
    },
    # (No resistors or capacitors were present in the original netlist, so none are defined.)
}
# Initial parameter values (EXACT original circuit values; must be inside the ranges above)
initial_params = {
    'w_M1': original_w_M1,   # 200e-6  (exact original width for M1)
    'w_M2': original_w_M2,   # 100e-6  (exact original width for M2)
    'V_pbias': original_V_pbias,  # 0.78 (exact original bias voltage)
}
# Brief descriptions of each parameter (physical meaning)
param_descriptions = {
    'w_M1': 'Channel width (W) of M1, the NMOS amplifier transistor (meters). L fixed at 45e-9 m.',
    'w_M2': 'Channel width (W) of M2, the PMOS active load transistor (meters). L fixed at 45e-9 m.',
    'V_pbias': 'DC gate bias applied to PMOS load (Vpbias). Controls the PMOS load current and operating point. Range constrained to 0.8–1.2× original but never above Vdd=1.2 V.'
}
# Short note on biasing and Vth:
# The process threshold (Vth ≈ 0.22 V) was considered when choosing the V_pbias range.
# The chosen 0.8–1.2× multiplier keeps the bias conservative around the original operating point
# (original Vpbias = 0.78 V), while ensuring it does not exceed the supply (1.2 V).
