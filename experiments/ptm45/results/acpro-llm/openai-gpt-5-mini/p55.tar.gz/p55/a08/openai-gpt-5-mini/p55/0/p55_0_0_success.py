from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage GBW-Optimized Amplifier')
# Define MOSFET models (from provided model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)      # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.50)     # Vin DC bias (no AC) ~ Vth + 0.28 V to bias M1
circuit.V('pbias', 'Vpbias', circuit.gnd, 0.78)  # PMOS gate bias (Vdd - |Vth| - 0.2)
# Devices (MOSFET definition format: name, drain, gate, source, bulk, model=..., w=..., l=...)
# M1: NMOS common-source amplifying transistor
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=200e-6, l=45e-9)
# M2: PMOS active current-source load (gate biased by Vpbias)
circuit.MOSFET('M2', 'Vout', 'Vpbias', 'Vdd', 'Vdd',
               model='pmos_model', w=100e-6, l=45e-9)
# The output node is Vout (connected to both M1 and M2 drains)
# No AC sources or external loads are included here — this netlist is for operating point / further AC analysis.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
