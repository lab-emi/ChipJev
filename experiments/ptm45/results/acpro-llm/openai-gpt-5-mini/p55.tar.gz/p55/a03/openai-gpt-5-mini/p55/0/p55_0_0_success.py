from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier Maximizing GBW')
# Define transistor models (provided by the external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC input bias (no AC sources)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.47)        # Vin DC bias = Vth(0.22) + 0.25 = 0.47 V
# Single-stage common-source NMOS amplifier
# M1: drain = Vout, gate = Vin, source = gnd, bulk = gnd
# Use nominal 45 nm channel length and wide device to maximize gm
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# Resistive load from Vout to Vdd (sets bias current). R = 3 kΩ (≈ 200 µA bias current).
circuit.R('1', 'Vout', 'Vdd', 3@u_kΩ)
# Set output node name explicitly exists: Vout
# End of topology: ready for DC/AC analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
