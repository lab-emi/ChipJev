```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: The model import requested below must appear exactly as written inside create_circuit()

def create_circuit(params):
    """
    Create the Single-Stage CS amplifier circuit with parameterized components.

    Required: this function must include the line:
        from model import nmos_params, pmos_params
    exactly as written (the model module is provided by the execution environment).
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier Maximizing GBW')

    # Transistor models (external model parameters provided by model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Fixed supply = 1.2 V (45 nm process)

    # Input voltage (fixed, not parameterized). Kept fixed for DC sweeps to find operating point.
    circuit.V('in', 'Vin', circuit.gnd, 0.47)  # Original bias = Vth(0.22V) + 0.25V = 0.47 V

    # MOSFET M1: Single-stage common-source NMOS amplifier
    # Keep length fixed to the 45 nm process value; width is parameterized for optimization.
    L_M1 = 45e-9  # fixed channel length (45 nm)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_M1)

    # Resistive load from Vout to Vdd (parameterized)
    # The parameter r_R1 is provided in kilo-ohms (kΩ). PySpice accepts strings such as "3k".
    circuit.R('1', 'Vout', 'Vdd', f"{params['r_R1']}k")

    # No explicit capacitors in the original netlist; if a fixed load capacitor existed it would be kept fixed.

    return circuit


# Optimization parameter search ranges (annotated for use with Optuna or similar)
# All numeric ranges are provided in SI-equivalent units unless otherwise noted (e.g., resistors in kΩ).
param_ranges_definition = {
    # Transistor dimensions
    # Width W for M1: constrained to 1 - 500 × L (L = 45e-9 m)
    # Use log sampling for wide dynamic range of widths.
    'w_M1': {
        'min': 1 * 45e-9,                # 1 × L  = 45 nm
        'max': 500 * 45e-9,              # 500 × L = 22.5 µm
        'log': True
    },

    # Passive components
    # Resistor R1 (load): expressed in kilo-ohms (kΩ) as a simple scalar,
    # search range 0.5 - 2 × original (original = 3 kΩ)
    'r_R1': {
        'min': 0.5 * 3.0,   # 1.5 kΩ
        'max': 2.0 * 3.0,   # 6.0 kΩ
        'log': True
    },

    # No capacitors or additional voltage sources were present in the original netlist.
    # If added later, follow the provided capacitor/voltage scaling rules.
}

# Initial parameters (EXACT original values from the provided netlist)
# IMPORTANT: These values are the original values and must remain unchanged.
initial_params = {
    'w_M1': 20e-6,   # Original width for M1 (20 µm)
    'r_R1': 3.0      # Original resistor R1 value (3 kΩ)
}

# Brief description of each parameter (physical meaning)
parameter_descriptions = {
    'w_M1': "Channel width of NMOS M1 (in meters). L is fixed at 45 nm; W controls W/L and thus gm, current, capacitances.",
    'r_R1': "Load resistor from Vout to Vdd (in kilo-ohms). Sets the DC bias current and load on the amplifier."
}
```

Notes and rationale:
- The function create_circuit includes the required "from model import nmos_params, pmos_params" line exactly as requested.
- Vdd and Vin are kept fixed (not included in the parameter search) so DC sweeps of input can be used to find operating points.
- L is fixed at 45e-9 (45 nm); only W is parameterized because W/L ratio is what affects device behavior for optimization.
- W range enforces the 1–500×L constraint (45e-9 — 22.5e-6 m). The initial value (20e-6 m) lies within this range.
- Resistor range enforces 0.5–2× the original 3 kΩ (1.5–6 kΩ); initial value 3.0 kΩ is within range.
- No other voltage sources or capacitors were present in your original netlist; therefore none are parameterized. If you later add compensation or other caps, include them per the provided multiplier rules (comp caps: 0.5–5×, other caps: 0.8–1.5×).
- All voltage sources, if parameterized in future, must be constrained to ≤ 1.2 V and within 0.8–1.2× their original values as requested.