```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: per requirements, the model import must appear exactly as shown inside the create_circuit function

def create_circuit(params):
    """
    Create the Single-Stage GBW-Optimized CS Amplifier circuit.
    params: dictionary containing parameterized values:
      - 'w_M1', 'w_M2' : transistor widths in meters
      - 'v_bias'       : bias voltage for PMOS current source in volts
    The function imports nmos_params and pmos_params from model as required by the framework.
    """
    from model import nmos_params, pmos_params  # must be present exactly as required

    circuit = Circuit('Single-Stage GBW-Optimized CS Amplifier')

    # MOSFET models (parameters supplied externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power & input supplies
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd fixed at 1.2 V (do NOT parameterize)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)   # Vin fixed at 0.42 V (do NOT parameterize)

    # PMOS bias supply (parameterized, constrained to <= 1.2 V)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])

    # Device geometry (L fixed to 45 nm; only W is parameterized)
    L_min = 0.045e-6  # 45 nm fixed process length

    # M1: NMOS common-source amplifier transistor (width parameterized)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)

    # M2: PMOS active current-source load (width parameterized)
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_min)

    return circuit


# ---------------------------
# Optimization parameter search ranges
# ---------------------------
# Note on width ranges:
# - Requested design rule: W within 1-500× L (L = 45 nm -> 45e-9 .. 22.5e-6 m).
# - However, the original circuit used W values (50e-6, 80e-6) that exceed 500×L.
# - To satisfy the requirement that initial_params remain EXACTLY the original values and
#   to ensure initial values lie inside the search ranges, the upper bounds here are set
#   to max(500*L, original_width). This preserves the recommended 1-500×L guideline while
#   allowing the optimizer to start from the user's exact original geometry.
L_min = 0.045e-6  # 45 nm

param_ranges_definition = {
    # Transistor widths (meters)
    # Preferred/design-rule range: 1×L .. 500×L  (45e-9 .. 22.5e-6 m)
    # Upper bounds extended to include the original widths so initial_params are inside ranges.
    'w_M1': {
        'min': 1.0 * L_min,                      # 1 × L
        'max': max(500.0 * L_min, 50e-6),        # 500 × L or original (50e-6) whichever is larger
        'log': True                              # use log sampling (wide dynamic range)
    },
    'w_M2': {
        'min': 1.0 * L_min,
        'max': max(500.0 * L_min, 80e-6),        # include original 80e-6 if it exceeds 500×L
        'log': True
    },

    # Bias voltages (conservative 0.8-1.2× original, but never exceed 1.2 V)
    # Original Vbias = 0.78 V -> range [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    'v_bias': {
        'min': 0.8 * 0.78,   # 0.624 V
        'max': min(1.2 * 0.78, 1.2),  # 0.936 V (and <= 1.2 V)
        'log': False
    }
}

# ---------------------------
# Initial parameter values (EXACT original circuit values, as required)
# ---------------------------
# IMPORTANT: these values are exactly the values used in the provided original circuit code.
initial_params = {
    'w_M1': 50e-6,    # Original M1 width (m) -- must remain exactly as provided
    'w_M2': 80e-6,    # Original M2 width (m) -- must remain exactly as provided
    'v_bias': 0.78    # Original bias voltage (V)  -- must remain exactly as provided
}

# ---------------------------
# Brief descriptions of parameters (physical meaning)
# ---------------------------
# w_M1  : Width of the NMOS amplifier transistor M1 (meters). With fixed L=45 nm, W/L sets drive current and gm.
# w_M2  : Width of the PMOS current-source/load transistor M2 (meters). With fixed L=45 nm, W/L sets current and output resistance.
# v_bias: DC bias voltage that drives the PMOS active load (Vbias). Adjusts operating point / tail current indirectly.
#
# Notes / considerations:
# - L is held constant at 45 nm (0.045e-6 m) because W/L (not absolute W alone) controls device behavior
#   for the optimization and process geometry is fixed.
# - Vdd and input source(s) (Vin) are intentionally fixed (Vdd = 1.2 V, Vin = 0.42 V) and are NOT parameterized,
#   as required by the optimization framework and DC sweep procedures.
# - The v_bias range is chosen conservatively (0.8–1.2× original value) and capped at 1.2 V (supply limit).
#   With Vth ≈ 0.22 V, the chosen v_bias range maintains the device in reasonable operating regions for small adjustments.
# - The width ranges use log sampling because device currents scale strongly with width and the search spans orders of magnitude.
# - The original widths exceed the 1–500×L recommendation; the optimizer ranges were extended to include those original values
#   so the initial_params are inside the ranges. If you prefer to strictly enforce 1–500×L, set the 'max' entries to 500*L
#   (22.5e-6) but then initial_params would be outside those ranges and would need modification.
```