from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage GBW-Optimized CS Amplifier')
# Define MOSFET models (parameters provided via imported dictionaries)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC operating points only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)   # Vin DC bias (operating point), no AC
circuit.V('bias', 'Vbias', circuit.gnd, 0.78) # Vbias for PMOS current source
# Transistor dimensions (45 nm technology, widths chosen to maximize gm while limiting capacitance)
L_min = 0.045e-6  # 45 nm
# M1: NMOS common-source amplifier transistor
# circuit.MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=50e-6, l=L_min)
# M2: PMOS active current-source load
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=80e-6, l=L_min)
# End: prepare simulator for operating point / AC analysis if desired
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
