```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # Import transistor model parameter dicts from the provided module
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier Optimized for GBW')

    # Transistor models (provided by external model module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd fixed at 1.2 V

    # Input voltage source (fixed, not parameterized; will be swept externally)
    circuit.V('in', 'Vin', circuit.gnd, 0.6)    # Vin fixed at 0.6 V

    # Bias voltage (parameterized; constrained to remain <= Vdd and within conservative range)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])

    # Transistor channel length (fixed for 45 nm process)
    L = 45e-9

    # M1: NMOS common-source amplifier transistor
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # M2: PMOS active load (current source)
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)

    # No load capacitors or resistors were present in the original netlist.
    # If present, C_load should be kept fixed and NOT included in the parameter search.

    return circuit


# =========================
# Optimization parameter search ranges (annotated)
# =========================

# Fixed process length
L_FIXED = 45e-9  # 45 nm process (kept constant)

# Original (exact) widths from the provided netlist (must be preserved in initial_params)
_original_w_M1 = 20e-6  # 20 µm
_original_w_M2 = 40e-6  # 40 µm

# Enforce the guideline: W between 1xL and 500xL where possible, BUT ensure the original
# width is always included in the search range. Therefore upper bound is at least max(500*L, original_W).
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling recommended for wide dynamic range.
    'w_M1': {
        'min': L_FIXED * 1.0,                     # 1 × L (45 nm)
        'max': max(500.0 * L_FIXED, _original_w_M1),  # 500 × L or original value, whichever is larger
        'log': True
    },
    'w_M2': {
        'min': L_FIXED * 1.0,                     # 1 × L (45 nm)
        'max': max(500.0 * L_FIXED, _original_w_M2),  # 500 × L or original value, whichever is larger
        'log': True
    },

    # Bias voltage: 0.8 - 1.2 × original, but never exceed Vdd (1.2 V).
    # Original Vbias = 0.78 V -> allowed range [0.8*0.78, 1.2*0.78] = [0.624, 0.936] (both <= 1.2 V)
    'Vbias': {
        'min': max(0.8 * 0.78, 0.0),  # 0.624 V
        'max': min(1.2 * 0.78, 1.2),  # 0.936 V
        'log': False
    },
}

# =========================
# Initial parameter values (EXACT original circuit values)
# =========================
# NOTE: These must match the original netlist values exactly and be within the ranges above.
initial_params = {
    'w_M1': 20e-6,   # Original width of M1 = 20 µm (exact)
    'w_M2': 40e-6,   # Original width of M2 = 40 µm (exact)
    'Vbias': 0.78,   # Original bias voltage = 0.78 V (exact)
}

# =========================
# Brief description of each parameter (physical meaning)
# =========================
# w_M1 : Gate width (W) of the NMOS amplifier transistor M1, in meters.
#        Controls transconductance (gm), overdrive current, and parasitic capacitances.
#        L is fixed at 45 nm; optimizing W changes the W/L ratio.
#
# w_M2 : Gate width (W) of the PMOS active load transistor M2, in meters.
#        Controls the current-source behavior, output resistance, and capacitances.
#        L is fixed at 45 nm; original width (40 µm) is preserved as the initial value.
#
# Vbias: Gate bias voltage applied to M2 (the PMOS load) in volts.
#        Tunes the DC current through the amplifier; ranges limited to a conservative
#        window (0.8–1.2× original, clipped to <= 1.2 V) to avoid moving device
#        operation out of the intended region. Consider device threshold Vth = 0.22 V
#        when adjusting this bias; the provided range keeps the bias well above Vth.
#
# Notes:
# - Vdd and input source(s) (Vin) remain fixed (Vdd = 1.2 V, Vin = 0.6 V) as requested.
# - No load capacitors were present in the original netlist. If any load capacitance
#   exists in future variants, keep it fixed and do not include it in the search.
# - Width ranges follow the 1–500×L guideline but ensure original widths are included;
#   hence the upper bound is max(500*L, original_width). This preserves the original
#   starting point while keeping a physically reasonable design space.
```