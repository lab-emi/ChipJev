from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage GBW-Optimized CS Amplifier')
# Define MOSFET models (nmos_params and pmos_params supplied by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)         # DC bias at input gate (Vth + Vov = 0.22 + 0.20)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)     # PMOS gate bias (Vdd - (|Vth| + Vov) = 1.2 - 0.42)
# Transistor sizing (45 nm technology)
# M1: NMOS input transistor (common-source)
# circuit.MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# M2: PMOS active current-source load
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# (Optional) Small explicit load capacitance can be added externally when performing GBW analysis.
# No AC sources are used here; set up is for operating point / small-signal analysis.
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
