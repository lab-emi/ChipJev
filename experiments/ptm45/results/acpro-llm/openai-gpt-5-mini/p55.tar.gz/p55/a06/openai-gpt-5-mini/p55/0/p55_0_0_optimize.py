from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create parameterized PySpice circuit for 'Single-Stage GBW-Optimized CS Amplifier'.
    Required: keeps Vdd and input voltages fixed (as per spec).
    Uses params dict for other tunable values.
    """
    circuit = Circuit('Single-Stage GBW-Optimized CS Amplifier')
    # MOSFET models (external module provides nmos_params, pmos_params)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed supply, do NOT parameterize
    # Input voltage (fixed for DC sweeps / operating point finding)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)  # fixed input bias (Vth + Vov)
    # PMOS gate bias - parameterized (conservative range enforced elsewhere)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Process length (fixed for 45 nm technology). Keep exactly as original circuit:
    L_nm = 45e-9           # 45 nm in meters (original code used 0.045e-6)
    L_value_for_spice = 0.045e-6  # keep same numeric expression used in original code
    # NMOS input transistor M1 (common-source)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_value_for_spice)
    # PMOS active current-source load M2
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_value_for_spice)
    # Note: No explicit load capacitance was present in the original netlist.
    # If a load capacitor is added externally for GBW analysis, keep it fixed and do NOT
    # include it in the optimization parameter set (per specification).
    return circuit
# -------------------------
# Parameter search ranges
# -------------------------
# Important rules applied:
# - L is fixed (45 nm). W ranges are given in absolute meters.
# - Default transistor width constraint: 1 - 500 × L.
#   However, original M2 width exceeds 500×L. To both respect the 1-500×L guideline
#   and ensure the exact original initial value is inside the search range (required),
#   we set the upper bound to max(500*L, original_width). This preserves the guideline
#   while guaranteeing the original starting point is valid for optimization.
# - v_bias is limited to 0.8-1.2× original but never above 1.2V (supply).
# - There were no resistors or capacitors explicitly in the original netlist; none are
#   parameterized here. If you later add passive components, follow the scaling rules
#   in the problem statement.
#
# Note on scaling: 'log' indicates recommendation to sample in log-space for sizes.
param_ranges_definition = {
    # Transistor widths (absolute meters)
    # L = 45e-9
    'w_M1': {
        'min': 1.0 * 45e-9,                     # 1 × L
        'max': max(500.0 * 45e-9, 20e-6),      # 500 × L (or include original if larger)
        'log': True
    },
    'w_M2': {
        'min': 1.0 * 45e-9,                     # 1 × L
        'max': max(500.0 * 45e-9, 40e-6),      # 500 × L (but ensure original 40e-6 is included)
        'log': True
    },
    # Other voltage sources (except Vdd and input Vin): v_bias
    # Original v_bias = 0.78 V, so 0.8× -> 0.624, 1.2× -> 0.936 (<= 1.2V supply)
    'v_bias': {
        'min': 0.8 * 0.78,   # 0.624 V
        'max': min(1.2 * 0.78, 1.2),  # 0.936 V (capped at supply 1.2 V)
        'log': False
    },
    # If later you add resistors, capacitors: follow the given scaling rules.
    # Resistive example (not present in original): r_example: 0.5-2× original
    # Capacitance example (not present in original): c_comp (critical): 0.5-5× original
}
# -------------------------
# Initial parameter values
# -------------------------
# MUST match the exact original circuit values (unchanged).
initial_params = {
    # Transistor widths exactly as in the provided netlist (do NOT modify)
    'w_M1': 20e-6,   # original M1 width (meters)
    'w_M2': 40e-6,   # original M2 width (meters)
    # Bias voltages (original)
    'v_bias': 0.78,  # original bias voltage (V)
}
# Ensure initial values are inside the search ranges (they are by construction above).
# -------------------------
# Parameter descriptions (physical meaning)
# -------------------------
param_descriptions = {
    'w_M1': 'NMOS input transistor M1 width (meters). L is fixed at 45 nm; W/L controls device drive current and gm.',
    'w_M2': 'PMOS active-load transistor M2 width (meters). L is fixed at 45 nm; W/L controls load current and output impedance.',
    'v_bias': 'Gate bias voltage applied to the PMOS load (Vbias). Sets PMOS operating point and DC tail current; must stay <= Vdd (1.2V).'
}
# -------------------------
# Notes / Recommendations
# -------------------------
# - L is kept at the exact numeric expression used in the original netlist (0.045e-6).
# - All voltages (except Vdd=1.2 and input Vin=0.42) are parameterized conservatively.
# - If you later add explicit load capacitors for GBW analysis, include them as fixed values
#   (the original netlist had no explicit C_load).
# - Because the original M2 width (40e-6) exceeds 500×L, the max bound for w_M2 has been
#   set to include that original value so the required "initial_params" point is valid.
