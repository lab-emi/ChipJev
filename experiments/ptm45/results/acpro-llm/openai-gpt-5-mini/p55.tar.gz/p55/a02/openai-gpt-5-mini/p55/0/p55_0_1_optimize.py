from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the following import MUST appear exactly as written inside create_circuit(), per requirements:
# from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create a parameterized PySpice Circuit for:
    'Single-Stage CS Amplifier Max GBW - Corrected Bias'
    Required: this function MUST contain the line:
        from model import nmos_params, pmos_params
    (the module is provided in the execution environment)
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage CS Amplifier Max GBW - Corrected Bias')
    # MOSFET models (provided externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, NOT part of parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd fixed at 1.2 V (45nm)
    # Input voltage (fixed; will be swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0.90)  # Vin fixed at 0.90 V (do not parameterize)
    # Bias voltage (parameterized but constrained conservatively)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # Vbias parameter
    # Transistors
    # NOTE: Per instructions L is held constant for optimization (45 nm = 45e-9 m).
    # Only W is optimized. Although the original netlist had different explicit L for M2,
    # the optimization framework assumes a fixed process L (45 nm).
    L_fixed = 45e-9  # 45 nm fixed process length
    # M1: input NMOS (common-source)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_fixed)
    # M2: PMOS active load (current-source); gate tied to Vbias; source & bulk to Vdd
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_fixed)
    # Output node is Vout (drain of M1 and M2)
    return circuit
# Optimization parameter search ranges (suitable for Optuna or similar frameworks)
# All numeric values are in SI units (meters for widths, volts for voltages).
# - Width bounds follow the rule: W in [1 * L, 500 * L] (L fixed at 45 nm)
# - Vbias is constrained to 0.8–1.2× original, but never > 1.2 V and chosen to remain above Vth=0.22 V
param_ranges_definition = {
    # Transistor widths (meters). Log-scale sampling recommended due to wide span.
    'w_M1': {
        'min': 45e-9 * 1.0,         # 1 × L (45 nm)
        'max': 45e-9 * 500.0,       # 500 × L (22.5 µm)
        'log': True
    },
    'w_M2': {
        'min': 45e-9 * 1.0,         # 1 × L (45 nm)
        'max': 45e-9 * 500.0,       # 500 × L (22.5 µm)
        'log': True
    },
    # Bias voltage for PMOS gate (volts).
    # Original = 0.30 V -> allowed range = [0.8*0.30, 1.2*0.30] = [0.24, 0.36] V
    # Ensure not above Vdd (1.2 V) and keep conservative margin relative to Vth=0.22 V.
    'v_bias': {
        'min': 0.30 * 0.8,   # 0.24 V
        'max': min(0.30 * 1.2, 1.2),  # 0.36 V (also clipped to Vdd if needed)
        'log': False
    },
}
# Initial parameter values (EXACT original values from the provided circuit code)
# These are preserved verbatim and MUST be within the corresponding ranges above.
initial_params = {
    # Transistor widths from original netlist (meters)
    'w_M1': 20e-6,    # original M1 width = 20 µm
    'w_M2': 5e-6,     # original M2 width = 5 µm
    # Bias voltages from original netlist (volts)
    'v_bias': 0.30,   # original Vbias = 0.30 V
}
# Brief description of each parameter (physical meaning)
param_descriptions = {
    'w_M1': "Width of the input NMOS (M1). Together with fixed L (45 nm) this sets M1 W/L and thus its current and transconductance.",
    'w_M2': "Width of the PMOS active load/current-source (M2). With fixed L (45 nm) this sets M2 W/L and its current/source resistance.",
    'v_bias': "Gate bias voltage for the PMOS current-source (M2). Adjusts DC operating point / tail current; constrained to keep device properly biased (considering Vth=0.22 V)."
}
