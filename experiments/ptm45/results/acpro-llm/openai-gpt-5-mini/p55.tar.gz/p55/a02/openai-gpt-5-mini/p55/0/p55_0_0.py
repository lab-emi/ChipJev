from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier Max GBW')
# Define MOSFET models (external module provides parameter dictionaries)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and bias nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)        # Vin DC bias ≈ Vth + 0.2 (0.22 + 0.2)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)    # Vbias for PMOS current-source gate
# Transistors
# M1: input NMOS (common-source)
# name, drain, gate, source, bulk, model, w, l
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=30e-6, l=0.045e-6)
# M2: PMOS active load (current-source)
# gate tied to Vbias; source to Vdd; bulk to Vdd
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=10e-6, l=0.18e-6)
# The output node is Vout (drain of M1 and M2)
# No external load resistor is added here to keep the output node high-impedance
# and to focus on maximizing the amplifier's intrinsic GBW.
# Ready for DC operating-point or small-signal analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
