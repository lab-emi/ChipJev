```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # kept at top-level for clarity (the function also imports it as requested)

def create_circuit(params):
    """
    Create the Single-Stage High-GBW Amplifier circuit using parameter dictionary `params`.

    Required params keys:
      - 'w_M1'  : width of NMOS M1 in meters
      - 'w_M2'  : width of PMOS M2 in meters
      - 'v_bias': bias voltage for PMOS gate Vbias in volts

    Notes:
      - Supply Vdd and input Vin are fixed as required (not parameterized).
      - MOSFET channel length is fixed to the process value (45 nm).
      - The import below is required exactly as written by the framework.
    """
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage High-GBW Amplifier')

    # MOS models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V (fixed)

    # Input voltage source (fixed, not parameterized per requirements)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC bias = 0.42 V (fixed)

    # Parameterized gate bias (this is the only non-Vdd voltage parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # parameterized but constrained externally

    # Fixed channel length for 45 nm technology
    L_ch = 0.045e-6  # 45 nm in meters (kept constant)

    # Transistors: only widths are parameterized (W), lengths kept constant
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_ch)

    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_ch)

    return circuit


# Optimization parameter search ranges
# NOTE: Units are SI (meters for widths, volts for bias).
# Width constraints: nominal guideline is 1 - 500 × L (L = 45 nm).
# However the original M2 width (40e-6 m) exceeds 500×L; to satisfy the strict
# requirement that initial_params MUST be inside the ranges we slightly extended
# the M2 upper bound above 500×L to include the original value (see justification below).
param_ranges_definition = {
    # MOSFET widths (meters). Log-scale sampling is recommended for geometry parameters.
    # L_ch = 0.045e-6 (45 nm)
    'w_M1': {
        'min': 1 * 0.045e-6,              # 1 × L = 45 nm
        'max': 500 * 0.045e-6,            # 500 × L = 22.5e-6 m
        'log': True
    },
    # For M2 the original width (40e-6 m) is larger than 500×L (22.5e-6 m).
    # To satisfy the strict requirement that initial_params exactly match the
    # original and fall inside ranges, we extended the upper bound slightly above
    # the original (original * 1.2). This is an exception to the 500×L guideline
    # required to keep the optimizer feasible with the provided initial point.
    'w_M2': {
        'min': 1 * 0.045e-6,              # 1 × L = 45 nm
        'max': max(500 * 0.045e-6, 1.2 * 40e-6),  # ensure original (40e-6) is inside
        'log': True
    },

    # Bias voltage for the PMOS gate (Vbias):
    # allowed range 0.8–1.2× original but never exceeding Vdd (1.2 V).
    # original Vbias = 0.78 V -> range = [0.8*0.78, min(1.2*0.78, 1.2)] = [0.624, 0.936]
    'v_bias': {
        'min': 0.8 * 0.78,
        'max': min(1.2 * 0.78, 1.2),
        'log': False
    }
}

# Initial parameter values (EXACT original circuit values — do NOT modify)
initial_params = {
    'w_M1': 20e-6,   # Original M1 width (20 µm)
    'w_M2': 40e-6,   # Original M2 width (40 µm)
    'v_bias': 0.78   # Original Vbias (0.78 V)
}

# Brief descriptions of each parameter (physical meaning)
param_descriptions = {
    'w_M1': 'NMOS M1 channel width (meters). Together with fixed L determines M1 W/L ratio and its current/ transconductance.',
    'w_M2': 'PMOS M2 channel width (meters). Sets the PMOS current-source/active-load strength when combined with fixed L.',
    'v_bias': 'DC bias voltage applied to the PMOS gate (Vbias). Adjusts the PMOS operating point / tail current; constrained to keep device in intended region.'
}
```

Notes and justification (concise):
- The create_circuit function is named exactly as required and imports "from model import nmos_params, pmos_params" inside the function as requested.
- Vdd (1.2 V) and input Vin (0.42 V) are fixed and not part of the optimization.
- Channel length L is fixed to 45 nm (0.045e-6 m); only widths (W) are parameterized because W/L ratio controls transistor behavior for this purpose.
- The M2 original width (40 µm) exceeds the strict 500×L guideline (which would be 22.5 µm). To satisfy the hard requirement that initial_params contain the exact original values and that those initial values lie within the search ranges, the M2 upper bound was extended to include the original. If you prefer strictly enforcing 500×L for all devices, you must revise the original M2 width to <= 22.5e-6 m so the initial point will be valid under that stricter constraint.
- All voltage parameter ranges are conservative and ensure values remain <= Vdd (1.2 V) and comfortably above Vth = 0.22 V where relevant.