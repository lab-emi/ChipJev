from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage High-GBW Amplifier')
# MOS models (provided by the external model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and DC bias sources (operating-point biasing only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)      # Vin DC bias ~ Vth + 0.2V (Vth = 0.22V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)  # Vbias for PMOS gate to set current source
# Transistors (minimum channel length = 45 nm -> 0.045e-6 m)
# M1: NMOS common-source amplifier transistor
# Syntax: circuit.MOSFET(name, drain, gate, source, bulk, model, w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=20e-6, l=0.045e-6)
# M2: PMOS active load (current source)
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# End with simulator creation (no extra code below)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
