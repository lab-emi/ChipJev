```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # The model import must appear exactly as written for the execution environment
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage GBW-Optimized Amplifier')

    # Transistor models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and bias supplies
    # Vdd is fixed (do NOT include in optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V (fixed)

    # Input node(s) are fixed (swept externally during DC analysis)
    circuit.V('in', 'Vin', circuit.gnd, 0@u_V)      # Vin DC operating point = 0 V (fixed)

    # Other bias voltages are parameterized
    circuit.V('bgn', 'Vbiasn', circuit.gnd, params['v_biasn'])   # NMOS gate bias (common-gate)
    circuit.V('bgp', 'Vbiasp', circuit.gnd, params['v_biasp'])   # PMOS gate bias (current-source load)

    # Devices (process length kept fixed at original L)
    L = 0.045e-6  # fixed channel length (45 nm) - keeps W/L optimisation meaningful

    # M1: NMOS, common-gate input transistor
    # drain = Vout, gate = Vbiasn (AC ground), source = Vin, bulk = Vin
    circuit.MOSFET('M1', 'Vout', 'Vbiasn', 'Vin', 'Vin',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # M2: PMOS, active current source load
    # drain = Vout, gate = Vbiasp, source = Vdd, bulk = Vdd
    circuit.MOSFET('M2', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L)

    return circuit


# Optimization parameter search ranges (annotated)
# NOTE: All voltage ranges obey the 0.8-1.2× rule (but never exceed 1.2 V supply).
# NOTE: Transistor widths use a recommended 1-500×L rule. To ensure the EXACT original
#       widths provided by the user's netlist are valid starting points, the upper bound
#       for each width is set to max(500*L, original_width). This keeps the recommended
#       constraint while guaranteeing the original value lies inside the range.
param_ranges_definition = {
    # Transistor dimensions (W). L is fixed to 45 nm inside create_circuit.
    # Use log scale search for widths to cover many decades efficiently.
    'w_M1': {
        'min': 1 * 0.045e-6,                # 1 × L = 45e-9 m
        'max': max(500 * 0.045e-6, 20e-6),  # 500 × L (22.5e-6 m) but ensure it includes original 20e-6
        'log': True
    },
    'w_M2': {
        'min': 1 * 0.045e-6,                # 1 × L
        # original W_M2 = 40e-6 exceeds 500×L (22.5e-6). Extend upper bound so initial value is allowed.
        'max': max(500 * 0.045e-6, 40e-6),  # max(22.5e-6, 40e-6) = 40e-6
        'log': True
    },

    # Bias voltages (conservative 0.8-1.2× original, never exceed 1.2 V)
    'v_biasn': {
        'min': 0.8 * 0.42,                  # 0.336 V
        'max': min(1.2, 1.2 * 0.42),        # 0.504 V (<= 1.2 V)
        'log': False
    },
    'v_biasp': {
        'min': 0.8 * 0.78,                  # 0.624 V
        'max': min(1.2, 1.2 * 0.78),        # 0.936 V (<= 1.2 V)
        'log': False
    }
}

# Initial parameter values (EXACT original circuit values --- MUST NOT be changed)
initial_params = {
    'w_M1': 20e-6,    # original M1 width (m)
    'w_M2': 40e-6,    # original M2 width (m)
    'v_biasn': 0.42,  # original NMOS gate bias (V)
    'v_biasp': 0.78   # original PMOS gate bias (V)
}
```

Parameter descriptions (brief)
- w_M1: M1 channel width (m). With L fixed at 45 nm, this controls the W/L ratio of the input NMOS (affects gm, bandwidth, and noise).
- w_M2: M2 channel width (m). With L fixed at 45 nm, this controls the W/L ratio of the PMOS active load (affects current sourcing, headroom, and output resistance).
- v_biasn: DC gate bias applied to M1 gate (V). Sets the bias point of the common-gate NMOS. Range chosen conservatively (0.8–1.2× original) and respects Vdd = 1.2 V and Vth = 0.22 V.
- v_biasp: DC gate bias applied to M2 gate (V). Sets the bias of the PMOS current-source load. Range chosen conservatively (0.8–1.2× original) and bounded by supply.

Notes / rationale
- L is held fixed at the original 45 nm (0.045e-6 m) because W/L is the relevant optimization degree-of-freedom for sizing.
- Vdd and Vin remain fixed as requested (Vdd = 1.2 V, Vin = 0 V) and are not included in the search space.
- All voltage parameter maxima are clamped so they never exceed the 1.2 V supply.
- The width search ranges use a log-scale option to efficiently explore many orders of magnitude; bias voltages use linear search.
- The upper bound for w_M2 was extended to include the user's original value (40 μm) because that original value exceeds the nominal 500×L recommendation. This preserves the strict requirement that initial_params exactly match the original netlist while still enforcing the 1–500×L guideline where possible. If you prefer strictly enforcing 500×L, change the 'max' to 500 * L (22.5e-6) but be aware the original 40e-6 initial value would then fall outside the range.