from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage GBW-Optimized Amplifier')
# Transistor models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies (DC only)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0@u_V)      # Vin DC operating point = 0 V (input node present)
circuit.V('bgn', 'Vbiasn', circuit.gnd, 0.42)   # NMOS gate bias for common-gate (≈ Vth + 0.2)
circuit.V('bgp', 'Vbiasp', circuit.gnd, 0.78)   # PMOS gate bias for current-source load
# Devices (45 nm technology: L = 45 nm = 0.045e-6 m)
# M1: NMOS, common-gate input transistor
# drain = Vout, gate = Vbiasn (AC ground), source = Vin, bulk = Vin
circuit.MOSFET('M1', 'Vout', 'Vbiasn', 'Vin', 'Vin',
               model='nmos_model', w=20e-6, l=0.045e-6)
# M2: PMOS, active current source load
# drain = Vout, gate = Vbiasp, source = Vdd, bulk = Vdd
circuit.MOSFET('M2', 'Vout', 'Vbiasp', 'Vdd', 'Vdd',
               model='pmos_model', w=40e-6, l=0.045e-6)
# End: create simulator (no further code beyond this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
