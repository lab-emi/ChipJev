from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    'w_M1': 30e-6,   # Original NMOS input transistor width = 30 µm
    'w_M2': 60e-6,   # Original PMOS load width = 60 µm
    'v_bias': 0.78,  # Original PMOS gate bias = 0.78 V
}
