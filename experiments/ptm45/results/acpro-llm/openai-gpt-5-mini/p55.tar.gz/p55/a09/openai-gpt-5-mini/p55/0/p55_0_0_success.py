from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage CS Amplifier Optimized for GBW')
# MOS models (provided by the environment via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supplies and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V
circuit.V('in', 'Vin', circuit.gnd, 0.42)           # Vin DC bias ≈ Vth + 0.2 V (0.22 + 0.2)
circuit.V('bias', 'Vbias', circuit.gnd, 0.78)       # PMOS gate bias to form current source
# Device dimensions for 45 nm technology
L_min = 45e-9     # 45 nm
W_M1 = 30e-6      # NMOS input transistor width = 30 um (increase gm)
W_M2 = 60e-6      # PMOS load width = 60 um (sized to provide moderate current)
# Single-stage common-source NMOS (M1)
# MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=W_M1, l=L_min)
# PMOS current-source load (M2) - gate biased by Vbias
circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
               model='pmos_model', w=W_M2, l=L_min)
# The circuit is ready for operating-point / small-signal analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
