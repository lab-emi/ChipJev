```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage CS Amplifier Optimized for GBW')

    # MOS models (provided by the environment via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, NOT part of optimization)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)            # Vdd = 1.2 V (fixed)

    # Input source (fixed, will be externally swept)
    circuit.V('in', 'Vin', circuit.gnd, 0.42)          # Vin DC bias (fixed)

    # Parameterized bias source (allowed to vary within constrained range)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])  # bias for PMOS gate

    # Process length (fixed for 45 nm technology)
    L_min = 45e-9     # 45 nm, kept constant (only W is optimized)

    # MOSFETs (W taken from params, L fixed)
    # Single-stage common-source NMOS (M1)
    circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)

    # PMOS current-source load (M2) - gate biased by Vbias
    circuit.MOSFET('M2', 'Vout', 'Vbias', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M2'],
                   l=L_min)

    # (No load capacitances were present in the original netlist;
    # any load caps are intentionally kept fixed per instructions.)

    return circuit
```

Optimization parameter search ranges (param_ranges_definition)
- Notes:
  - All voltage-source ranges (except Vdd and Vin) are limited to 0.8–1.2× their original value and never exceed 1.2 V.
  - Width constraints follow the requested guideline (1–500× L). Because the original widths exceed 500×L, the upper bound is set to max(500×L, original_value) so the original values remain inside the range (this preserves the required initial_params ∈ ranges).
  - Widths and voltages use SI units (meters, volts). Log sampling is recommended for widths due to wide dynamic range.

```python
param_ranges_definition = {
    # Transistor widths (W). Length fixed at 45e-9.
    # The requested 1-500×L gives an upper bound of 500*45e-9 = 22.5e-6,
    # but original widths exceed that. To ensure the initial values remain in-range,
    # the max is chosen as max(500*L, original_value).
    'w_M1': {
        'min': 1 * 45e-9,                               # 1×L
        'max': max(500 * 45e-9, 30e-6),                 # ensure original (30e-6) is included
        'log': True
    },
    'w_M2': {
        'min': 1 * 45e-9,
        'max': max(500 * 45e-9, 60e-6),                 # ensure original (60e-6) is included
        'log': True
    },

    # Bias voltages (0.8-1.2× original, clipped at <= 1.2 V)
    'v_bias': {
        'min': max(0.0, 0.8 * 0.78),                    # 0.624 V
        'max': min(1.2, 1.2 * 0.78),                    # 0.936 V (<= 1.2)
        'log': False
    },

    # No resistors, capacitors or load caps present in the original netlist to parameterize.
    # If later added, follow:
    # - Resistors: 0.5-2× original
    # - Critical caps: 0.5-5× original
    # - Other caps: 0.8-1.5× original
}
```

Initial parameters (EXACT original values from your provided netlist)
- These values are included verbatim and are guaranteed to be within the ranges defined above.

```python
initial_params = {
    'w_M1': 30e-6,   # Original NMOS input transistor width = 30 µm
    'w_M2': 60e-6,   # Original PMOS load width = 60 µm
    'v_bias': 0.78,  # Original PMOS gate bias = 0.78 V
}
```

Parameter descriptions (physical meaning)
- w_M1: Width of NMOS input transistor M1 (meters). Together with fixed L (45 nm) sets W/L and thus gm and current drive of the input device.
- w_M2: Width of PMOS current-source load transistor M2 (meters). Sets the current provided by the PMOS load and affects DC operating point and output resistance.
- v_bias: DC gate bias applied to PMOS M2 (volts). Controls load current and operating point; constrained to 0.8–1.2× original but never exceed Vdd (1.2 V). Kept conservative considering Vth ≈ 0.22 V.

Notes and rationale
- L is fixed at 45e-9 as requested; optimizer only varies W (W/L effectively optimized).
- Vdd and Vin remain fixed (Vdd = 1.2 V, Vin = 0.42 V) per your requirements so they can be swept externally as needed.
- All initial parameter values are exactly those from your original netlist and are contained within the specified ranges.
- If you later add resistors or capacitors to the netlist, follow the scaling constraints you provided for their parameter ranges (resistors 0.5–2×, critical caps 0.5–5×, other caps 0.8–1.5×).
- Because the original widths exceed 500×L, the width upper bounds were expanded to include the original values to meet the "initial_params exactly original" requirement; if strict enforcement of 500×L is required instead, you should reduce the initial widths in the netlist to lie within that bound before optimization.