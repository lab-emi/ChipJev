from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage GBW-Optimized Amplifier')
# Define transistor models (provided via import)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply and input DC bias (operating point)
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)    # Vdd = 1.2 V
# Vin is used both as DC operating bias (per instruction: use Vth when setting bias)
# Vth = 0.22V, choose Vov ~0.38V => Vin DC = 0.60V
circuit.V('in', 'Vin', circuit.gnd, 0.60)   # Vin DC bias for operating point
# Single-stage common-source NMOS (maximize gm: large W, minimum L)
# MOSFET(name, drain, gate, source, bulk, model, w=w1, l=l1)
circuit.MOSFET('M1', 'Vout', 'Vin', circuit.gnd, circuit.gnd,
               model='nmos_model', w=50e-6, l=0.045e-6)
# Resistive load from Vout to Vdd to set bias current and keep single dominant pole
circuit.R('L', 'Vout', 'Vdd', 2@u_kΩ)
# End: create simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p55/0/p55_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
