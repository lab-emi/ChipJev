from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the parameterized PySpice circuit.
    Notes:
    - Keeps Vdd and Vin fixed (per requirements).
    - MOSFET length is fixed at 45 nm (0.045e-6 m); only width is parameterized.
    - Resistor parameter (r_L) is expressed in kilo-ohms (kΩ) for convenient string formatting
      to the PySpice R() call (e.g. "2k" for 2 kΩ).
    - This function expects params to contain:
        - 'w_M1' : transistor width in meters (float)
        - 'r_L'  : load resistor value in kilo-ohms (float), e.g. 2 for 2 kΩ
    """
    circuit = Circuit('Single-Stage GBW-Optimized Amplifier')
    # Keep the exact import usage of the device models as requested:
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed at 1.2 V (45 nm technology)
    # Input DC bias (fixed; to be swept externally during operating point search)
    # Per instruction: use Vin = Vth + Vov ~ 0.22 + 0.38 = 0.60 V
    circuit.V('in', 'Vin', circuit.gnd, 0.60)
    # Single-stage common-source NMOS
    # Length is fixed at 45 nm (0.045e-6 m). Width is parameterized.
    circuit.MOSFET('M1',
                   'Vout',    # drain
                   'Vin',     # gate
                   circuit.gnd,  # source
                   circuit.gnd,  # bulk
                   model='nmos_model',
                   w=params['w_M1'],
                   l=0.045e-6)
    # Resistive load from Vout to Vdd.
    # r_L is provided in kilo-ohms (kΩ) in params, convert to ngspice unit string:
    circuit.R('L', 'Vout', 'Vdd', f"{params['r_L']}k")
    return circuit
# Optimization parameter search ranges (suitable for Optuna or similar frameworks)
# Notes on units:
# - w_M1 in meters (m)
# - r_L in kilo-ohms (kΩ)
#
# Important: initial_params below contains the EXACT original values from the user's circuit
# code (unchanged). All ranges are chosen so that initial values lie within them.
#
# Transistor width constraint: requested 1-500× L where L = 45 nm => [45e-9, 22.5e-6] m.
# However, the original width (50e-6 m) exceeds 500×L. To satisfy the requirement that the
# initial values be preserved exactly and remain inside the search ranges, the upper bound
# for w_M1 is set to include the original width. This is explicitly reflected below.
param_ranges_definition = {
    # Transistor dimensions (width only; length fixed at 45 nm in create_circuit)
    # Lower bound = 1 * L = 45e-9 m
    # Upper bound = max(500 * L, original_width) to ensure the original width is inside the range.
    'w_M1': {
        'min': 45e-9,                       # 1 × L (45 nm)
        'max': max(500 * 0.045e-6, 50e-6),  # normally 500×L = 22.5e-6, expanded to include original 50e-6
        'log': True
    },
    # Passive components
    # Resistive load r_L: original = 2 kΩ. Range = 0.5 - 2 × original = [1, 4] kΩ.
    'r_L': {
        'min': 0.5 * 2.0,   # in kΩ => 1.0 kΩ
        'max': 2.0 * 2.0,   # in kΩ => 4.0 kΩ
        'log': True
    },
    # No capacitors or additional voltages to parameterize in the original netlist.
    # If later adding compensation caps or other voltages, follow:
    # - critical caps: 0.5-5× original
    # - other caps: 0.8-1.5× original
    # - other voltages (except Vdd/Vin) : 0.8-1.2× original but never > 1.2 V
}
# Initial parameter values (EXACT original circuit values; must not be modified)
initial_params = {
    'w_M1': 50e-6,  # Original width value from the provided circuit (50 µm)
    # The original resistor was specified as 2@u_kΩ in the provided code -> 2 kΩ
    # Represented here in kΩ units to match r_L parameter interpretation above.
    'r_L': 2.0,     # 2 kΩ (original)
}
# Brief description of each parameter (physical meaning)
parameter_descriptions = {
    'w_M1': 'M1 channel width (meters). Controls device drive current and transconductance (gm). '
            'Length is fixed at 45 nm; optimization varies width to change W/L (and therefore gm).',
    'r_L': 'Load resistor between Vout and Vdd (in kilo-ohms). Sets DC bias current and the single-pole '
           'load dominated frequency response (affects gain and GBW). Expressed in kΩ for convenience '
           'when creating the netlist ("<value>k" format).'
}
# Short note about the width bound choice:
note = (
    "NOTE: The original transistor width (50e-6 m) exceeds 500× the stated length (45e-9 m). "
    "To satisfy the requirement that the initial parameters remain EXACT and inside the search "
    "ranges, the upper bound for 'w_M1' was expanded to include the original value. The "
    "nominal 1-500×L constraint is preserved as the recommended operating region; the range "
    "presented is a pragmatic compromise to allow starting from the provided original netlist."
)
