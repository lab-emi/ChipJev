from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp - GBW/Power Optimized')
# Define MOSFET models (provided by the environment via model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Supply and bias voltages
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd = 1.2 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)   # Tail bias (Vth + 0.2) = 0.42 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)      # Input positive DC (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)      # Input negative DC (common-mode)
# Dimensions (45 nm node)
L = 0.045e-6   # 45 nm
# Input pair small W to improve gm/C (GBW/Power)
W_in = 0.2e-6  # 0.2 um
# PMOS mirror sizes (slightly larger)
W_pmos = 0.6e-6  # 0.6 um
# Tail transistor
W_tail = 0.5e-6  # 0.5 um
# Nodes:
# - D1 : drain of left input NMOS and diode PMOS
# - Iss : common source of M1/M2 and drain of Mtail
# - Vout : single-ended output (drain of right input NMOS / mirror PMOS)
# Input NMOS differential pair
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=W_in, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=W_in, l=L)
# PMOS current mirror load: M3 diode-connected on left branch, M4 mirror on right branch
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=W_pmos, l=L)  # diode PMOS
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd', model='pmos_model', w=W_pmos, l=L)  # mirror PMOS
# Tail current source (NMOS)
circuit.MOSFET('Mtail', 'Iss', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=W_tail, l=L)
# Simulator creation (end here as requested)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
