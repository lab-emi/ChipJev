```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # Keep this import exactly as requested by the framework/environment
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp - GBW/Power Optimized (Corrected Bias)')

    # Define MOSFET models (provided by the environment via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power supply (fixed, do not parameterize)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Vdd fixed at 1.2 V (45 nm process)

    # Input voltages (fixed, will be swept externally for DC operating point analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.4)     # Input positive DC (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.4)     # Input negative DC (fixed)

    # Tail bias (parameterized)
    circuit.V('bias', 'Vbias', circuit.gnd, params['Vbias'])    # Tail bias (parameter)

    # Geometries: keep length constant (45 nm technology). Only widths are parameterized.
    L = 0.045e-6   # 45 nm (fixed)
    # Use parameterized widths (meters)
    W_in    = params['W_in']    # input NMOS width
    W_pmos  = params['W_pmos']  # PMOS mirror widths
    W_tail  = params['W_tail']  # tail NMOS width

    # Nodes:
    # - D1 : drain of left input NMOS and diode PMOS (mirror bias node)
    # - Iss : common source of M1/M2 and drain of Mtail (tail node)
    # - Vout : single-ended output (drain of right input NMOS / mirror PMOS)

    # Input NMOS differential pair (bulk tied to source node 'Iss' per original code)
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model', w=W_in, l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model', w=W_in, l=L)

    # PMOS current mirror load: M3 diode-connected on left branch, M4 mirror on right branch
    # bulk tied to source (Vdd)
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=W_pmos, l=L)  # diode PMOS
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model', w=W_pmos, l=L)  # mirror PMOS

    # Tail current source (NMOS) - bulk tied to source (circuit.gnd)
    circuit.MOSFET('Mtail', 'Iss', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=W_tail, l=L)

    return circuit
```

Parameter search ranges (annotated) suitable for Optuna or similar optimization tools:

```python
# Fixed process length (not an optimization parameter)
L_fixed = 0.045e-6  # 45 nm

# MOSFET width constraints: 1 - 500 × L (meters)
# Derived numeric bounds:
W_min = L_fixed * 1          # 45e-9 m
W_max = L_fixed * 500        # 22.5e-6 m

param_ranges_definition = {
    # Transistor widths (meters)
    # Use log sampling for widths because they span several decades and performance often scales with W/L.
    'W_in':   {'min': W_min,   'max': W_max,   'scale': 'log', 'unit': 'm'},
    'W_pmos': {'min': W_min,   'max': W_max,   'scale': 'log', 'unit': 'm'},
    'W_tail': {'min': W_min,   'max': W_max,   'scale': 'log', 'unit': 'm'},

    # Tail bias voltage: constrained to 0.8–1.2× original, and never exceed Vdd (1.2 V).
    # Original Vbias = 1.0 V -> allowed range [0.8, 1.2] V (linear sampling recommended).
    # Also chosen conservatively well above typical Vth (0.22 V) so tail device remains operational.
    'Vbias':  {'min': 0.8,     'max': 1.2,      'scale': 'linear', 'unit': 'V'},
}
```

Initial parameter values (EXACT original values from your supplied circuit code):
```python
initial_params = {
    # Transistor widths (exact as in original code)
    'W_in':   0.5e-6,   # original input NMOS width (0.5 um)
    'W_pmos': 1.0e-6,   # original PMOS mirror width (1.0 um)
    'W_tail': 1.0e-6,   # original tail NMOS width (1.0 um)

    # Tail bias (exact original)
    'Vbias':  1.0,      # original tail bias (1.0 V)
}
```

Short descriptions / physical meaning of each parameter:
- W_in: width of the input differential NMOS transistors (M1, M2). Controls gm, input device capacitance, and offset of device operating point.
- W_pmos: width of the PMOS mirror transistors (M3, M4). Controls mirror compliance, load current, and output swing.
- W_tail: width of the tail NMOS current source (Mtail). Controls tail current magnitude and common-mode compliance.
- Vbias: gate bias voltage applied to the tail NMOS. Controls the DC tail current and operating point of the differential pair.
- L (implicit fixed constant inside create_circuit): channel length for all MOSFETs, fixed to 45 nm (0.045e-6 m). Only W is being optimized per your requirements.

Notes and constraints applied (why ranges were chosen):
- Transistor widths: constrained to 1–500×L per your requirement. Numeric values computed from L = 45 nm give [45e-9, 22.5e-6] m. Log-scale sampling is recommended for optimization because performance often scales nonlinearly with W.
- Vbias: constrained to 0.8–1.2× the original value (1.0 V) and capped at Vdd = 1.2 V as required; lower bound remains comfortably above Vth = 0.22 V to keep the tail transistor conducting.
- vdd (1.2 V) and the input voltages Vinp/Vinn (0.4 V) are fixed exactly as in your netlist and are not included in the parameter search (they will be swept externally during DC analysis).
- No resistors or capacitors were present in the original netlist to parameterize. If you add compensation or load capacitors or resistors later, follow the ranges you specified (resistors 0.5–2× original, critical caps 0.5–5×, other caps 0.8–1.5×).

All initial parameter values are inside the ranges defined above. If you want the parameter names or units adapted to your optimizer (for example converting widths to micrometers or using named distributions compatible with Optuna), I can provide a small helper to convert units or map distributions into sampler suggestions for Optuna trials.