from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    # Transistor widths (exact as in original code)
    'W_in':   0.5e-6,   # original input NMOS width (0.5 um)
    'W_pmos': 1.0e-6,   # original PMOS mirror width (1.0 um)
    'W_tail': 1.0e-6,   # original tail NMOS width (1.0 um)
    # Tail bias (exact original)
    'Vbias':  1.0,      # original tail bias (1.0 V)
}
