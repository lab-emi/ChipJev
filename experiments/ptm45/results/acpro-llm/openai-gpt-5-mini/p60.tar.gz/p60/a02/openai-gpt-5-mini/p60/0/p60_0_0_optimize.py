from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the required import below must appear exactly as written inside create_circuit
# (per your requirement it will be present in the function)
# from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp circuit using parameter dictionary `params`.
    Required: this function must include the line "from model import nmos_params, pmos_params"
    exactly as written (the optimization environment provides that module).
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power optimized)')
    # Models (provided by external module)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power rails and DC biases (fixed)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd fixed at 1.2 V (NOT parameterized)
    # Inputs (fixed; swept externally during DC/op analysis)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp fixed at 0.6 V
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn fixed at 0.6 V
    # Tail bias (parameterized: conservative range around original 0.47 V)
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])
    # Device minimum length (fixed, same as original netlist)
    Lmin = 0.045e-6   # 45 nm (kept constant; only W is optimized)
    # Transistors (MOSFET(name, drain, gate, source, bulk, model, w=..., l=...))
    # NMOS input pair
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Ns', 'Ns',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=Lmin)
    circuit.MOSFET('M2', 'N2', 'Vinn', 'Ns', 'Ns',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=Lmin)
    # PMOS current mirror load
    circuit.MOSFET('M4', 'N2', 'N2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=Lmin)
    circuit.MOSFET('M3', 'Vout', 'N2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=Lmin)
    # Tail current source (NMOS)
    circuit.MOSFET('M5', 'Ns', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=Lmin)
    return circuit
# Optimization parameter search ranges
# NOTE: widths are given in meters; Vtail in volts.
# Guiding constraints used:
# - Nominal length Lmin = 0.045e-6 (45 nm) is fixed.
# - Width ranges intended to be 1×L .. 500×L, BUT original netlist includes device widths
#   larger than 500×L (40e-6 and 80e-6). To ensure the optimizer can start from the exact
#   original netlist values, the upper bound is expanded when needed to include the original.
#   Where an original width is within 1-500×L, the strict 500×L upper bound is used.
#
# - All voltage sources (other than vdd and inputs) are constrained to 0.8-1.2× original
#   and never exceed 1.2 V (supply). For Vtail (original 0.47 V), that yields [0.376, 0.564] V.
#
# Each entry is structured as {'min': ..., 'max': ..., 'log': True/False}.
Lmin = 0.045e-6
_max_by_500L = 500 * Lmin
param_ranges_definition = {
    # Transistor widths (meters)
    'w_M1': {
        # original w_M1 = 40e-6 (40 µm) -> larger than 500*L (22.5e-6)
        # so we expand upper bound to include original and allow margin.
        'min': 1.0 * Lmin,
        'max': max(_max_by_500L, 40e-6 * 2.0),  # allow up to 2× original to permit search
        'log': True
    },
    'w_M2': {
        # original w_M2 = 40e-6
        'min': 1.0 * Lmin,
        'max': max(_max_by_500L, 40e-6 * 2.0),
        'log': True
    },
    'w_M3': {
        # original w_M3 = 80e-6 (80 µm) -> exceeds 500*L; expand upper bound
        'min': 1.0 * Lmin,
        'max': max(_max_by_500L, 80e-6 * 2.0),
        'log': True
    },
    'w_M4': {
        # original w_M4 = 80e-6
        'min': 1.0 * Lmin,
        'max': max(_max_by_500L, 80e-6 * 2.0),
        'log': True
    },
    'w_M5': {
        # original w_M5 = 2e-6 (2 µm) -> within 1-500×L so strict 500×L upper bound suffices
        'min': 1.0 * Lmin,
        'max': max(_max_by_500L, 2e-6 * 2.0),  # ensures original is within range; but 500*L is larger
        'log': True
    },
    # Voltage sources (only Vtail is parameterized; inputs and vdd are fixed)
    'v_tail': {
        # original v_tail = 0.47 V
        # allowable: 0.8-1.2× original, but never exceed 1.2 V
        'min': max(0.8 * 0.47, 0.0),
        'max': min(1.2 * 0.47, 1.2),
        'log': False
    }
}
# Initial parameter values (EXACT original circuit values - required)
initial_params = {
    # widths (exactly as in original netlist)
    'w_M1': 40e-6,   # M1 original width
    'w_M2': 40e-6,   # M2 original width
    'w_M3': 80e-6,   # M3 original width
    'w_M4': 80e-6,   # M4 original width
    'w_M5': 2e-6,    # M5 original width
    # bias voltage (exact original)
    'v_tail': 0.47,  # original Vtail
}
# Brief parameter descriptions (physical meaning)
param_descriptions = {
    'w_M1': "Width of input NMOS M1 (drain=Vout, gate=Vinp). L fixed at 45 nm.",
    'w_M2': "Width of input NMOS M2 (drain=N2, gate=Vinn). L fixed at 45 nm.",
    'w_M3': "Width of PMOS mirror transistor M3 (drain=Vout, gate=N2). L fixed at 45 nm.",
    'w_M4': "Width of diode-connected PMOS mirror transistor M4 (drain=N2, gate=N2). L fixed at 45 nm.",
    'w_M5': "Width of tail NMOS current source M5 (drain=Ns, gate=Vtail). L fixed at 45 nm.",
    'v_tail': "Tail bias voltage applied to the gate of M5 (V). Conservative search range ±20% around original, clipped to supply."
}
# Sanity check (not required by the optimizer, but useful when inspecting ranges)
# Ensure initial values are within declared ranges
for key, val in initial_params.items():
    r = param_ranges_definition.get(key)
    if r is not None:
        assert r['min'] <= val <= r['max'], f"Initial param {key}={val} outside declared range {r}"
