from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power optimized)')
# Models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)         # Vdd = 1.2 V
# Inputs (DC common-mode)
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)       # Vinp = 0.6 V (DC operating point)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)       # Vinn = 0.6 V
# Tail bias (use Vth = 0.22 V as guidance; Vtail = Vth + 0.25 = 0.47 V)
circuit.V('tail', 'Vtail', circuit.gnd, 0.47)    # Vtail for NMOS tail current source
# Nodes:
# Ns  = common source node of input pair (tail node)
# N2  = drain of M2 and diode-connected PMOS (mirror gate node)
# Vout = output node (drain of M1 and mirrored PMOS)
# Transistors (MOSFET(name, drain, gate, source, bulk, model, w=..., l=...))
Lmin = 0.045e-6   # 45 nm in meters
# Input differential pair (NMOS)
# M1: drains -> Vout, gate -> Vinp, source -> Ns, bulk -> Ns
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Ns', 'Ns', model='nmos_model', w=40e-6, l=Lmin)
# M2: drains -> N2, gate -> Vinn, source -> Ns, bulk -> Ns
circuit.MOSFET('M2', 'N2', 'Vinn', 'Ns', 'Ns', model='nmos_model', w=40e-6, l=Lmin)
# PMOS current mirror load
# M4: diode-connected mirror transistor: drain -> N2, gate -> N2, source -> Vdd, bulk -> Vdd
circuit.MOSFET('M4', 'N2', 'N2', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=Lmin)
# M3: mirror transistor: drain -> Vout (single-ended output), gate -> N2, source -> Vdd, bulk -> Vdd
circuit.MOSFET('M3', 'Vout', 'N2', 'Vdd', 'Vdd', model='pmos_model', w=80e-6, l=Lmin)
# Tail current source (NMOS)
# M5: drain -> Ns, gate -> Vtail, source -> gnd, bulk -> gnd
circuit.MOSFET('M5', 'Ns', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=Lmin)
# End of netlist; create simulator for operating point / DC analysis
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
