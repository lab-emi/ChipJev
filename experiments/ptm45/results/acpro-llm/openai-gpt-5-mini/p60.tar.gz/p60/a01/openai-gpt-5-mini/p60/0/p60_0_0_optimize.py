from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
# Initial parameter values (EXACT original values from your netlist)
initial_params = {
    # Transistor widths (meters) - EXACT original values (no modification)
    'w_M1': 8e-6,   # M1 original width
    'w_M2': 8e-6,   # M2 original width
    'w_M3': 20e-6,  # M3 original width
    'w_M4': 20e-6,  # M4 original width
    'w_M5': 2e-6,   # M5 original width
    # Tail bias voltage (V) - EXACT original value
    'v_bias': 0.80,  # Vbias original
}
