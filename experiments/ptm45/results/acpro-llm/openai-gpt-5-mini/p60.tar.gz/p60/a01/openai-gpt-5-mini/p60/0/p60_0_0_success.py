from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Op-Amp (Active PMOS Mirror Load)')
# Define device models (assumed provided via model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias sources
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
# DC input nodes (common-mode set for operating point). No AC content per instructions.
circuit.V('inp', 'Vinp', circuit.gnd, 0.5)     # Vinp = 0.5 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.5)     # Vinn = 0.5 V
# Tail bias to set the differential pair current (choose > Vth = 0.22V)
circuit.V('bias', 'Vbias', circuit.gnd, 0.80)  # Vbias = 0.80 V
# Internal nets
# NodeL: drain of left input NMOS and diode-connected PMOS
# NodeS: common source node of input pair (tail node)
# Vout: drain of right input NMOS (single-ended output)
# Device sizes (45 nm technology)
L = 0.045e-6   # 45 nm
# NMOS inputs
circuit.MOSFET('M1', 'NodeL', 'Vinp', 'NodeS', circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'NodeS', circuit.gnd,
               model='nmos_model', w=8e-6, l=L)
# PMOS current mirror load: M3 diode-connected, M4 mirror transistor
circuit.MOSFET('M3', 'NodeL', 'NodeL', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'NodeL', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L)
# NMOS tail current source
circuit.MOSFET('M5', 'NodeS', 'Vbias', circuit.gnd, circuit.gnd,
               model='nmos_model', w=2e-6, l=L)
# Ensure the input and output node names required by the problem exist in the netlist:
#   Vinp, Vinn, Vout  (they are created by the voltage sources and transistor connections)
# Ready to run operating point / transient / AC as needed:
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
