from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: the model import required by the framework is placed inside create_circuit
# as requested by the specification.
def create_circuit(params):
    from model import nmos_params, pmos_params  # keep exactly as requested
    circuit = Circuit('Single-Stage Differential OpAmp (max GBW/Power FoM)')
    # Load device models (provided via the environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and DC bias supplies
    # Vdd is fixed per requirements (do NOT include in the parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V (fixed)
    # Input voltages are fixed and will be swept externally (do NOT include in search)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # Vinp = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # Vinn = 0.6 V (fixed)
    # Tail bias voltage (parameterized; constrained per spec to 0.8-1.2x original, <= 1.2V)
    circuit.V('tail', 'Vtail', circuit.gnd, params['Vtail'])  # parameterized
    # Process length - fixed (only W/L matters for optimization)
    L = 0.045e-6  # 45 nm process (fixed)
    # Input pair (NMOS)
    # M1: left input, drain -> Vout, gate -> Vinp, source -> Iss, bulk -> Iss
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    # M2: right input, drain -> Vb, gate -> Vinn, source -> Iss, bulk -> Iss
    circuit.MOSFET('M2', 'Vb', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS current mirror load
    # M3: diode-connected PMOS at node Vb (drain = gate = Vb)
    circuit.MOSFET('M3', 'Vb', 'Vb', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    # M4: mirror PMOS, gate tied to Vb, drain -> Vout
    circuit.MOSFET('M4', 'Vout', 'Vb', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)
    # Tail current source (NMOS)
    # M5: drain -> Iss, gate -> Vtail, source -> ground, bulk -> ground
    circuit.MOSFET('M5', 'Iss', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    return circuit
# Optimization parameter search ranges (annotated)
# Rules applied:
# - Transistor widths: 1xL .. 500xL  (L = 0.045e-6 m)
# - Vtail: 0.8 - 1.2 × original, clipped to <= 1.2 V
# - initial_params must equal the EXACT original values from the provided circuit
L = 0.045e-6
param_ranges_definition = {
    # Transistor widths (meters). Use log-scale sampling recommended for wide dynamic range.
    'w_M1': {                 # M1 original: 10e-6
        'min': 1.0 * L,       # 1 × L
        'max': 500.0 * L,     # 500 × L
        'scale': 'log'
    },
    'w_M2': {                 # M2 original: 10e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    'w_M3': {                 # M3 original: 20e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    'w_M4': {                 # M4 original: 20e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    'w_M5': {                 # M5 original: 2e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    # Voltage sources (except Vdd, Vinp, Vinn which are fixed)
    # Vtail original = 0.6 V -> search: 0.8*0.6 .. min(1.2*0.6, 1.2) = 0.48 .. 0.72 V
    'Vtail': {
        'min': 0.8 * 0.6,
        'max': min(1.2 * 0.6, 1.2),
        'scale': 'linear'
    }
}
# Initial parameter values (EXACT original circuit values; MUST match the original code)
initial_params = {
    # Transistor widths (meters) - exactly as in the original netlist
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 2e-6,
    # Voltage (exact original)
    'Vtail': 0.6,
}
