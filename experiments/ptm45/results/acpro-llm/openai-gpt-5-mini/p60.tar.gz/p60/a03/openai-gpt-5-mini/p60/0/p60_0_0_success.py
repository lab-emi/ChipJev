from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (max GBW/Power FoM)')
# Define device models (from provided model dictionary)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and DC bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # DC bias for Vinp (operating point)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # DC bias for Vinn (operating point)
# Vtail chosen using Vth = 0.22 V guidance: Vtail ~ Vth + 0.38 ~ 0.6 V
circuit.V('tail', 'Vtail', circuit.gnd, 0.6)      # Gate bias for tail current source
# Node names used:
# Vout - single-ended output
# Vb   - diode/mirror node (drain of M2, gate of mirror)
# Iss  - common source node of M1/M2 (drain of tail M5)
# Device sizes (45 nm technology: l = 0.045e-6)
L = 0.045e-6
# Input pair (NMOS)
# M1: left input, drain -> Vout, gate -> Vinp, source -> Iss, bulk -> Iss
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=L)
# M2: right input, drain -> Vb, gate -> Vinn, source -> Iss, bulk -> Iss
circuit.MOSFET('M2', 'Vb', 'Vinn', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=L)
# PMOS current mirror load
# M3: diode-connected PMOS at node Vb (drain = gate = Vb)
circuit.MOSFET('M3', 'Vb', 'Vb', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L)
# M4: mirror PMOS, gate tied to Vb, drain -> Vout
circuit.MOSFET('M4', 'Vout', 'Vb', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=L)
# Tail current source (NMOS)
# M5: drain -> Iss, gate -> Vtail, source -> ground, bulk -> ground
circuit.MOSFET('M5', 'Iss', 'Vtail', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=L)
# End of circuit; run operating point simulator outside as required
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
