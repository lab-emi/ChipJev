```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: the model import required by the framework is placed inside create_circuit
# as requested by the specification.

def create_circuit(params):
    from model import nmos_params, pmos_params  # keep exactly as requested

    circuit = Circuit('Single-Stage Differential OpAmp (max GBW/Power FoM)')

    # Load device models (provided via the environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power and DC bias supplies
    # Vdd is fixed per requirements (do NOT include in the parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)          # Vdd = 1.2 V (fixed)

    # Input voltages are fixed and will be swept externally (do NOT include in search)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)        # Vinp = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)        # Vinn = 0.6 V (fixed)

    # Tail bias voltage (parameterized; constrained per spec to 0.8-1.2x original, <= 1.2V)
    circuit.V('tail', 'Vtail', circuit.gnd, params['Vtail'])  # parameterized

    # Process length - fixed (only W/L matters for optimization)
    L = 0.045e-6  # 45 nm process (fixed)

    # Input pair (NMOS)
    # M1: left input, drain -> Vout, gate -> Vinp, source -> Iss, bulk -> Iss
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)

    # M2: right input, drain -> Vb, gate -> Vinn, source -> Iss, bulk -> Iss
    circuit.MOSFET('M2', 'Vb', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # PMOS current mirror load
    # M3: diode-connected PMOS at node Vb (drain = gate = Vb)
    circuit.MOSFET('M3', 'Vb', 'Vb', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)

    # M4: mirror PMOS, gate tied to Vb, drain -> Vout
    circuit.MOSFET('M4', 'Vout', 'Vb', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # Tail current source (NMOS)
    # M5: drain -> Iss, gate -> Vtail, source -> ground, bulk -> ground
    circuit.MOSFET('M5', 'Iss', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)

    return circuit


# Optimization parameter search ranges (annotated)
# Rules applied:
# - Transistor widths: 1xL .. 500xL  (L = 0.045e-6 m)
# - Vtail: 0.8 - 1.2 × original, clipped to <= 1.2 V
# - initial_params must equal the EXACT original values from the provided circuit
L = 0.045e-6
param_ranges_definition = {
    # Transistor widths (meters). Use log-scale sampling recommended for wide dynamic range.
    'w_M1': {                 # M1 original: 10e-6
        'min': 1.0 * L,       # 1 × L
        'max': 500.0 * L,     # 500 × L
        'scale': 'log'
    },
    'w_M2': {                 # M2 original: 10e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    'w_M3': {                 # M3 original: 20e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    'w_M4': {                 # M4 original: 20e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },
    'w_M5': {                 # M5 original: 2e-6
        'min': 1.0 * L,
        'max': 500.0 * L,
        'scale': 'log'
    },

    # Voltage sources (except Vdd, Vinp, Vinn which are fixed)
    # Vtail original = 0.6 V -> search: 0.8*0.6 .. min(1.2*0.6, 1.2) = 0.48 .. 0.72 V
    'Vtail': {
        'min': 0.8 * 0.6,
        'max': min(1.2 * 0.6, 1.2),
        'scale': 'linear'
    }
}

# Initial parameter values (EXACT original circuit values; MUST match the original code)
initial_params = {
    # Transistor widths (meters) - exactly as in the original netlist
    'w_M1': 10e-6,
    'w_M2': 10e-6,
    'w_M3': 20e-6,
    'w_M4': 20e-6,
    'w_M5': 2e-6,

    # Voltage (exact original)
    'Vtail': 0.6,
}
```

Parameter descriptions (brief)
- w_M1 (m): Width of input NMOS M1 (drain -> Vout). Together with fixed L sets W/L for M1, controlling transconductance and overdrive.
- w_M2 (m): Width of input NMOS M2 (drain -> Vb). Sets W/L for the differential pair right device.
- w_M3 (m): Width of diode-connected PMOS M3 (at Vb). Affects mirror bias current and mirror output impedance.
- w_M4 (m): Width of PMOS mirror device M4 (drain -> Vout). Affects load current sourcing and output swing.
- w_M5 (m): Width of tail NMOS M5 (current source). Controls tail current capability (with gate bias Vtail).
- Vtail (V): Gate bias of the tail NMOS M5. Parameterized conservatively between 0.48 V and 0.72 V (0.8–1.2× original 0.6 V, clipped to <= 1.2 V). This adjusts tail current; constraints keep operation near the intended biasing region (considering Vth ≈ 0.22 V).

Notes and rationale
- L is fixed at 45 nm (0.045e-6 m) because only W/L matters; we expose W for optimization.
- All transistor width ranges are 1×L .. 500×L per your constraint (numerical range: 0.045e-6 .. 22.5e-6 m).
- Vdd and input voltages (Vinp, Vinn) are intentionally left fixed to allow external sweeping for operating point searches.
- No resistors or capacitors were present in the original netlist; therefore none are parameterized. Any load/compensation capacitors (if later added) should follow the specified multiplier ranges and initial value rules.
- initial_params contains exactly the original numeric values from the provided circuit code (unchanged). All initial values are within the declared search ranges.

Usage tips
- The optimization framework should call create_circuit(params) passing the sampled params.
- Use param_ranges_definition to drive sampler (log sampling recommended for widths).
- Ensure the simulator environment provides model.nmos_params and model.pmos_params as required.