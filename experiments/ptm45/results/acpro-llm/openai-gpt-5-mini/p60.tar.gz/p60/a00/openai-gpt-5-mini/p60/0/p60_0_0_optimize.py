from PySpice.Unit import *
from PySpice.Spice.Netlist import Circuit
initial_params = {
    'w_M1':    10e-6,   # original M1 width
    'w_M2':    10e-6,   # original M2 width
    'w_M3':    20e-6,   # original M3 width (PMOS diode)
    'w_M4':    20e-6,   # original M4 width (PMOS mirror)
    'w_Mtail': 2e-6,    # original tail NMOS width
    'v_bias':  0.42,    # original bias voltage
}
