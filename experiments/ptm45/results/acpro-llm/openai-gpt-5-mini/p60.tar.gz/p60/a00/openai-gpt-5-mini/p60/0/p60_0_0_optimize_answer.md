```python
from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *

def create_circuit(params):
    # NOTE: keep this import exactly as written for the execution environment
    from model import nmos_params, pmos_params

    circuit = Circuit('Single-Stage Differential OpAmp (NMOS input, PMOS mirror load)')

    # MOSFET models (provided by environment)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)

    # Power rails and DC nodes (Vdd and inputs are fixed per requirements)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)        # Supply (fixed)
    circuit.V('vinp', 'Vinp', circuit.gnd, 0.60)   # Input + (fixed, swept externally)
    circuit.V('vinn', 'Vinn', circuit.gnd, 0.60)   # Input - (fixed, swept externally)

    # Parameterized bias source (allowed to vary within conservative bounds)
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])

    # Technology length is fixed (45 nm). Only widths are parameterized.
    L = 0.045e-6  # 45 nm, fixed

    # Input NMOS transistors (left and right/output)
    circuit.MOSFET('M1', 'Node_NL', 'Vinp', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', 'Iss',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)

    # PMOS current mirror load: M3 diode-connected, M4 mirrored device
    circuit.MOSFET('M3', 'Node_NL', 'Node_NL', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)
    circuit.MOSFET('M4', 'Vout', 'Node_NL', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)

    # Tail current source (NMOS) from Iss to ground, gate tied to Vbias
    circuit.MOSFET('Mtail', 'Iss', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L)

    return circuit
```

Parameter search ranges (for use with Optuna or similar):
```python
param_ranges_definition = {
    # Transistor widths (W) - constrained to 1×L .. 500×L (L = 45e-9 => min=45e-9, max=22.5e-6)
    # Use log sampling for device widths to cover wide dynamic range efficiently.
    'w_M1':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M1 input NMOS (left)
    'w_M2':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M2 input NMOS (right/output)
    'w_M3':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M3 PMOS diode (left)
    'w_M4':    {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # M4 PMOS mirror (right/output)
    'w_Mtail': {'min': 45e-9,     'max': 22.5e-6,   'log': True},  # Mtail NMOS tail device

    # Bias voltage: 0.8 - 1.2 × original, but not exceeding 1.2 V (original Vbias = 0.42 V)
    # 0.8*0.42 = 0.336 V, 1.2*0.42 = 0.504 V -> both below 1.2 V so upper bound = 0.504 V
    'v_bias':  {'min': 0.336,     'max': 0.504,      'log': False},  # Tail/gate bias (conservative linear sampling)
}
```

Initial parameters (EXACT original values from your circuit code — do not modify these):
```python
initial_params = {
    'w_M1':    10e-6,   # original M1 width
    'w_M2':    10e-6,   # original M2 width
    'w_M3':    20e-6,   # original M3 width (PMOS diode)
    'w_M4':    20e-6,   # original M4 width (PMOS mirror)
    'w_Mtail': 2e-6,    # original tail NMOS width
    'v_bias':  0.42,    # original bias voltage
}
```

Short descriptions of each parameter (physical meaning):
- w_M1: Width of input NMOS M1 (left differential transistor). Controls its current drive, gm, and input device capacitance.
- w_M2: Width of input NMOS M2 (right/output-side differential transistor). Controls current drive, gm, and output swing contribution.
- w_M3: Width of PMOS diode-connected device (left branch of mirror). Sets mirror reference current and headroom in the mirror.
- w_M4: Width of PMOS mirror device (right branch). Sets current delivered to the output node and mirror mismatch behavior.
- w_Mtail: Width of NMOS tail device (current source). Sets tail current, tail output resistance, and impacts common-mode behavior.
- v_bias: Tail/gate bias voltage (Vbias). Sets the tail transistor gate bias (thus tail current). Range chosen conservatively (0.8–1.2× original and ≤ 1.2 V) and respects the process threshold (Vth ≈ 0.22 V).

Notes and rationale:
- Length (L) is fixed at 45 nm (0.045e-6) across all MOSFETs; only widths are parameterized (W/L changes are achieved by varying W).
- Vdd and the input DC sources (Vinp and Vinn) remain fixed as requested (these are typically swept externally during DC operating point searches).
- The bias voltage parameter v_bias is limited to [0.336, 0.504] V which is 0.8–1.2× the original 0.42 V and stays below the 1.2 V supply. This keeps bias adjustments conservative while allowing modest tuning around the design point; the lower bound remains above 0V and near threshold but still conservative.
- All width initial values are inside the defined 1–500×L search range (45e-9 … 22.5e-6), and the initial v_bias = 0.42 is inside its defined range.
- No capacitors or resistors were present in the original netlist; therefore none were added to the search. If you later add compensation or load capacitors, follow the requested multipliers (compensation: 0.5–5×, others: 0.8–1.5×) and keep load caps fixed per your requirement.

You can feed param_ranges_definition and initial_params into your optimizer (Optuna or another) and call create_circuit(trial_params) to build test circuits.