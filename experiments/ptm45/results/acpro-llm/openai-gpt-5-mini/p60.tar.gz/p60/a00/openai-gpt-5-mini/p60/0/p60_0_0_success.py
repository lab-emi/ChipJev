from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (NMOS input, PMOS mirror load)')
# Define MOSFET models (parameters provided by imported module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power rails and DC nodes
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)       # Vdd = 1.2 V
circuit.V('vinp', 'Vinp', circuit.gnd, 0.60)   # DC common-mode input (can be changed)
circuit.V('vinn', 'Vinn', circuit.gnd, 0.60)   # DC common-mode input (can be changed)
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)  # Vbias = Vth (0.22V) + 0.20V = 0.42V
# Internal nodes
# Node Iss: common source node of input pair (drain of tail)
# Node Node_NL: left drain node (diode-connected PMOS)
# Output node: Vout (single-ended)
# Input NMOS transistors: M1 (left), M2 (right/output)
# MOSFET(name, drain, gate, source, bulk, model=..., w=..., l=...)
circuit.MOSFET('M1', 'Node_NL', 'Vinp', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=0.045e-6)
circuit.MOSFET('M2', 'Vout',  'Vinn', 'Iss', 'Iss', model='nmos_model', w=10e-6, l=0.045e-6)
# PMOS current mirror load
# M3 diode-connected on left branch (gate tied to its drain Node_NL)
circuit.MOSFET('M3', 'Node_NL', 'Node_NL', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# M4 mirrored device, gate tied to Node_NL
circuit.MOSFET('M4', 'Vout', 'Node_NL', 'Vdd', 'Vdd', model='pmos_model', w=20e-6, l=0.045e-6)
# Tail current source (NMOS) from Iss to ground, gate tied to Vbias
circuit.MOSFET('Mtail', 'Iss', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=0.045e-6)
# Note: All bulks tied to sources per instructions (see MOSFET arguments above).
# Create simulator
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
