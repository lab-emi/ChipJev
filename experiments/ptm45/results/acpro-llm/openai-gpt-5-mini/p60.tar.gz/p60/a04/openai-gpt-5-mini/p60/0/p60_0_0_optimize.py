from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: The following import must appear inside create_circuit as required by the framework:
# "from model import nmos_params, pmos_params"
def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp circuit with parameterized device widths
    and tail bias voltage. This function keeps Vdd and input voltages fixed, per requirements.
    IMPORTANT: the import below must be present exactly as written.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power Optimized)')
    # MOSFET models (provided externally via model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V (fixed)
    # Input DC nodes - fixed (will be swept outside)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # Vinp DC common-mode = 0.6 V (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # Vinn DC common-mode = 0.6 V (fixed)
    # Tail bias (parameterized). Must always be <= 1.2 V; range enforced externally in param_ranges.
    circuit.V('tail', 'Vbias', circuit.gnd, params['v_tail'])
    # Process length (fixed 45 nm as in original circuit)
    L = 0.045e-6  # 45 nm
    # Differential pair (NMOS)
    circuit.MOSFET('M1', 'D_left', 'Vinp', 'S', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L)
    # PMOS current mirror load (M3 diode-connected to set mirror gate)
    circuit.MOSFET('M3', 'D_left', 'D_left', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L)  # diode-connected on left drain
    circuit.MOSFET('M4', 'Vout', 'D_left', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L)  # mirror transistor
    # Tail current source (NMOS)
    circuit.MOSFET('M5', 'S', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L)
    return circuit
# -------------------------------
# Optimization parameter search ranges (for Optuna or similar)
# -------------------------------
# Process length fixed (45 nm):
L = 0.045e-6  # 45 nm
# Helper to compute default upper bound per "1-500×L" rule but ensure it includes the original (initial) value.
# Original widths (from user's circuit): M1=20e-6, M2=20e-6, M3=40e-6, M4=40e-6, M5=5e-6
# 500 * L = 500 * 45e-9 = 22.5e-6
# Note: M3 and M4 original widths (40e-6) exceed 500*L; to comply with the requirement that the initial
# values remain inside the search ranges, we extend the upper bound to include the original widths.
# This is annotated below.
param_ranges_definition = {
    # Transistor widths (W). L is fixed at 45 nm; optimization varies W only.
    # Recommended physical constraint: 1×L .. 500×L. For devices whose original widths exceed 500×L,
    # the upper bound is extended to include the original value so the initial point lies within the range.
    'w_M1': {
        'min': 1.0 * L,
        'max': max(500.0 * L, 20e-6),  # 20e-6 is the original width for M1
        'log': True
    },
    'w_M2': {
        'min': 1.0 * L,
        'max': max(500.0 * L, 20e-6),  # original width for M2
        'log': True
    },
    'w_M3': {
        'min': 1.0 * L,
        # original M3 width = 40e-6 which is > 500*L; upper bound extended to include original
        'max': max(500.0 * L, 40e-6),
        'log': True
    },
    'w_M4': {
        'min': 1.0 * L,
        # original M4 width = 40e-6 which is > 500*L; upper bound extended to include original
        'max': max(500.0 * L, 40e-6),
        'log': True
    },
    'w_M5': {
        'min': 1.0 * L,
        'max': max(500.0 * L, 5e-6),   # original width for M5
        'log': True
    },
    # Tail bias voltage (Vbias) - parameterized, conservative range per instructions:
    # Allowed factor: 0.8 - 1.2 × original (0.6 V) but never exceed 1.2 V.
    # So range = [0.8*0.6, min(1.2*0.6, 1.2)] = [0.48, 0.72]
    'v_tail': {
        'min': 0.8 * 0.6,
        'max': min(1.2 * 0.6, 1.2),
        'log': False
    },
}
# -------------------------------
# Initial parameter values (EXACT original circuit values - MUST match the original code)
# -------------------------------
initial_params = {
    # Transistor widths (exact values from user's original netlist)
    'w_M1': 20e-6,   # M1 original width
    'w_M2': 20e-6,   # M2 original width
    'w_M3': 40e-6,   # M3 original width (diode-connected PMOS)
    'w_M4': 40e-6,   # M4 original width (mirror PMOS)
    'w_M5': 5e-6,    # M5 original width (tail NMOS)
    # Tail bias (exact original)
    'v_tail': 0.6,   # Tail bias (Vbias) original value
}
# -------------------------------
# Brief parameter descriptions (physical meaning)
# -------------------------------
param_descriptions = {
    'w_M1': 'Width of NMOS M1 (left differential transistor). L fixed at 45 nm. Optimization varies W to set gm and current capability.',
    'w_M2': 'Width of NMOS M2 (right differential transistor). L fixed at 45 nm.',
    'w_M3': 'Width of PMOS M3 (diode-connected device forming the mirror gate). Affects mirror bias and load impedance.',
    'w_M4': 'Width of PMOS M4 (mirror transistor feeding the right output). Affects load current and output resistance.',
    'w_M5': 'Width of NMOS M5 (tail current source). Controls tail-source compliance and tail current when used with fixed Vbias.',
    'v_tail': 'Tail bias voltage applied to the gate of the tail NMOS (M5). Parameterized to allow conservative bias shifts (0.8–1.2× original), clipped at supply.',
}
# Notes:
# - vdd (1.2 V) and input voltages Vinp/Vinn (0.6 V) are kept fixed and are not part of the parameter search.
# - L is held constant (45e-9 m). Only W is parameterized because W/L ratio is the relevant variable for device sizing.
# - There were no explicit resistors or explicit capacitors in the provided netlist; thus resistor/capacitor parameterization is not included.
# - All initial_params values are inside their corresponding ranges defined in param_ranges_definition.
# - The PMOS widths M3/M4 in the original netlist exceed the typical 500×L upper guideline; the upper search bounds
#   for w_M3 and w_M4 have been extended to include the original values so the starting point is valid for optimization.
