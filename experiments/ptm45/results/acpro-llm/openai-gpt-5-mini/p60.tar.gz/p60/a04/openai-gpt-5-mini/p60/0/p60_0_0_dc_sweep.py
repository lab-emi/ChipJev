from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power Optimized)')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# External DC nodes (operating-point inputs and tail bias)
# No AC sources per instructions — these are DC operating points for OP analysis
circuit.V('dc', 'Vinn', 'Vinp', 0.0)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # Vinn DC common-mode ~0.6 V
circuit.V('tail', 'Vbias', circuit.gnd, 0.6) # Tail bias for current source gate
# Transistor sizing (45 nm technology: L = 45e-9 ~ 0.045e-6)
L = 0.045e-6
# Differential pair (NMOS)
circuit.MOSFET('M1', 'D_left', 'Vinp', 'S', circuit.gnd, model='nmos_model', w=20e-6, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# PMOS current mirror load
# M3 is diode-connected on the left drain (D_left) to generate mirror gate voltage
circuit.MOSFET('M3', 'D_left', 'D_left', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'D_left', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L)     # mirror transistor
# Tail current source (NMOS)
circuit.MOSFET('M5', 'S', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=L)
# End with simulator instantiation (no other code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

import numpy as np

# Get the VDD value from the circuit
try:
    dc_value = circuit.element('Vdd').dc_value
    if type(dc_value) == str:
        v_dd_value = float(dc_value.split()[0])
    else:
        v_dd_value = float(dc_value)
except:
    # Try alternative name formats
    try:
        dc_value = circuit.element('VDD').dc_value
        if type(dc_value) == str:
            v_dd_value = float(dc_value.split()[0])
        else:
            v_dd_value = float(dc_value)
    except:
        # Default to 1.2V if VDD cannot be found
        v_dd_value = 1.2

# Define reasonable voltage range for differential amplifier biasing
# Avoid regions too close to rails where transistors might not be in saturation
min_voltage = 0.2
max_voltage = v_dd_value - 0.2  # Avoid saturation region

# Target output voltage is typically VDD/2 for many amplifier circuits
target_vout = v_dd_value / 2

# Save the data to file in two lines
fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_dc.txt", "w")


for element in circuit.elements:
    if element.name == "Vinn":
        vin_pin_name = element.pins[0].node
# Three-level scanning strategy
# Level 1: Coarse scan across reasonable operating range
coarse_step = (max_voltage - min_voltage) / 20  # Adaptive step size
analysis_coarse = simulator.dc(Vinn=slice(min_voltage, max_voltage, coarse_step))
out_voltage_coarse = np.array(analysis_coarse.Vout)
in_voltage_coarse = np.array(getattr(analysis_coarse, vin_pin_name))

# Find the approximate best point
best_vin_coarse = v_dd_value / 2  # Initial guess
min_diff_coarse = float('inf')
for i, vout in enumerate(out_voltage_coarse):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_coarse:
        min_diff_coarse = diff
        best_vin_coarse = float(in_voltage_coarse[i])

# Level 2: Medium resolution scan around best point from coarse scan
mid_range = (max_voltage - min_voltage) / 4  # 25% of the range
mid_step = (max_voltage - min_voltage) / 200  # Higher resolution
mid_min = max(min_voltage, best_vin_coarse - mid_range/2)
mid_max = min(max_voltage, best_vin_coarse + mid_range/2)

# get vin pin name



analysis_mid = simulator.dc(Vinn=slice(mid_min, mid_max, mid_step))
out_voltage_mid = np.array(analysis_mid.Vout)
in_voltage_mid = np.array(getattr(analysis_mid, vin_pin_name))

# Find the best point in medium resolution scan
best_vin_mid = best_vin_coarse
min_diff_mid = float('inf')
for i, vout in enumerate(out_voltage_mid):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_mid:
        min_diff_mid = diff
        best_vin_mid = float(in_voltage_mid[i])

# Level 3: Ultra-high resolution scan around best point from medium scan
fine_range = (max_voltage - min_voltage) / 40  # ~2.5% of the range
fine_step = (max_voltage - min_voltage) / 2000  # Ultra-fine resolution
fine_min = max(min_voltage, best_vin_mid - fine_range/2)
fine_max = min(max_voltage, best_vin_mid + fine_range/2)

analysis_fine = simulator.dc(Vinn=slice(fine_min, fine_max, fine_step))
out_voltage = np.array(analysis_fine.Vout)
in_voltage = np.array(getattr(analysis_fine, vin_pin_name))

# Print information about the search
print(f"VDD = {v_dd_value:.3f}V, Target Vout = {target_vout:.3f}V")
print(f"Search range: {min_voltage:.3f}V to {max_voltage:.3f}V")
print(f"Coarse scan result: Best Vin ≈ {best_vin_coarse:.6f}V")
print(f"Medium scan result: Best Vin ≈ {best_vin_mid:.6f}V")

# Find best point in fine scan
best_vin_fine = best_vin_mid
best_vout_fine = target_vout
min_diff_fine = float('inf')
for i, vout in enumerate(out_voltage):
    diff = abs(float(vout) - target_vout)
    if diff < min_diff_fine:
        min_diff_fine = diff
        best_vin_fine = float(in_voltage[i])
        best_vout_fine = float(vout)

print(f"Fine scan result: Best Vin = {best_vin_fine:.6f}V (Vout ≈ {best_vout_fine:.6f}V)")

# Combine all results for comprehensive data output
all_out_voltage = np.concatenate((out_voltage_coarse, out_voltage_mid, out_voltage))
all_in_voltage = np.concatenate((in_voltage_coarse, in_voltage_mid, in_voltage))

for item in all_in_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
for item in all_out_voltage:
    fopen.write(f"{item:.6f} ")
fopen.write("\n")
fopen.close()