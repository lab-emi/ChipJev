from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power Optimized)')
# MOSFET models (provided by external module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # Vdd = 1.2 V
# External DC nodes (operating-point inputs and tail bias)
# No AC sources per instructions — these are DC operating points for OP analysis
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)   # Vinp DC common-mode ~0.6 V
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)   # Vinn DC common-mode ~0.6 V
circuit.V('tail', 'Vbias', circuit.gnd, 0.6) # Tail bias for current source gate
# Transistor sizing (45 nm technology: L = 45e-9 ~ 0.045e-6)
L = 0.045e-6
# Differential pair (NMOS)
circuit.MOSFET('M1', 'D_left', 'Vinp', 'S', circuit.gnd, model='nmos_model', w=20e-6, l=L)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'S', circuit.gnd, model='nmos_model', w=20e-6, l=L)
# PMOS current mirror load
# M3 is diode-connected on the left drain (D_left) to generate mirror gate voltage
circuit.MOSFET('M3', 'D_left', 'D_left', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'D_left', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=L)     # mirror transistor
# Tail current source (NMOS)
circuit.MOSFET('M5', 'S', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=5e-6, l=L)
# End with simulator instantiation (no other code after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
