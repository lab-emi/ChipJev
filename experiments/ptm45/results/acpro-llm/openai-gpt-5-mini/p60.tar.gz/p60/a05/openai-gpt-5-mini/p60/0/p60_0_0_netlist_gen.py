from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp - GBW/Power Optimized')
# Models (provided externally)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and biases
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.60)            # Vin+ DC bias (common-mode)
circuit.V('inn', 'Vinn', circuit.gnd, 0.60)            # Vin- DC bias (common-mode)
circuit.V('tail', 'Vbias_tail', circuit.gnd, 0.42)     # Tail bias (Vth + 0.2 per guideline)
# Nodes:
# Vs  = common source node of input pair
# D2  = drain of right input transistor and gate/diode node of mirror
# Vout = output node (drain of left input transistor / PMOS mirror)
# Transistor instances
# M1: left input NMOS (drain = Vout)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=4e-6, l=0.045e-6)
# M2: right input NMOS (drain = D2)
circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=4e-6, l=0.045e-6)
# M3: diode-connected PMOS (sets mirror gate at D2)
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=16e-6, l=0.045e-6)
# M4: PMOS mirror load (drain = Vout, gate tied to D2)
circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=16e-6, l=0.045e-6)
# M5: tail NMOS current source (connects Vs to ground)
circuit.MOSFET('M5', 'Vs', 'Vbias_tail', circuit.gnd, circuit.gnd, model='nmos_model', w=1e-6, l=0.045e-6)
# End: create simulator (no further code per instructions)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
