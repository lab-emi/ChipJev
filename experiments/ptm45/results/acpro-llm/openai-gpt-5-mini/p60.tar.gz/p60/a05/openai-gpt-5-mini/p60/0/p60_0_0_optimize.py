from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# NOTE: the following import must appear exactly as written inside create_circuit per requirements:
# from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create a PySpice Circuit for the Single-Stage Differential OpAmp (GBW/Power optimized).
    The module-level models are imported inside this function as required by the optimization framework.
    params: dict with keys:
        'w_M1','w_M2','w_M3','w_M4','w_M5'  -> transistor widths (meters)
        'v_tail'                             -> tail bias voltage (volts)
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp - GBW/Power Optimized')
    # Models (provided externally)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and biases
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Vdd fixed at 1.2 V (NOT parameterized)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.60)           # Vin+ fixed at 0.60 V (swept externally)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.60)           # Vin- fixed at 0.60 V (swept externally)
    # Tail bias (parameterized; constrained to <= 1.2 V and within 0.8-1.2x original)
    circuit.V('tail', 'Vbias_tail', circuit.gnd, params['v_tail'])
    # Transistor instances
    # Note: process length is fixed (45 nm). Only widths are parameterized.
    L_FIXED = 0.045e-6  # 45 nm (kept constant)
    # M1: left input NMOS (drain = Vout)
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_FIXED)
    # M2: right input NMOS (drain = D2)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_FIXED)
    # M3: diode-connected PMOS (sets mirror gate at D2)
    circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_FIXED)
    # M4: PMOS mirror load (drain = Vout, gate tied to D2)
    circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_FIXED)
    # M5: tail NMOS current source (connects Vs to ground)
    circuit.MOSFET('M5', 'Vs', 'Vbias_tail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_M5'],
                   l=L_FIXED)
    # No load capacitors / resistors included here per original netlist.
    # (If a load capacitor existed it would be kept fixed and not parameterized.)
    return circuit
# Optimization parameter search ranges (annotated)
# Process fixed length: L = 45e-9 m -> allowed W range is [1*L, 500*L] = [45e-9, 22.5e-6] meters
param_ranges_definition = {
    # Transistor widths (meters). Use log sampling recommended for wide ranges.
    'w_M1': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # M1 input NMOS width (original 4e-6)
    'w_M2': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # M2 input NMOS width (original 4e-6)
    'w_M3': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # M3 diode PMOS width  (original 16e-6)
    'w_M4': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # M4 mirror PMOS width (original 16e-6)
    'w_M5': {'min': 45e-9, 'max': 22.5e-6, 'log': True},   # M5 tail NMOS width   (original 1e-6)
    # Tail bias voltage (volts)
    # Original = 0.42 V. Allowed = 0.8-1.2 × original, capped by supply (1.2 V).
    # 0.8*0.42 = 0.336 V, 1.2*0.42 = 0.504 V -> use [0.336, 0.504]
    'v_tail': {'min': 0.336, 'max': 0.504, 'log': False}
}
# Initial parameter values (EXACT original circuit values)
initial_params = {
    # Transistor widths (meters) - EXACT values from original netlist
    'w_M1': 4e-6,    # M1 original width
    'w_M2': 4e-6,    # M2 original width
    'w_M3': 16e-6,   # M3 original width
    'w_M4': 16e-6,   # M4 original width
    'w_M5': 1e-6,    # M5 original width
    # Tail bias voltage - EXACT original value
    'v_tail': 0.42,  # Vbias_tail original
}
# Brief description of each parameter (physical meaning)
parameter_descriptions = {
    'w_M1': "Width of left input NMOS (M1). Controls input transconductance and current; L fixed at 45 nm.",
    'w_M2': "Width of right input NMOS (M2). Symmetric to M1; affects matching and GBW.",
    'w_M3': "Width of diode-connected PMOS in mirror (M3). Sets mirror gate bias and mirror resistance.",
    'w_M4': "Width of PMOS mirror load (M4). Controls current sourcing capability and load resistance.",
    'w_M5': "Width of tail NMOS current source (M5). Controls tail current and pair bias point.",
    'v_tail': "Tail bias voltage applied to gate of M5 (Vbias_tail). Adjusts tail current level; constrained to 0.8-1.2× original and ≤ Vdd."
}
