from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Opamp (Active PMOS Mirror Load)')
# Define MOSFET models (provided externally via model module)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Inputs (DC common-mode bias). Names required by the problem: Vinp, Vinn
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Tail bias (sets tail current). Use Vth guidance: Vth = 0.22V -> Vtail = Vth + 0.2 = 0.42V
circuit.V('tail', 'Vtail', circuit.gnd, 0.42)
# Node names:
# D1  = diode node (PMOS diode-connected gate/drain)
# Iss = source node of input pair (drain of tail)
# Vout = output node (single-ended)
# Device sizes (45 nm technology)
L_min = 0.045e-6  # 45 nm
# NMOS input pair: M1 (left), M2 (right)
circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', circuit.gnd,
               model='nmos_model', w=10e-6, l=L_min)
circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', circuit.gnd,
               model='nmos_model', w=10e-6, l=L_min)
# Tail current source (NMOS): drain = Iss, gate = Vtail, source = gnd
circuit.MOSFET('Mtail', 'Iss', 'Vtail', circuit.gnd, circuit.gnd,
               model='nmos_model', w=5e-6, l=L_min)
# PMOS active mirror load:
# M3: diode-connected PMOS (sets the reference gate voltage). drain= D1, gate= D1, source=Vdd
circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L_min)
# M4: mirror transistor. gate tied to M3 gate (node D1). drain = Vout (single-ended output)
circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
               model='pmos_model', w=20e-6, l=L_min)
# Ensure the output node name required by the problem appears:
# Vout is defined above as the drain of M2 and M4.
# Create simulator (end of provided runnable code)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
