from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the model import is required INSIDE create_circuit as requested below.
L_min = 0.045e-6  # 45 nm, fixed channel length for all devices (do not parameterize)
def create_circuit(params):
    """
    Create the PySpice Circuit for the Single-Stage Differential Opamp (Active PMOS Mirror Load).
    The function imports transistor model parameter dictionaries from the provided 'model' module
    as required by the execution environment.
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential Opamp (Active PMOS Mirror Load)')
    # Attach device models (provided externally)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, not parameterized)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed 1.2V supply for 45nm technology
    # Inputs (fixed, not parameterized — will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Tail bias (parameterized within conservative range)
    # Note: params['v_tail'] is in volts and guaranteed <= 1.2V by the search range
    circuit.V('tail', 'Vtail', circuit.gnd, params['v_tail'])
    # Node names:
    # D1  = diode node (PMOS diode-connected gate/drain)
    # Iss = source node of input pair (drain of tail)
    # Vout = output node (single-ended)
    # NMOS input pair: M1 (left), M2 (right)
    circuit.MOSFET('M1', 'D1', 'Vinp', 'Iss', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M1'],
                   l=L_min)
    circuit.MOSFET('M2', 'Vout', 'Vinn', 'Iss', circuit.gnd,
                   model='nmos_model',
                   w=params['w_M2'],
                   l=L_min)
    # Tail current source (NMOS): drain = Iss, gate = Vtail, source = gnd
    circuit.MOSFET('Mtail', 'Iss', 'Vtail', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=L_min)
    # PMOS active mirror load:
    # M3: diode-connected PMOS (sets the reference gate voltage). drain= D1, gate= D1, source=Vdd
    circuit.MOSFET('M3', 'D1', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=L_min)
    # M4: mirror transistor. gate tied to M3 gate (node D1). drain = Vout (single-ended output)
    circuit.MOSFET('M4', 'Vout', 'D1', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=L_min)
    return circuit
# -------------------------
# Optimization parameter search ranges (annotated)
# -------------------------
# All units are SI (meters for widths, volts for voltages).
# Transistor width constraints: 1xL .. 500xL  (L = 45e-9 m)
# Voltage constraints: 0.8x .. 1.2x original, and <= 1.2V (supply). Tail bias respects Vth guidance.
param_ranges_definition = {
    # NMOS input pair widths (meters)
    'w_M1': {'min': L_min, 'max': 500 * L_min, 'log': True},  # original 10e-6
    'w_M2': {'min': L_min, 'max': 500 * L_min, 'log': True},  # original 10e-6
    # NMOS tail transistor width (meters)
    'w_Mtail': {'min': L_min, 'max': 500 * L_min, 'log': True},  # original 5e-6
    # PMOS mirror device widths (meters)
    'w_M3': {'min': L_min, 'max': 500 * L_min, 'log': True},  # original 20e-6
    'w_M4': {'min': L_min, 'max': 500 * L_min, 'log': True},  # original 20e-6
    # Tail bias voltage (volts) - 0.8-1.2× original but never exceed 1.2V
    # Original tail = 0.42 V -> 0.336 .. 0.504 (0.504 < 1.2, so this is the range)
    'v_tail': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
}
# -------------------------
# Initial parameter values (EXACT original circuit values)
# These must match the original code's numerical values exactly.
# -------------------------
initial_params = {
    'w_M1': 10e-6,    # original width of M1
    'w_M2': 10e-6,    # original width of M2
    'w_Mtail': 5e-6,  # original width of Mtail
    'w_M3': 20e-6,    # original width of M3 (PMOS diode)
    'w_M4': 20e-6,    # original width of M4 (PMOS mirror)
    'v_tail': 0.42,   # original tail bias voltage (Vtail)
}
# -------------------------
# Brief description of parameters (physical meaning)
# -------------------------
param_descriptions = {
    'w_M1': "Width (W) of NMOS input transistor M1 (left differential device). L fixed at 45nm. "
            "Controls input device current drive, gm, and W/L ratio.",
    'w_M2': "Width (W) of NMOS input transistor M2 (right differential device). L fixed at 45nm. "
            "Symmetric to M1 for differential operation.",
    'w_Mtail': "Width (W) of NMOS tail transistor (Mtail) that biases the input pair. "
               "Adjusts tail current capability and headroom of input stage.",
    'w_M3': "Width (W) of PMOS diode-connected transistor (M3) in the active mirror load. "
            "Sets mirror reference current and output common-mode point.",
    'w_M4': "Width (W) of PMOS mirror transistor (M4) that provides the active load to the output. "
            "Together with M3 determines mirror accuracy and load current.",
    'v_tail': "Tail gate voltage (Vtail) applied to Mtail. Controls tail current and operating point. "
              "Search range kept conservative (0.8–1.2× original) and always <= Vdd (1.2 V).",
}
# End of file
