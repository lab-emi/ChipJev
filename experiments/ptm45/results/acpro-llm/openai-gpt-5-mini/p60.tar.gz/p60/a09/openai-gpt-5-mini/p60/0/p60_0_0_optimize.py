from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
# Note: the model import must appear exactly as below inside create_circuit per requirements
def create_circuit(params):
    """
    Create the Single-Stage Differential OpAmp circuit with parameterized device widths and bias.
    The function uses the external transistor models via: from model import nmos_params, pmos_params
    (This import is required to be written exactly as shown by the problem statement.)
    """
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power Optimized)')
    # MOS models (provided by external module 'model')
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power and input supplies (fixed, not included in parameter search)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Vdd = 1.2 V (fixed)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)            # Input positive DC (fixed)
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)            # Input negative DC (fixed)
    # Tail bias source (parameterized)
    # Keep this bounded to be within 0.8-1.2x original but never exceed 1.2 V.
    circuit.V('bias', 'Vbias', circuit.gnd, params['v_bias'])
    # Technology length (kept fixed in behavior; original value preserved)
    Lmin = params.get('Lmin', 0.045e-6)
    # Input differential pair (NMOS) - widths parameterized, length held constant
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M1'],
                   l=Lmin)
    circuit.MOSFET('M2', 'Voutb', 'Vinn', 'Vs', 'Vs',
                   model='nmos_model',
                   w=params['w_M2'],
                   l=Lmin)
    # PMOS current mirror load - widths parameterized, length held constant
    circuit.MOSFET('M3', 'Voutb', 'Voutb', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M3'],
                   l=Lmin)
    circuit.MOSFET('M4', 'Vout', 'Voutb', 'Vdd', 'Vdd',
                   model='pmos_model',
                   w=params['w_M4'],
                   l=Lmin)
    # Tail current source (NMOS) - width parameterized, length held constant
    circuit.MOSFET('Mtail', 'Vs', 'Vbias', circuit.gnd, circuit.gnd,
                   model='nmos_model',
                   w=params['w_Mtail'],
                   l=Lmin)
    return circuit
# -------------------------
# Optimization parameter search ranges (for Optuna or similar)
# -------------------------
# Constraints applied:
# - Transistor width (W) range: 1×L .. 500×L
# - Voltages (except Vdd and input pins) scaled 0.8..1.2× original but capped at 1.2 V
# - All initial values are the exact original numbers from the provided netlist
Lmin_original = 0.045e-6  # original Lmin from the provided circuit
param_ranges_definition = {
    # Transistor widths (meters). Range: 1×Lmin .. 500×Lmin
    # Use log sampling recommended for width sweeps across many decades
    'w_M1': {'min': 1.0 * Lmin_original, 'max': 500.0 * Lmin_original, 'log': True},
    'w_M2': {'min': 1.0 * Lmin_original, 'max': 500.0 * Lmin_original, 'log': True},
    'w_M3': {'min': 1.0 * Lmin_original, 'max': 500.0 * Lmin_original, 'log': True},
    'w_M4': {'min': 1.0 * Lmin_original, 'max': 500.0 * Lmin_original, 'log': True},
    'w_Mtail': {'min': 1.0 * Lmin_original, 'max': 500.0 * Lmin_original, 'log': True},
    # Bias voltage (Vbias) - conservative variation: 0.8..1.2 × original, but never exceed 1.2 V.
    # Original Vbias = 0.42 V -> range = [0.336, 0.504] V
    'v_bias': {'min': 0.8 * 0.42, 'max': min(1.2 * 0.42, 1.2), 'log': False},
}
# -------------------------
# Initial parameter values (EXACT original circuit values - do NOT modify)
# -------------------------
initial_params = {
    # Transistor widths (exactly as in original netlist)
    'w_M1': 20e-6,    # M1 original width
    'w_M2': 20e-6,    # M2 original width
    'w_M3': 40e-6,    # M3 original width
    'w_M4': 40e-6,    # M4 original width
    'w_Mtail': 2e-6,  # Mtail original width
    # Fixed length (original variable in the provided code)
    'Lmin': 0.045e-6,  # original Lmin (kept as fixed process length)
    # Bias voltage (exact original)
    'v_bias': 0.42,    # original Vbias value
}
