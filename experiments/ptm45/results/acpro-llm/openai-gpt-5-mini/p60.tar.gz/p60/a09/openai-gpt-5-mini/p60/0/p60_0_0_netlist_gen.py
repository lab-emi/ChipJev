from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential OpAmp (GBW/Power Optimized)')
# MOS models (provided by external module 'model')
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power and bias supplies
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)               # Vdd = 1.2 V
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)             # Input positive DC (common-mode ~ 0.6 V)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)             # Input negative DC (common-mode ~ 0.6 V)
# Use Vth = 0.22 V in bias selection: Vbias = Vth + 0.20 = 0.42 V
circuit.V('bias', 'Vbias', circuit.gnd, 0.42)          # Tail gate bias for NMOS current source
# Nodes:
# Vs  : common source (tail) node of input pair
# Vout: single-ended output (drain of left input transistor)
# Voutb: other drain (drain of right input transistor and diode-connected PMOS node)
# Transistor sizing (45 nm node -> L = 0.045e-6)
Lmin = 0.045e-6
# Input differential pair (NMOS)
# M1: drain=Vout, gate=Vinp, source=Vs, bulk tied to source (Vs)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=Lmin)
# M2: drain=Voutb, gate=Vinn, source=Vs, bulk tied to source (Vs)
circuit.MOSFET('M2', 'Voutb', 'Vinn', 'Vs', 'Vs', model='nmos_model', w=20e-6, l=Lmin)
# PMOS current mirror load
# M3: diode-connected PMOS at the right branch to set reference (drain=gate=Voutb)
circuit.MOSFET('M3', 'Voutb', 'Voutb', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=Lmin)
# M4: mirror PMOS providing load at Vout (gate tied to Voutb)
circuit.MOSFET('M4', 'Vout', 'Voutb', 'Vdd', 'Vdd', model='pmos_model', w=40e-6, l=Lmin)
# Tail current source (NMOS)
# Mtail: drain=Vs, gate=Vbias, source=GND, bulk=GND
circuit.MOSFET('Mtail', 'Vs', 'Vbias', circuit.gnd, circuit.gnd, model='nmos_model', w=2e-6, l=Lmin)
# End of circuit definition
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))

source = str(circuit)
print(source)
