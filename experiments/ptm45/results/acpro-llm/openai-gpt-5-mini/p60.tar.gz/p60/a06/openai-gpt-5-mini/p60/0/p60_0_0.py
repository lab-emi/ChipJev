from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params  # Import MOSFET parameters from model module
circuit = Circuit('Single-Stage Differential Op-Amp (GBW/Power Optimized)')
# MOS models (provided externally in model.py)
circuit.model('nmos_model', 'nmos', **nmos_params)
circuit.model('pmos_model', 'pmos', **pmos_params)
# Power supply
circuit.V('dd', 'Vdd', circuit.gnd, 1.2)
# Input nodes (DC operating point biases only)
# Common-mode = 0.6 V (mid-rail). Use identical DC for both inputs here (operating point).
circuit.V('inp', 'Vinp', circuit.gnd, 0.6)
circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
# Tail bias for NMOS current source (set modest overdrive; Vth = 0.22 V used when choosing this)
circuit.V('biasn', 'Vbias_n', circuit.gnd, 0.40)
# Device geometry choices (45 nm technology; L = 90 nm used for improved gm/I and output resistance)
L = 0.09e-6     # 90 nm
W_in = 20e-6    # input transistors (M1, M2)
W_pmos = 40e-6  # PMOS mirror devices (M3 diode, M4 mirror)
W_tail = 2e-6   # tail device
# Nodes: S = common source node, D2 = reference/mirror gate node
# NMOS input pair: M1 (left) and M2 (right)
circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S', model='nmos_model', w=W_in, l=L)
circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S', model='nmos_model', w=W_in, l=L)
# NMOS tail current source
circuit.MOSFET('Mtail', 'S', 'Vbias_n', circuit.gnd, circuit.gnd, model='nmos_model', w=W_tail, l=L)
# PMOS current mirror load: M3 diode-connected at D2, M4 mirrored to output
circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=W_pmos, l=L)  # diode-connected
circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd', model='pmos_model', w=W_pmos, l=L)
# Create simulator (do not add any commands after this line)
simulator = circuit.simulator()

try:
    analysis = simulator.operating_point()
    fopen = open("openai-gpt-5-mini/p60/0/p60_0_0_op.txt", "w")
    for node in analysis.nodes.values(): 
        fopen.write(f"{str(node)}\t{float(analysis[str(node)][0]):.6f}\n")
    fopen.close()
except Exception as e:
    print("Analysis failed due to an error:")
    print(str(e))
