from PySpice.Spice.Netlist import Circuit
from PySpice.Unit import *
from model import nmos_params, pmos_params
def create_circuit(params):
    """
    Create the Single-Stage Differential Op-Amp circuit with parameterized transistor widths
    and the NMOS tail bias voltage. This function keeps Vdd and the input DC bias voltages
    (Vinp/Vinn) fixed (they will be swept externally during analysis).
    Required keys in `params`:
      - 'w_M1', 'w_M2'   : widths for the NMOS input pair (meters)
      - 'w_M3', 'w_M4'   : widths for the PMOS current mirror devices (meters)
      - 'w_Mtail'        : width for the NMOS tail current source (meters)
      - 'v_bias_n'       : bias voltage for the NMOS tail gate (Volts)
    Note: The process channel length L is fixed inside this function to the original value
    used in the provided netlist (90 nm = 0.09e-6 m). Only widths (W) are exposed to the optimizer.
    """
    # Re-import model params exactly as requested (module is provided in execution environment)
    from model import nmos_params, pmos_params
    circuit = Circuit('Single-Stage Differential Op-Amp (GBW/Power Optimized) - Corrected Bias')
    # Attach MOS models (provided by model.py)
    circuit.model('nmos_model', 'nmos', **nmos_params)
    circuit.model('pmos_model', 'pmos', **pmos_params)
    # Power supply (fixed, do not parameterize)
    circuit.V('dd', 'Vdd', circuit.gnd, 1.2)  # fixed supply 1.2 V
    # Input nodes (DC operating point biases only) - fixed (will be swept externally)
    circuit.V('inp', 'Vinp', circuit.gnd, 0.6)  # common-mode mid-rail
    circuit.V('inn', 'Vinn', circuit.gnd, 0.6)
    # Fixed channel length (use the original L from the provided netlist: 90 nm)
    L = 0.09e-6  # 90 nm (kept constant; only W is optimized)
    # Parameterized tail bias (must obey 0.8-1.2x original but <= 1.2 V)
    v_bias_n = params['v_bias_n']
    # Parameterized transistor widths (meters)
    w_M1 = params['w_M1']
    w_M2 = params['w_M2']
    w_M3 = params['w_M3']
    w_M4 = params['w_M4']
    w_Mtail = params['w_Mtail']
    # Circuit devices (body nodes tied as in original netlist)
    # Note: using MOSFET instance names identical to the original netlist
    circuit.MOSFET('M1', 'Vout', 'Vinp', 'S', 'S',
                   model='nmos_model', w=w_M1, l=L)
    circuit.MOSFET('M2', 'D2', 'Vinn', 'S', 'S',
                   model='nmos_model', w=w_M2, l=L)
    # NMOS tail current source (bulk tied to source = gnd)
    circuit.MOSFET('Mtail', 'S', 'Vbias_n', circuit.gnd, circuit.gnd,
                   model='nmos_model', w=w_Mtail, l=L)
    # PMOS current mirror load: M3 diode-connected at D2, M4 mirrored to output
    circuit.MOSFET('M3', 'D2', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model', w=w_M3, l=L)  # diode-connected
    circuit.MOSFET('M4', 'Vout', 'D2', 'Vdd', 'Vdd',
                   model='pmos_model', w=w_M4, l=L)
    # Parameterized bias voltage source (tail)
    circuit.V('biasn', 'Vbias_n', circuit.gnd, v_bias_n)
    return circuit
# --------------------------
# Optimization parameter search ranges (annotated)
# --------------------------
# Original L used in netlist (kept constant in the circuit): 0.09e-6 (90 nm)
L_original = 0.09e-6
param_ranges_definition = {
    # Transistor widths: allowed range 1x-500x the channel length (W in meters)
    # Use log sampling where appropriate to span orders of magnitude efficiently.
    'w_M1': {'min': 1.0 * L_original, 'max': 500.0 * L_original, 'log': True},
    'w_M2': {'min': 1.0 * L_original, 'max': 500.0 * L_original, 'log': True},
    'w_M3': {'min': 1.0 * L_original, 'max': 500.0 * L_original, 'log': True},
    'w_M4': {'min': 1.0 * L_original, 'max': 500.0 * L_original, 'log': True},
    'w_Mtail': {'min': 1.0 * L_original, 'max': 500.0 * L_original, 'log': True},
    # Tail bias voltage: 0.8-1.2× original, but never exceeding 1.2 V (linear sampling)
    # Original v_bias_n = 0.90 V -> allowed range [0.72, 1.08] V
    'v_bias_n': {'min': 0.8 * 0.90, 'max': min(1.2 * 0.90, 1.2), 'log': False},
}
# --------------------------
# Initial parameter values (EXACT original circuit values)
# These values MUST match the original netlist exactly (no modifications).
# --------------------------
initial_params = {
    # Transistor widths (meters) - EXACT as in original netlist
    'w_M1': 15e-6,     # input transistor M1 original width
    'w_M2': 15e-6,     # input transistor M2 original width (same as M1 in original)
    'w_M3': 30e-6,     # PMOS diode M3 original width
    'w_M4': 30e-6,     # PMOS mirror M4 original width
    'w_Mtail': 5e-6,   # tail NMOS original width
    # Tail bias voltage (Volts) - EXACT original value
    'v_bias_n': 0.90,
    # Include original L value for bookkeeping (NOT part of optimization ranges).
    # The optimizer will not modify L; it is kept constant inside create_circuit.
    'L': 0.09e-6,      # original channel length (90 nm) - retained for reference
}
# --------------------------
# Physical meaning of each parameter
# --------------------------
# w_M1, w_M2  : Widths of the NMOS input differential pair (meters). Larger width increases current
#               capability, transconductance (gm) and parasitics; affects gm/I and noise.
# w_M3, w_M4  : Widths of the PMOS current mirror load devices (meters). Set mirror current and
#               output resistance; affects gain and output swing.
# w_Mtail     : Width of the NMOS tail current source device (meters). Controls tail current,
#               common-mode behavior and headroom of the pair.
# v_bias_n    : Gate bias voltage for the NMOS tail device (Volts). Adjusts tail current; constrained
#               conservatively to keep device bias in intended region (range derived from original).
# L (reference): Channel length used in the original circuit (meters). Kept fixed in the simulator;
#                only provided here in initial_params for exact reproducibility.
# --------------------------
# Notes / Constraints enforced
# --------------------------
# - Vdd is fixed at 1.2 V and is NOT included in the parameter search.
# - Vinp and Vinn (input DC biases) are fixed at 0.6 V and are NOT included in the parameter search.
# - All transistor widths ranges obey 1×L to 500×L (meters).
# - The tail bias range is 0.8–1.2× the original (0.90 V) but clipped to <= 1.2 V supply.
# - initial_params contains exactly the original values from the provided netlist.
# - There are no resistors or capacitors in the provided netlist to parameterize. If you add them,
#   follow the constraints in your problem statement for their ranges.
