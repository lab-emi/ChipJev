tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load m1_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 33.36 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m1_f0
load m2_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f0
load m2_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f1
load m2_f2
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f2
load m2_f3
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f3
load m2_f4
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f4
load m2_f5
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f5
load m2_f6
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f6
load m2_f7
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f7
load m2_f8
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f8
load m2_f9
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f9
load m2_f10
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f10
load m2_f11
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f11
load m3_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f0
load m3_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f1
load m3_f2
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f2
load m3_f3
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f3
load m3_f4
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f4
load m3_f5
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f5
load m3_f6
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f6
load m3_f7
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f7
load m3_f8
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f8
load m3_f9
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f9
load m3_f10
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f10
load m3_f11
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 50 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f11
load m4_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 25.68 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m4_f0
load m4_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 25.68 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m4_f1
load m5_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 25.68 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m5_f0
load m5_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 25.68 l 1.2 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m5_f1
} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
