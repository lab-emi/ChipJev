tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load m1_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 6.06 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m1_f0
load m2_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 2.21 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m2_f0
load m3_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 2.21 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m3_f0
load m4_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 25.74 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m4_f0
load m5_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 25.74 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m5_f0
load m6_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 36.42 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m6_f0
load m6_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 36.42 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m6_f1
load m6_f2
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 36.42 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m6_f2
load m7_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 36.42 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m7_f0
load m7_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 36.42 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m7_f1
load m7_f2
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 36.42 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m7_f2
load m8_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 22.28 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m8_f0
load m9_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 22.28 l 0.25 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m9_f0
load m10_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 3.71 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m10_f0
load m11_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 4.28 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m11_f0
load m12_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 4.28 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m12_f0
load m13_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 4.28 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m13_f0
} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
