tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load layout
select top cell
drc euclidean on
drc style drc(full)
drc on
drc check
drc catchup
set fd [open drc.txt w]
puts $fd [drc listall why]
close $fd
puts "@@DRC [drc list count total]"
extract unique
extract all
ext2spice lvs
ext2spice scale off
ext2spice -o lvs.spice
ext2spice cthresh 0
ext2spice -o capacitance.spice
gds write layout.gds
save layout

} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
