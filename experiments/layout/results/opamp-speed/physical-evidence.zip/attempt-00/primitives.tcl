tech load {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tech}
source {/home/cgao/git/ChipJev/.tools/pdk/sky130_pdk/libs.tech/magic/sky130A.tcl}
scalegrid 1 2
units internal
snap internal
drc off
crashbackups stop
if {[catch {
load m1_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 6.42 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m1_f0
load m2_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 28.05 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m2_f0
load m2_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 28.05 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m2_f1
load m3_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 28.05 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m3_f0
load m3_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 28.05 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m3_f1
load m4_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 4.17 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m4_f0
load m5_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 4.17 l 0.15 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m5_f0
load m6_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 0.42 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m6_f0
load m7_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 44.58 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m7_f0
load m7_f1
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__nfet_01v8_defaults] {w 44.58 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__nfet_01v8_draw $p
save m7_f1
load m8_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 1.17 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m8_f0
load m9_f0
box values 0 0 0 0
set p [dict merge [sky130::sky130_fd_pr__pfet_01v8_defaults] {w 32.46 l 0.18 nf 1 guard 1 topc 1 botc 0 viagb 100}]
sky130::sky130_fd_pr__pfet_01v8_draw $p
save m9_f0
} problem]} {puts stderr $::errorInfo; exit 1}
puts "@@CHIPJEV_DONE"
quit -noprompt
